#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Send an URL to the crawler - Create a crawler task
================

Queues a URL for the Crawler (one-shot, or recurring with a frequency).
Runs on the server itself and writes the task straight into the database,
so the AIL environment must be active and Kvrocks/Redis must be running:

    source AILENV/bin/activate
    python3 tools/crawler_add_task.py -u http://example.onion -p tor

"""

import argparse
import os
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import ail_users
from lib import crawlers
from lib.ConfigLoader import ConfigLoader

def check_frequency(value):
    if int(value) <= 0:
        print(f'Error: Invalid frequency {value}', file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Send an URL to the crawler - Create a crawler task')
    parser.add_argument('-u', '--url', type=str, help='URL to crawl', required=True)
    parser.add_argument('--user', type=str, default='admin@admin.test', help='User the task is created for (default: admin@admin.test)')
    parser.add_argument('-d', '--depth', type=int, default=1, help='Depth limit')
    parser.add_argument('--cookiejar', type=str, help='Cookiejar uuid')
    parser.add_argument('-p', '--proxy', type=str, help='Proxy address to use, "web" and "tor" can be used as shortcut (web is used by default if the domain isn\'t an onion)')

    group = parser.add_mutually_exclusive_group()
    group.add_argument('--har', dest='har', action='store_true', help='Save HAR')
    group.add_argument('--no-har', dest='har', action='store_false', help='Don\'t save HAR')
    parser.set_defaults(har=None)

    group = parser.add_mutually_exclusive_group()
    group.add_argument('--screenshot', dest='screenshot', action='store_true', help='Save screenshot')
    group.add_argument('--no-screenshot', dest='screenshot', action='store_false', help='Don\'t save screenshot')
    parser.set_defaults(screenshot=None)

    group = parser.add_argument_group('Frequency, create a regular crawler/scheduler. one shot if not specified')
    group.add_argument('-f', '--frequency', type=str, choices=['monthly', 'weekly', 'daily', 'hourly'],
                       help='monthly, weekly, daily or hourly frequency or specify a custom one with the others arguments')
    group.add_argument('--minutes', type=int, help='frequency in minutes')
    group.add_argument('--hours', type=int, help='frequency in hours')
    group.add_argument('--days', type=int, help='frequency in days')
    group.add_argument('--weeks', type=int, help='frequency in weeks')
    group.add_argument('--months', type=int, help='frequency in months')

    args = parser.parse_args()

    if not ail_users.exists_user(args.user):
        print(f'Error: unknown user {args.user}', file=sys.stderr)
        sys.exit(1)

    # Load crawler default config
    config_loader = ConfigLoader()
    har = args.har
    if har is None:
        har = config_loader.get_config_boolean('Crawler', 'default_har')
    screenshot = args.screenshot
    if screenshot is None:
        screenshot = config_loader.get_config_boolean('Crawler', 'default_screenshot')

    if args.depth < 0:
        print(f'Error: Invalid depth {args.depth}', file=sys.stderr)
        sys.exit(1)

    # frequency
    frequency = {}
    if args.frequency:
        frequency = args.frequency
    else:
        for unit in ('minutes', 'hours', 'days', 'weeks', 'months'):
            value = getattr(args, unit)
            if value is not None:
                check_frequency(value)
                frequency[unit] = value

    data = {'url': args.url, 'depth': args.depth, 'har': har, 'screenshot': screenshot}
    if args.proxy:
        data['proxy'] = args.proxy
    if args.cookiejar:
        data['cookiejar'] = args.cookiejar
    if frequency:
        data['frequency'] = frequency

    res, status = crawlers.api_add_crawler_task(data, ail_users.get_user_org(args.user), user_id=args.user)
    print(res)
    if status != 200:
        sys.exit(1)
