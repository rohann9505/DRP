#!/bin/bash
# Uninstall an Anorphix install created by install.sh / installing_deps.sh.
#
# Run it FROM INSIDE the install folder (the one holding anorphix.sh):
#     ./uninstall.sh            # remove this install + what the installer added
#     ./uninstall.sh --purge    # ALSO remove Tor, the apt packages the
#                               # installer pulled, Redis/Kvrocks, and the
#                               # download caches - a full scorched-earth wipe
#                               # so the next install.sh is a true from-zero run
#                               # (use on a DEDICATED test box; see warning).
#
# Default mode leaves apt packages and Tor in place. --purge removes them and
# runs `apt-get autoremove --purge`, which on a shared machine can remove
# packages other software relies on - only use --purge where that is acceptable.

set -u
PURGE=no
[ "${1:-}" = "--purge" ] && PURGE=yes

AIL_HOME="$(cd "$(dirname "$0")" && pwd)"

# --- safety guards: never operate on a system/root path, and only on a real
#     Anorphix install folder (must contain anorphix.sh) ---
case "$AIL_HOME" in
    ""|"/"|"/home"|"/root"|"/opt"|"/usr"|"/etc"|"/var"|"/bin"|"/boot")
        echo "Refusing to uninstall from an unsafe path: $AIL_HOME" >&2; exit 1;;
esac
if [ ! -f "$AIL_HOME/anorphix.sh" ] || [ ! -f "$AIL_HOME/supervisord.conf" ]; then
    echo "This does not look like an Anorphix install folder: $AIL_HOME" >&2
    echo "(run uninstall.sh from inside the folder that holds anorphix.sh)" >&2
    exit 1
fi

CRON_LINE="supervisord -c $AIL_HOME/supervisord.conf"
NEEDRESTART_DROPIN=/etc/needrestart/conf.d/90-anorphix-noninteractive.conf
REDIS_IS_OURS=no
if [ -L /opt/redis ] && [ "$(readlink -f /opt/redis 2>/dev/null)" = "$(readlink -f "$AIL_HOME/redis" 2>/dev/null)" ]; then
    REDIS_IS_OURS=yes
fi

# Packages the installers add (install.sh / installing_deps.sh system list +
# the storage engines). --purge removes exactly these, then autoremoves orphans.
APT_PKGS="python3-pip python3-dev virtualenv g++ make cmake automake autoconf \
libtool pkg-config unzip wget curl git build-essential libssl-dev libffi-dev \
libsnappy-dev libfreetype6-dev libfuzzy-dev libzbar0 libadns1-dev graphviz \
protobuf-compiler libprotobuf-dev tor tor-geoipdb redis-server redis-tools \
valkey-server"

echo "This will REMOVE:"
echo "  - the running stack (supervisord will be shut down)"
echo "  - this install folder and EVERYTHING in it (code + all data, logs,"
echo "    sessions, reports, the AILENV virtualenv):"
echo "        $AIL_HOME"
[ -d /opt/lacus ]            && echo "  - /opt/lacus  (the Lacus capture engine installed for this stack)"
[ "$REDIS_IS_OURS" = yes ]   && echo "  - /opt/redis  (symlink that points into this install)"
[ -f "$NEEDRESTART_DROPIN" ] && echo "  - $NEEDRESTART_DROPIN"
echo "  - the '@reboot' autostart crontab line for this install (if present)"
if [ "$PURGE" = yes ]; then
    echo
    echo "  --purge ALSO removes (scorched earth):"
    echo "  - Tor + its data/config (/etc/tor, /var/lib/tor, /var/log/tor)"
    echo "  - these apt packages, then 'apt-get autoremove --purge':"
    echo "        $APT_PKGS" | fold -s -w 72 | sed 's/^/        /'
    echo "  - download caches: ~/.cache/ms-playwright, ~/.cache/pip, apt .deb cache"
    echo
    echo "  !! 'apt-get autoremove --purge' can remove packages OTHER software on"
    echo "     this machine depends on. Only continue on a dedicated test box."
fi
echo
echo "This cannot be undone."
if [ "$PURGE" = yes ]; then
    printf "Type 'PURGE' to wipe everything: "
    read -r ans
    [ "$ans" = "PURGE" ] || { echo "Aborted - nothing was removed."; exit 1; }
else
    printf "Type 'yes' to proceed: "
    read -r ans
    [ "$ans" = "yes" ] || { echo "Aborted - nothing was removed."; exit 1; }
fi

echo
echo "[1] stopping the stack ..."
if [ -x "$AIL_HOME/AILENV/bin/supervisorctl" ]; then
    "$AIL_HOME/AILENV/bin/supervisorctl" -c "$AIL_HOME/supervisord.conf" shutdown 2>/dev/null || true
    sleep 2
fi
pkill -f "$CRON_LINE" 2>/dev/null || true

if [ "$PURGE" = yes ]; then
    echo "[2] stopping + disabling Tor ..."
    sudo systemctl disable --now tor 2>/dev/null || true
    pkill -x tor 2>/dev/null || true
    echo "[3] purging apt packages the installer added ..."
    sudo env DEBIAN_FRONTEND=noninteractive apt-get purge -y $APT_PKGS || true
    # kvrocks came from a local .deb - its name is not in any apt repo, so naming
    # it unconditionally would abort the WHOLE purge (removing nothing). Purge it
    # only if it is actually installed.
    if dpkg -l kvrocks 2>/dev/null | grep -q '^ii'; then
        sudo env DEBIAN_FRONTEND=noninteractive apt-get purge -y kvrocks || true
    fi
    sudo env DEBIAN_FRONTEND=noninteractive apt-get autoremove --purge -y || true
    sudo rm -rf /etc/tor /var/lib/tor /var/log/tor
    echo "[4] clearing download caches (so the next install truly re-downloads) ..."
    sudo apt-get clean 2>/dev/null || true
    rm -rf "$HOME/.cache/ms-playwright" "$HOME/.cache/pip" 2>/dev/null || true
fi

echo "[5] removing /opt/lacus ..."
[ -d /opt/lacus ] && sudo rm -rf /opt/lacus && echo "    removed /opt/lacus"

echo "[6] removing /opt/redis symlink (only if it points here) ..."
[ "$REDIS_IS_OURS" = yes ] && sudo rm -f /opt/redis && echo "    removed /opt/redis"

echo "[7] removing the needrestart drop-in + autostart crontab line ..."
[ -f "$NEEDRESTART_DROPIN" ] && sudo rm -f "$NEEDRESTART_DROPIN" && echo "    removed needrestart drop-in"
if crontab -l 2>/dev/null | grep -qF "$CRON_LINE"; then
    crontab -l 2>/dev/null | grep -vF "$CRON_LINE" | crontab - && echo "    removed @reboot line"
fi

echo "[8] removing the Meilisearch instance-uid for this install ..."
# Meilisearch writes a per-data-path marker under ~/.config/Meilisearch (OUTSIDE
# the install folder): the DATA_MEILISEARCH path with '/'->'-' + '-instance-uid'.
# Remove this install's one so no trace is left behind in the user's home.
MEILI_UID="$HOME/.config/Meilisearch/$(printf '%s' "${AIL_HOME#/}/DATA_MEILISEARCH" | tr '/' '-')-instance-uid"
[ -f "$MEILI_UID" ] && rm -f "$MEILI_UID" && echo "    removed $MEILI_UID"
rmdir "$HOME/.config/Meilisearch" 2>/dev/null || true

echo "[9] removing the install folder: $AIL_HOME ..."
cd /
rm -rf "$AIL_HOME" && echo "    removed $AIL_HOME"

echo
if [ "$PURGE" = yes ]; then
    echo "Done - full wipe. Tor, the installer's apt packages, and caches are gone."
    echo "A few generic shared libraries pulled in by the browser step may remain"
    echo "if other packages still depend on them; they add only seconds to a"
    echo "re-install. For a perfectly repeatable baseline, time install.sh in a"
    echo "fresh Ubuntu container."
else
    echo "Anorphix uninstalled. apt packages and Tor were left in place."
    echo "This script was in the folder just removed, so to also remove those"
    echo "(the --purge step), paste this:"
    echo
    echo "  sudo systemctl disable --now tor 2>/dev/null"
    echo "  sudo env DEBIAN_FRONTEND=noninteractive apt-get purge -y $APT_PKGS"
    echo "  sudo env DEBIAN_FRONTEND=noninteractive apt-get autoremove --purge -y"
    echo "  sudo rm -rf /etc/tor /var/lib/tor /var/log/tor; sudo apt-get clean"
    echo "  rm -rf ~/.cache/ms-playwright ~/.cache/pip"
    echo
    echo "(Tip: next time run  ./uninstall.sh --purge  to do it all at once.)"
fi
