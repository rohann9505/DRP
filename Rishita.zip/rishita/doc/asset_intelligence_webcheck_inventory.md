# Web-Check Capability Inventory vs. Anorphix Asset Intelligence

Reference: [Lissy93/web-check](https://github.com/Lissy93/web-check) (source inspected directly,
`api/*.js`, 38 check modules). Used as a **feature and data-model reference only** — no code copied,
no dependency, no iframe.

Status legend:

| Tag | Meaning |
|---|---|
| **[AVAILABLE NOW]** | Implemented and running in Anorphix today |
| **[IMPLEMENT NEXT]** | Keyless/local, reproducible with what we already have; not yet built |
| **[FUTURE TOOL]** | Needs an external binary installed (Nuclei, Nmap, Chromium, …) |
| **[OPTIONAL API]** | Needs a third-party account/key; only worth adding if the user wants it |

---

## 1. Full inventory

### Already covered in Anorphix

| Web-Check module | Data returned | How collected | Key? | Anorphix provider | Status |
|---|---|---|---|---|---|
| `dns` | A/AAAA/MX/NS/TXT/CNAME/SOA | Node `dns/promises` | No | `dnspython` (`dns_provider`) | **[AVAILABLE NOW]** |
| `whois` / `domain info` | registrar, created/updated/expires, nameservers, status | RDAP + `whoiser` | No | `python-whois` (`whois_provider`) | **[AVAILABLE NOW]** |
| `subdomains` | subdomain list | crt.sh / CertSpotter / HackerTarget | No | crt.sh + CertSpotter + HackerTarget (unioned) | **[AVAILABLE NOW]** |
| `status` | isUp, response time, response code | HTTPS GET | No | `liveness_probe` (+ TCP fallback) | **[AVAILABLE NOW]** |
| `ssl` / `tls-connection` | issuer, subject, validity, SANs, cipher, protocol, ALPN | Node `tls` socket | No | `tls_provider` (stdlib `ssl`) | **[AVAILABLE NOW]** |
| `http-security` | 10 security-header booleans | HTTP GET headers | No | `security_config_probe` (8 headers + version disclosure) | **[AVAILABLE NOW]** |
| `headers` | full response headers | HTTP GET | No | stored per-asset via `security_headers` | **[AVAILABLE NOW]** |
| `tech-stack` | detected technologies | Wappalyzer patterns (Chromium) | No | `technologies_probe` (header/cookie/HTML regex) | **[AVAILABLE NOW]** *(narrower)* |
| `firewall` | WAF/CDN product | header + cookie signatures | No | `firewall_provider` (30 signatures) | **[AVAILABLE NOW]** |
| `dnssec` | DNSKEY / DS / RRSIG | Google DoH | No | `dnssec_provider` (direct DNS + AD flag) | **[AVAILABLE NOW]** |
| `mail-config` | SPF, DKIM, DMARC, BIMI, MX provider | DNS TXT/MX | No | `mail_config_provider` | **[AVAILABLE NOW]** |
| `ports` | open TCP ports | raw socket connect | No | `ports_tcp` (32 ports, IP-deduped) | **[AVAILABLE NOW]** |
| `robots-txt` | crawl directives | HTTP GET | No | `crawl_rules_provider` | **[AVAILABLE NOW]** |
| `sitemap` | public URL list | XML parse | No | `crawl_rules_provider` (index-following) | **[AVAILABLE NOW]** |
| `security-txt` | contact, policy, PGP-signed | `/.well-known/security.txt` | No | `security_txt_provider` | **[AVAILABLE NOW]** |
| `social-tags` | title, description, OG/Twitter tags | HTML meta parse | No | `social_tags_provider` | **[AVAILABLE NOW]** |
| `redirects` | redirect chain | HTTP no-follow walk | No | `redirect_chain_provider` (+ HTTPS-upgrade finding) | **[AVAILABLE NOW]** |
| `archives` | first/last snapshot, scan count | Wayback CDX API | No | `wayback_archives` | **[AVAILABLE NOW]** |

Anorphix additionally has, with **no Web-Check equivalent**: baseline-calibrated directory
enumeration, live→disconnected→**back-online** transition tracking with alerting, scheduled
recurring scans, per-target circuit breakers, and persistent history — Web-Check is a
point-in-time single-page lookup, not an ASM system.

### Missing — keyless, worth adding next

| Capability | Data | How | Recommended OSS | Status |
|---|---|---|---|---|
| Server location / ASN | country, city, lat/long, ASN, ISP | IP geolocation | **MaxMind GeoLite2** (local `.mmdb`, free, no per-request key) via `geoip2` | **[IMPLEMENT NEXT]** |
| HSTS preload status | preload eligibility | parse HSTS header + preload list | local rules + `hstspreload.org` list | **[IMPLEMENT NEXT]** |
| Cookie inspection | Secure/HttpOnly/SameSite flags | already-fetched response | stdlib (we already hold the response) | **[IMPLEMENT NEXT]** |
| Linked pages | internal/external link graph | HTML anchor parse | `beautifulsoup4` (already a dep) | **[IMPLEMENT NEXT]** |
| Block/threat lists | resolves on filtering DNS; URLhaus/PhishTank | DNS to 12 resolvers + keyless APIs | `dnspython` + URLhaus API (keyless) | **[IMPLEMENT NEXT]** |
| DNS server info | authoritative NS, DoH support | DNS + HTTPS probe | `dnspython` | **[IMPLEMENT NEXT]** |
| TLS cipher enumeration | full supported cipher/protocol matrix | multi-handshake probing | **sslyze** (pip, no binary) or `testssl.sh` | **[IMPLEMENT NEXT]** |

### Missing — needs a tool installed

| Capability | Recommended OSS | Status |
|---|---|---|
| Vulnerability/CVE detection | **Nuclei** + nuclei-templates | **[FUTURE TOOL]** *(stub registered)* |
| Fast port scan / service versions | **Naabu**, **Nmap** | **[FUTURE TOOL]** *(stubs registered)* |
| Deep subdomain enumeration | **Subfinder**, **Amass** | **[FUTURE TOOL]** *(stubs registered)* |
| Web app scanning | **w3af**, **ZAP baseline**, **Nikto** | **[FUTURE TOOL]** *(stub registered)* |
| Rich HTTP probing / tech ID | **ProjectDiscovery HTTPx** | **[FUTURE TOOL]** *(stub registered; name-collision guarded)* |
| Screenshots | Playwright/Chromium — **note: AIL already runs Lacus** and could supply captures | **[FUTURE TOOL]** |
| Traceroute | `scapy` / `mtr` (needs raw sockets or CAP_NET_RAW) | **[FUTURE TOOL]** |
| Full Wappalyzer fingerprints | `python-Wappalyzer` or the open fingerprint DB | **[FUTURE TOOL]** |

### Deliberately not reproduced

| Web-Check module | Why |
|---|---|
| `quality` (Lighthouse) | Needs `GOOGLE_CLOUD_API_KEY`; SEO/perf scoring is not attack-surface data — **[OPTIONAL API]** |
| `rank` (Tranco) | Needs `TRANCO_USERNAME`/`TRANCO_API_KEY` — **[OPTIONAL API]** |
| `tls-labs` (Qualys) | Third-party queue, heavily rate-limited; `sslyze` gives the same audit locally — **[OPTIONAL API]** |
| `shodan` | Needs a Shodan key — **[OPTIONAL API]** |
| `threats` (Cloudmersive / Safe Browsing) | Keyed; the URLhaus half is keyless and is listed above — **[OPTIONAL API]** |
| `social-presence` | Brand-presence checking, not attack surface |
| `carbon` | Environmental estimate; no security value |

---

## 2. Architecture note

Every capability above is (or would be) a single `AssetProvider` subclass registered in
`backend/lib/asset_providers/__init__.py` under a category. That registry is the only file that
knows which tools exist; `asset_jobs.run_job()` never imports a provider directly. Consequently:

- Adding a tool = write one class + add one list entry.
- Replacing a tool (e.g. `ports_tcp` → Naabu) = registration order change; both can co-exist.
- Disabling one = remove it from the list; nothing else changes.
- An uninstalled tool reports itself as "not yet configured" in the UI instead of silently
  producing an empty section — `is_available()` also verifies binary *identity*, not just
  presence on PATH.
