#!/bin/bash
# FAST install for Anorphix (Ubuntu). Run from the package root as a normal,
# sudo-capable user (NOT with sudo in front):
#
#   bash install.sh 2>&1 | tee logs/install.log
#
# Difference from installing_deps.sh: Redis comes from apt and Kvrocks from a
# prebuilt .deb instead of being compiled from source, which removes the
# 15-40 minute Kvrocks build. Both are symlinked into the paths the stack
# expects (redis/src/, kvrocks/build/) so nothing else changes.
# Safe to re-run: finished steps are skipped.

set -e
AIL_HOME="$(cd "$(dirname "$0")" && pwd)"
cd "$AIL_HOME"
mkdir -p logs

# ---- Make apt non-interactive for the whole install (prevents hangs) ----
# On modern Ubuntu, apt sub-steps - notably `playwright install --with-deps`,
# which pulls the browser's X/font/codec packages - trigger needrestart's
# "restart services?" dialog (and occasionally a debconf prompt) that silently
# STALLS the install for ever (Ctrl-C won't dismiss it). Neutralise both for
# every apt run during this install, including those made by sub-processes.
# The needrestart drop-in is read from disk, so it also covers the apt that
# `playwright` / Lacus run under their own sudo.
export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a NEEDRESTART_SUSPEND=1
if [ -d /etc/needrestart ]; then
    printf '%s\n' "\$nrconf{restart} = 'a';" \
        | sudo tee /etc/needrestart/conf.d/90-anorphix-noninteractive.conf >/dev/null 2>&1 || true
fi
APT_GET="sudo env DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a NEEDRESTART_SUSPEND=1 apt-get"

# ---- System packages ----
$APT_GET update
$APT_GET install -qq -y python3-pip python3-dev virtualenv g++ make cmake \
    automake autoconf libtool pkg-config unzip wget curl git build-essential \
    libssl-dev libffi-dev libsnappy-dev libfreetype6-dev libfuzzy-dev \
    libzbar0 libadns1-dev graphviz protobuf-compiler libprotobuf-dev tor

# ---- Submodules (MISP taxonomies/galaxies, YARA rules) ----
clone_pinned() {  # dir url commit
    if [ -z "$(ls -A "$1" 2>/dev/null)" ]; then
        rm -rf "$1"
        git clone -q "$2" "$1"
        git -C "$1" checkout -q "$3"
    fi
}
# Only the YARA rules are cloned here. MISP taxonomies/galaxies are NOT cloned:
# the PyTaxonomies / PyMISPGalaxies pip packages bundle that exact data, so we
# link files/misp-* to the pip copy after the virtualenv is built (see below),
# skipping a redundant ~57MB clone.
if [ -d .git ]; then
    git submodule update --init backend/trackers/yara/ail-yara-rules
else
    clone_pinned backend/trackers/yara/ail-yara-rules https://github.com/ail-project/ail-yara-rules.git 3ccbec3145d3dec0ebf46fb996eb79d0932388d9
fi

# ---- Redis from apt (cache + queues, ports 6379-6381) ----
# Newer Ubuntu may ship valkey (a drop-in Redis fork) instead of redis; accept
# either. We run our OWN three instances via supervisord, so the distro's
# auto-started service is disabled to keep port 6379 free.
if [ ! -e redis/src/redis-server ]; then
    $APT_GET install -qq -y redis-server || $APT_GET install -qq -y valkey-server
    for svc in redis-server valkey-server redis valkey; do
        sudo systemctl disable --now "$svc" 2>/dev/null || true
        sudo service "$svc" stop 2>/dev/null || true
    done
    REDIS_SERVER="$(command -v redis-server || command -v valkey-server)"
    REDIS_CLI="$(command -v redis-cli || command -v valkey-cli)"
    if [ -z "$REDIS_SERVER" ] || [ -z "$REDIS_CLI" ]; then
        echo "ERROR: could not find a redis/valkey server+cli from apt" >&2; exit 1
    fi
    mkdir -p redis/src
    ln -sf "$REDIS_SERVER" redis/src/redis-server
    ln -sf "$REDIS_CLI"    redis/src/redis-cli
fi

# ---- Kvrocks from prebuilt .deb (main database, port 6383) ----
# Skips the long source build. apt resolves the .deb's own dependencies.
KVROCKS_DEB_VERSION="2.17.0-1"
if [ ! -e kvrocks/build/kvrocks ]; then
    TMP=$(mktemp -d)
    wget -q "https://github.com/RocksLabs/kvrocks-fpm/releases/download/${KVROCKS_DEB_VERSION}/kvrocks_${KVROCKS_DEB_VERSION}_amd64.deb" \
        -O "$TMP/kvrocks.deb"
    $APT_GET install -qq -y "$TMP/kvrocks.deb"
    rm -rf "$TMP"
    for svc in kvrocks; do
        sudo systemctl disable --now "$svc" 2>/dev/null || true
        sudo service "$svc" stop 2>/dev/null || true
    done
    KVBIN="$(command -v kvrocks || dpkg -L kvrocks 2>/dev/null | grep -E '/kvrocks$' | head -1)"
    if [ -z "$KVBIN" ]; then
        echo "ERROR: kvrocks binary not found after installing the .deb" >&2; exit 1
    fi
    mkdir -p kvrocks/build
    ln -sf "$KVBIN" kvrocks/build/kvrocks
fi
mkdir -p DATA_KVROCKS

# ---- Meilisearch (full-text index, port 7700) ----
MEILISEARCH_VERSION="1.53.1"
if [ ! -x meilisearch ]; then
    wget -q "https://github.com/meilisearch/meilisearch/releases/download/v${MEILISEARCH_VERSION}/meilisearch-linux-amd64" -O meilisearch
    chmod +x meilisearch
fi

# ---- tlsh (fuzzy hashing) - small, built from source ----
if [ ! -d tlsh/build/release ]; then
    test -d tlsh || git clone --depth 1 https://github.com/trendmicro/tlsh.git
    (cd tlsh && ./make.sh)
fi
(cd tlsh/build/release && sudo make install && sudo ldconfig)

# ---- YARA 4.3.0 (pinned to match yara-python) - built from source ----
YARA_VERSION="4.3.0"
if ! command -v yara >/dev/null || [ "$(yara --version)" != "$YARA_VERSION" ]; then
    TMP=$(mktemp -d)
    wget -q "https://github.com/VirusTotal/yara/archive/v${YARA_VERSION}.zip" -O "$TMP/yara.zip"
    unzip -qq "$TMP/yara.zip" -d "$TMP"
    (cd "$TMP/yara-${YARA_VERSION}" && ./bootstrap.sh && ./configure && make -j "$(nproc)" && sudo make install && sudo ldconfig)
    rm -rf "$TMP"
fi

# ---- Config ----
test -f configs/core.cfg || cp configs/core.cfg.sample configs/core.cfg

# ---- Python virtualenv, packages, web assets ----
./install_virtualenv.sh
. AILENV/bin/activate

# ---- MISP taxonomy/galaxy data: reuse the pip packages (skip redundant clone) ----
# PyTaxonomies / PyMISPGalaxies bundle the full data sets; Tag.py reads them from
# files/misp-*. Link to the pip copy rather than cloning the upstream repos again.
# No-op if real data is already present (e.g. a full git checkout's submodules).
link_misp() {  # files_dir  python_module  data_subdir
    { [ -d "$1/galaxies" ] || [ -f "$1/MANIFEST.json" ]; } && return 0
    local src
    src=$(python3 -c "import $2,os;print(os.path.join(os.path.dirname($2.__file__),'data','$3'))" 2>/dev/null)
    [ -n "$src" ] && [ -d "$src" ] && { rm -rf "$1"; ln -sfn "$src" "$1"; }
}
link_misp files/misp-taxonomies pytaxonomies misp-taxonomies
link_misp files/misp-galaxy pymispgalaxies misp-galaxy

# ---- Runtime data directories ----
mkdir -p PASTES HASHS FILES IMAGES FAVICONS Blooms temp/pdf \
    CRAWLED_SCREENSHOT/screenshot CRAWLED_SCREENSHOT/cookiejar_local_storage \
    INTEL_REPORTS ASSET_REPORTS FORUM_PROFILES supervisor_logs supervisor_run

# ---- TLS certificate for the web UI (self-signed) ----
if [ ! -f backend/web/server.crt ]; then
    (cd tools/gen_cert && bash gen_root.sh && bash gen_cert.sh)
    cp tools/gen_cert/server.crt tools/gen_cert/server.key backend/web/
fi

# ---- Lacus (page-capture engine used by the crawler) + Tor ----
# Lacus is a separate open-source project installed into THIS virtualenv. These
# steps are made non-fatal (set +e): the core platform is already built, so a
# network/browser hiccup here only warns - finish it by hand via INSTALL.txt.
set +e
LACUS_DIR=/opt/lacus
echo "Installing Lacus (page-capture engine) at $LACUS_DIR ..."
if [ ! -d "$LACUS_DIR/.git" ]; then
    sudo git clone -q https://github.com/ail-project/lacus.git "$LACUS_DIR" && sudo chown -R "$USER" "$LACUS_DIR"
fi
echo "LACUS_HOME=$LACUS_DIR" > "$LACUS_DIR/.env"
# Lacus looks for redis one level up from itself - point it at THIS install
[ -e /opt/redis ] || sudo ln -s "$AIL_HOME/redis" /opt/redis
pip install -q -e "$LACUS_DIR"
# only the browsers the tool uses (chromium + firefox) - skips webkit
playwright install --with-deps chromium firefox
# config: copy the sample, then bind the capture engine to localhost only
# (the sample ships website_listen_ip 0.0.0.0); port 7100 + Tor proxy are already correct
if [ ! -f "$LACUS_DIR/config/generic.json" ]; then
    cp "$LACUS_DIR/config/generic.json.sample" "$LACUS_DIR/config/generic.json"
    python3 - "$LACUS_DIR/config/generic.json" <<'PYJSON'
import json, sys
p = sys.argv[1]; c = json.load(open(p))
c['website_listen_ip'] = '127.0.0.1'
json.dump(c, open(p, 'w'), indent=2)
PYJSON
fi

echo "Enabling Tor (for .onion sources) ..."
if command -v systemctl >/dev/null 2>&1 && systemctl list-units --type=service >/dev/null 2>&1; then
    sudo systemctl enable --now tor 2>/dev/null
else
    # no systemd (e.g. some WSL setups) - start the tor daemon directly
    pgrep -x tor >/dev/null 2>&1 || sudo -u debian-tor tor >/dev/null 2>&1 &
fi
set -e

# ---- Database init: start storage briefly, create the admin account ----
wait_for_pong() {  # port [password]
    for _ in $(seq 1 60); do
        if redis/src/redis-cli -p "$1" ${2:+-a "$2"} --no-auth-warning PING 2>/dev/null | grep -q PONG; then
            return 0
        fi
        sleep 1
    done
    echo "Storage on port $1 did not start (check logs/install_storage.log)" >&2
    return 1
}

if redis/src/redis-cli -p 6383 -a ail --no-auth-warning PING 2>/dev/null | grep -q PONG; then
    echo "Storage is already running (stack is up) - skipping database init."
    echo "Run './anorphix.sh stop' first if you need to re-run it."
    exit 0
fi

PIDS=()
for port in 6379 6380 6381; do
    redis/src/redis-server "configs/${port}.conf" >> logs/install_storage.log 2>&1 &
    PIDS+=($!)
done
kvrocks/build/kvrocks -c configs/6383.conf >> logs/install_storage.log 2>&1 &
PIDS+=($!)
trap 'kill "${PIDS[@]}" 2>/dev/null || true' EXIT

for port in 6379 6380 6381; do wait_for_pong "$port"; done
wait_for_pong 6383 ail

if python3 -c "import sys; sys.path.append('bin'); from lib import ail_users; sys.exit(0 if ail_users.exists_user('admin@admin.test') else 1)"; then
    echo "Admin account already exists - not touching its password."
else
    (cd backend/web && python3 create_default_user.py)
fi

kill "${PIDS[@]}"
wait "${PIDS[@]}" 2>/dev/null || true
trap - EXIT

# ---- Start the full stack and point the crawler at Lacus ----
echo
echo "Starting the stack ..."
./anorphix.sh start
# wait for kvrocks (6383) to accept connections, then register the Lacus URL
for _ in $(seq 1 60); do
    redis/src/redis-cli -p 6383 -a ail --no-auth-warning PING 2>/dev/null | grep -q PONG && break
    sleep 1
done
python3 -c "import sys; sys.path.append('bin'); from lib import crawlers; crawlers.save_lacus_url_api('http://127.0.0.1:7100', None); print('Lacus URL registered (crawler connects within ~30s)')" || true

echo
echo "============================================================"
echo " Install complete - the full stack is running."
echo "   Web UI : https://<this-server>:7000"
echo "   Login  : admin@admin.test   (password in $AIL_HOME/DEFAULT_PASSWORD)"
echo "   Manage : ./anorphix.sh start | stop | restart | status"
echo "   On boot (optional):"
echo "     (crontab -l 2>/dev/null; echo \"@reboot sleep 20 && $AIL_HOME/AILENV/bin/supervisord -c $AIL_HOME/supervisord.conf\") | crontab -"
echo "============================================================"
