# Anorphix — Dark-Web Intelligence

Anorphix monitors approved dark-web and clearnet forums and ransomware leak
trackers for mentions of a domain, organisation or keyword, and turns what it
finds into scored, evidence-backed findings (thread, extract, screenshot, PDF
report) plus standing watchlist alerts.

This repository has been trimmed to the dark-web module. It is built on the
[AIL Framework](https://github.com/ail-project/ail-framework) (CIRCL), which is
why some internal names still say "AIL" — `AIL_HOME`/`AIL_BIN` environment
variables, the `AILENV` virtualenv, `ail_*.py` core libraries. Those are the
framework's storage/config/object layer that the dark-web code runs on; they
are required, not leftovers. Licensed under **AGPL-3.0** (see `LICENSE`) —
keep the license and upstream copyright notices.

## How it runs

Everything is one supervisord group, `anorphix` (`supervisord.conf`):

| Program | Role |
|---|---|
| `flask` | Web UI + API on `https://<host>:7000` (`backend/web/Flask_server.py`) |
| `domainintelworker` | Runs intelligence jobs: live forum search → corpus fold → findings → report (`backend/intel/DomainIntelWorker.py` → `backend/lib/intel_jobs.py`) |
| `forummonitorworker` | Scheduled re-collection and watchlist checks |
| `alertdispatchworker` | Delivers watchlist alerts (webhook / Telegram / SMTP) |
| `crawler` | Page capture through Lacus (evidence screenshots, forums without native search) |
| `kvrocks`, `meilisearch`, `redis6379-6381` | Storage, full-text index, queues |
| `lacus_*` | Browser capture engine (checkout at `/opt/lacus`) |
| `ail_init` | One-shot boot step (waits for storage, clears queue stats) |

Tor is a system service (`systemctl status tor`); `.onion` sources are always
routed through it. A `@reboot` crontab entry starts supervisord.

```bash
./anorphix.sh start | stop | restart | status | logs <program>
```

## Where the dark-web code lives

- `backend/lib/forum_*.py` — forum registry (allowlist, routing, circuit breaker),
  native search, collection, fetch backend, persistent sessions, storage/dedup,
  metrics, screenshots.
- `backend/lib/forum_providers/` — per-platform adapters (MyBB, XenForo, RSS,
  ransomware.live, …).
- `backend/lib/intel_jobs.py`, `intel_extraction.py`, `intel_pdf.py` — job
  orchestration, deterministic matching + risk scoring (the no-false-positive
  gate), PDF reports.
- `backend/lib/watchlist.py`, `alert_dispatch.py`, `ransomware_live.py`.
- `backend/intel/` — the workers, `forum_session_login.py` (one-time human login
  per forum) and `onion_crawl_diagnostic.py`.
- `backend/web/blueprints/intel_*.py` + `frontend/templates/intel/` — the Dark Web
  pages (Dashboard, Forums, Intelligence, Watchlist, Reports, System).

Also present but switched off: Asset Intelligence (`backend/lib/asset_*`,
`asset_providers/`, `AssetIntelWorker.py`, `blueprints/asset_*.py`,
`tools/bin` scanners) — `autostart=false`.

## Adding a forum

1. Register it on the **Forums** page (disabled until a session exists if the
   site needs a login).
2. Log in once yourself, in a visible browser, on its persistent profile:
   `source AILENV/bin/activate && python3 backend/intel/forum_session_login.py <forum_id>`.
   The crawler reuses that session; it never solves a CAPTCHA or bypasses a
   login on its own, and detects and skips challenge pages.
3. Set the search adapter and queries, enable it, run a test search.

## Building a server

Ubuntu with Python 3.14, from the repo root:

```bash
./installing_deps.sh 2>&1 | tee logs/install.log
```

It installs system packages, builds Redis 5.0, Kvrocks, tlsh and YARA, runs
`install_virtualenv.sh` (AILENV, Python packages, NLTK data, and the web
assets via `frontend/update_thirdparty.sh`), creates `configs/core.cfg`, the
data folders and a self-signed TLS cert, and creates the `admin@admin.test`
account (credentials in `DEFAULT_PASSWORD`). It is safe to re-run: finished
builds are skipped, and it won't touch the database while the stack is running
or reset an existing admin password. Install Lacus at `/opt/lacus` separately,
then `./anorphix.sh start`.
Runtime data (`DATA_*`, `CRAWLED_SCREENSHOT`, `FORUM_PROFILES`, reports, logs)
and secrets (`backend/web/server.key`, forum profiles, API keys) are never
committed.
