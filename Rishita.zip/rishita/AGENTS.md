# AGENTS.md

## Repository purpose

Anorphix is a dark-web intelligence platform: it monitors approved forums and
ransomware leak trackers for mentions of a domain, organisation or keyword and
turns matches into scored, evidence-backed findings, PDF reports and watchlist
alerts. A secondary Asset Intelligence module (attack-surface scanning) is
present but switched off by default.

It is built on a trimmed-down copy of the AIL Framework (CIRCL). Only the AIL
storage, config, object and crawler layers remain; upstream AIL's importers,
processing modules, exporters, updater and object-explorer UI have been
removed. Internal names such as `AIL_HOME`, `AILENV` and `ail_*.py` come from
that base and are still required.

## How it runs

Everything is started by supervisord (`supervisord.conf`, wrapped by
`./anorphix.sh start|stop|restart|status|logs <program>`). These are the only
entry points:

| Entry point | Role |
|---|---|
| `backend/web/Flask_server.py` | Web UI + API (port 7000) |
| `backend/intel/DomainIntelWorker.py` | Runs intelligence search jobs (`backend/lib/intel_jobs.py`) |
| `backend/intel/ForumMonitorWorker.py` | Scheduled forum re-collection + watchlist checks |
| `backend/intel/AlertDispatchWorker.py` | Delivers watchlist alerts |
| `backend/intel/AssetIntelWorker.py` | Asset Intelligence scans (`autostart=false`) |
| `backend/crawlers/Crawler.py` | Page capture through Lacus (`/opt/lacus`) |
| `backend/AIL_Init.py` | One-shot boot step, run by `backend/supervisor_wait_and_init.sh` |

Manual CLI scripts: `backend/intel/forum_session_login.py` (one-time human login
per forum), `backend/intel/onion_crawl_diagnostic.py`, `backend/web/create_default_user.py`,
and `tools/` (`create_users.py`, `crawler_add_task.py` (queues a crawl directly
in the DB), `reindex_meilisearch.py`, `gen_cert/`).

Install: `installing_deps.sh` → `install_virtualenv.sh` → `frontend/update_thirdparty.sh`.

Storage: Redis 6379/6380/6381 (cache, queues), Kvrocks 6383 (main DB),
Meilisearch 7700 (full-text index). Tor is a system service.

## Directory map

Source is split into `backend/` (all Python: workers, business logic, the
Flask app) and `frontend/` (Jinja templates and static assets). `AIL_BIN`
points at `backend/`, `AIL_FLASK` at `backend/web/`. `configs/` stays at the
root because `lib/ConfigLoader.py` reads `$AIL_HOME/configs`.

- `backend/intel/` - the platform's workers and operator scripts.
- `backend/lib/` - all business logic.
  - `forum_*.py` + `forum_providers/` - forum registry, native search,
    collection, sessions, storage/dedup, metrics, screenshots; one adapter per
    forum platform or feed (MyBB, XenForo, RSS, ransomware.live, ...).
  - `intel_jobs.py`, `intel_extraction.py`, `intel_pdf.py`, `leak_intel.py` -
    job orchestration, deterministic matching and risk scoring, PDF reports.
  - `watchlist.py`, `alert_dispatch.py`, `ransomware_live.py`, `russian_market.py`.
  - `asset_*.py` + `asset_providers/` - Asset Intelligence jobs, registry and
    one provider per scanner/check.
  - AIL base layer: `ConfigLoader.py`, `ail_core.py`, `ail_users.py`,
    `ail_orgs.py`, `ail_queues.py`, `ail_logger.py`, `Tag.py`, `Tracker.py`,
    `crawlers.py`, `search_engine.py`, `correlations_engine.py`, ...
  - `objects/` - typed AIL objects (domains, items, screenshots, ...). They are
    wired together through `objects/ail_objects.py`, so most are reachable even
    if the UI doesn't show them.
- `backend/crawlers/Crawler.py` - the only `AbstractModule` (`backend/modules/abstract_module.py`)
  still running; its queue wiring lives in `configs/modules.cfg`.
- `backend/exporter/` - only the mail exporter (used for user-account emails).
- `backend/packages/` - small AIL helpers (`Date.py`, `git_status.py`).
- `backend/trackers/yara/` - YARA rule locations used by `lib/Tracker.py`.
- `backend/requirements.txt` - Python packages.
- `backend/web/` - Flask app (`Flask_server.py`, `Flask_config.py`,
  `Role_Manager.py`, `create_default_user.py`, the git-ignored TLS cert/key).
  - `blueprints/intel_*.py` - Dark Web pages.
  - `blueprints/asset_*.py` - Asset Intelligence pages.
  - `blueprints/root.py` - login, OTP, password change.
- `frontend/` - everything the browser gets.
  - `templates/intel/`, `templates/asset/`, `templates/*.html` - Jinja pages.
  - `static/` - bootstrap, jquery, font-awesome, and the `intel-theme.css`,
    `asset-console.css` and `fonts/` theme files.
  - `update_thirdparty.sh` - downloads the vendor static assets.
- `configs/` - `core.cfg.sample` (copy to the git-ignored `core.cfg`),
  `modules.cfg`, Redis/Kvrocks `63xx.conf`, `logging.json`,
  `keys/virusTotalKEYS.py.sample`.
- `files/misp-taxonomies`, `files/misp-galaxy` - tagging data (git submodules).
- `tests/` - unittest-based regression tests.
- `doc/` - feature notes.
- `media/` - reference UI screenshots and example search-result outcomes
  (documentation only; see `media/README.md`).

Git-ignored runtime data: `AILENV/`, `DATA_KVROCKS/`, `DATA_MEILISEARCH/`,
`CRAWLED_SCREENSHOT/`, `FORUM_PROFILES/`, `INTEL_REPORTS/`, `ASSET_REPORTS/`,
`logs/`, `supervisor_*`, `redis/`, `kvrocks/`, `tools/bin/`, `tools/vulnx/`.
Never commit or delete these casually: this checkout is the live server.

## Development guidelines

- Put reusable logic in `backend/lib/`; keep workers, blueprints and templates thin.
- New forum platform or feed: add an adapter in `backend/lib/forum_providers/`
  following `base.py` / `search_base.py`.
- New Asset Intelligence check: add a provider in `backend/lib/asset_providers/`
  following `base.py` and add it to `PROVIDERS` in `asset_providers/__init__.py`.
- Web UI: routes in `backend/web/blueprints/`, templates in `frontend/templates/`,
  assets in `frontend/static/`, and register new blueprints in `Flask_server.py`.
- Changing configuration: update `configs/core.cfg.sample` too.
- Run tests with `python -m unittest discover -s tests -t .` from the repo
  root, with `AILENV` activated.
- Do not commit secrets, API keys, forum session profiles, generated logs, or
  runtime database/cache content.
- Keep imports straightforward; do not wrap imports in broad `try`/`except` blocks.
