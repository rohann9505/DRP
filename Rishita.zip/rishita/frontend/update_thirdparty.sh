#!/bin/bash
# Downloads the third-party web assets the templates load (git-ignored):
#   static/css/bootstrap4.min.css, static/js/bootstrap4.min.js,
#   static/js/jquery.js, static/css/font-awesome.min.css + static/webfonts/
# static/fonts/ holds Anorphix's own tracked theme fonts and is never touched.

set -e
cd "$(dirname "$0")"

BOOTSTRAP_VERSION='4.2.1'
JQUERY_VERSION='3.4.1'
FONT_AWESOME_VERSION='6.6.0'

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p static/css static/js

# Bootstrap 4
wget -q "https://github.com/twbs/bootstrap/releases/download/v${BOOTSTRAP_VERSION}/bootstrap-${BOOTSTRAP_VERSION}-dist.zip" -O "$TMP/bootstrap.zip"
unzip -qq "$TMP/bootstrap.zip" -d "$TMP"
cp "$TMP/bootstrap-${BOOTSTRAP_VERSION}-dist/css/bootstrap.min.css" static/css/bootstrap4.min.css
cp "$TMP/bootstrap-${BOOTSTRAP_VERSION}-dist/css/bootstrap.min.css.map" static/css/bootstrap4.min.css.map
cp "$TMP/bootstrap-${BOOTSTRAP_VERSION}-dist/js/bootstrap.min.js" static/js/bootstrap4.min.js

# jQuery
wget -q "https://code.jquery.com/jquery-${JQUERY_VERSION}.js" -O static/js/jquery.js

# Font Awesome (the css references ../webfonts/)
wget -q "https://github.com/FortAwesome/Font-Awesome/archive/${FONT_AWESOME_VERSION}.zip" -O "$TMP/fa.zip"
unzip -qq "$TMP/fa.zip" -d "$TMP"
cp "$TMP/Font-Awesome-${FONT_AWESOME_VERSION}/css/all.min.css" static/css/font-awesome.min.css
rm -rf static/webfonts
cp -r "$TMP/Font-Awesome-${FONT_AWESOME_VERSION}/webfonts" static/webfonts

echo "Third-party web assets installed."
