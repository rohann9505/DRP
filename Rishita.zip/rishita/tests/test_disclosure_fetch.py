#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Regression tests for the leak-site disclosure fetch path.

Every failure mode used to collapse into a bare ``None``, so "the hidden
service is offline", "it timed out", "it demanded a login" and "it answered
fine but published nothing" were indistinguishable in both the logs and the
UI. These tests pin each of the nine distinct outcomes so that never regresses.

The success case is exercised against the REAL Silent-group payload shape
(the field names and nesting the live API actually uses), which is what proves
the UI will populate automatically once that .onion service is reachable again.

No network egress leaves the host: every HTTP case is served by a local
fixture, and the two Tor-transport failures are raised at the transport
boundary exactly as ``requests`` raises them in production.
"""

import json
import os
import sys
import threading
import time
import unittest

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import intel_jobs


# The live Silent disclosure payload shape. `files` is populated here because
# the live company_id=2 record publishes an empty list - the per-file inventory
# is what the UI must render when a group does publish one.
REAL_PAYLOAD = {
    "total_active_disclosures": 1,
    "results": [{
        "id": 2,
        "title": "Full",
        "filesCount": 950221,
        "filesSizes": "854GB",
        "description": "Full corporate data set: accounting, HR records, client contracts.",
        "view_number": 14,
        "status": True,
        "zip_link": "/media/archives/versa_full.zip",
        "unix_date": 1745404800,
        "company": 2,
        "company_name": "Versa Networks",
        "screenshots": [
            {"id": 6, "url": "/media/screenshots/doc.jpg"},
            {"id": 7, "url": "/media/screenshots/1.jpg"},
            {"id": 8, "url": "/media/screenshots/43553.jpg"},
        ],
        "tag_details": [
            {"id": 5, "name": "Full", "status": True},
            {"id": 4, "name": "Accounting", "status": True},
            {"id": 6, "name": "Client", "status": True},
            {"id": 7, "name": "HR", "status": True},
            {"id": 8, "name": "Confidentially", "status": True},
        ],
        "files": [
            {"id": 101, "name": "employees_2024.sql", "url": "/media/files/employees_2024.sql",
             "size": "2.4GB", "unix_date": 1745404800},
            {"id": 102, "name": "payroll_q1.xlsx", "url": "/media/files/payroll_q1.xlsx",
             "size": "18MB", "unix_date": 1745405000},
            {"id": 103, "name": "toolkit.exe", "url": "/media/files/toolkit.exe",
             "size": "1.2MB", "unix_date": 1745405100},
            {"id": 104, "name": "vpn_config.env", "url": "/media/files/vpn_config.env",
             "size": "4KB", "unix_date": 1745405200},
        ],
    }],
}


class _Handler(BaseHTTPRequestHandler):

    def log_message(self, *args):
        pass  # keep the test output clean

    def _send(self, code, body, ctype='application/json'):
        data = body.encode()
        try:
            self.send_response(code)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            # The timeout test hangs up mid-write by design.
            pass

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/disclosures/ok':
            return self._send(200, json.dumps(REAL_PAYLOAD))
        if path == '/api/disclosures/empty':
            return self._send(200, json.dumps({"total_active_disclosures": 0, "results": []}))
        if path == '/api/disclosures/badjson':
            return self._send(200, '<html>not json</html>', 'text/html')
        if path == '/api/disclosures/forbidden':
            return self._send(403, 'forbidden', 'text/plain')
        if path == '/api/disclosures/loginwall':
            return self._send(200, '<html><body>You must be logged in to view this page.'
                                   '</body></html>', 'text/html')
        if path == '/api/disclosures/slow':
            time.sleep(5)
            return self._send(200, '{}')
        if path == '/api/disclosures/error':
            return self._send(500, 'internal error', 'text/plain')
        return self._send(404, 'nope', 'text/plain')


class _QuietServer(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        pass  # a client that hangs up is an expected case here, not a fault


class DisclosureFetchTestCase(unittest.TestCase):
    """Pins all nine `_fetch_disclosure` outcomes."""

    @classmethod
    def setUpClass(cls):
        cls.server = _QuietServer(('127.0.0.1', 0), _Handler)
        cls.base = f'http://127.0.0.1:{cls.server.server_address[1]}'
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

        # The production call always routes through Tor. The fixture is on
        # loopback, so strip the proxy for the duration of the tests - the code
        # path under test (status/body classification) is otherwise untouched.
        cls._real_get = requests.get

        def _loopback_get(url, **kwargs):
            kwargs.pop('proxies', None)
            return cls._real_get(url, **kwargs)

        requests.get = _loopback_get

    @classmethod
    def tearDownClass(cls):
        requests.get = cls._real_get
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        self.logged = []

    def _log(self, msg):
        self.logged.append(msg)

    def fetch(self, path):
        return intel_jobs._fetch_disclosure(f'{self.base}{path}', logger=self._log)

    # ---- 1. successful real-payload-shaped response ----------------------

    def test_success_real_payload_shape(self):
        parsed, status, detail = self.fetch('/api/disclosures/ok')
        self.assertEqual(status, intel_jobs.DISCLOSURE_OK)
        self.assertIsNone(detail)
        self.assertIsNotNone(parsed)

        # description + identity
        self.assertEqual(parsed['disclosure_id'], 2)
        self.assertEqual(parsed['title'], 'Full')
        self.assertIn('accounting', (parsed['description'] or '').lower())
        self.assertEqual(parsed['company_name'], 'Versa Networks')
        self.assertEqual(parsed['files_count'], 950221)
        self.assertEqual(parsed['files_total_size'], '854GB')
        self.assertEqual(parsed['total_active_disclosures'], 1)

        # bulk-download status
        self.assertTrue(parsed['zip_available'])
        self.assertTrue(parsed['zip_link'].endswith('/media/archives/versa_full.zip'))

        # provenance
        self.assertEqual(parsed['source_url'], f'{self.base}/api/disclosures/ok')

        # files: ids / names / types / URLs / sizes / timestamps
        self.assertEqual(len(parsed['files']), 4)
        by_name = {f['name']: f for f in parsed['files']}
        self.assertEqual(set(by_name), {'employees_2024.sql', 'payroll_q1.xlsx',
                                        'toolkit.exe', 'vpn_config.env'})
        sql = by_name['employees_2024.sql']
        self.assertEqual(sql['id'], 101)
        self.assertEqual(sql['category'], 'database')
        self.assertEqual(sql['extension'], 'sql')
        self.assertEqual(sql['size'], '2.4GB')
        self.assertTrue(sql['url'].endswith('/media/files/employees_2024.sql'))
        self.assertTrue(sql['date'], 'a human-readable timestamp must be derived')
        self.assertFalse(sql['unsafe'])

        # unsafe-file handling: the executable is flagged and not previewable
        exe = by_name['toolkit.exe']
        self.assertTrue(exe['unsafe'])
        self.assertFalse(exe['previewable'])
        self.assertEqual(exe['category'], 'executable')

        # config file is categorised (drives the credential-exposure indicator)
        self.assertEqual(by_name['vpn_config.env']['category'], 'config')

        # tags, all with a resolved category
        self.assertEqual(len(parsed['tags']), 5)
        self.assertEqual({t['name'] for t in parsed['tags']},
                         {'Full', 'Accounting', 'Client', 'HR', 'Confidentially'})
        self.assertTrue(all(t['id'] is not None for t in parsed['tags']))

        # screenshots
        self.assertEqual(len(parsed['screenshots']), 3)
        self.assertTrue(all(s['url'].startswith('http') for s in parsed['screenshots']))

        # data-exposure indicator input: categories counted, never valued
        self.assertGreaterEqual(parsed['categories'].get('malware', 0), 1)
        self.assertGreaterEqual(parsed['categories'].get('database', 0), 1)
        self.assertTrue(all(isinstance(v, int) for v in parsed['categories'].values()))

    # ---- 2. offline .onion ----------------------------------------------

    def test_offline_onion_reports_tor_failure_not_timeout(self):
        """An offline hidden service surfaces as a Timeout, because tor holds the
        SOCKS connection open while it retries the HSDir hashring. It must NOT be
        reported as a generic timeout."""
        onion = 'http://silentteam5bnvv2xvfz2j5vqhbrzsgpqvzclvpqrqvpqnvpqrqvpqd.onion/api/disclosures/'

        def _raise_timeout(url, **kwargs):
            raise requests.exceptions.Timeout('timed out')

        real, requests.get = requests.get, _raise_timeout
        try:
            parsed, status, detail = intel_jobs._fetch_disclosure(onion, logger=self._log)
        finally:
            requests.get = real

        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_TOR_FAILURE)
        self.assertIn('no descriptor published', detail)
        self.assertIn('offline', detail)

    def test_onion_socks_resolve_failure_reports_tor_failure(self):
        """The other shape of the same condition: tor answers the SOCKS request
        with a resolution failure instead of stalling."""
        onion = 'http://silentteam5bnvv2xvfz2j5vqhbrzsgpqvzclvpqrqvpqnvpqrqvpqd.onion/api/disclosures/'

        def _raise_socks(url, **kwargs):
            raise requests.exceptions.ConnectionError(
                'SOCKSHTTPConnectionPool: Host unreachable')

        real, requests.get = requests.get, _raise_socks
        try:
            parsed, status, detail = intel_jobs._fetch_disclosure(onion, logger=self._log)
        finally:
            requests.get = real

        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_TOR_FAILURE)
        self.assertIn('no descriptor published', detail)

    # ---- 3. timeout (clearnet) ------------------------------------------

    def test_timeout(self):
        original = intel_jobs._DISCLOSURE_TIMEOUT
        intel_jobs._DISCLOSURE_TIMEOUT = 1
        try:
            parsed, status, detail = self.fetch('/api/disclosures/slow')
        finally:
            intel_jobs._DISCLOSURE_TIMEOUT = original
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_TIMEOUT)
        self.assertIn('timed out', detail)

    # ---- 4. HTTP 403 -----------------------------------------------------

    def test_http_403_is_auth_required(self):
        parsed, status, detail = self.fetch('/api/disclosures/forbidden')
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_AUTH)
        self.assertEqual(detail, 'HTTP 403')

    # ---- 5. login-wall 200 ----------------------------------------------

    def test_login_wall_200_is_auth_required(self):
        parsed, status, _ = self.fetch('/api/disclosures/loginwall')
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_AUTH)

    # ---- 6. non-JSON response -------------------------------------------

    def test_non_json_is_invalid_payload(self):
        parsed, status, detail = self.fetch('/api/disclosures/badjson')
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_BAD_PAYLOAD)
        self.assertIn('not valid JSON', detail)

    # ---- 7. HTTP 500 -----------------------------------------------------

    def test_http_500_is_unavailable(self):
        parsed, status, detail = self.fetch('/api/disclosures/error')
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_UNREACHABLE)
        self.assertEqual(detail, 'HTTP 500')

    # ---- 8. valid empty response ----------------------------------------

    def test_valid_but_empty_is_empty_not_failure(self):
        parsed, status, detail = self.fetch('/api/disclosures/empty')
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_EMPTY)
        self.assertIn('no disclosure records', detail)

    # ---- 9. non-published claim URL --------------------------------------

    def test_non_api_claim_url_is_not_published(self):
        parsed, status, _ = intel_jobs._fetch_disclosure(
            'http://example.onion/versa-networks', logger=self._log)
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_NOT_APPLICABLE)

    def test_missing_claim_url_is_not_published(self):
        parsed, status, _ = intel_jobs._fetch_disclosure(None, logger=self._log)
        self.assertIsNone(parsed)
        self.assertEqual(status, intel_jobs.DISCLOSURE_NOT_APPLICABLE)

    # ---- cross-cutting: never fabricate, never leak ----------------------

    def test_failures_never_fabricate_a_disclosure(self):
        """Every non-OK outcome must return None rather than a synthesised
        record, so the UI can only ever show real published data."""
        for path in ('/api/disclosures/empty', '/api/disclosures/badjson',
                     '/api/disclosures/forbidden', '/api/disclosures/loginwall',
                     '/api/disclosures/error'):
            parsed, status, _ = self.fetch(path)
            self.assertIsNone(parsed, f'{path} fabricated a disclosure')
            self.assertNotEqual(status, intel_jobs.DISCLOSURE_OK)

    def test_logs_carry_no_response_bodies(self):
        """Logs record the status, the URL and a short transport reason only -
        never the response body, and never anything credential-shaped."""
        for path in ('/api/disclosures/ok', '/api/disclosures/badjson',
                     '/api/disclosures/loginwall', '/api/disclosures/error'):
            self.fetch(path)
        blob = '\n'.join(self.logged)
        # fixture body fragments that must never be echoed into a log line
        for leaked in ('not json', 'You must be logged in', 'internal error',
                       'Versa Networks', 'employees_2024.sql', 'toolkit.exe',
                       'versa_full.zip'):
            self.assertNotIn(leaked, blob, f'log leaked response content: {leaked!r}')
        for secretish in ('password', 'passwd', 'token', 'api_key', 'apikey',
                          'secret', 'BEGIN PRIVATE KEY', 'Authorization'):
            self.assertNotIn(secretish.lower(), blob.lower())

    def test_every_documented_state_is_reachable(self):
        """Guards against a constant being renamed or dropped."""
        for const in ('DISCLOSURE_OK', 'DISCLOSURE_EMPTY', 'DISCLOSURE_BAD_PAYLOAD',
                      'DISCLOSURE_AUTH', 'DISCLOSURE_TIMEOUT', 'DISCLOSURE_UNREACHABLE',
                      'DISCLOSURE_NOT_APPLICABLE', 'DISCLOSURE_TOR_FAILURE'):
            self.assertTrue(hasattr(intel_jobs, const), f'missing {const}')
        self.assertEqual(intel_jobs.DISCLOSURE_OK, 'retrieved')
        self.assertEqual(intel_jobs.DISCLOSURE_TOR_FAILURE, 'tor_failure')
        self.assertEqual(intel_jobs.DISCLOSURE_NOT_APPLICABLE, 'not_published')
        self.assertEqual(intel_jobs.DISCLOSURE_BAD_PAYLOAD, 'invalid_payload')
        self.assertEqual(intel_jobs.DISCLOSURE_AUTH, 'auth_required')
        self.assertEqual(intel_jobs.DISCLOSURE_UNREACHABLE, 'unavailable')
        self.assertEqual(intel_jobs.DISCLOSURE_EMPTY, 'empty')
        self.assertEqual(intel_jobs.DISCLOSURE_TIMEOUT, 'timeout')


if __name__ == '__main__':
    unittest.main(verbosity=2)
