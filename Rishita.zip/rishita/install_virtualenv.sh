#!/bin/bash
# Creates the AILENV virtualenv, installs the Python packages, the tlsh
# extension, NLTK data and the third-party web assets. Safe to re-run.
# Called by installing_deps.sh; can also be run on its own from the repo root.

set -e
AIL_HOME="$(cd "$(dirname "$0")" && pwd)"
cd "$AIL_HOME"

if [ ! -d AILENV ]; then
    virtualenv -p python3 AILENV
fi

# AIL_* variables every component relies on (rewritten on each run)
grep -v "^export AIL_" AILENV/bin/activate > AILENV/bin/activate.tmp
mv AILENV/bin/activate.tmp AILENV/bin/activate
cat >> AILENV/bin/activate <<EOF
export AIL_HOME=$AIL_HOME
export AIL_BIN=$AIL_HOME/backend/
export AIL_FLASK=$AIL_HOME/backend/web/
export AIL_REDIS=$AIL_HOME/redis/src/
export AIL_KVROCKS=$AIL_HOME/kvrocks/build/
EOF

. AILENV/bin/activate

pip3 install -U pip
# setuptools/wheel are no longer bundled in Python 3.12+ venvs, but the tlsh
# extension's setup.py needs them (it is built outside pip's build isolation).
pip3 install -U setuptools wheel

# These packages often fail to build on recent Python (3.14); they are only
# needed by optional features, so they are tried separately and may be skipped.
OPTIONAL='^(easyocr|scrapy-splash|qreader)'
REQS=$(mktemp)
grep -vE "$OPTIONAL" backend/requirements.txt > "$REQS"
pip3 install -U -r "$REQS"
rm -f "$REQS"
grep -E "$OPTIONAL" backend/requirements.txt | while read -r pkg; do
    pip3 install "$pkg" || echo "WARNING: optional package $pkg failed to install, skipped"
done

# tlsh Python extension (tlsh itself is built by installing_deps.sh)
pushd tlsh/py_ext
python3 setup.py build
python3 setup.py install
popd

# NLTK / TextBlob data, stored under $AIL_HOME/nltk_data
HOME="$AIL_HOME" python3 -m textblob.download_corpora
HOME="$AIL_HOME" python3 -m nltk.downloader vader_lexicon punkt

bash frontend/update_thirdparty.sh
