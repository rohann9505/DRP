#!/usr/bin/env bash
#
# One command to start, stop, or check the whole Anorphix platform - no AI
# assistant needed. Everything (storage, Lacus/Tor capture engine, the
# Flask website, and all background workers) is managed by supervisord as
# a single group, so you never start pieces by hand.
#
# Usage:
#   ./anorphix.sh start     # start everything (safe to run if already running)
#   ./anorphix.sh stop      # stop everything
#   ./anorphix.sh restart   # restart everything
#   ./anorphix.sh status    # show what's running
#   ./anorphix.sh logs <name>   # tail one component's log, e.g: ./anorphix.sh logs flask
#
# Survives a full server reboot on its own (crontab -l shows an @reboot
# entry that runs this same supervisord config) - you only need this
# script if you stopped it yourself and want it back, or want to check on it.

set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

CONF="$PWD/supervisord.conf"
PIDFILE="$PWD/supervisor_run/supervisord.pid"
source "$PWD/AILENV/bin/activate"

is_running() {
    [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null
}

case "${1:-}" in
    start)
        if is_running; then
            echo "Already running."
        else
            supervisord -c "$CONF"
            echo "Starting... this takes about 30-60 seconds for every component to come up."
            echo "Run './anorphix.sh status' in a bit, then open https://<this-server>:7000"
        fi
        ;;
    stop)
        if is_running; then
            supervisorctl -c "$CONF" shutdown
        else
            echo "Not running."
        fi
        ;;
    restart)
        if is_running; then
            supervisorctl -c "$CONF" shutdown
            sleep 2
        fi
        supervisord -c "$CONF"
        echo "Restarting... give it 30-60 seconds, then './anorphix.sh status'"
        ;;
    status)
        if is_running; then
            supervisorctl -c "$CONF" status
        else
            echo "Not running. Start it with: ./anorphix.sh start"
        fi
        ;;
    logs)
        if [ -z "${2:-}" ]; then
            echo "Usage: ./anorphix.sh logs <name>"
            echo "Names: $(supervisorctl -c "$CONF" status 2>/dev/null | awk -F: '{print $2}' | awk '{print $1}' | tr '\n' ' ')"
            exit 1
        fi
        tail -f "$PWD/supervisor_logs/$2.log"
        ;;
    *)
        echo "Usage: ./anorphix.sh {start|stop|restart|status|logs <name>}"
        exit 1
        ;;
esac
