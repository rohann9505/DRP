# media/

Reference screenshots of the Anorphix UI, for developers deploying or working
on the platform. They show what each page should look like on a healthy
install. They are documentation only; nothing in the code reads this folder.

Secrets (API keys, tokens, SMTP credentials) were blanked before capture.

## screenshots/ — the UI, page by page

| File | Page | What it shows |
|---|---|---|
| `01-login.png` | `/login` | Sign-in screen (2FA follows if enabled) |
| `02-dark-web-dashboard.png` | `/dashboard` | Forum counts, recent collection activity, recent intelligence jobs |
| `03-forums-list.png` | `/forums` | Monitored forums with status, health, session and document counts |
| `04-forum-detail-session-health.png` | `/forums/<id>` | One forum: collection stats, health banner, session login/validate, crawl controls |
| `05-forum-collected-documents.png` | `/forums/<id>/documents` | Documents collected from a forum, with indicator counts |
| `06-intelligence-new-search.png` | `/intelligence/search` | Start a domain or keyword search across selected sources |
| `07-intelligence-search-history.png` | `/intelligence/history` | All intelligence jobs with status, forums searched and findings |
| `08-watchlist.png` | `/watchlist` | Standing watches and the alert feed |
| `09-reports.png` | `/reports` | Completed jobs available as JSON reports |
| `10-system-health-and-alert-channels.png` | `/system` | Lacus/Tor and Meilisearch health, job queue, alert channels, API keys |
| `11-asset-intelligence-discovery.png` | `/assets` | Asset Intelligence: scan a domain, scanned-target inventory |
| `12-asset-intelligence-scan-jobs.png` | `/assets/jobs` | Asset Intelligence scan job history |

## search_results/ — what a search produces

| File | What it shows |
|---|---|
| `01-result-summary-and-findings.png` | Top of a result (`/intelligence/result/<job>`): status, sources searched live, combined findings, first findings |
| `02-finding-thread-screenshot-and-extract.png` | One finding: thread screenshot captured through the authenticated session, plus the text extract with the match highlighted |
| `03-thread-screenshot-full-view-keyword-highlight.png` | The full-size thread screenshot with the matched keyword highlighted on the page |

Asset Intelligence is switched off by default (`assetintelworker`
`autostart=false`); screenshots 11–12 show it with past scans.
