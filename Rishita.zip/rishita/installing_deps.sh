#!/bin/bash
# Fresh-server install for Anorphix (Ubuntu). Run from the repo root as a
# sudo-capable user:
#
#   ./installing_deps.sh 2>&1 | tee logs/install.log
#
# Safe to re-run: every build step is skipped if its output already exists.
# Not installed here (see README.md): the Lacus capture engine at /opt/lacus.

set -e
AIL_HOME="$(cd "$(dirname "$0")" && pwd)"
cd "$AIL_HOME"
mkdir -p logs

# ---- Make apt non-interactive for the whole install (prevents hangs) ----
# On modern Ubuntu, apt sub-steps (e.g. browser X/font/codec packages) trigger
# needrestart's "restart services?" dialog, and sometimes a debconf prompt, that
# silently STALLS the install (Ctrl-C won't dismiss it). Neutralise both for
# every apt run here, including those made by sub-processes. The needrestart
# drop-in is read from disk, so it also covers apt run under another sudo.
export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a NEEDRESTART_SUSPEND=1
if [ -d /etc/needrestart ]; then
    printf '%s\n' "\$nrconf{restart} = 'a';" \
        | sudo tee /etc/needrestart/conf.d/90-anorphix-noninteractive.conf >/dev/null 2>&1 || true
fi
APT_GET="sudo env DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a NEEDRESTART_SUSPEND=1 apt-get"

# ---- System packages ----
$APT_GET update
$APT_GET install -qq -y python3-pip python3-dev virtualenv g++ make cmake \
    automake autoconf libtool pkg-config unzip wget git build-essential \
    libssl-dev libffi-dev libsnappy-dev libfreetype6-dev libfuzzy-dev \
    libzbar0 libadns1-dev graphviz protobuf-compiler libprotobuf-dev tor

# ---- Submodules (MISP taxonomies/galaxies, YARA rules) ----
# Outside a git checkout (e.g. a source copy), clone them at the same pinned
# commits as the submodules - keep these in sync with `git submodule status`.
clone_pinned() {  # dir url commit
    if [ -z "$(ls -A "$1" 2>/dev/null)" ]; then
        rm -rf "$1"
        git clone -q "$2" "$1"
        git -C "$1" checkout -q "$3"
    fi
}
if [ -d .git ]; then
    git submodule update --init --recursive
else
    clone_pinned files/misp-taxonomies https://github.com/MISP/misp-taxonomies.git 36162561c74fcb992dce4455fd0ff8b6f9e1d1b3
    clone_pinned files/misp-galaxy https://github.com/MISP/misp-galaxy.git 20529c5500e967afce3f7c7941d589ed95d91bd0
    clone_pinned backend/trackers/yara/ail-yara-rules https://github.com/ail-project/ail-yara-rules.git 3ccbec3145d3dec0ebf46fb996eb79d0932388d9
fi

# ---- Redis 5.0 (cache + queues, ports 6379-6381) ----
if [ ! -x redis/src/redis-server ]; then
    test -d redis || git clone --branch 5.0 https://github.com/redis/redis.git
    make -C redis
fi

# ---- Kvrocks (main database, port 6383) ----
if [ ! -x kvrocks/build/kvrocks ]; then
    test -d kvrocks || git clone --depth 1 https://github.com/apache/kvrocks.git kvrocks
    (cd kvrocks && ./x.py build -j "$(nproc)")
fi
mkdir -p DATA_KVROCKS

# ---- Meilisearch (full-text index, port 7700) ----
# Pinned: its on-disk DATA_MEILISEARCH format is tied to the version.
MEILISEARCH_VERSION="1.53.1"
if [ ! -x meilisearch ]; then
    wget -q "https://github.com/meilisearch/meilisearch/releases/download/v${MEILISEARCH_VERSION}/meilisearch-linux-amd64" -O meilisearch
    chmod +x meilisearch
fi

# ---- tlsh (fuzzy hashing, used for duplicate detection) ----
if [ ! -d tlsh/build/release ]; then
    test -d tlsh || git clone --depth 1 https://github.com/trendmicro/tlsh.git
    (cd tlsh && ./make.sh)
fi
(cd tlsh/build/release && sudo make install && sudo ldconfig)

# ---- YARA 4.3.0 (used by YARA trackers) ----
YARA_VERSION="4.3.0"
if ! command -v yara >/dev/null || [ "$(yara --version)" != "$YARA_VERSION" ]; then
    TMP=$(mktemp -d)
    wget -q "https://github.com/VirusTotal/yara/archive/v${YARA_VERSION}.zip" -O "$TMP/yara.zip"
    unzip -qq "$TMP/yara.zip" -d "$TMP"
    (cd "$TMP/yara-${YARA_VERSION}" && ./bootstrap.sh && ./configure && make -j "$(nproc)" && sudo make install && sudo ldconfig)
    rm -rf "$TMP"
fi

# ---- Config ----
test -f configs/core.cfg || cp configs/core.cfg.sample configs/core.cfg

# ---- Python virtualenv, packages, web assets ----
./install_virtualenv.sh
. AILENV/bin/activate

# ---- Runtime data directories ----
mkdir -p PASTES HASHS FILES IMAGES FAVICONS Blooms temp/pdf \
    CRAWLED_SCREENSHOT/screenshot CRAWLED_SCREENSHOT/cookiejar_local_storage \
    INTEL_REPORTS ASSET_REPORTS FORUM_PROFILES supervisor_logs supervisor_run

# ---- TLS certificate for the web UI (self-signed) ----
if [ ! -f backend/web/server.crt ]; then
    (cd tools/gen_cert && bash gen_root.sh && bash gen_cert.sh)
    cp tools/gen_cert/server.crt tools/gen_cert/server.key backend/web/
fi

# ---- Database init: start storage briefly, create the admin account ----
wait_for_pong() {  # port [password]
    for _ in $(seq 1 60); do
        if redis/src/redis-cli -p "$1" ${2:+-a "$2"} --no-auth-warning PING 2>/dev/null | grep -q PONG; then
            return 0
        fi
        sleep 1
    done
    echo "Storage on port $1 did not start" >&2
    return 1
}

if redis/src/redis-cli -p 6383 -a ail --no-auth-warning PING 2>/dev/null | grep -q PONG; then
    echo "Storage is already running (stack is up) - skipping database init."
    echo "Run './anorphix.sh stop' first if you need to re-run it."
    exit 0
fi

PIDS=()
for port in 6379 6380 6381; do
    redis/src/redis-server "configs/${port}.conf" >> logs/install_storage.log 2>&1 &
    PIDS+=($!)
done
kvrocks/build/kvrocks -c configs/6383.conf >> logs/install_storage.log 2>&1 &
PIDS+=($!)
trap 'kill "${PIDS[@]}" 2>/dev/null || true' EXIT

for port in 6379 6380 6381; do wait_for_pong "$port"; done
wait_for_pong 6383 ail

# Only on a fresh DB: create_default_user.py resets the admin password if the account exists
if python3 -c "import sys; sys.path.append('bin'); from lib import ail_users; sys.exit(0 if ail_users.exists_user('admin@admin.test') else 1)"; then
    echo "Admin account already exists - not touching its password."
else
    (cd backend/web && python3 create_default_user.py)
fi

kill "${PIDS[@]}"
wait "${PIDS[@]}" 2>/dev/null || true
trap - EXIT

echo
echo "Install complete. Admin credentials are in $AIL_HOME/DEFAULT_PASSWORD."
echo "Next:"
echo "  1. Install Lacus at /opt/lacus (capture engine used by the crawler)."
echo "  2. ./anorphix.sh start      then open https://<this-server>:7000"
echo "  3. Optional, start on boot:  (crontab -l; echo \"@reboot sleep 20 && $AIL_HOME/AILENV/bin/supervisord -c $AIL_HOME/supervisord.conf\") | crontab -"
