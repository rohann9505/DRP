# Anorphix — Developer Guide

Everything a developer needs to set up, run, understand and extend Anorphix.
Read this first; `README.md` is the short operator overview and `AGENTS.md`
is a compact map for AI coding assistants.

---

## 1. What Anorphix is

Anorphix is a dark-web intelligence platform. An analyst enters a domain,
company name or keyword. Anorphix then:

1. searches approved dark-web and clearnet forums, plus ransomware leak
   trackers, for it (live searches and previously collected data);
2. keeps only exact, evidence-backed matches (no fuzzy "maybe" hits);
3. scores each finding, captures screenshots as evidence, and produces a PDF report;
4. keeps watching standing **watchlist** terms and sends alerts (webhook,
   Telegram, e-mail) when something new appears.

A second, optional module, **Asset Intelligence**, scans a company's
internet-facing assets (subdomains, open ports, TLS, known vulnerabilities).
It is switched off by default.

**Built on AIL.** Anorphix is built on a trimmed copy of the open-source
[AIL Framework](https://github.com/ail-project/ail-framework) (CIRCL). AIL
provides the database layer, configuration, users/login and web crawler, which
is why you will see names like `AIL_HOME`, `AILENV` and `ail_users.py`. Those
parts are required, not leftovers. Licence: **AGPL-3.0** (`LICENSE`). Keep the
licence and upstream copyright notices.

---

## 2. What's in this folder (and what isn't)

This folder contains **only source code** (~230 files). When the platform
runs, it creates or downloads a lot more next to the code, and none of that
belongs in version control:

| Created at install/run time | What it is |
|---|---|
| `AILENV/` | Python virtualenv (~30,000 files) |
| `redis/`, `kvrocks/`, `tlsh/`, `meilisearch` | Compiled/downloaded databases and tools |
| `files/misp-*`, `backend/trackers/yara/ail-yara-rules` | Third-party data (fetched by the installer) |
| `frontend/static/{css,js,webfonts}` vendor files | Bootstrap, jQuery, Font Awesome (downloaded) |
| `DATA_KVROCKS/`, `DATA_MEILISEARCH/` | Databases |
| `CRAWLED_SCREENSHOT/`, `INTEL_REPORTS/`, `ASSET_REPORTS/` | Collected evidence and reports |
| `FORUM_PROFILES/` | Logged-in forum browser sessions (**secret**) |
| `logs/`, `supervisor_logs/`, `supervisor_run/` | Logs and process state |
| `configs/core.cfg`, `backend/web/server.{crt,key}` | Local config and TLS key (**secret**) |

All of these are listed in `.gitignore`. A running server has around 50,000
files, but only this source tree is the project.

**No Node.js / npm is needed.** The front end is server-rendered Jinja HTML
with Bootstrap and jQuery, downloaded by `frontend/update_thirdparty.sh`.
Python packages come from `backend/requirements.txt`.

---

## 3. Setting up a development/server machine

### 3.1 Prerequisites

- **Ubuntu** (22.04+; production runs Ubuntu with **Python 3.14**)
- A user with `sudo`
- ~10 GB free disk, 4+ CPU cores (building Kvrocks takes 15–40 min)
- Outbound internet access (packages, GitHub, Tor network)

### 3.2 Put the code in place

Production lives at `/opt/ail-framework`. Any path works, but these
instructions use that one.

```bash
sudo mkdir -p /opt/ail-framework && sudo chown $USER /opt/ail-framework
cp -r anorphix/. /opt/ail-framework/        # or: git clone <your repo> /opt/ail-framework
cd /opt/ail-framework
```

### 3.3 Run the installer

```bash
./installing_deps.sh 2>&1 | tee logs/install.log
```

It does the following (safe to re-run; finished steps are skipped):

1. Installs system packages with apt, including `tor` and `graphviz`.
2. Fetches the MISP taxonomy/galaxy data and YARA rules at pinned versions.
3. Builds **Redis 5.0**, **Kvrocks**, **tlsh** and **YARA 4.3.0**, and
   downloads **Meilisearch 1.53.1**.
4. Copies `configs/core.cfg.sample` to `configs/core.cfg` (only if it doesn't exist).
5. Runs `install_virtualenv.sh`, which creates `AILENV/`, installs
   `backend/requirements.txt`, the tlsh Python extension, NLTK data and the web assets.
6. Creates the data folders and a self-signed TLS certificate.
7. Starts the databases briefly and creates the admin account. Its
   credentials are written to `DEFAULT_PASSWORD` in the repo root.

The Python packages `gcld3`, `easyocr`, `scrapy-splash` and `qreader` often
fail to build on new Python versions. The installer only warns about them;
nothing in the dark-web module needs them.

### 3.4 Install Lacus (page-capture engine)

The crawler takes screenshots through [Lacus](https://github.com/ail-project/lacus),
a separate open-source project that drives a headless browser. It is
installed into the same virtualenv:

```bash
sudo git clone https://github.com/ail-project/lacus.git /opt/lacus
sudo chown -R $USER /opt/lacus
echo "LACUS_HOME=/opt/lacus" > /opt/lacus/.env
sudo ln -s /opt/ail-framework/redis /opt/redis     # Lacus looks for ../redis next to itself

source /opt/ail-framework/AILENV/bin/activate
pip install -e /opt/lacus
playwright install --with-deps                    # headless browsers

cp /opt/lacus/config/generic.json.sample /opt/lacus/config/generic.json
# In generic.json set:  "website_listen_ip": "127.0.0.1",  "website_listen_port": 7100
# and point Lacus at Tor (socks5://127.0.0.1:9050) as described in its README.
```

Then tell Anorphix where Lacus is (a one-off setting stored in the database;
the databases must be running, so do this after the first start in 3.6):

```bash
cd /opt/ail-framework && source AILENV/bin/activate
python3 -c "import sys; sys.path.append('bin'); from lib import crawlers; crawlers.save_lacus_url_api('http://127.0.0.1:7100', None)"
```

### 3.5 Tor

`.onion` sources always go through Tor, which runs as a normal system service:

```bash
sudo systemctl enable --now tor
systemctl status tor
```

### 3.6 Start everything

```bash
./anorphix.sh start
./anorphix.sh status        # after ~60 s every program should be RUNNING
```

Open **https://<server>:7000** (self-signed certificate, so the browser will
warn) and log in with the credentials in `DEFAULT_PASSWORD`. You'll be asked
to change the password.

To start the stack automatically after a reboot:

```bash
(crontab -l 2>/dev/null; echo "@reboot sleep 20 && /opt/ail-framework/AILENV/bin/supervisord -c /opt/ail-framework/supervisord.conf") | crontab -
```

### 3.7 Optional: Asset Intelligence scanners

Asset Intelligence can use external scanners: `subfinder`, `amass`, `httpx`,
`naabu`, `nmap`, `nuclei`, `osv-scanner`, `vulnx`. Drop the binaries into
`tools/bin/` (or put them on `PATH`); each provider detects whether its tool
is present and is skipped if it isn't. Then enable the worker:

```bash
AILENV/bin/supervisorctl -c supervisord.conf start assetintelworker
```

An optional self-hosted [Web-Check](https://github.com/Lissy93/web-check)
instance on port 3000 feeds one more Asset Intelligence provider
(`webcheck_provider.py`). It is a separate Node.js app and not required.

---

## 4. Everyday commands

```bash
./anorphix.sh start | stop | restart | status
./anorphix.sh logs flask                     # follow one program's log

source AILENV/bin/activate                   # always do this before running Python
supervisorctl -c supervisord.conf restart domainintelworker   # restart one program
```

| Program | Port | What it does |
|---|---|---|
| `flask` | 7000 | Web UI + JSON endpoints |
| `domainintelworker` | – | Runs intelligence search jobs |
| `forummonitorworker` | – | Scheduled forum re-collection, watchlist checks |
| `alertdispatchworker` | – | Sends watchlist alerts |
| `assetintelworker` | – | Asset Intelligence scans (off by default) |
| `crawler` | – | Sends capture tasks to Lacus, stores results |
| `kvrocks` | 6383 | Main database (Redis protocol, password `ail`) |
| `redis6379/6380/6381` | 6379–6381 | Cache, crawler state, queues |
| `meilisearch` | 7700 | Full-text search over collected forum documents |
| `lacus_*` | 7100 | Capture engine (from `/opt/lacus`) |
| `ail_init` | – | One-shot boot step (waits for databases, resets queue stats) |

Inspect the databases: `redis/src/redis-cli -p 6383 -a ail` (Kvrocks) or
`redis/src/redis-cli -p 6380`.

---

## 5. How it works

### 5.1 Architecture

```
          Browser  ──►  Flask web app (backend/web + frontend/)  :7000
                              │  creates jobs, reads results
       ┌──────────────────────┼───────────────────────────┐
       ▼                      ▼                           ▼
DomainIntelWorker     ForumMonitorWorker         AlertDispatchWorker
       │                      │                           │
       └──────── business logic: backend/lib/ ────────────┘
                              │
     Crawler (backend/crawlers) ──► Lacus :7100 ──► Tor ──► .onion sites
                              │
   Kvrocks :6383 (data) · Redis :6379-6381 (cache/queues) · Meilisearch :7700 (search)
```

All processes are independent Python programs managed by supervisord
(`supervisord.conf`). They don't call each other directly; they communicate
through the databases (job queues, status fields).

### 5.2 What happens when an analyst runs a search

1. The **Intelligence** page (`backend/web/blueprints/intel_search.py`) calls
   `intel_jobs.create_job(...)`, which stores the job in Kvrocks and queues it.
2. `backend/intel/DomainIntelWorker.py` pops the job (`intel_jobs.pop_queued_job`)
   and calls `intel_jobs.run_job(job_id)`.
3. `run_job`:
   - runs **live native searches** on each selected forum
     (`lib/forum_search.py` + a `forum_providers/*_search.py` adapter), going
     through Tor for `.onion` sites and reusing the forum's logged-in session
     (`lib/forum_session.py`, `FORUM_PROFILES/`);
   - stores what it finds as documents (`lib/forum_documents.py`,
     `lib/forum_ingest.py`) and indexes them in Meilisearch;
   - searches the whole collected corpus in Meilisearch;
   - runs **deterministic matching and scoring** (`lib/intel_extraction.py`).
     A document only becomes a finding if the term appears verbatim; e-mails,
     phones and credential combos are attributed strictly;
   - checks ransomware leak trackers (`lib/ransomware_live.py`, `lib/leak_intel.py`);
   - asks the crawler for **evidence screenshots** of the critical pages
     (`crawlers.create_task` → `Crawler.py` → Lacus);
   - builds the PDF report (`lib/intel_pdf.py`) in `INTEL_REPORTS/`.
4. The **Reports** page (`intel_reports.py`) lists completed jobs
   (`intel_jobs.list_jobs` / `get_job`) and serves their PDFs.

**Watchlists:** `ForumMonitorWorker.py` periodically re-collects forums and
checks watchlist terms (`lib/watchlist.py`); new hits are queued for
`AlertDispatchWorker.py` (`lib/alert_dispatch.py`).

### 5.3 Forum access rules (important)

- Forums are an **allowlist** managed on the **Forums** page
  (`lib/forum_registry.py`). Nothing outside it is contacted.
- For forums that need an account, a **human logs in once** in a visible
  browser; the session is saved and reused:
  `python3 backend/intel/forum_session_login.py <forum_id>`
- The platform **never solves CAPTCHAs or bypasses logins or anti-bot
  protection**. It detects challenge pages, marks the session expired and
  skips the forum (`lib/forum_session.py`, `forum_providers/base.py:detect_block`).
  Keep it that way.
- Each forum has a circuit breaker and rate limiting (MyBB forums enforce a
  30 s flood-control delay between searches).

---

## 6. Code map

```
anorphix.sh                  start/stop/status wrapper around supervisord
supervisord.conf             every process, its command and start order
installing_deps.sh           full install (→ install_virtualenv.sh → frontend/update_thirdparty.sh)

backend/                     all Python ($AIL_BIN)
  requirements.txt           Python packages
  AIL_Init.py                boot step (run by supervisor_wait_and_init.sh)
  intel/                     Anorphix workers + operator scripts
    DomainIntelWorker.py       runs search jobs
    ForumMonitorWorker.py      scheduled collection + watchlist
    AlertDispatchWorker.py     alert delivery
    AssetIntelWorker.py        asset scans
    forum_session_login.py     one-time human login for a forum
    onion_crawl_diagnostic.py  debug a .onion fetch end to end
  crawlers/Crawler.py        Lacus capture loop
  lib/                       ALL business logic
    forum_*.py                 registry, search, collection, sessions, docs, metrics, screenshots
    forum_providers/           one adapter per forum platform / feed
    intel_jobs.py              search-job orchestration (the core flow above)
    intel_extraction.py        matching, attribution, risk scoring
    intel_pdf.py               PDF reports
    leak_intel.py, ransomware_live.py, russian_market.py   leak/ransomware sources
    watchlist.py, alert_dispatch.py                        watchlists + alerts
    asset_*.py, asset_providers/                           Asset Intelligence
    ConfigLoader.py, ail_core.py, ail_users.py, ail_orgs.py,
    ail_queues.py, crawlers.py, search_engine.py, Tag.py, Tracker.py, ...  (AIL base layer)
    objects/                   AIL typed objects (Domain, Item, Screenshot, ...)
  modules/abstract_module.py base class of Crawler.py (queue wiring: configs/modules.cfg)
  exporter/MailExporter.py   account e-mails
  packages/                  small AIL helpers
  web/                       Flask app ($AIL_FLASK)
    Flask_server.py            app factory, blueprint registration, template filters
    Flask_config.py, Role_Manager.py   config + login/role decorators
    blueprints/
      root.py                    login, 2FA, password change
      intel_dashboard|forums|search|reports|watchlist|system.py   Dark Web pages
      asset_dashboard|target|scans.py                            Asset Intelligence pages

frontend/                    what the browser gets (served by backend/web)
  templates/intel/, templates/asset/, templates/*.html
  static/css/intel-theme.css, asset-console.css, static/fonts/   Anorphix theme (tracked)
  update_thirdparty.sh       downloads Bootstrap/jQuery/Font Awesome

configs/
  core.cfg.sample            main config template → copy to core.cfg
  modules.cfg                queue wiring for Crawler.py
  6379/6380/6381.conf        Redis; 6383.conf Kvrocks
  logging.json
tools/
  create_users.py            bulk-create users (-f file)
  crawler_add_task.py        queue a crawl from the command line
  reindex_meilisearch.py     rebuild the search index
  gen_cert/                  self-signed TLS certificate scripts
tests/                       unittest regression tests
doc/                         feature notes
media/                       reference UI screenshots + example search results (see media/README.md)
```

Every Python file begins with `sys.path.append(os.environ['AIL_BIN'])` and
imports as `from lib import ...`, `from lib.objects import ...`. That's why
the virtualenv must be activated: `AILENV/bin/activate` exports `AIL_HOME`,
`AIL_BIN`, `AIL_FLASK`, `AIL_REDIS` and `AIL_KVROCKS`.

---

## 7. Configuration

`configs/core.cfg` (created from `core.cfg.sample`, never committed) is read
through `lib/ConfigLoader.py`. The sections that matter most:

| Section | Key settings |
|---|---|
| `[Flask]` | `host` (0.0.0.0), `port` (7000) |
| `[Directories]` | data folders incl. `intel_reports`, `asset_reports` |
| `[Indexer]` | `meilisearch = True` (**required**: intel jobs search it), URL, key |
| `[Crawler]` | `activate_crawler = True` (**required** for screenshots), defaults |
| `[Redis_*]`, `[Kvrocks_*]` | database connections |

Other settings are stored in the database and changed through the UI: the
forum registry, watchlists, alert channels, source API keys (for example
ransomware.live), and the Lacus URL (see 3.4).

When you add a config key, add it to `core.cfg.sample` too, and document any
manual step existing servers need.

---

## 8. Development workflow

### Run one component in the foreground (with live output)

```bash
source AILENV/bin/activate
supervisorctl -c supervisord.conf stop flask
cd backend/web && python3 Flask_server.py    # Ctrl-C, then: supervisorctl ... start flask
```

The same pattern works for the workers (`cd backend/intel && python3 DomainIntelWorker.py`).
Python changes take effect only after the program restarts.

### Tests

```bash
source AILENV/bin/activate
python -m unittest discover -s tests -t .
```

The tests use local fixtures; no network access is required. They need
`configs/core.cfg` (created by the installer, or copy `core.cfg.sample`) and
the databases running (`./anorphix.sh start`), because the libraries connect
when imported.

### Adding things

- **A forum platform (native search):** add `backend/lib/forum_providers/<name>_search.py`
  subclassing `SearchProvider` (`search_base.py`): implement `build_search`,
  `extract_results`, `is_last_page`. Register it in the `registry` dict in
  `lib/forum_search.py`. Use `mybb_search.py` as the reference.
- **A forum platform (board crawling) or feed:** subclass `ForumProvider`
  (`forum_providers/base.py`: `page_url`, `extract_threads`, `is_last_page`)
  and add it to `PROVIDERS` in `forum_providers/__init__.py`.
- **An Asset Intelligence check:** subclass `AssetProvider`
  (`asset_providers/base.py`), set `id`, `name`, `category`, and optionally
  `requires_binary` / `requires_api_key`. Implement `collect(target_domain, context)`
  and add an instance to `PROVIDERS` in `asset_providers/__init__.py`.
- **A web page:** add a blueprint in `backend/web/blueprints/`, templates in
  `frontend/templates/<area>/` extending `intel/base.html`, and register the
  blueprint in `Flask_server.py`. Protect every route with Flask-Login's
  `@login_required`, plus a role decorator from `Role_Manager.py`
  (`login_admin`, `login_user`, `login_read_only`, ...) where needed.
- **A background process:** add a `[program:...]` block to `supervisord.conf`
  and add it to the `[group:anorphix]` list.

### Conventions

- Business logic goes in `backend/lib/`; workers, blueprints and templates stay thin.
- Keep imports plain; don't wrap them in `try/except`.
- Never commit secrets, API keys, `FORUM_PROFILES/`, logs, database data or
  `configs/core.cfg`.

---

## 9. Gotchas

- **"AIL" names are intentional.** Renaming `AIL_*` env vars, `ail_*.py` or
  the install folder touches hundreds of references; don't do it casually.
- **`configs/modules.cfg`** must keep a `[Crawler]` section listing every
  queue `Crawler.py` publishes to, or the crawler raises on send. Nothing
  subscribes to those queues in this platform, which is intentional.
- **Meilisearch version is pinned** (1.53.1). Its data folder can't be
  opened by a different version; upgrading needs a dump/re-import or
  `tools/reindex_meilisearch.py`.
- **Restarting Lacus:** `supervisorctl restart lacus_website` may leave the
  old gunicorn master running on port 7100; check with `ss -ltnp | grep 7100`.
- **Some forums return the same sticky post for every search** (e.g. a
  "private archive" announcement). The exact-match gate in `intel_extraction.py`
  is what stops those becoming findings. Don't loosen it without tests.
- **`tools/crawler_add_task.py`** writes to the database directly and starts
  a real crawl; don't use it to "test" arguments against a live server.

---

## 10. Security checklist before production

The defaults are only safe because every service listens on 127.0.0.1:

- Kvrocks password `ail` (`configs/6383.conf`, `[Kvrocks_*]` in `core.cfg`).
- Meilisearch master key `ailmeilisearchpassword` (`supervisord.conf`, `[Indexer]`).
- Self-signed TLS certificate for the web UI (`tools/gen_cert/`); replace it
  with a real one for anything user-facing.
- Only port 7000 should be reachable from outside; restrict it with a firewall.
- Treat `FORUM_PROFILES/`, `DEFAULT_PASSWORD`, `backend/web/server.key` and
  `configs/core.cfg` as secrets.
