#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: Intelligence Dashboard
"""

import os
import sys

from flask import render_template, Blueprint
from flask_login import login_required

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_registry
from lib import intel_jobs

intel_dashboard = Blueprint('intel_dashboard', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/intel'))


@intel_dashboard.route("/", methods=['GET'])
@intel_dashboard.route("/dashboard", methods=['GET'])
@login_required
def dashboard():
    # Pool stats mirror the Forums page: every registered forum, so counts
    # match what the Forums tab shows and a newly added source is reflected.
    forums = forum_registry.list_forums()
    jobs = intel_jobs.list_jobs(limit=200)

    active = sum(1 for f in forums if f.get('enabled'))
    errors = sum(1 for f in forums if f.get('last_crawl_status') == 'error')
    stored_documents = sum(f.get('document_count') or 0 for f in forums)
    running_jobs = sum(1 for j in jobs if j.get('status') in ('QUEUED', 'RUNNING'))

    stats = {
        'monitored_forums': len(forums),
        'active': active,
        'collection_errors': errors,
        'stored_documents': stored_documents,
        'intelligence_jobs': len(jobs),
        'running_jobs': running_jobs,
    }

    # "Recent collection activity" should reflect ANY collection, not just the
    # "Collect Now" enqueue path. A forum exercised by native search or a
    # scheduled run records last_successful_crawl (not last_collection_triggered),
    # so keying only on the latter hid every search-collected forum. Include a
    # forum if it has EITHER timestamp, and sort by whichever is most recent.
    def _last_activity(f):
        return max(int(f.get('last_collection_triggered') or 0),
                   int(f.get('last_successful_crawl') or 0))
    recent_collections = sorted(
        [f for f in forums if _last_activity(f) > 0],
        key=_last_activity, reverse=True
    )[:8]
    recent_jobs = jobs[:8]

    return render_template('dashboard.html', active_nav='dashboard', stats=stats,
                            recent_collections=recent_collections, recent_jobs=recent_jobs)
