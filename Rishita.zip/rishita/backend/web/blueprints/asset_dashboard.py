#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: Asset Intelligence - Asset Discovery (entry point)
"""

import os
import sys

from flask import render_template, request, Blueprint, redirect, url_for
from flask_login import login_required

from Role_Manager import login_admin

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import asset_registry
from lib import asset_jobs

asset_dashboard = Blueprint('asset_dashboard', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/asset'))


@asset_dashboard.route("/assets", methods=['GET'])
@login_required
def asset_discovery():
    targets = asset_registry.list_targets()
    return render_template('asset_discovery.html', active_nav='asset_discovery', targets=targets,
                            success=request.args.get('success'), error=request.args.get('error'))


@asset_dashboard.route("/assets/scan", methods=['POST'])
@login_required
@login_admin
def scan_new_target():
    domain = request.form.get('domain')
    target, code = asset_registry.get_or_create_target(domain)
    if code != 200:
        return redirect(url_for('asset_dashboard.asset_discovery', error=target.get('reason')))
    # Quick scan = root-only fast categories (Web-Check + DNS/WHOIS/TLS/OSINT),
    # skipping the heavy subdomain fan-out / ports / Nuclei / directory work, so
    # results land in seconds. Full scan (default) runs every category.
    from lib import asset_providers
    categories = asset_providers.QUICK_CATEGORIES if request.form.get('mode') == 'quick' else None
    asset_jobs.create_job(target['id'], categories=categories)
    label = 'Quick scan queued (root only, Web-Check + core OSINT)' if categories else 'Full scan queued'
    return redirect(url_for('asset_target.target_detail', target_id=target['id'], success=label))
