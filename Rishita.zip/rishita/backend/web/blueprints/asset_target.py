#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: Asset Intelligence - Target Dashboard
"""

import os
import sys

from flask import render_template, request, Blueprint, redirect, url_for, abort
from flask_login import login_required

from Role_Manager import login_admin

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import asset_registry
from lib import asset_data
from lib import asset_jobs
from lib import asset_providers
from lib.asset_providers.base import SEVERITY_ORDER

asset_target = Blueprint('asset_target', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/asset'))

# Sidebar sections -> anchors on the target dashboard. Declared here (not in
# the template) so the section route can validate the slug it is handed
# instead of redirecting to an anchor that does not exist.
TARGET_SECTIONS = [
    ('findings', 'Security Findings'),
    ('domains', 'Domains/Subdomains'),
    ('dns-whois', 'DNS/WHOIS'),
    ('dns-security', 'DNSSEC'),
    ('tls', 'TLS/SSL'),
    ('ports', 'Ports & Services'),
    ('live-status', 'Live/Disconnected'),
    ('vulnerabilities', 'Vulnerabilities'),
    ('technologies', 'Technologies'),
    ('security-config', 'Security Config'),
    ('waf', 'WAF/CDN & Redirects'),
    ('email-security', 'Email Authentication'),
    ('crawl-rules', 'Crawl Rules & Sitemap'),
    ('osint', 'Metadata & Archive'),
    ('directory-enum', 'Directory Enum'),
    ('web-check', 'Web-Check Report'),
]
_SECTION_SLUGS = {slug for slug, _ in TARGET_SECTIONS}

# Security headers whose presence is a genuine "pass" (mirror of the ones the
# security_config provider warns about when absent - so a header is either a
# warning or a pass, never both).
_HEADER_PASS_LABELS = {
    'Strict-Transport-Security': 'Strict-Transport-Security set',
    'Content-Security-Policy': 'Content-Security-Policy set',
    'X-Frame-Options': 'X-Frame-Options set',
    'X-Content-Type-Options': 'X-Content-Type-Options set',
    'Referrer-Policy': 'Referrer-Policy set',
    'Permissions-Policy': 'Permissions-Policy set',
}


def build_advisory(target, root_asset, intel, findings):
    """Web-Check-style advisory: the collected data folded into Warnings /
    Informational / Passes.

    Warnings and Informational come straight from the providers' findings
    (severity != INFO -> warning, INFO -> informational). Passes are DERIVED
    from the same real collected data - a control that the providers had no
    reason to warn about is, by definition, a pass (HSTS present, cert
    trusted, SPF published, DNSSEC on, ...). Nothing here is fabricated: every
    pass is read back from a stored value, so it flips to a warning the moment
    the underlying fact changes.
    """
    order = {sev: i for i, sev in enumerate(SEVERITY_ORDER)}
    warnings, info, passes = [], [], []
    root_fqdn = target['id']

    for f in findings:
        sev = f.get('severity', 'INFO')
        item = {'title': f.get('title'), 'desc': f.get('detail') or '',
                'severity': sev, 'fqdn': f.get('fqdn') or root_fqdn}
        (info if sev == 'INFO' else warnings).append(item)
    warnings.sort(key=lambda x: order.get(x['severity'], len(order)))

    # Warnings grouped by host so a scan spanning many subdomains stays
    # legible: one collapsible sub-group per fqdn, hosts ordered by their
    # worst finding (then by name), items within a host by severity. The flat
    # `warnings` list above is kept for the counts/legend and any consumer
    # that wants the ungrouped view.
    hosts = {}
    for w in warnings:
        hosts.setdefault(w['fqdn'], []).append(w)
    warnings_by_host = []
    for fqdn, items in hosts.items():
        worst = min(order.get(i['severity'], len(order)) for i in items)
        counts = {}
        for i in items:
            counts[i['severity']] = counts.get(i['severity'], 0) + 1
        warnings_by_host.append({
            'fqdn': fqdn, 'entries': items, 'count': len(items),
            'worst_severity': SEVERITY_ORDER[worst] if worst < len(order) else 'INFO',
            'is_root': fqdn == root_fqdn, '_rank': worst,
        })
    # Root domain first among equals, then by worst severity, then name.
    warnings_by_host.sort(key=lambda h: (h['_rank'], not h['is_root'], h['fqdn']))

    root = root_asset or {}
    tls = root.get('tls') or {}
    headers = root.get('security_headers') or {}
    waf = root.get('waf') or []
    whois = root.get('whois') or {}
    mc = intel.get('mail_config') or {}
    ds = intel.get('dnssec') or {}
    stxt = intel.get('security_txt') or {}

    def add_pass(title, desc=''):
        passes.append({'title': title, 'desc': desc})

    if root.get('current_status') == 'live':
        add_pass('Site responded', 'Root domain is reachable over HTTP(S)')
    if tls.get('trusted'):
        add_pass('SSL certificate valid',
                 'Chain verified for {}'.format(tls.get('issuer_org') or tls.get('issuer_cn') or 'the host'))
    if tls.get('protocol'):
        add_pass('{} negotiated'.format(tls.get('protocol')))
    days = tls.get('days_until_expiry')
    if isinstance(days, int) and days > 0:
        add_pass('Certificate not expired', 'Valid for {} more day(s)'.format(days))
    for header, label in _HEADER_PASS_LABELS.items():
        if header in headers:
            add_pass(label)
    if whois.get('expiration_date'):
        add_pass('Domain registration is valid',
                 'Expires {}'.format(whois.get('expiration_date')))
    if mc.get('spf_present'):
        add_pass('SPF record published')
    if mc.get('dmarc_present') and mc.get('dmarc_policy') in ('quarantine', 'reject'):
        add_pass('DMARC enforced', 'Policy p={}'.format(mc.get('dmarc_policy')))
    if mc.get('dkim_found'):
        add_pass('DKIM key found')
    if mc.get('bimi_present'):
        add_pass('BIMI record published')
    if ds.get('enabled'):
        add_pass('DNSSEC enabled')
    if stxt.get('present'):
        add_pass('security.txt found', '/{}'.format(stxt.get('found_in', '')))
    if waf:
        add_pass('Edge protection detected', ', '.join(waf))

    return {
        'warnings': warnings, 'warnings_by_host': warnings_by_host,
        'info': info, 'passes': passes,
        'counts': {'warnings': len(warnings), 'info': len(info), 'passes': len(passes),
                   'warning_hosts': len(warnings_by_host)},
    }


def group_security_findings(root_asset, root_fqdn):
    """Group the root asset's target-wide security_findings by host.

    security_config_probe stores every header/config finding on the root
    asset (they are collected target-wide) and embeds the affected host in
    the finding text as '... on <fqdn>'. For a multi-subdomain target that is
    an undifferentiated wall of rows, so here they are folded into one group
    per host - same shape build_advisory() uses for warnings, so the template
    renders both the same way. Domain-level findings with no '... on <host>'
    suffix (WHOIS expiry, wildcard DNS) fall under the root domain.
    """
    order = {sev: i for i, sev in enumerate(SEVERITY_ORDER)}
    sf = (root_asset or {}).get('security_findings') or []
    hosts = {}
    for f in sf:
        text = f.get('finding') or ''
        host = root_fqdn
        title = text
        if ' on ' in text:
            head, candidate = text.rsplit(' on ', 1)
            candidate = candidate.strip()
            # A real hostname: has a dot, no whitespace.
            if candidate and ' ' not in candidate and '.' in candidate:
                host = candidate
                # Drop the now-redundant "... on <host>" suffix - the host is
                # the group header.
                title = head.strip()
        item = dict(f)
        item['title'] = title
        hosts.setdefault(host, []).append(item)

    grouped = []
    for host, items in hosts.items():
        items.sort(key=lambda x: order.get(x.get('severity'), len(order)))
        worst = order.get(items[0].get('severity'), len(order))
        grouped.append({
            'fqdn': host, 'entries': items, 'count': len(items),
            'worst_severity': SEVERITY_ORDER[worst] if worst < len(order) else 'INFO',
            'is_root': host == root_fqdn, '_rank': worst,
        })
    grouped.sort(key=lambda h: (h['_rank'], not h['is_root'], h['fqdn']))
    return grouped


def default_target_id():
    """The target a section link should open when the user has not picked
    one - the most recently scanned, falling back to the most recently
    added. Returns None when nothing has been registered yet."""
    targets = asset_registry.list_targets()
    if not targets:
        return None

    def _epoch(v):
        # Kvrocks returns these as strings for scanned targets but they fall
        # back to the int 0 when never set - mixing the two breaks sort() on
        # Python 3 ("'<' not supported between 'int' and 'str'"). Coerce both.
        try:
            return int(v)
        except (TypeError, ValueError):
            return 0

    targets.sort(key=lambda t: (_epoch(t.get('last_scan_completed')), _epoch(t.get('created_at'))),
                 reverse=True)
    return targets[0]['id']


@asset_target.route("/assets/section/<section>", methods=['GET'])
@login_required
def target_section(section):
    """Real route behind every target-dependent sidebar link.

    These used to be inert placeholder spans whenever no target was open,
    which made the whole Asset Intelligence group look broken. Resolving the
    target here means the sidebar is always navigable: the link either lands
    on a real target's section, or sends the user to Asset Discovery with an
    explanation - never nothing.
    """
    if section not in _SECTION_SLUGS:
        abort(404)
    target_id = request.args.get('target') or default_target_id()
    if not target_id:
        return redirect(url_for(
            'asset_dashboard.asset_discovery',
            error='No Asset Intelligence targets yet. Add a domain below to scan it, '
                  'then its detailed sections become available.'))
    return redirect(url_for('asset_target.target_detail', target_id=target_id,
                            section=section) + f'#{section}')


@asset_target.route("/assets/<target_id>", methods=['GET'])
@login_required
def target_detail(target_id):
    target, code = asset_registry.get_target(target_id)
    if code != 200:
        abort(404)
    assets = asset_data.list_assets(target_id)
    root_asset = next((a for a in assets if a.get('fqdn') == target_id), None)
    subdomain_assets = [a for a in assets if a.get('fqdn') != target_id]
    provider_status = {cat: asset_providers.provider_status(cat) for cat in asset_providers.CATEGORY_ORDER}
    intel = asset_data.get_target_intel(target_id)
    findings = intel.get('findings') or []
    severity_counts = {sev: sum(1 for f in findings if f.get('severity') == sev)
                       for sev in SEVERITY_ORDER}
    advisory = build_advisory(target, root_asset, intel, findings)
    security_by_host = group_security_findings(root_asset, target_id)
    return render_template('asset_target.html', active_nav='asset_target', target=target,
                            security_by_host=security_by_host,
                            assets=assets, root_asset=root_asset, subdomain_assets=subdomain_assets,
                            provider_status=provider_status, category_labels=asset_providers.CATEGORY_LABELS,
                            intel=intel, findings=findings, severity_counts=severity_counts,
                            advisory=advisory, severity_order=SEVERITY_ORDER,
                            active_section=request.args.get('section'),
                            all_targets=asset_registry.list_targets(),
                            success=request.args.get('success'), error=request.args.get('error'))


@asset_target.route("/assets/<target_id>/scan", methods=['POST'])
@login_required
@login_admin
def target_rescan(target_id):
    target, code = asset_registry.get_target(target_id)
    if code != 200:
        abort(404)
    categories = asset_providers.QUICK_CATEGORIES if request.form.get('mode') == 'quick' else None
    asset_jobs.create_job(target_id, categories=categories)
    label = 'Quick rescan queued (root only, Web-Check + core OSINT)' if categories else 'Full rescan queued'
    return redirect(url_for('asset_target.target_detail', target_id=target_id, success=label))


@asset_target.route("/assets/<target_id>/pause", methods=['POST'])
@login_required
@login_admin
def target_pause(target_id):
    asset_registry.set_enabled(target_id, False)
    return redirect(url_for('asset_target.target_detail', target_id=target_id, success='Target paused'))


@asset_target.route("/assets/<target_id>/resume", methods=['POST'])
@login_required
@login_admin
def target_resume(target_id):
    asset_registry.set_enabled(target_id, True)
    return redirect(url_for('asset_target.target_detail', target_id=target_id, success='Target resumed'))


@asset_target.route("/assets/<target_id>/frequency", methods=['POST'])
@login_required
@login_admin
def target_frequency(target_id):
    res, code = asset_registry.set_scan_frequency(target_id, request.form.get('scan_frequency'))
    if code != 200:
        return redirect(url_for('asset_target.target_detail', target_id=target_id, error=res.get('reason')))
    return redirect(url_for('asset_target.target_detail', target_id=target_id, success='Scan frequency updated'))


@asset_target.route("/assets/<target_id>/delete", methods=['POST'])
@login_required
@login_admin
def target_delete(target_id):
    asset_registry.delete_target(target_id)
    asset_data.delete_target_assets(target_id)
    return redirect(url_for('asset_dashboard.asset_discovery', success=f'Removed target: {target_id}'))
