#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: Watchlist (continuous monitoring - "as soon as it's posted")
"""

import os
import sys

from flask import render_template, request, Blueprint, redirect, url_for, abort
from flask_login import login_required

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_registry
from lib import watchlist

intel_watchlist = Blueprint('intel_watchlist', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/intel'))


@intel_watchlist.route("/watchlist", methods=['GET'])
@login_required
def watchlist_page():
    watches = watchlist.list_watches()
    alerts = watchlist.list_alerts(limit=100)
    return render_template('watchlist.html', active_nav='watchlist', watches=watches, alerts=alerts,
                            forums=forum_registry.list_forums(),
                            success=request.args.get('success'), error=request.args.get('error'))


@intel_watchlist.route("/watchlist/add", methods=['POST'])
@login_required
def watch_add():
    query = request.form.get('query')
    query_type = request.form.get('query_type', 'domain')
    forum_ids = request.form.getlist('forum_ids')
    res, code = watchlist.add_watch(query, query_type=query_type, forum_ids=forum_ids)
    if code != 200:
        return redirect(url_for('intel_watchlist.watchlist_page', error=res.get('reason')))
    return redirect(url_for('intel_watchlist.watchlist_page', success=f'Now watching "{res["query"]}"'))


@intel_watchlist.route("/watchlist/<watch_id>/pause", methods=['POST'])
@login_required
def watch_pause(watch_id):
    res, code = watchlist.set_enabled(watch_id, False)
    if code != 200:
        abort(404)
    return redirect(url_for('intel_watchlist.watchlist_page', success='Watch paused'))


@intel_watchlist.route("/watchlist/<watch_id>/resume", methods=['POST'])
@login_required
def watch_resume(watch_id):
    res, code = watchlist.set_enabled(watch_id, True)
    if code != 200:
        abort(404)
    return redirect(url_for('intel_watchlist.watchlist_page', success='Watch resumed'))


@intel_watchlist.route("/watchlist/<watch_id>/delete", methods=['POST'])
@login_required
def watch_delete(watch_id):
    watchlist.delete_watch(watch_id)
    return redirect(url_for('intel_watchlist.watchlist_page', success='Watch removed'))
