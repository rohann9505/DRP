#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: Domain Intelligence Search
"""

import os
import re
import sys

from flask import render_template, request, Blueprint, redirect, url_for, abort, send_file, Response
from flask_login import login_required

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_registry
from lib import intel_jobs
from lib import intel_pdf
from lib import correlations_engine
from lib.objects.Screenshots import Screenshot


def _finding_screenshot_filepath(finding):
    """Same resolution the finding_screenshot route uses, minus the abort()
    calls - returns None instead of a 404 so PDF export can degrade to
    "no screenshot" rather than failing the whole export. A ransomware.live
    finding has no local item_id at all (its screenshot is an externally
    hosted URL - see finding.get('screenshot_url')), so there's nothing to
    resolve to a local file for those."""
    # Forum-document findings carry the screenshot id directly (they are not
    # AIL items with a correlation) - resolve that first.
    doc_sid = finding.get('doc_screenshot_id')
    if doc_sid and re.fullmatch(r'[0-9a-f]{64}', str(doc_sid)):
        fp = Screenshot(doc_sid).get_filepath()
        if fp and os.path.isfile(fp):
            return fp
    item_id = finding.get('document_id')
    if not item_id:
        return None
    correlations = correlations_engine.get_correlations('item', '', item_id, filter_types=['screenshot'])
    screenshot_ids = correlations.get('screenshot', set())
    if not screenshot_ids:
        return None
    screenshot = Screenshot(next(iter(screenshot_ids)).lstrip(':'))
    filepath = screenshot.get_filepath()
    return filepath if filepath and os.path.isfile(filepath) else None

intel_search = Blueprint('intel_search', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/intel'))


@intel_search.route("/intelligence/search", methods=['GET'])
@login_required
def new_search():
    forums = forum_registry.list_forums()
    return render_template('search_new.html', active_nav='intelligence', forums=forums,
                            live_timeout_hint=intel_jobs.LIVE_SEARCH_TIMEOUT_PER_FORUM,
                            error=request.args.get('error'))


@intel_search.route("/intelligence/search/run", methods=['GET', 'POST'])
@login_required
def run_search():
    if request.method == 'GET':
        # This page only ever exists as the target of the search form's
        # POST - reaching it via GET means a browser refresh/back-button
        # replayed the navigation without the form data. Redirect to the
        # search form instead of a raw 405 error page.
        return redirect(url_for('intel_search.new_search'))
    domain = request.form.get('domain')
    forum_ids = request.form.getlist('forum_ids')
    query_type = request.form.get('query_type', 'domain')
    live = request.form.get('live') == 'on'
    res, code = intel_jobs.create_job(domain, forum_ids, query_type=query_type, live=live)
    if code != 200:
        return redirect(url_for('intel_search.new_search', error=res.get('reason')))
    return redirect(url_for('intel_search.search_result', job_id=res['id']))


@intel_search.route("/intelligence/history", methods=['GET'])
@login_required
def search_history():
    jobs = intel_jobs.list_jobs(limit=200)
    return render_template('search_history.html', active_nav='intelligence', jobs=jobs)


@intel_search.route("/intelligence/result/<job_id>", methods=['GET'])
@login_required
def search_result(job_id):
    job, code = intel_jobs.get_job(job_id)
    if code != 200:
        abort(404)
    findings = []
    report_summary = {}
    if job['status'] == 'COMPLETED':
        report, rcode = intel_jobs.get_report(job_id)
        if rcode == 200:
            findings = report.get('findings', [])
            report_summary = report.get('summary', {})
    return render_template('search_result.html', active_nav='intelligence', job=job, findings=findings,
                            report_summary=report_summary)


@intel_search.route("/intelligence/result/<job_id>/finding/<int:finding_index>/pdf", methods=['GET'])
@login_required
def finding_pdf(job_id, finding_index):
    job, code = intel_jobs.get_job(job_id)
    if code != 200:
        abort(404)
    report, rcode = intel_jobs.get_report(job_id)
    if rcode != 200:
        abort(404)
    findings = report.get('findings', [])
    if finding_index < 0 or finding_index >= len(findings):
        abort(404)
    finding = findings[finding_index]
    screenshot_path = _finding_screenshot_filepath(finding)
    pdf_bytes = intel_pdf.generate_finding_pdf(job, finding, screenshot_path=screenshot_path,
                                                screenshot_url=finding.get('screenshot_url'))
    safe_domain = (job.get('domain') or 'report').replace('/', '_').replace(' ', '_')
    return Response(pdf_bytes, mimetype='application/pdf', headers={
        'Content-Disposition': f'attachment; filename="threat_report_{safe_domain}_{finding_index + 1}.pdf"',
    })


@intel_search.route("/intelligence/result/<job_id>/delete", methods=['POST'])
@login_required
def delete_job(job_id):
    intel_jobs.delete_job(job_id)
    next_url = request.form.get('next') or url_for('intel_search.search_history')
    return redirect(next_url)


@intel_search.route("/intelligence/history/clear", methods=['POST'])
@login_required
def clear_all_jobs():
    intel_jobs.delete_all_jobs()
    next_url = request.form.get('next') or url_for('intel_search.search_history')
    return redirect(next_url)


@intel_search.route("/intelligence/screenshot/<path:item_id>", methods=['GET'])
@login_required
def finding_screenshot(item_id):
    correlations = correlations_engine.get_correlations('item', '', item_id, filter_types=['screenshot'])
    screenshot_ids = correlations.get('screenshot', set())
    if not screenshot_ids:
        abort(404)
    screenshot_id = next(iter(screenshot_ids)).lstrip(':')
    screenshot = Screenshot(screenshot_id)
    filepath = screenshot.get_filepath()
    if not filepath or not os.path.isfile(filepath):
        abort(404)
    return send_file(filepath, mimetype='image/png')


@intel_search.route("/intelligence/doc_screenshot/<screenshot_id>", methods=['GET'])
@login_required
def doc_screenshot(screenshot_id):
    """Serve an authenticated forum-thread evidence screenshot by its sha256 id
    (recorded on the forum document by forum_screenshots). Unlike
    finding_screenshot this needs no item correlation - forum documents are not
    AIL items - so the id IS the screenshot. The sha256 shape is enforced and
    get_filepath() is confined to the screenshot folder, so no path escapes."""
    if not re.fullmatch(r'[0-9a-f]{64}', screenshot_id or ''):
        abort(404)
    screenshot = Screenshot(screenshot_id)
    filepath = screenshot.get_filepath()
    if not filepath or not os.path.isfile(filepath):
        abort(404)
    return send_file(filepath, mimetype='image/png')
