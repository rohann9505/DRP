#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: System - Settings & Jobs/Health
"""

import os
import sys

from flask import render_template, request, redirect, url_for, Blueprint
from flask_login import login_required

from Role_Manager import login_admin

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import alert_dispatch
from lib import asset_keys
from lib import crawlers
from lib import forum_registry
from lib import intel_jobs
from lib import ransomware_live
from lib import search_engine


intel_system = Blueprint('intel_system', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/intel'))


@intel_system.route("/system/alert_channels", methods=['POST'])
@login_required
@login_admin
def save_alert_channels():
    alert_dispatch.set_channel_config(
        webhook_url=request.form.get('webhook_url', '').strip(),
        telegram_bot_token=request.form.get('telegram_bot_token', '').strip(),
        telegram_chat_id=request.form.get('telegram_chat_id', '').strip(),
        smtp_host=request.form.get('smtp_host', '').strip(),
        smtp_port=request.form.get('smtp_port', '587').strip() or '587',
        smtp_user=request.form.get('smtp_user', '').strip(),
        smtp_pass=request.form.get('smtp_pass', '').strip(),
        email_to=request.form.get('email_to', '').strip(),
    )
    return redirect(url_for('intel_system.system_page', success='Notification channels updated'))


@intel_system.route("/system/ransomware_live_key", methods=['POST'])
@login_required
@login_admin
def save_ransomware_live_key():
    ransomware_live.set_api_key(request.form.get('api_key', ''))
    return redirect(url_for('intel_system.system_page', success='Ransomware.live API key updated'))


@intel_system.route("/system/webcheck_url", methods=['POST'])
@login_required
@login_admin
def save_webcheck_url():
    # Asset Intelligence's Web-Check provider reads this base URL (blank clears
    # it, falling back to $WEBCHECK_URL then http://localhost:3000).
    asset_keys.set_api_key('webcheck_base_url', request.form.get('webcheck_url', '').strip())
    return redirect(url_for('intel_system.system_page', success='Web-Check URL updated'))


@intel_system.route("/system", methods=['GET'])
@login_required
def system_page():
    try:
        lacus_up = crawlers.is_lacus_connected()
    except Exception:
        lacus_up = False

    try:
        meili_up = search_engine.Engine is not None and search_engine.Engine.is_up()
    except Exception:
        meili_up = False

    queue_depth = crawlers.r_crawler.llen(intel_jobs.QUEUE_KEY)
    jobs = intel_jobs.list_jobs(limit=500)
    running_jobs = [j for j in jobs if j.get('status') in ('QUEUED', 'RUNNING')]
    forums = forum_registry.list_forums()

    health = {
        'lacus_up': lacus_up,
        'meilisearch_up': meili_up,
        'job_queue_depth': queue_depth,
        'running_jobs': running_jobs,
        'forums_with_errors': [f for f in forums if f.get('last_crawl_status') == 'error'],
    }
    return render_template('system.html', active_nav='system', health=health,
                            alert_channels=alert_dispatch.get_channel_config(),
                            ransomware_live_api_key=ransomware_live.get_api_key(),
                            webcheck_url=asset_keys.get_api_key('webcheck_base_url'),
                            success=request.args.get('success'))
