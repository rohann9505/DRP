#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: Asset Intelligence - Scan Jobs/History + Reports
"""

import io
import os
import sys

from flask import (render_template, Blueprint, abort, send_file, request,
                   redirect, url_for)
from flask_login import login_required

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import asset_jobs
from lib import asset_report_pdf

asset_scans = Blueprint('asset_scans', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/asset'))


@asset_scans.route("/assets/jobs", methods=['GET'])
@login_required
def scan_jobs():
    jobs = asset_jobs.list_jobs(limit=500)
    return render_template('asset_jobs.html', active_nav='asset_jobs', jobs=jobs)


@asset_scans.route("/assets/jobs/<job_id>/delete", methods=['POST'])
@login_required
def delete_scan_job(job_id):
    asset_jobs.delete_job(job_id)
    next_url = request.form.get('next') or url_for('asset_scans.scan_jobs')
    return redirect(next_url)


@asset_scans.route("/assets/reports", methods=['GET'])
@login_required
def asset_reports_list():
    jobs = [j for j in asset_jobs.list_jobs(limit=500) if j.get('status') == 'COMPLETED']
    return render_template('asset_reports.html', active_nav='asset_reports', jobs=jobs)


@asset_scans.route("/assets/reports/<job_id>/download", methods=['GET'])
@login_required
def asset_report_download(job_id):
    """Raw JSON export - kept as the machine-readable secondary format."""
    job, code = asset_jobs.get_job(job_id)
    if code != 200 or job['status'] != 'COMPLETED' or not job.get('report_path'):
        abort(404)
    return send_file(job['report_path'], mimetype='application/json', as_attachment=True,
                      download_name=f"asset_report_{job['target_id']}_{job_id}.json")


@asset_scans.route("/assets/reports/<job_id>/download.pdf", methods=['GET'])
@login_required
def asset_report_pdf_download(job_id):
    """Human-readable PDF export - the primary report format."""
    report, code = asset_jobs.get_report(job_id)
    if code != 200:
        abort(404)
    pdf_bytes = asset_report_pdf.build_pdf(report)
    target = (report.get('query') or {}).get('target_id') or 'target'
    safe = ''.join(c if c.isalnum() or c in '.-_' else '_' for c in target)
    return send_file(io.BytesIO(pdf_bytes), mimetype='application/pdf', as_attachment=True,
                     download_name=f"asset_report_{safe}_{job_id[:8]}.pdf")
