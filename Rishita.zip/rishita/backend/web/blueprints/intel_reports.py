#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: JSON Reports
"""

import os
import sys

from flask import render_template, Blueprint, abort, send_file
from flask_login import login_required

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import intel_jobs

intel_reports = Blueprint('intel_reports', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/intel'))


@intel_reports.route("/reports", methods=['GET'])
@login_required
def reports_list():
    jobs = [j for j in intel_jobs.list_jobs(limit=500) if j.get('status') == 'COMPLETED']
    return render_template('reports_list.html', active_nav='reports', jobs=jobs)


@intel_reports.route("/reports/<job_id>/download", methods=['GET'])
@login_required
def report_download(job_id):
    job, code = intel_jobs.get_job(job_id)
    if code != 200 or job['status'] != 'COMPLETED' or not job.get('report_path'):
        abort(404)
    return send_file(job['report_path'], mimetype='application/json', as_attachment=True,
                      download_name=f"intel_report_{job['domain']}_{job_id}.json")
