#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Blueprint Flask: Forum Registry (Monitored Forums)
"""

import os
import sys
import time

from flask import render_template, request, Blueprint, redirect, url_for, abort, jsonify
from flask_login import login_required

from Role_Manager import login_admin

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_registry
from lib import forum_collector
from lib import forum_metrics
from lib import forum_ingest
from lib import forum_crawl
from lib import forum_session
from lib import crawlers

intel_forums = Blueprint('intel_forums', __name__, template_folder=os.path.join(os.environ['AIL_HOME'], 'frontend/templates/intel'))

# Minimum gap between MANUAL native searches on one forum. This protects the
# authenticated persistent session from the rapid-launch / session-priming race
# (back-to-back Playwright/cookie-export launches intermittently 404 the
# session). It is per-forum, enforced server-side, and does NOT touch scheduled
# searches - those run through forum_crawl.run_forum_crawl, never this route.
NATIVE_SEARCH_COOLDOWN_SECONDS = 30


def _native_search_cooldown_remaining(forum_id):
    """Seconds the caller must still wait, or 0 if a manual search is allowed."""
    try:
        last = crawlers.r_crawler.get(f'forumsearch:cooldown:{forum_id}')
    except Exception:
        return 0
    if not last:
        return 0
    remaining = NATIVE_SEARCH_COOLDOWN_SECONDS - (int(time.time()) - int(last))
    return remaining if remaining > 0 else 0


@intel_forums.route("/forums", methods=['GET'])
@login_required
def forums_list():
    # Every registered forum is shown here, onion or clearnet, so a source
    # reflects in this list the moment it is added and disappears the moment
    # it is deleted. (Previously onion-only, which silently hid clearnet
    # sources an operator had explicitly registered.)
    forums = forum_registry.list_forums()
    # Split each corpus by HOW it was collected. A forum whose documents all
    # came from link-crawling is not evidence that its own search works, and
    # showing one number for both hides exactly that distinction.
    for f in forums:
        f['doc_modes'] = forum_ingest.count_documents_by_mode(f['id'])
    return render_template('forums_list.html', active_nav='forums', forums=forums,
                            success=request.args.get('success'), error=request.args.get('error'))


@intel_forums.route("/forums/add", methods=['POST'])
@login_required
@login_admin
def forum_add():
    name = request.form.get('name')
    url = request.form.get('url')
    source_type = request.form.get('source_type') or None
    crawl_frequency = request.form.get('crawl_frequency') or 'manual'
    res, code = forum_registry.register_forum(name, url, source_type=source_type, crawl_frequency=crawl_frequency, enabled=True)
    if code != 200:
        return redirect(url_for('intel_forums.forums_list', error=res.get('reason')))
    forum_id = res['id']
    engine = request.form.get('browser_engine')
    if engine:
        forum_registry.set_browser_engine(forum_id, engine)
    # If the operator asked for it, open the one-time sign-in window right away
    # so adding a forum that needs a login no longer means running a CLI script.
    # The window opens on the server's display for the human to log in; nothing
    # is automated. Land on the forum's page either way, where the Session panel
    # lives.
    if request.form.get('open_login') == 'on':
        status, _ = forum_session.launch_login(forum_id)
        if status == 'launched':
            return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                    success=f"Registered {res['name']}. Opening a sign-in window on the server."))
        if status == 'already_running':
            return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                    success=f"Registered {res['name']}. A sign-in window is already open — use it, or Log In below."))
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                error=f"Registered {res['name']}, but could not open the login window ({status}). Use Log In below."))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            success=f"Registered forum: {res['name']}"))


@intel_forums.route("/forums/<forum_id>", methods=['GET'])
@login_required
def forum_detail(forum_id):
    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    from lib import gentlemen_intel
    return render_template('forum_detail.html', active_nav='forums', forum=forum,
                            is_leak_site=gentlemen_intel.is_leak_site(forum_id),
                            doc_modes=forum_ingest.count_documents_by_mode(forum_id),
                            last_run=forum_metrics.get_last_run(forum_id),
                            runs=forum_metrics.list_runs(forum_id, limit=15),
                            crawl_state=forum_metrics.get_state(forum_id),
                            cursor=forum_metrics.get_cursor(forum_id),
                            frequency_labels=forum_registry.FREQUENCY_LABELS,
                            route_labels=forum_registry.ROUTE_LABELS,
                            effective_route=forum_registry.resolve_route(forum_id),
                            success=request.args.get('success'), error=request.args.get('error'))


@intel_forums.route("/forums/<forum_id>/collect", methods=['POST'])
@login_required
@login_admin
def forum_collect(forum_id):
    """Incremental crawl. Enqueued, not run inline - a full paginated walk
    takes minutes and must never block the request."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    forum_metrics.enqueue_crawl(forum_id, full_resync=False)
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            success='Incremental crawl queued'))


@intel_forums.route("/forums/<forum_id>/resync", methods=['POST'])
@login_required
@login_admin
def forum_resync(forum_id):
    """FULL CRAWL / RESYNC: forget the incremental cursor and walk the
    available history again."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    forum_metrics.reset_cursor(forum_id)
    forum_metrics.enqueue_crawl(forum_id, full_resync=True)
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            success='Full crawl / resync queued'))


@intel_forums.route("/forums/<forum_id>/live", methods=['POST'])
@login_required
@login_admin
def forum_live(forum_id):
    enabled = request.form.get('live_crawl') == 'on'
    res, code = forum_registry.set_live_crawl(forum_id, enabled)
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, error=res.get('reason')))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            success=f"Live crawling {'enabled' if enabled else 'disabled'}"))


@intel_forums.route("/forums/<forum_id>/routing", methods=['POST'])
@login_required
@login_admin
def forum_routing(forum_id):
    """Configure this forum's network route.

    The submitted proxy URL may contain credentials; they are split out and
    stored separately by set_route(). Nothing here echoes the raw value back -
    on error only the validator's own message is surfaced, which never
    includes the password.
    """
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    res, code = forum_registry.set_route(
        forum_id,
        request.form.get('route'),
        proxy_url=request.form.get('proxy_url'),
        proxy_label=request.form.get('proxy_label'),
    )
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                error=res.get('reason')))
    route = forum_registry.resolve_route(forum_id)
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            success=f"Network route saved — {route['reason']}"))


@intel_forums.route("/forums/<forum_id>/routing/test", methods=['POST'])
@login_required
@login_admin
def forum_routing_test(forum_id):
    """Actively verify the resolved route by making a real request through it
    and reporting the observed egress IP - not a configuration echo."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    route = forum_registry.resolve_route(forum_id)
    check_browser = request.form.get('check_browser') == '1'
    try:
        diag = forum_crawl.diagnose_route(route, check_browser=check_browser)
    except Exception as e:
        diag = {'ok': False, 'mode': route.get('mode'),
                'error': f'{type(e).__name__}: {str(e)[:200]}'}
    # `display` is already credential-masked by resolve_route().
    return jsonify({
        'forum_id': forum_id,
        'mode': diag.get('mode'),
        'reason': route.get('reason'),
        'display': route.get('display'),
        'ok': diag.get('ok', False),
        'egress_ip': diag.get('egress_ip'),
        'direct_ip': diag.get('direct_ip'),
        'is_tor_exit': diag.get('is_tor_exit'),
        'verdict': diag.get('verdict'),
        'error': diag.get('error'),
        'browser': diag.get('browser'),
    })


@intel_forums.route("/forums/<forum_id>/limits", methods=['POST'])
@login_required
@login_admin
def forum_limits(forum_id):
    try:
        max_pages = int(request.form.get('max_pages') or 0) or None
        max_documents = int(request.form.get('max_documents') or 0) or None
    except ValueError:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                error='Limits must be whole numbers'))
    res, code = forum_registry.set_crawl_limits(forum_id, max_pages=max_pages,
                                                max_documents=max_documents)
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, error=res.get('reason')))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            success='Crawl safety limits updated'))


@intel_forums.route("/forums/<forum_id>/status.json", methods=['GET'])
@login_required
def forum_status_json(forum_id):
    """Live crawl status, polled by the forum page so the LIVE CRAWL indicator
    updates without a full reload."""
    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    state = forum_metrics.get_state(forum_id)
    last = forum_metrics.get_last_run(forum_id) or {}
    return jsonify({
        'forum_id': forum_id,
        'status': state.get('status', 'idle'),
        'running': state.get('running', False),
        'pages': state.get('pages', 0),
        'documents': state.get('documents', 0),
        'new': state.get('new', 0),
        'started_at': state.get('started_at'),
        'finished_at': state.get('finished_at'),
        'skipped_runs': state.get('skipped_runs', 0),
        'live_crawl': forum.get('live_crawl'),
        'crawl_frequency': forum.get('crawl_frequency'),
        'total_documents': forum.get('document_count'),
        'last_run': {
            'documents_stored': last.get('documents_stored', 0),
            'duplicates_skipped': last.get('duplicates_skipped', 0),
            'pages_fetched': last.get('pages_fetched', 0),
            'errors': last.get('errors', 0),
            'termination_reason': last.get('termination_reason', ''),
            'recorded_at': last.get('recorded_at'),
        },
    })


@intel_forums.route("/forums/<forum_id>/documents", methods=['GET'])
@login_required
def forum_documents_list(forum_id):
    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    try:
        offset = max(0, int(request.args.get('offset') or 0))
    except ValueError:
        offset = 0
    q = (request.args.get('q') or '').strip()
    docs = forum_ingest.list_documents(forum_id, limit=50, offset=offset)
    if q:
        # Show just the documents this query matched (newest first already).
        docs = [d for d in docs if (d.get('matched_query') or '').lower() == q.lower()]
    # Native-search status banner, populated when arriving from a user search.
    search_status = None
    if request.args.get('found') is not None:
        search_status = {
            'query': q, 'found': request.args.get('found'),
            'stored': request.args.get('stored'), 'dupes': request.args.get('dupes'),
            'errors': request.args.get('errs'), 'blocked': request.args.get('blocked') or '',
        }
    # A blocked-by-cooldown manual search redirects here with ?wait=N so the
    # user sees exactly how long to wait; the search was NOT executed.
    try:
        cooldown_wait = int(request.args.get('wait') or 0)
    except ValueError:
        cooldown_wait = 0
    return render_template('forum_documents.html', active_nav='forums',
                           forum=forum, documents=docs, offset=offset,
                           total=forum_ingest.count_documents(forum_id),
                           search_status=search_status, q=q,
                           cooldown_wait=cooldown_wait if cooldown_wait > 0 else None)


@intel_forums.route("/forums/<forum_id>/search", methods=['POST'])
@login_required
def forum_native_search(forum_id):
    """Run this forum's OWN native search for a user-entered query, using the
    existing authenticated persistent session and configured route, then show
    the stored results in the existing documents view.

    This REUSES forum_search.run_search_collection - the same engine the
    scheduler and the proven proof-of-life use - it is not a second search
    implementation. Minimal by design: page 1 only, no pagination expansion.
    """
    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    query = (request.form.get('query') or '').strip()
    if not query:
        return redirect(url_for('intel_forums.forum_documents_list', forum_id=forum_id))
    # Server-side rate guard. A second manual search inside the window is NOT
    # executed - it never reaches the session - and the user is told how long
    # to wait. Enforced here so it cannot be bypassed with multiple tabs.
    remaining = _native_search_cooldown_remaining(forum_id)
    if remaining > 0:
        return redirect(url_for('intel_forums.forum_documents_list', forum_id=forum_id,
                                q=query, wait=remaining))
    # Claim the window BEFORE running (also serialises concurrent submits).
    try:
        crawlers.r_crawler.set(f'forumsearch:cooldown:{forum_id}', int(time.time()),
                               ex=NATIVE_SEARCH_COOLDOWN_SECONDS)
    except Exception:
        pass
    from lib import forum_search
    payload = forum_search.run_search_collection(
        forum_id, queries=[query], follow_results=True, max_pages=1)
    errs = payload.get('errors')
    # Record this native search as a normal intelligence job so it shows up in
    # Dashboard -> Recent Intelligence Jobs like every other search. Findings =
    # how many stored documents this query actually matched (what the row links
    # to), so the count and the click-through corpus stay consistent.
    try:
        from lib import intel_jobs
        matched = sum(1 for d in forum_ingest.list_documents(forum_id, limit=1000)
                      if (d.get('matched_query') or '').lower() == query.lower())
        intel_jobs.record_native_search_job(forum_id, query, matched)
    except Exception:
        pass
    return redirect(url_for('intel_forums.forum_documents_list', forum_id=forum_id,
                            q=query,
                            found=payload.get('documents_discovered', 0),
                            stored=payload.get('documents_stored', 0),
                            dupes=payload.get('duplicates_skipped', 0),
                            errs=(errs if isinstance(errs, int) else len(errs or [])),
                            blocked=payload.get('block_category') or ''))


@intel_forums.route("/forums/<forum_id>/login", methods=['POST'])
@login_required
@login_admin
def forum_login(forum_id):
    """Open the one-time HEADED operator-login window for this forum, from the
    UI instead of the CLI script. A visible browser opens on the server's
    display; the operator signs in and solves any CAPTCHA themselves. Nothing
    is automated or bypassed - this only removes the manual shell step."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    status, detail = forum_session.launch_login(forum_id)
    if status == 'launched':
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                success='Opening a sign-in window on the server.'))
    if status == 'already_running':
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                success='A login window is already open for this forum.'))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            error=f'Could not open the login window: {detail}'))


@intel_forums.route("/forums/<forum_id>/validate", methods=['POST'])
@login_required
@login_admin
def forum_validate(forum_id):
    """Run a headless session health check (same as the CLI --validate) in the
    background; the result is written to this forum's session health and shown
    by the Session panel."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    status, detail = forum_session.launch_validate(forum_id)
    if status in ('launched', 'already_running'):
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                success='Validating the stored session…'))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            error=f'Could not start validation: {detail}'))


@intel_forums.route("/forums/<forum_id>/session.json", methods=['GET'])
@login_required
def forum_session_json(forum_id):
    """Session health + whether a login/validation is in flight, polled by the
    forum page so the Session panel updates without a reload."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    health = forum_session.get_health(forum_id)
    health['login_running'] = forum_session.login_running(forum_id)
    health['validating'] = forum_session.validate_running(forum_id)
    health['leak_importing'] = forum_session.leak_import_running(forum_id)
    health['leak_import_result'] = forum_session.get_leak_import_result(forum_id)
    return jsonify(health)


@intel_forums.route("/forums/<forum_id>/leak_import", methods=['POST'])
@login_required
@login_admin
def forum_leak_import(forum_id):
    """Open the headed leak-site import window: the operator clears the anti-bot,
    and the site's own victim list is captured and stored as documents. Only
    valid for a configured leak site."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    from lib import gentlemen_intel
    if not gentlemen_intel.is_leak_site(forum_id):
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                error='This forum is not a configured leak site.'))
    status, detail = forum_session.launch_leak_import(forum_id)
    if status in ('launched', 'already_running'):
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                                success='Import window opening — clear the challenge in it; documents appear when it finishes.'))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            error=f'Could not start the import: {detail}'))


@intel_forums.route("/forums/<forum_id>/engine", methods=['POST'])
@login_required
@login_admin
def forum_engine(forum_id):
    """Set the browser used for this forum's headed login and session checks.
    Chromium (default) or Firefox - Firefox is for onion sites that refuse
    Chromium's connection."""
    _, code = forum_registry.get_forum(forum_id)
    if code != 200:
        abort(404)
    res, code = forum_registry.set_browser_engine(forum_id, request.form.get('browser_engine'))
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, error=res.get('reason')))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id,
                            success=f"Login browser set to {res.get('browser_engine')}."))


@intel_forums.route("/forums/<forum_id>/pause", methods=['POST'])
@login_required
@login_admin
def forum_pause(forum_id):
    forum_registry.set_enabled(forum_id, False)
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, success='Forum paused'))


@intel_forums.route("/forums/<forum_id>/resume", methods=['POST'])
@login_required
@login_admin
def forum_resume(forum_id):
    forum_registry.set_enabled(forum_id, True)
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, success='Forum resumed'))


@intel_forums.route("/forums/<forum_id>/frequency", methods=['POST'])
@login_required
@login_admin
def forum_frequency(forum_id):
    res, code = forum_registry.set_crawl_frequency(forum_id, request.form.get('crawl_frequency'))
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, error=res.get('reason')))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, success='Crawl frequency updated'))


@intel_forums.route("/forums/<forum_id>/rss", methods=['POST'])
@login_required
@login_admin
def forum_rss(forum_id):
    res, code = forum_registry.set_rss_url(forum_id, request.form.get('rss_url'))
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, error=res.get('reason')))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, success='RSS feed updated'))


@intel_forums.route("/forums/<forum_id>/poll_rss", methods=['POST'])
@login_required
@login_admin
def forum_poll_rss(forum_id):
    res, code = forum_collector.poll_forum_rss(forum_id)
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, error=res.get('reason')))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, success='RSS poll queued'))


@intel_forums.route("/forums/<forum_id>/search_queries", methods=['POST'])
@login_required
@login_admin
def forum_search_queries(forum_id):
    """Per-forum intelligence queries run against the forum's OWN search.

    Terms are stored separately from the on/off toggle so pausing a noisy
    source never discards its configured query list.
    """
    raw = request.form.get('search_queries') or ''
    enabled = request.form.get('search_enabled') == 'on'
    forum_registry.set_search_queries(forum_id, raw)
    res, code = forum_registry.set_search_enabled(forum_id, enabled)
    if code != 200:
        abort(404)
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id))


@intel_forums.route("/forums/<forum_id>/search_url", methods=['POST'])
@login_required
@login_admin
def forum_search_url(forum_id):
    res, code = forum_registry.set_search_url(forum_id, request.form.get('search_url'))
    if code != 200:
        return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, error=res.get('reason')))
    return redirect(url_for('intel_forums.forum_detail', forum_id=forum_id, success='Search URL updated'))


@intel_forums.route("/forums/<forum_id>/delete", methods=['POST'])
@login_required
@login_admin
def forum_delete(forum_id):
    forum_registry.delete_forum(forum_id)
    return redirect(url_for('intel_forums.forums_list', success=f'Removed forum: {forum_id}'))
