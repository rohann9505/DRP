#!/usr/bin/env python3
# -*-coding:UTF-8 -*

import os
import sys
import ssl
import json
import random
import logging
import logging.config

from flask import Flask, render_template, jsonify, request, Request, Response, session, redirect, url_for
from flask_login import LoginManager, current_user, login_user, logout_user, login_required
from werkzeug.middleware.proxy_fix import ProxyFix

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.ConfigLoader import ConfigLoader
from lib.ail_users import AILUser, get_session_user
from lib import Tag
from lib import ail_core
from lib import ail_logger
from lib import passivedns
from lib.objects import SSHKeys

from packages.git_status import clear_git_meta_cache

# Import config
import Flask_config

# Import Blueprint
#
# Dark Web Intelligence: only the auth blueprint (root) and the product's own
# blueprints (intel_*) are registered below. The rest of AIL Framework's
# blueprints are intentionally left unregistered (not deleted - the backend
# modules they call into may still be used internally) so their routes are
# unreachable from the running application.
from blueprints.root import root
from blueprints.intel_dashboard import intel_dashboard
from blueprints.intel_forums import intel_forums
from blueprints.intel_search import intel_search
from blueprints.intel_reports import intel_reports
from blueprints.intel_system import intel_system
from blueprints.intel_watchlist import intel_watchlist
from blueprints.asset_dashboard import asset_dashboard
from blueprints.asset_target import asset_target
from blueprints.asset_scans import asset_scans


Flask_dir = os.environ['AIL_FLASK']
# templates/ and static/ live in the separate frontend/ tree
Frontend_dir = os.path.join(os.environ['AIL_HOME'], 'frontend')

# CONFIG #
config_loader = ConfigLoader()
baseUrl = config_loader.get_config_str("Flask", "baseurl")
host = config_loader.get_config_str("Flask", "host")
baseUrl = baseUrl.replace('/', '')
if baseUrl != '':
    baseUrl = '/'+baseUrl

try:
    FLASK_PORT = config_loader.get_config_int("Flask", "port")
except Exception:
    FLASK_PORT = 7000

# ========= REDIS =========#
r_serv_db = config_loader.get_db_conn("Kvrocks_DB")

# logs
log_dir = os.path.join(os.environ['AIL_HOME'], 'logs')
if not os.path.isdir(log_dir):
    os.makedirs(log_dir)

# ========= LOGS =========#

access_logger = ail_logger.get_access_config(create=True)

class FilterLogErrors(logging.Filter):
    def filter(self, record):
        # print(dict(record.__dict__))
        if record.levelname == 'ERROR':
            if record.msg.startswith('Error on request:'):
                if 'ssl.SSLEOFError: EOF occurred in violation of protocol' in record.msg:
                    return False
        return True


logging.config.dictConfig(ail_logger.get_config(name='flask'))
flask_logger = logging.getLogger()
ignore_filter = FilterLogErrors()
for handler in flask_logger.handlers:
    handler.addFilter(ignore_filter)


# =========  TLS  =========#

ssl_context = None
self_signed_certfile = os.path.join(Flask_dir, 'server.crt')
self_signed_keyfile = os.path.join(Flask_dir, 'server.key')

if os.path.exists(self_signed_certfile) and os.path.exists(self_signed_keyfile):
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain(certfile=self_signed_certfile, keyfile=self_signed_keyfile)
    ssl_context.suppress_ragged_eofs = True
    # print(ssl_context.get_ciphers())
# =========       =========#

Flask_config.app = Flask(__name__, static_url_path=baseUrl+'/static/',
                         template_folder=os.path.join(Frontend_dir, 'templates'),
                         static_folder=os.path.join(Frontend_dir, 'static'))
app = Flask_config.app
app.config['MAX_CONTENT_LENGTH'] = 2000 * 1024 * 1024

# =========  BLUEPRINT  =========#
app.register_blueprint(root, url_prefix=baseUrl)
app.register_blueprint(intel_dashboard, url_prefix=baseUrl)
app.register_blueprint(intel_forums, url_prefix=baseUrl)
app.register_blueprint(intel_search, url_prefix=baseUrl)
app.register_blueprint(intel_reports, url_prefix=baseUrl)
app.register_blueprint(intel_system, url_prefix=baseUrl)
app.register_blueprint(intel_watchlist, url_prefix=baseUrl)
app.register_blueprint(asset_dashboard, url_prefix=baseUrl)
app.register_blueprint(asset_target, url_prefix=baseUrl)
app.register_blueprint(asset_scans, url_prefix=baseUrl)


# The Asset Intelligence sidebar renders on every page, including Dark Web
# pages whose views know nothing about asset sections - so the section list
# is injected globally rather than being passed by each view (or duplicated
# into the template, where it would drift from the route that validates it).
@app.context_processor
def inject_asset_sections():
    from blueprints.asset_target import TARGET_SECTIONS
    return {'asset_sections': TARGET_SECTIONS}


@app.template_filter('fmt_duration')
def fmt_duration(seconds):
    """Human-readable elapsed time: 12s, 1m 24s, 3m 08s, 1h 05m. Timestamps
    themselves are formatted client-side (local timezone) by the [data-epoch]
    converter in base.html; durations are timezone-independent so they are
    done here where the two epochs are already known."""
    try:
        seconds = int(round(float(seconds)))
    except (TypeError, ValueError):
        return ''
    if seconds < 0:
        return ''
    if seconds < 60:
        return f'{seconds}s'
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f'{minutes}m {sec:02d}s'
    hours, minutes = divmod(minutes, 60)
    return f'{hours}h {minutes:02d}m'


@app.template_filter('epoch_iso')
def epoch_iso(value):
    """Any timestamp -> an ISO-8601 UTC string the [data-epoch-iso] client-side
    converter can render in the viewer's own timezone, so EVERY date in the tool
    shows in one consistent format. Accepts a unix epoch (seconds, int or numeric
    string) or an already-ISO string (passed through). Empty/unparseable -> ''."""
    if value in (None, '', 0, '0'):
        return ''
    try:
        import datetime as _dt
        n = float(value)
        # Treat >~ year 2001 in seconds; milliseconds if absurdly large.
        if n > 1e12:
            n = n / 1000.0
        return _dt.datetime.fromtimestamp(n, _dt.timezone.utc).isoformat()
    except (TypeError, ValueError):
        return str(value)  # already an ISO/human string


@app.template_filter('fmt_day')
def fmt_day(value):
    """Render a stored YYYYMMDD day string as 'Sep 6, 2026'. Date-only values are
    timezone-independent, so they are formatted here rather than client-side.
    Returns the original value unchanged if it is not a YYYYMMDD day."""
    if value in (None, '', 0, '0'):
        return ''
    s = str(value).strip()
    if len(s) == 8 and s.isdigit():
        import datetime as _dt
        try:
            return _dt.datetime.strptime(s, '%Y%m%d').strftime('%b %-d, %Y')
        except ValueError:
            pass
    return s


@app.template_filter('leak_severity')
def leak_severity(category):
    """Severity for a normalised leaked-data category (leak_intel)."""
    from lib import leak_intel
    return leak_intel.CATEGORY_SEVERITY.get(category, 'MEDIUM')


@app.template_filter('leak_label')
def leak_label(category):
    """Human label for a normalised leaked-data category (leak_intel)."""
    from lib import leak_intel
    return leak_intel.CATEGORY_LABELS.get(category, (category or '').replace('_', ' ').title())


@app.template_filter('mask_cred')
def mask_cred(value):
    """Mask a leaked identifier for display: keep the first character and the
    domain, blank the rest (e.g. 'john.doe@versa-networks.com' ->
    'j****@versa-networks.com'). The e-mail/username is shown partially so an
    analyst can act, without republishing the full credential. Never applied to
    a password - those are not stored at all, only their presence is shown."""
    if not value:
        return value
    s = str(value)
    if '@' in s:
        local, _, domain = s.partition('@')
        head = local[0] if local else ''
        return f'{head}{"*" * max(3, len(local) - 1)}@{domain}'
    if len(s) <= 2:
        return '*' * len(s)
    return f'{s[0]}{"*" * max(3, len(s) - 2)}{s[-1]}'


@app.template_filter('highlight_query')
def highlight_query(text, query):
    """Wrap every case-insensitive occurrence of the searched keyword/domain in
    a <mark> so an analyst can immediately SEE where, and how often, the query
    matched inside the retrieved extract. The text is HTML-escaped first and the
    query is matched against that escaped form, so only our own <mark> tags are
    ever emitted - no untrusted markup can reach the page."""
    import re as _re
    from markupsafe import Markup, escape
    escaped = str(escape(text or ''))
    q = (query or '').strip()
    if not q:
        return Markup(escaped)
    q_esc = str(escape(q))
    try:
        pattern = _re.compile(_re.escape(q_esc), _re.IGNORECASE)
    except _re.error:
        marked = escaped
    else:
        marked = pattern.sub(lambda m: f'<mark class="q-hl">{m.group(0)}</mark>', escaped)
    # Badge the redaction markers in place. This is the authenticity proof: a
    # real leak shows exactly WHERE each secret sat (a fabricated one has
    # nothing to redact). The value stays withheld; the marker stays visible.
    marked = _re.sub(r'\[REDACTED[^\]]*\]',
                     lambda m: f'<span class="redact-badge" title="A real secret was found here and withheld from display by policy">{m.group(0)}</span>',
                     marked)
    return Markup(marked)


_LEAK_LABELS = {
    'secret_fields': 'Credential leak (passwords / keys)',
    'credential_pairs': 'Credential pairs (user:pass)',
    'tokens': 'API tokens',
    'private_keys': 'Private keys',
    'payment_cards': 'Payment cards',
    'emails': 'Emails',
    'ipv4': 'IP addresses',
    'btc': 'BTC addresses',
    'onion': 'Onion URLs',
    'hashes': 'Password hashes',
}


@app.template_filter('leak_breakdown')
def leak_breakdown(indicators):
    """Flatten an indicators dict (including the nested `credentials` sub-dict)
    into labelled (category, count) pairs for display - named categories such as
    'Credential leak' and 'Payment cards', counts only. No secret VALUE is ever
    contained in or produced by this; the values were redacted at collection."""
    out = []
    for k, v in (indicators or {}).items():
        if isinstance(v, dict):
            for kk, vv in v.items():
                out.append((_LEAK_LABELS.get(kk, kk.replace('_', ' ').title()), vv))
        else:
            out.append((_LEAK_LABELS.get(k, k.replace('_', ' ').title()), v))
    # Credential-bearing categories first, then the rest.
    _priority = {'Credential leak (passwords / keys)': 0, 'Credential pairs (user:pass)': 1,
                 'Payment cards': 2, 'API tokens': 3, 'Private keys': 4, 'Password hashes': 5}
    out.sort(key=lambda p: _priority.get(p[0], 50))
    return out


@app.template_filter('excerpt_around')
def excerpt_around(text, query, size=4000, lead=600):
    """Return the slice of `text` CENTRED on the first occurrence of `query`, so
    the matched term is visible (and highlightable) rather than cut off at the
    top of a long thread. Falls back to the head when the term is absent."""
    text = text or ''
    q = (query or '').strip()
    if not q:
        return text[:size]
    i = text.lower().find(q.lower())
    if i < 0:
        return text[:size]
    start = max(0, i - lead)
    seg = text[start:start + size]
    return ('…' + seg) if start > 0 else seg


@app.template_filter('fmt_ttl')
def fmt_ttl(seconds):
    """DNS TTL in human-readable form: 60 sec, 5 min, 1 hr, 1 day."""
    try:
        seconds = int(seconds)
    except (TypeError, ValueError):
        return ''
    if seconds < 0:
        return ''
    if seconds < 60:
        return f'{seconds} sec'
    if seconds < 3600:
        m = seconds // 60
        return f'{m} min' if seconds % 60 == 0 else f'{m} min {seconds % 60} sec'
    if seconds < 86400:
        h = seconds // 3600
        rem = (seconds % 3600) // 60
        return f'{h} hr' if rem == 0 else f'{h} hr {rem} min'
    d = seconds // 86400
    rem_h = (seconds % 86400) // 3600
    return f'{d} day' + ('s' if d != 1 else '') + (f' {rem_h} hr' if rem_h else '')

# =========       =========#

# ========= Cookie name ========
app.config.update(SESSION_COOKIE_NAME='ail_framework_{}'.format(ail_core.get_ail_uuid_int()))

# ========= session ========
app.secret_key = str(random.getrandbits(256))
login_manager = LoginManager()
login_manager.login_view = 'root.login'
login_manager.init_app(app)

# ========= LOGIN MANAGER ========

@login_manager.user_loader
def load_user(session_id):
    # print(session)
    user_id = get_session_user(session_id)
    if user_id:
        user = AILUser.get(user_id)
        # print(user)
        return user
    return None


# ========= JINJA2 FUNCTIONS ========
def list_len(s):
    return len(s)


app.jinja_env.filters['list_len'] = list_len

# ========= PROXY ========
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1)


# ========= CACHE CONTROL ========
@app.after_request
def add_header(response):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    response.headers['X-UA-Compatible'] = 'IE=Edge,chrome=1'
    # HTML documents must never be served from cache: the page carries the
    # versioned <link> tags and body classes that pull the current CSS, so a
    # stale HTML document silently pins the browser to an old stylesheet even
    # after the CSS itself is cache-busted. `no-store` forces a fresh document
    # on every navigation (normal reload, no hard-refresh needed). Static
    # assets keep their own caching (they are cache-busted with ?v=).
    ctype = response.headers.get('Content-Type', '')
    if ctype.startswith('text/html'):
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
    elif 'Cache-Control' not in response.headers:
        response.headers['Cache-Control'] = 'private, max-age=0'
    return response

# ========== USERS ============
@app.before_request
def before_request():
    if current_user.is_authenticated:
        current_user.update_last_seen()


# ========== ROUTES ============

#@app.route('/endpoints')
#def endpoints():
#    for rule in app.url_map.iter_rules():
#        str_endpoint = str(rule)
#        if len(str_endpoint)>5:
#            if str_endpoint[0:5]=='/api/': ## add baseUrl ???
#                print(str_endpoint)
#                #print(rule.endpoint) #internal endpoint name
#                #print(rule.methods)
#    return 'ok'

# ========== ERROR HANDLER ============

@app.errorhandler(405)
def _handle_client_error(e):
    if request.path.startswith('/api/'): ## # TODO: add baseUrl
        res_dict = {"status": "error", "reason": "Method Not Allowed: The method is not allowed for the requested URL"}
        anchor_id = request.path[8:]
        anchor_id = anchor_id.replace('/', '_')
        api_doc_url = 'https://github.com/ail-project/ail-framework/tree/master/doc#{}'.format(anchor_id)
        res_dict['documentation'] = api_doc_url
        return Response(json.dumps(res_dict) + '\n', mimetype='application/json'), 405
    else:
        return e

@app.errorhandler(403)
def error_page_not_found(e):
    if request.path.startswith('/api/'): ## # TODO: add baseUrl
        return Response(json.dumps({"status": "error", "reason": "403 Access Denied"}) + '\n', mimetype='application/json'), 403
    else:
        # avoid endpoint enumeration
        return page_forbidden(e)

@app.errorhandler(404)
def error_page_not_found(e):
    if request.path.startswith('/api/'): ## # TODO: add baseUrl
        return Response(json.dumps({"status": "error", "reason": "404 Not Found"}) + '\n', mimetype='application/json'), 404
    else:
        # avoid endpoint enumeration
        return page_not_found(e)

@app.errorhandler(500)
def _handle_client_error(e):
    if request.path.startswith('/api/'):
        return Response(json.dumps({"status": "error", "reason": "Server Error"}) + '\n', mimetype='application/json'), 500
    else:
        if current_user:
            try:
                flask_logger.warning(f'User: {current_user.get_user_id()}')
            except AttributeError as e:
                flask_logger.warning(f'Anonymous User error (AnonymousUserMixin, user not logged)')
        return e

@login_required
def page_forbidden(e):
    return render_template("error/403.html"), 403

@login_required
def page_not_found(e):
    # avoid endpoint enumeration
    return render_template('error/404.html'), 404


# ========== INITIAL taxonomies ============
if not Tag.is_taxonomy_enabled("infoleak"):
    default_taxonomies = ["infoleak", "gdpr", "fpf", "dark-web"]
    # enable default taxonomies
    for taxonomy in default_taxonomies:
        Tag.enable_taxonomy_tags(taxonomy)

# ========== GIT Cache ============
clear_git_meta_cache()

# Passive SSH
if not SSHKeys.get_passive_ssh_url():
    SSHKeys.set_default_passive_ssh()
# Passive DNS
if not passivedns.get_passive_dns_url():
    passivedns.set_default_passive_dns()

# r = [str(p) for p in app.url_map.iter_rules()]
# for p in r:
#     print(p)

# ============ MAIN ============

if __name__ == "__main__":
    app.run(host=host, port=FLASK_PORT, threaded=True, ssl_context=ssl_context)
