#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Alert Dispatch Worker
===================

Pops queued watchlist alerts (lib.alert_dispatch) and delivers them over
whatever channels are configured (webhook / Telegram / email) - see the
System page for configuration. Kept as its own process, same shape as
DomainIntelWorker.py/ForumMonitorWorker.py, so a slow or failing delivery
(network timeout, bad SMTP creds) never touches the capture pipeline that
queues the alerts in the first place.
"""

import os
import sys
import time
import traceback

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import alert_dispatch


def main():
    print('AlertDispatchWorker started, waiting for alerts...')
    while True:
        try:
            alert_id = alert_dispatch.pop_queued_delivery(timeout=5)
            if not alert_id:
                continue
            delivered = alert_dispatch.dispatch_one(alert_id)
            print(f'Alert {alert_id} delivered via: {delivered or "no channels configured"}')
        except KeyboardInterrupt:
            break
        except Exception:
            traceback.print_exc()
            time.sleep(2)


if __name__ == '__main__':
    main()
