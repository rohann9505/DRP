#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Forum Monitor Worker
===================

Continuous-monitoring loop: on a fixed interval, polls every registered,
enabled forum that has an RSS/syndication feed configured (see
forum_registry.set_rss_url), queuing a capture of just that feed URL
(tagged so Crawler.py routes it to forum_collector.process_rss_feed instead
of indexing it as a document). process_rss_feed then queues capture_page()
for any genuinely new thread it finds, and that capture - once it comes
back through the normal pipeline - runs the watchlist check automatically
(forum_collector.record_forum_document -> _check_watchlist). This is what
makes "give me a domain/keyword once, get notified as soon as it's posted"
actually continuous rather than only ever running when someone happens to
click Collect.

Also drives each forum's "Crawl Frequency" setting (see
forum_registry.set_crawl_frequency) - confirmed that field was pure UI
decoration until this: nothing anywhere actually read it, so setting a
forum to "daily" silently did nothing and bulk collection only ever ran
when an admin clicked Collect Now by hand. This loop is the scheduler for
it now - same due-check pattern as RSS polling, just against
last_successful_crawl instead of last_rss_poll.

Deliberately its own small loop rather than folded into Crawler.py: polling
is a scheduling concern (when to check), not a capture-processing concern
(what to do with a result) - Crawler.py already does the latter for
whatever gets queued, regardless of who queued it.
"""

import os
import sys
import time
import traceback

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_registry
from lib import forum_collector
from lib import forum_metrics
from lib import forum_ingest

# How often each forum's RSS feed is re-polled. Widened from 10 minutes to
# 3 hours to keep the request footprint against each forum minimal - fewer
# chances to trip anti-bot protection the way rapid-fire search requests
# did earlier this session (xforums.st's "DNSPROXY ANTIBOT" challenge after
# ~10 requests in ~20 min). Trade-off: a new thread can now take up to 3
# hours to surface as a watchlist alert instead of up to 10 minutes.
POLL_INTERVAL_SECONDS = 3 * 60 * 60
# Wakes every 20s so a per-forum "every 1 minute" schedule is actually
# honourable. The old 300s tick made any sub-5-minute frequency impossible to
# express regardless of what the UI offered.
TICK_SECONDS = 20

FREQUENCY_SECONDS = {
    'every_1min': 60,
    'every_5min': 5 * 60,
    'every_15min': 15 * 60,
    'every_30min': 30 * 60,
    'hourly': 60 * 60,
    'daily': 24 * 60 * 60,
    'weekly': 7 * 24 * 60 * 60,
    'monthly': 30 * 24 * 60 * 60,
}


def _due_forums():
    due = []
    now = int(time.time())
    # onion_only: the monitored collection pool is dark-web scoped. Clearnet
    # sources stay registered and re-crawlable on demand, but this scheduler
    # does not pick them up.
    for forum in forum_registry.list_forums(onion_only=True):
        if not forum.get('enabled') or not forum.get('rss_url'):
            continue
        last_poll = forum.get('last_rss_poll')
        if not last_poll or (now - int(last_poll)) >= POLL_INTERVAL_SECONDS:
            due.append(forum)
    return due


def _due_for_bulk_collection():
    """Forums whose configured crawl frequency says they're due now.

    A forum whose previous crawl is still running is NOT returned - the run is
    recorded as skipped instead (forum_metrics.record_skipped_run), which is
    what keeps an 'every 1 minute' schedule from stacking overlapping crawls
    when one takes longer than a minute.
    """
    due = []
    now = int(time.time())
    # Every enabled forum the UI lets you set a frequency on, not just onion
    # sources. The forum list and the per-forum Crawl Frequency control are
    # shown for clearnet forums too, so the scheduler must honour them there as
    # well - otherwise the dropdown is cosmetic for a clearnet source. (RSS
    # polling above stays dark-web scoped; this is the bulk-crawl schedule.)
    for forum in forum_registry.list_forums():
        if not forum.get('enabled'):
            continue
        freq = forum.get('crawl_frequency')
        if freq == 'disabled':
            continue
        interval = FREQUENCY_SECONDS.get(freq)
        if not interval:
            continue  # 'manual' (or unset) - never auto-triggered
        fid = forum['id']
        if forum_metrics.is_running(fid):
            forum_metrics.record_skipped_run(fid)
            continue
        # A forum whose persistent session has lapsed cannot be auto-recovered -
        # it needs the operator to log in again (forum_session_login). Re-firing
        # it every tick would just re-hit the login wall and, against a source
        # that already flagged us, be needlessly abusive. Skip only THIS forum;
        # every healthy forum below still runs. Cleared automatically once a
        # re-login flips the session back to valid.
        sh = forum.get('session_health') or {}
        if sh.get('needs_operator'):
            forum_metrics.record_skipped_run(
                fid, why=f"session {sh.get('state')} - operator re-login required")
            continue
        # Schedule against the last ATTEMPT, not the last success: a forum
        # that is blocked never records a success, and scheduling on success
        # alone would re-fire it every single tick forever.
        last = forum_metrics.get_last_run(fid)
        last_at = (last or {}).get('recorded_at') or forum.get('last_successful_crawl')
        if not last_at or (now - int(last_at)) >= interval:
            due.append(forum)
    return due


def main():
    print(f'ForumMonitorWorker started, polling every {POLL_INTERVAL_SECONDS}s per forum, '
          f'plus per-forum scheduled bulk collection...')
    while True:
        try:
            # Operator-requested crawls first (Collect Now / Full Resync).
            # These are queued by the Flask routes so a request never blocks
            # on a multi-minute paginated walk.
            while True:
                job = forum_metrics.pop_crawl_job()
                if not job:
                    break
                fid = job.get('forum_id')
                try:
                    res = forum_ingest.run_forum_crawl(
                        fid, full_resync=job.get('full_resync', False))
                except Exception:
                    print(f"Queued crawl FAILED for {fid} - draining rest of queue:")
                    traceback.print_exc()
                    try:
                        forum_metrics.mark_finished(fid, status='error')
                    except Exception:
                        pass
                    continue
                if res.get('skipped'):
                    print(f"Queued crawl skipped for {fid}: {res.get('reason')}")
                elif res.get('error'):
                    print(f"Queued crawl error for {fid}: {res.get('error')}")
                else:
                    print(f"Queued crawl done for {fid}: "
                          f"{res.get('documents_stored')} new / "
                          f"{res.get('pages_fetched')} pages / "
                          f"{res.get('termination_reason')}")

            for forum in _due_forums():
                # PER-FORUM ISOLATION. Without this, an exception escaping one
                # forum unwinds to the outer handler and silently skips every
                # REMAINING forum in the tick - so one dead source stops all
                # the healthy ones. Each forum is contained to itself.
                try:
                    res, code = forum_collector.poll_forum_rss(forum['id'])
                    if code == 200:
                        print(f"Polled RSS for {forum['id']} ({forum['name']})")
                    else:
                        print(f"RSS poll skipped for {forum['id']}: {res.get('reason')}")
                except Exception:
                    print(f"RSS poll FAILED for {forum['id']} - continuing with other forums:")
                    traceback.print_exc()

            for forum in _due_for_bulk_collection():
                # Runs the real paginating incremental crawl in-process.
                # Incremental by default: the cursor means a 1-minute schedule
                # fetches only newly-posted threads, not the whole history.
                # Isolated for the same reason as the RSS loop above.
                try:
                    res = forum_ingest.run_forum_crawl(forum['id'])
                    if res.get('skipped'):
                        print(f"Crawl skipped for {forum['id']}: {res.get('reason')}")
                    elif res.get('error'):
                        print(f"Crawl error for {forum['id']}: {res.get('error')}")
                    else:
                        print(f"Crawl done for {forum['id']} ({forum['name']}, "
                              f"freq={forum.get('crawl_frequency')}): "
                              f"{res.get('documents_stored')} new / "
                              f"{res.get('pages_fetched')} pages / "
                              f"{res.get('termination_reason')}")
                except Exception:
                    # Recorded, reported, and the loop moves on to the next
                    # forum rather than abandoning the rest of the tick.
                    print(f"Crawl FAILED for {forum['id']} - continuing with other forums:")
                    traceback.print_exc()
                    try:
                        forum_metrics.mark_finished(forum['id'], status='error')
                        forum_registry.record_crawl_result(
                            forum['id'], success=False, error='worker exception')
                    except Exception:
                        pass
            time.sleep(TICK_SECONDS)
        except KeyboardInterrupt:
            break
        except Exception:
            traceback.print_exc()
            time.sleep(5)


if __name__ == '__main__':
    main()
