#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Asset Intelligence Worker
===================

Two responsibilities in one loop (same merge this session already applied
to ForumMonitorWorker.py for RSS polling + scheduled bulk collection):

  1. Pops queued Asset Intelligence scan jobs (lib.asset_jobs) and executes
     them - manual "scan this domain" / "rescan" requests.
  2. Periodically checks every enabled target with a recurring
     scan_frequency set and queues a fresh scan job for any that are due -
     this is what actually detects a previously disconnected asset coming
     back online, rather than only ever finding out on the next manual
     rescan.
"""

import os
import sys
import time
import traceback

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import asset_jobs
from lib import asset_registry

PERIODIC_CHECK_INTERVAL = 300  # how often to check for targets due for a recurring rescan

FREQUENCY_SECONDS = {
    'hourly': 60 * 60,
    'daily': 24 * 60 * 60,
    'weekly': 7 * 24 * 60 * 60,
    'monthly': 30 * 24 * 60 * 60,
}


def _due_for_scan():
    due = []
    now = int(time.time())
    for target in asset_registry.list_targets():
        if not target.get('enabled'):
            continue
        interval = FREQUENCY_SECONDS.get(target.get('scan_frequency'))
        if not interval:
            continue  # 'manual' - never auto-triggered
        last = target.get('last_scan_completed')
        if not last:
            continue  # never-scanned targets are seeded by the initial manual scan, not this loop
        if (now - int(last)) >= interval:
            due.append(target)
    return due


def _queue_due_scans():
    for target in _due_for_scan():
        if asset_registry.is_circuit_open(target['id']):
            continue
        asset_jobs.create_job(target['id'])
        print(f"Scheduled recurring scan queued for {target['id']} (frequency={target.get('scan_frequency')})")


def main():
    requeued = asset_jobs.recover_orphaned_jobs()
    if requeued:
        print(f'Recovered {len(requeued)} orphaned RUNNING job(s), re-queued: {requeued}')
    print('AssetIntelWorker started, waiting for jobs...')
    last_periodic_check = 0.0
    while True:
        try:
            job_id = asset_jobs.pop_queued_job(timeout=5)
            if job_id:
                print(f'Running asset scan job {job_id}')
                asset_jobs.run_job(job_id)
                print(f'Finished asset scan job {job_id}')

            now = time.time()
            if now - last_periodic_check >= PERIODIC_CHECK_INTERVAL:
                _queue_due_scans()
                last_periodic_check = now
        except KeyboardInterrupt:
            break
        except Exception:
            traceback.print_exc()
            time.sleep(2)


if __name__ == '__main__':
    main()
