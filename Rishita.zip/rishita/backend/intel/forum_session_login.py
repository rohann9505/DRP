#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Operator session bootstrap for a persistent per-forum profile.

This is the ONE manual step behind Anorphix's authenticated collection, and the
only place a human is in the loop. It opens the forum in a real, visible browser
that writes to the forum's persistent profile. You log in yourself - and solve
any CAPTCHA yourself, exactly as in your own browser. Nothing here automates,
guesses, solves or bypasses a login or a challenge; it only opens a window and
keeps whatever session you establish.

Once you close the window, the established session lives in the profile and every
later scheduled crawl reuses it (Requests + Playwright share it). When it later
lapses, the crawler DETECTS and CLASSIFIES that, records per-forum session
health, and pauses only that forum while the rest keep collecting.

Usage:
    # log in once (headed browser; needs a display):
    AILENV/bin/python3 bin/intel/forum_session_login.py <forum_id>
    AILENV/bin/python3 bin/intel/forum_session_login.py <forum_id> --url https://forum/login

    # just check the stored session's health (headless probe, no window):
    AILENV/bin/python3 bin/intel/forum_session_login.py <forum_id> --validate
"""

import argparse
import os
import sys

sys.path.append(os.environ['AIL_BIN'])

from lib import forum_registry
from lib import forum_session
from lib import forum_search  # provider lookup for markers / probe path


def _provider_for(forum_id):
    try:
        return forum_search.get_search_provider(forum_id)
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser(description='Establish/validate a forum session.')
    ap.add_argument('forum_id')
    ap.add_argument('--url', help='page to open (default: the forum base URL / login)')
    ap.add_argument('--validate', action='store_true',
                    help='headless health check only, do not open a window')
    ap.add_argument('--engine', choices=('chromium', 'firefox'),
                    help='browser engine for the login window (default: the '
                         'forum\'s stored browser_engine, else chromium)')
    args = ap.parse_args()

    forum, code = forum_registry.get_forum(args.forum_id)
    if code != 200:
        print(f'unknown forum: {args.forum_id}')
        return 2
    route = forum_registry.resolve_route(args.forum_id)
    provider = _provider_for(args.forum_id)
    base_url = forum.get('url')
    engine = args.engine or forum.get('browser_engine') or 'chromium'

    if args.validate:
        probe = provider.session_probe_url(base_url) if provider else base_url
        state, detail = forum_session.validate_session(
            args.forum_id, probe, provider=provider, route=route)
        print(f'session state: {state}' + (f' ({detail})' if detail else ''))
        return 0

    url = args.url or base_url
    print(f'Opening {url} in a headed {engine} browser on the persistent '
          f'profile for {args.forum_id}.\nLog in (and solve any CAPTCHA) '
          f'yourself, then close the window.')
    forum_session.open_login(args.forum_id, url, route=route, engine=engine)

    # Confirm what was established, without storing any page.
    probe = provider.session_probe_url(base_url) if provider else base_url
    state, detail = forum_session.validate_session(
        args.forum_id, probe, provider=provider, route=route)
    print(f'session now: {state}' + (f' ({detail})' if detail else ''))
    if state == forum_session.SESSION_VALID:
        print('Session established and persisted. Scheduled crawls will reuse it.')
    else:
        print('No valid session detected yet - re-run and complete the login.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
