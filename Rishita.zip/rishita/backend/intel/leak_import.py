#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Operator-triggered leak-site import (The Gentlemen and similar blogs).

Opens the leak site in a HEADED browser on this forum's persistent profile so
the operator can clear the PoW+CAPTCHA THEMSELVES - exactly as in their own
browser. Once cleared, the site's SPA fetches its own `/api/companies` list; we
INTERCEPT that response and store every victim as a forum document (company,
domain, leak description). Nothing here solves, guesses or bypasses the
challenge - it only reads what the human's cleared session received.

Before opening the window it checks the hidden service actually answers over
Tor. A down/unreachable onion would otherwise open a window stuck forever on
"Connecting..."; instead the operator gets a clear "site unreachable" result.

Usage (normally launched from the UI, not by hand):
    AILENV/bin/python3 bin/intel/leak_import.py <forum_id> [--timeout 720]
"""

import argparse
import os
import socks
import sys
import time

sys.path.append(os.environ['AIL_BIN'])

from lib import forum_registry
from lib import forum_session
from lib import forum_browser
from lib import gentlemen_intel


def _tor_socks():
    """(host, port) of the SOCKS proxy used to reach onions - the crawler's."""
    raw = os.environ.get('FORUM_CRAWL_TOR_PROXY', 'socks5h://127.0.0.1:9050')
    hostport = raw.split('://', 1)[-1].split('/', 1)[0]
    host, _, port = hostport.partition(':')
    return host or '127.0.0.1', int(port or 9050)


def _onion_reachable(host, port, attempts=2, timeout=45):
    """True if Tor can open a TCP stream to the hidden service.

    This probes the TOR layer only (the SOCKS CONNECT), sending no HTTP. That
    is exactly the layer that fails when the service is offline, and it is
    independent of the site's HTTP anti-bot - so a live-but-protected site is
    never wrongly reported as down.
    """
    proxy_host, proxy_port = _tor_socks()
    for _ in range(attempts):
        s = socks.socksocket()
        s.set_proxy(socks.SOCKS5, proxy_host, proxy_port, rdns=True)
        s.settimeout(timeout)
        try:
            s.connect((host, port))
            return True
        except Exception:
            pass
        finally:
            try:
                s.close()
            except Exception:
                pass
    return False


def main():
    ap = argparse.ArgumentParser(description='Import a leak site victim list as documents.')
    ap.add_argument('forum_id')
    ap.add_argument('--timeout', type=int, default=720,
                    help='seconds to wait for the operator to clear the challenge')
    args = ap.parse_args()
    fid = args.forum_id

    forum, code = forum_registry.get_forum(fid)
    if code != 200:
        print(f'unknown forum: {fid}')
        return 2
    site = gentlemen_intel.leak_site_for(fid)
    if not site:
        print(f'{fid} is not a configured leak site')
        return 2

    url = f'http://{site["host"]}/'
    engine = forum_session._engine_for(fid)
    proxy, use_default = forum_session._route_to_proxy(forum_registry.resolve_route(fid))

    # Pre-flight: is the hidden service even up right now? If not, don't open a
    # window that would just hang on "Connecting..." - tell the operator.
    print('Checking the leak site is reachable over Tor…', flush=True)
    if not _onion_reachable(site['host'], 80):
        msg = ('Leak site did not answer over Tor — the hidden service looks '
               'offline right now. Try again later.')
        print(msg, flush=True)
        forum_session.set_leak_import_result(fid, msg)
        return 1

    # Wait for the profile lock to free - the operator may still have a login
    # window open on the same profile (a browser can't open it twice).
    session = None
    for _ in range(36):
        try:
            session = forum_browser.BrowserSession(
                proxy=proxy, use_default_proxy=use_default, headless=False,
                user_data_dir=forum_session.profile_dir(fid), engine=engine).start()
            break
        except Exception as e:
            last = e
            time.sleep(5)
    if session is None:
        msg = f'Could not open the import window (profile busy?): {last}'
        print(msg)
        forum_session.set_leak_import_result(fid, msg)
        return 1

    page = session._page
    captured = {}

    def on_response(resp):
        try:
            if gentlemen_intel.CAPTURE_ENDPOINT in resp.url and resp.status == 200:
                body = resp.text()
                if body and len(body) > 50:
                    captured['body'] = body
        except Exception:
            pass
    page.on('response', on_response)

    print('WINDOW OPEN. Clear the PoW+CAPTCHA in this window; import is automatic.',
          flush=True)
    print('(Onions load slowly over Tor - give it a moment before it shows the page.)',
          flush=True)
    try:
        page.goto(url, timeout=forum_browser.NAV_TIMEOUT_MS, wait_until='domcontentloaded')
    except Exception as e:
        # A slow first load or a transient Tor hiccup must NOT end the import -
        # the window stays open so the operator can reload and clear the check.
        # But if the window is already gone, stop now instead of polling for ages.
        print(f'initial load issue ({type(e).__name__}: {str(e)[:120]}).', flush=True)

    closed = False
    deadline = time.time() + args.timeout
    while time.time() < deadline and 'body' not in captured:
        try:
            if page.is_closed():
                closed = True
                break
        except Exception:
            closed = True
            break
        time.sleep(3)
    try:
        session.close()
    except Exception:
        pass

    if 'body' not in captured:
        if closed:
            msg = 'Import window was closed before the list loaded — nothing imported.'
        else:
            msg = 'Challenge was not cleared in time — nothing imported.'
        print(msg)
        forum_session.set_leak_import_result(fid, msg)
        return 1
    stored, dup, total = gentlemen_intel.store_companies(fid, captured['body'])
    msg = f'Imported {stored} new, {dup} already stored — {total} documents total.'
    print(msg, flush=True)
    forum_session.set_leak_import_result(fid, msg)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
