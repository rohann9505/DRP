#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Onion-only crawl diagnostic
===========================

Answers exactly one question:

    "Can Anorphix retrieve forum content from onion services through Tor and
     store real forum documents?"

Rules this harness enforces, because a diagnostic that cheats is worse than
no diagnostic at all:

  * TARGETS ARE REGISTRY ONION FORUMS ONLY. A source is included only if its
    STORED url/source_type is .onion/.i2p - never inferred from its name, and
    never padded with clearnet sites, news feeds or threat-intel APIs to make
    the pass count look better.
  * ONION -> TOR -> ONION. If the resolved route is not Tor, the forum is a
    FAILURE, not a fallback. A clearnet connection for an onion source is
    never acceptable and is reported as ROUTE_NOT_TOR.
  * A 200 on the homepage is NOT success. Success requires the full path:
    index -> board -> pagination -> thread -> post -> parser -> persistence,
    ending in documents actually stored.
  * Failures are classified precisely. "Timeout" is not an acceptable label
    for a hidden service with no published descriptor.
  * Never prints cookie values, passwords, session tokens or Authorization
    headers - only counts, names, domains and expiry.

Usage:  python3 onion_crawl_diagnostic.py [--crawl]
        --crawl performs the real paginated crawl (slow). Without it, only
        the transport/route/reachability layers are exercised.
"""

import os
import sys
import time
from urllib.parse import urlparse

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_registry
from lib import forum_crawl
from lib import forum_ingest
from lib import forum_metrics
from lib import crawlers
from lib.forum_providers import base as fp_base

TOR_TEST_ONION = 'http://2gzyxa5ihm7nsggfxnu52rck2vv4rvmdlkiu3zzui5du4xyclen53wid.onion/'
TOR_CHECK_API = 'https://check.torproject.org/api/ip'

# Precise failure vocabulary - see requirement 8.
TOR_UNAVAILABLE = 'TOR_UNAVAILABLE'
ROUTE_NOT_TOR = 'ROUTE_NOT_TOR'
ONION_UNRESOLVABLE = 'ONION_UNRESOLVABLE'
HIDDEN_SERVICE_OFFLINE = 'HIDDEN_SERVICE_OFFLINE'
CONNECTION_TIMEOUT = 'CONNECTION_TIMEOUT'
HTTP_403 = 'HTTP_403'
HTTP_429 = 'HTTP_429'
HTTP_5XX = 'HTTP_5XX'
AUTH_REQUIRED = 'AUTH_REQUIRED'
NO_COOKIEJAR = 'AUTH_REQUIRED / NO_COOKIEJAR'
COOKIE_INVALID = 'COOKIE_INVALID'
ANTI_BOT_CHALLENGE = 'ANTI_BOT_CHALLENGE'
PARSER_FAILURE = 'PARSER_FAILURE'
PAGINATION_FAILURE = 'PAGINATION_FAILURE'
NO_DOCUMENTS = 'NO_DOCUMENTS'
SUCCESS = 'SUCCESS'

# Tor's own wording when the hashring has no descriptor for a service.
_OFFLINE_MARKERS = ('no more hsdir', 'host unreachable', 'ttl expired',
                    'general socks server failure', 'connection not allowed')


def _hr(char='-', n=100):
    print(char * n)


# ---------------------------------------------------------------------------
# Layer 1: is Tor itself usable?
# ---------------------------------------------------------------------------

def verify_tor():
    """Returns (ok, details). Nothing below runs if this fails."""
    import socket
    import requests

    out = {}
    print('# TOR TRANSPORT VERIFICATION')
    _hr()

    # 1. SOCKS port listening
    sock = socket.socket()
    sock.settimeout(5)
    try:
        sock.connect(('127.0.0.1', 9050))
        out['port'] = True
        print('  127.0.0.1:9050 listening            : YES')
    except Exception as e:
        out['port'] = False
        print(f'  127.0.0.1:9050 listening            : NO ({type(e).__name__})')
        return False, out
    finally:
        sock.close()

    # 2. Exit-node confirmation. socks5h so DNS resolves through Tor too.
    proxies = {'http': 'socks5h://127.0.0.1:9050',
               'https': 'socks5h://127.0.0.1:9050'}
    try:
        r = requests.get(TOR_CHECK_API, proxies=proxies, timeout=45)
        data = r.json()
        out['is_tor'] = bool(data.get('IsTor'))
        out['exit_ip'] = data.get('IP')
        print(f"  check.torproject.org IsTor          : {data.get('IsTor')}")
        print(f"  Tor exit IP                         : {data.get('IP')}")
    except Exception as e:
        out['is_tor'] = False
        print(f'  check.torproject.org                : FAILED ({type(e).__name__})')
        return False, out

    # 3. A known-legitimate hidden service must resolve, or onion lookups are
    #    broken locally and every forum failure below would be misattributed.
    t0 = time.time()
    try:
        r = requests.get(TOR_TEST_ONION, proxies=proxies, timeout=90)
        out['onion_ok'] = (r.status_code == 200)
        print(f'  known-good .onion (torproject)      : HTTP {r.status_code} '
              f'in {time.time() - t0:.1f}s')
    except Exception as e:
        out['onion_ok'] = False
        print(f'  known-good .onion (torproject)      : FAILED ({type(e).__name__})')
        return False, out

    if not out.get('is_tor'):
        return False, out
    print('  VERDICT                             : Tor transport OPERATIONAL')
    _hr()
    print()
    return True, out


# ---------------------------------------------------------------------------
# Layer 2: which registry sources are actually onion?
# ---------------------------------------------------------------------------

def onion_forums():
    """Registry forums whose STORED url/source_type is a hidden service."""
    out = []
    for f in forum_registry.list_forums():
        host = (urlparse(f.get('url') or '').hostname or '').lower()
        if host.endswith('.onion') or host.endswith('.i2p') \
                or f.get('source_type') in ('onion', 'i2p'):
            out.append(f)
    return out


def _cookiejar_summary(uuid):
    """Metadata ONLY - never a cookie value."""
    if not uuid:
        return {'uuid': None, 'count': 0, 'names': [], 'domains': []}
    try:
        jar = crawlers.Cookiejar(uuid)
        if not jar.exists():
            return {'uuid': uuid, 'count': 0, 'names': [], 'domains': [],
                    'missing': True}
        names, domains = [], set()
        for c in jar.get_cookies():
            if c.get('name'):
                names.append(c['name'])
            if c.get('domain'):
                domains.add(c['domain'])
        return {'uuid': uuid, 'count': len(names), 'names': names,
                'domains': sorted(domains)}
    except Exception as e:
        return {'uuid': uuid, 'count': 0, 'names': [], 'domains': [],
                'error': type(e).__name__}


def classify_transport_error(err):
    low = (err or '').lower()
    if any(m in low for m in _OFFLINE_MARKERS):
        return HIDDEN_SERVICE_OFFLINE
    if 'timeout' in low or 'timed out' in low:
        # For an onion, tor holds the connection open while retrying the
        # HSDir hashring, so OUR timeout is the usual shape of "no descriptor".
        return HIDDEN_SERVICE_OFFLINE
    if 'name or service not known' in low or 'failed to resolve' in low:
        return ONION_UNRESOLVABLE
    return CONNECTION_TIMEOUT


def diagnose_forum(forum, do_crawl=False):
    """Full per-forum trace. Returns a result dict with a precise verdict."""
    fid = forum['id']
    url = forum.get('url')
    host = (urlparse(url or '').hostname or '')
    res = {'forum': fid, 'url': url, 'host': host, 'verdict': None}

    route = forum_registry.resolve_route(fid)
    jar = _cookiejar_summary(forum.get('cookiejar_uuid'))
    res['route'] = route
    res['cookiejar'] = jar

    print(f'Forum              : {fid}')
    print(f'URL                : {url}')
    print(f'source_type        : {forum.get("source_type")}')
    print(f'provider           : {forum.get("provider")}')
    print(f'configured route   : {forum.get("route")}')
    print(f'resolved route     : {route.get("mode")}  ({route.get("reason")})')
    print(f'route forced       : {route.get("forced")}')
    proxy_display = route.get('display')
    if proxy_display:
        p = urlparse(proxy_display if '://' in proxy_display else f'//{proxy_display}')
        print(f'proxy scheme       : {p.scheme or "n/a"}')
        print(f'proxy host/port    : {p.hostname}:{p.port}' if p.hostname else
              f'proxy              : {proxy_display}')
    print(f'cookiejar UUID     : {jar["uuid"] or "(none)"}')
    print(f'cookie count       : {jar["count"]}')
    if jar['names']:
        print(f'cookie names       : {", ".join(jar["names"])}')
        print(f'cookie domains     : {", ".join(jar["domains"])}')
        # Requirement 7: the jar must belong to THIS hidden service.
        if host and not any(host in d or d in host for d in jar['domains']):
            print(f'cookie domain match: NO  <-- jar does not belong to {host}')
            res['cookie_domain_match'] = False
        else:
            print('cookie domain match: YES')
            res['cookie_domain_match'] = True

    # ---- HARD RULE: an onion source must resolve to Tor -------------------
    if route.get('mode') != 'tor':
        print(f'\n  VERDICT: {ROUTE_NOT_TOR} - an onion source resolved to '
              f'"{route.get("mode")}". Refusing to crawl over clearnet.')
        res['verdict'] = ROUTE_NOT_TOR
        return res

    # ---- REQUESTS transport ----------------------------------------------
    print('\nREQUESTS:')
    backend = forum_crawl.FetchBackend(
        allow_browser=False, route=route,
        cookiejar_uuid=forum.get('cookiejar_uuid'))
    configured = backend.http.proxies.get('https') or backend.http.proxies.get('http')
    uses_socks5h = str(configured).startswith('socks5h://')
    print(f'  proxy actually configured : {"YES" if configured else "NO"}  ({configured})')
    print(f'  remote DNS (socks5h)      : {"YES" if uses_socks5h else "NO"}')
    if not configured or not uses_socks5h:
        # Without socks5h the hostname would be resolved locally, which for a
        # .onion means a guaranteed DNS failure - and, worse, a DNS leak.
        print(f'\n  VERDICT: {ROUTE_NOT_TOR} - requests transport is not on socks5h.')
        res['verdict'] = ROUTE_NOT_TOR
        backend.close()
        return res

    metrics = forum_crawl.CrawlMetrics(fid, 'diagnostic')
    t0 = time.time()
    html = err = None
    try:
        html, err = forum_crawl.fetch(backend, url, metrics, allow_retry=False)
    except fp_base.AccessRejected as e:
        err = f'AccessRejected: {e}'
        res['block_category'] = e.category
    except fp_base.BlockedError as e:
        err = f'BlockedError: {e}'
        res['block_category'] = (getattr(e, 'info', None) or {}).get('category')
    except Exception as e:
        err = f'{type(e).__name__}: {e}'
    elapsed = time.time() - t0

    print(f'  connection result         : {"OK" if not err else "FAILED"}  ({elapsed:.1f}s)')
    if err:
        print(f'  error                     : {str(err)[:160]}')
        res['verdict'] = classify_transport_error(err)
        if res.get('block_category') == fp_base.BLOCK_CHALLENGE:
            res['verdict'] = ANTI_BOT_CHALLENGE
        elif res.get('block_category') in (fp_base.BLOCK_AUTH, fp_base.BLOCK_SESSION):
            res['verdict'] = AUTH_REQUIRED if jar['count'] else NO_COOKIEJAR
        elif res.get('block_category') == fp_base.BLOCK_ANTISPAM:
            res['verdict'] = AUTH_REQUIRED
        print(f'\n  VERDICT: {res["verdict"]}')
        backend.close()
        return res

    print(f'  content length            : {len(html or "")}')
    info = fp_base.classify_block(forum_crawl._strip_tags(html or ''), html)
    if info:
        print(f'  block classification      : {info["category"]} ({info["label"]})')
        if info['category'] == fp_base.BLOCK_CHALLENGE:
            res['verdict'] = ANTI_BOT_CHALLENGE
        elif info['category'] in (fp_base.BLOCK_AUTH, fp_base.BLOCK_SESSION):
            res['verdict'] = NO_COOKIEJAR if not jar['count'] else COOKIE_INVALID
        elif info['category'] == fp_base.BLOCK_ANTISPAM:
            res['verdict'] = AUTH_REQUIRED
        else:
            res['verdict'] = HTTP_403
        print(f'\n  VERDICT: {res["verdict"]}')
        backend.close()
        return res
    backend.close()

    # ---- REAL CRAWL (index -> board -> pages -> threads -> documents) -----
    if not do_crawl:
        res['verdict'] = 'REACHABLE (crawl not run; pass --crawl)'
        print(f'\n  VERDICT: {res["verdict"]}')
        return res

    print('\nCRAWL:')
    m = forum_ingest.run_forum_crawl(fid) or {}
    res['metrics'] = m
    stored = m.get('documents_stored', 0)
    discovered = m.get('documents_discovered', 0)
    print(f'  pages walked              : {m.get("pages_fetched", 0)}')
    print(f'  threads/docs discovered   : {discovered}')
    print(f'  parsed                    : {m.get("documents_parsed", 0)}')
    print(f'  stored                    : {stored}')
    print(f'  duplicates                : {m.get("duplicates_skipped", 0)}')
    print(f'  rejected                  : {m.get("documents_rejected", 0)}')
    print(f'  attachments               : {m.get("attachments_discovered", 0)}')
    print(f'  errors / retries          : {m.get("errors", 0)} / {m.get("retries", 0)}')
    print(f'  duration                  : {m.get("duration", 0)}s')
    print(f'  termination reason        : {m.get("termination_reason")}')

    cat = m.get('block_category')
    if cat == fp_base.BLOCK_CHALLENGE:
        res['verdict'] = ANTI_BOT_CHALLENGE
    elif cat in (fp_base.BLOCK_AUTH, fp_base.BLOCK_SESSION):
        res['verdict'] = NO_COOKIEJAR if not jar['count'] else COOKIE_INVALID
    elif cat == fp_base.BLOCK_ANTISPAM:
        res['verdict'] = AUTH_REQUIRED
    elif stored > 0:
        res['verdict'] = SUCCESS
    elif discovered > 0:
        # Threads were found but nothing persisted - that is a parser or
        # persistence fault on OUR side, not the source's.
        res['verdict'] = PARSER_FAILURE
    elif m.get('pages_fetched', 0) <= 1:
        res['verdict'] = PAGINATION_FAILURE
    else:
        res['verdict'] = NO_DOCUMENTS
    print(f'\n  VERDICT: {res["verdict"]}')
    return res


def main():
    do_crawl = '--crawl' in sys.argv
    print()
    ok, _tor = verify_tor()
    if not ok:
        print(f'\nABORT: {TOR_UNAVAILABLE} - Tor transport is not usable, so no '
              'onion result below could be trusted.')
        return 1

    forums = onion_forums()
    print('# CONFIGURED ONION FORUMS')
    _hr()
    print(f'  Found: {len(forums)}')
    for f in forums:
        print(f'   - {f["id"]}  {f.get("url")}')
    if not forums:
        print('   (none - every configured source is clearnet)')
    _hr()
    print()

    results = []
    for f in forums:
        _hr('=')
        results.append(diagnose_forum(f, do_crawl=do_crawl))
        _hr('=')
        print()

    # ---- final report ----------------------------------------------------
    print('# ONION CRAWLING STATUS')
    _hr()
    verdicts = [r.get('verdict') for r in results]
    working = [r for r in results if r.get('verdict') == SUCCESS]
    print(f'  Configured onion forums          : {len(forums)}')
    print(f'  Reachable onion forums           : '
          f'{sum(1 for v in verdicts if v and (v == SUCCESS or "REACHABLE" in str(v) or v in (ANTI_BOT_CHALLENGE, AUTH_REQUIRED, NO_COOKIEJAR, COOKIE_INVALID)))}')
    print(f'  Authenticated onion forums       : '
          f'{sum(1 for r in results if (r.get("cookiejar") or {}).get("count"))}')
    print(f'  Successfully producing documents : {len(working)}')
    print(f'  Offline                          : '
          f'{sum(1 for v in verdicts if v in (HIDDEN_SERVICE_OFFLINE, ONION_UNRESOLVABLE))}')
    print(f'  Blocked (challenge/403)          : '
          f'{sum(1 for v in verdicts if v in (ANTI_BOT_CHALLENGE, HTTP_403))}')
    print(f'  Auth required                    : '
          f'{sum(1 for v in verdicts if v in (AUTH_REQUIRED, NO_COOKIEJAR, COOKIE_INVALID))}')
    print(f'  Parser failures                  : '
          f'{sum(1 for v in verdicts if v in (PARSER_FAILURE, PAGINATION_FAILURE, NO_DOCUMENTS))}')
    print()

    print('# WORKING ONION FORUMS')
    _hr()
    if working:
        for r in working:
            m = r.get('metrics', {})
            print(f'  {r["forum"]}: route=TOR pages={m.get("pages_fetched")} '
                  f'discovered={m.get("documents_discovered")} '
                  f'stored={m.get("documents_stored")} '
                  f'duplicates={m.get("duplicates_skipped")}')
    else:
        print('  NONE - no onion forum produced a stored document.')
    print()

    print('# FAILED ONION FORUMS')
    _hr()
    failed = [r for r in results if r.get('verdict') != SUCCESS]
    if not failed:
        print('  (none)')
    for r in failed:
        print(f'  {r["forum"]}: {r.get("verdict")}')
    print()

    print('# CRITICAL FINDING')
    _hr()
    print('  "Is Anorphix currently capable of crawling actual onion forums')
    print('   through Tor and storing real forum documents?"')
    print()
    if working:
        print('  YES - proven by the crawl metrics above.')
    elif not forums:
        print('  NOT PROVEN - there are ZERO onion forums configured, so the')
        print('  onion collection path has no target to demonstrate against.')
        print('  The Tor transport itself is verified operational above')
        print('  (a known-good hidden service returns HTTP 200), and the route')
        print('  resolver hard-forces .onion/.i2p through Tor. The missing')
        print('  layer is SOURCES, not transport.')
    else:
        print('  NO - onion forums are configured but none produced documents.')
        print('  Blocking layer per forum listed under FAILED ONION FORUMS.')
    _hr()
    return 0


if __name__ == '__main__':
    sys.exit(main())
