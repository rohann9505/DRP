#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Domain Intelligence Worker
===================

Pops queued Domain Intelligence Jobs (lib.intel_jobs) and executes them.
Kept deliberately simple (a blocking-pop loop) rather than folded into
the generic AIL module/queue chain, since jobs are synchronous
request/response work triggered by a client action, not a stage in the
crawl-ingestion pipeline.
"""

import os
import sys
import time
import traceback

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import intel_jobs


def main():
    requeued = intel_jobs.recover_orphaned_jobs()
    if requeued:
        print(f'Recovered {len(requeued)} orphaned RUNNING job(s), re-queued: {requeued}')
    print('DomainIntelWorker started, waiting for jobs...')
    while True:
        try:
            job_id = intel_jobs.pop_queued_job(timeout=5)
            if not job_id:
                continue
            print(f'Running job {job_id}')
            intel_jobs.run_job(job_id)
            print(f'Finished job {job_id}')
        except KeyboardInterrupt:
            break
        except Exception:
            traceback.print_exc()
            time.sleep(2)


if __name__ == '__main__':
    main()
