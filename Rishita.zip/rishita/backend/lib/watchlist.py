#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Watchlist
===================

Standing "tell me as soon as this shows up" entries (a domain or a free-text
keyword), matched at collection time - see forum_collector.record_forum_document()
- against every genuinely new document as it comes in, rather than only when
a client manually runs a search. This is what makes collection "continuous":
forum_monitor.py polls each forum's RSS feed for new threads, feeds them
through the normal capture/index pipeline, and that pipeline checks them
against every active watch immediately, producing an Alert the moment a
match is found - not the next time someone happens to search that term.

Independent of intel_jobs.py's on-demand search jobs: a watch never blocks
or waits on anything, it just records an Alert row when collection notices
a match. Reuses the same deterministic classifiers intel_jobs.run_job() uses
(intel_extraction.classify_matches / classify_keyword_matches) so a watch
match and a manual search match for the same term always agree.
"""

import json
import os
import sys
import time
import uuid

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers

r_crawler = crawlers.r_crawler

WATCH_TYPES = {'domain', 'keyword'}
ALERTS_ZSET = 'watchlist:alerts:zset'
MAX_ALERTS_PER_WATCH = 500  # bounds unbounded growth from a very chatty watch/forum pair


def _watch_key(watch_id):
    return f'watch:meta:{watch_id}'


def _alert_key(alert_id):
    return f'watchalert:meta:{alert_id}'


def add_watch(query, query_type='domain', forum_ids=None):
    query = (query or '').strip()
    query_type = query_type if query_type in WATCH_TYPES else 'domain'
    if not query:
        return {'status': 'error', 'reason': 'Missing watch query'}, 400
    if query_type == 'domain':
        query = query.lower()

    forum_ids = [f for f in (forum_ids or []) if f]  # empty list == watch every registered forum

    # Idempotent on (query_type, query, forum_ids) - re-adding the same
    # watch re-enables it rather than piling up duplicates that would each
    # independently fire their own alert for the same match.
    forum_ids_sorted = sorted(forum_ids)
    for w in list_watches():
        if w['query_type'] == query_type and w['query'] == query and sorted(w['forum_ids']) == forum_ids_sorted:
            set_enabled(w['id'], True)
            return get_watch(w['id'])

    watch_id = str(uuid.uuid4())
    now = int(time.time())
    r_crawler.hset(_watch_key(watch_id), mapping={
        'id': watch_id,
        'query': query,
        'query_type': query_type,
        'forum_ids': json.dumps(forum_ids),
        'enabled': 1,
        'created_at': now,
        'last_alert_at': '',
        'alert_count': 0,
    })
    return get_watch(watch_id)


def get_watch(watch_id):
    data = r_crawler.hgetall(_watch_key(watch_id))
    if not data:
        return {'status': 'error', 'reason': 'Unknown watch'}, 404
    return _watch_to_dict(data), 200


def list_watches():
    watches = []
    for key in r_crawler.scan_iter(match='watch:meta:*', count=200):
        data = r_crawler.hgetall(key)
        if data:
            watches.append(_watch_to_dict(data))
    watches.sort(key=lambda w: w.get('created_at') or 0, reverse=True)
    return watches


def get_active_watches():
    return [w for w in list_watches() if w['enabled']]


def _watch_to_dict(data):
    d = dict(data)
    d['forum_ids'] = json.loads(d.get('forum_ids') or '[]')
    d['enabled'] = bool(int(d.get('enabled') or 0))
    for int_field in ('created_at', 'last_alert_at', 'alert_count'):
        d[int_field] = int(d[int_field]) if d.get(int_field) not in (None, '') else None
    return d


def set_enabled(watch_id, enabled):
    watch, code = get_watch(watch_id)
    if code != 200:
        return watch, code
    r_crawler.hset(_watch_key(watch_id), 'enabled', 1 if enabled else 0)
    return get_watch(watch_id)


def delete_watch(watch_id):
    watch, code = get_watch(watch_id)
    if code != 200:
        return watch, code
    r_crawler.delete(_watch_key(watch_id))
    return {'status': 'ok', 'deleted': watch_id}, 200


def record_alert(watch_id, forum_id, forum_name, url, document_id, match_type, matched_value,
                  risk_level, risk_score, snippet):
    watch, code = get_watch(watch_id)
    if code != 200:
        return None

    alert_id = str(uuid.uuid4())
    now = int(time.time())
    r_crawler.hset(_alert_key(alert_id), mapping={
        'id': alert_id,
        'watch_id': watch_id,
        'watch_query': watch['query'],
        'watch_query_type': watch['query_type'],
        'forum_id': forum_id,
        'forum_name': forum_name or forum_id,
        'url': url or '',
        'document_id': document_id or '',
        'match_type': match_type or '',
        'matched_value': matched_value or '',
        'risk_level': risk_level or '',
        'risk_score': risk_score if risk_score is not None else '',
        'snippet': (snippet or '')[:500],
        'created_at': now,
    })
    r_crawler.zadd(ALERTS_ZSET, {alert_id: now})

    r_crawler.hset(_watch_key(watch_id), mapping={
        'last_alert_at': now,
        'alert_count': int(watch.get('alert_count') or 0) + 1,
    })

    # Queue (never call directly) - see alert_dispatch.py's module docstring
    # for why this must stay a fast, non-blocking enqueue: record_alert()
    # runs inline in Crawler.py's single-threaded capture loop.
    try:
        from lib import alert_dispatch
        alert_dispatch.queue_alert_delivery(alert_id)
    except Exception as e:
        print(f'Failed to queue alert delivery for {alert_id}: {e}')

    # Bound growth: trim the global feed and drop the oldest alert's own
    # record so watchalert:meta:* keys don't accumulate forever for a
    # long-lived, chatty watch.
    total = r_crawler.zcard(ALERTS_ZSET)
    if total > MAX_ALERTS_PER_WATCH * 20:
        oldest = r_crawler.zrange(ALERTS_ZSET, 0, total - MAX_ALERTS_PER_WATCH * 20 - 1)
        if oldest:
            r_crawler.zrem(ALERTS_ZSET, *oldest)
            for old_id in oldest:
                r_crawler.delete(_alert_key(old_id))

    return alert_id


def list_alerts(limit=100, watch_id=None):
    alert_ids = r_crawler.zrevrange(ALERTS_ZSET, 0, -1 if watch_id else limit - 1)
    alerts = []
    for alert_id in alert_ids:
        data = r_crawler.hgetall(_alert_key(alert_id))
        if not data:
            continue
        if watch_id and data.get('watch_id') != watch_id:
            continue
        d = dict(data)
        d['created_at'] = int(d['created_at']) if d.get('created_at') else None
        alerts.append(d)
        if watch_id and len(alerts) >= limit:
            break
    return alerts


def count_alerts():
    return r_crawler.zcard(ALERTS_ZSET)
