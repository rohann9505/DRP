#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Russian Market — stealer-log marketplace source adapter
=======================================================

A SOURCE ADAPTER inside the existing intelligence pipeline (intel_jobs.run_job),
not a separate product: a domain search runs this alongside the forum-corpus
query and the ransomware.live check, and its results land in the same report,
the same findings list and the same UI.

What it contributes: "bots"/logs — machines compromised by an infostealer whose
captured credentials are listed for sale. That is a different signal from a
forum credential paste or a ransomware claim: it says a *live host* holding
credentials for this domain is currently purchasable.

SECURITY - the non-negotiable part of this module
-------------------------------------------------
A stealer log's entire value to a criminal is the plaintext it carries. This
adapter therefore stores NONE of it. Passwords, cookie values, session tokens,
autofill values and form data are dropped at parse time and never written,
logged or rendered - only their CATEGORY and COUNT survive
(`credential_count`, `has_cookies`, `cookie_count`, `has_autofill`).
`_assert_no_secrets()` re-checks every normalised record before it is returned,
so a parser change can never quietly start leaking values.

Access reality (verified live 2026-09-06): russianmarket.to serves a Django
login page carrying username/password AND a `captcha` + `captcha_image` field.
The marketplace is authentication- and CAPTCHA-gated. This adapter does not
solve CAPTCHAs, create accounts, or bypass any control - it reports
RM_CAPTCHA/RM_AUTH honestly and the rest of the intelligence search continues.
The legitimate route in is an operator-supplied session (AIL cookiejar), the
same mechanism the forum crawler already uses.
"""

import json
import os
import re
import sys
from datetime import datetime, timezone
from urllib.parse import urlparse, quote, urljoin

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers

# ---------------------------------------------------------------------------
# Source status. Mirrors the disclosure-fetch vocabulary: every failure mode is
# distinct, because "gated behind a login", "CAPTCHA", "rate limited" and
# "checked, nothing found" demand different operator actions and must never
# collapse into one "unavailable".
# ---------------------------------------------------------------------------
RM_OK = 'retrieved'
RM_EMPTY = 'no_matches'              # searched successfully, nothing for this asset
RM_AUTH = 'auth_required'            # login wall / session rejected
RM_CAPTCHA = 'captcha_required'      # interactive CAPTCHA - not solved by design
RM_RATE_LIMITED = 'rate_limited'
RM_UNAVAILABLE = 'unavailable'       # host down / HTTP 5xx
RM_TIMEOUT = 'timeout'
RM_BAD_PAYLOAD = 'invalid_payload'
RM_NOT_CONFIGURED = 'not_configured'  # no base URL configured for the source

SOURCE_NAME = 'Russian Market'
SOURCE_KIND = 'stealer-log marketplace'

DEFAULT_BASE_URL = os.environ.get('RUSSIAN_MARKET_URL', 'https://russianmarket.to')
REQUEST_TIMEOUT = int(os.environ.get('RUSSIAN_MARKET_TIMEOUT', 45))
MAX_PAGES = int(os.environ.get('RUSSIAN_MARKET_MAX_PAGES', 10))

# Kvrocks config + dedupe keys, in the crawler namespace alongside the rest of
# the intelligence config (same key-prefix convention as forum:/watch:).
_CFG_KEY = 'rmarket:config'
_SEEN_KEY = 'rmarket:seen'          # canonical bot ids ever stored
_CACHE_KEY = 'rmarket:bots'         # bot_id -> normalised record JSON


def _r():
    return crawlers.r_crawler


# ---------------------------------------------------------------------------
# Redaction. Applied at parse time, then re-verified before returning.
# ---------------------------------------------------------------------------

# Field names whose VALUES must never be retained, in any casing/spelling the
# marketplace might use.
_SECRET_FIELDS = {
    'password', 'passwd', 'pass', 'pwd', 'secret', 'token', 'auth_token',
    'access_token', 'refresh_token', 'session', 'session_id', 'sessionid',
    'cookie', 'cookies', 'cookie_data', 'autofill', 'autofill_data',
    'form_data', 'formdata', 'credit_card', 'card_number', 'cvv', 'pin',
    'private_key', 'seed', 'seed_phrase', 'mnemonic', 'wallet_key',
}

# Value shapes that look like usable secrets even under an innocuous key.
_SECRET_VALUE_RES = (
    re.compile(r'\bBEGIN [A-Z ]*PRIVATE KEY\b'),
    re.compile(r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'),   # JWT
    re.compile(r'\b[A-Fa-f0-9]{32,}\b'),                          # long hex blob
)


def _is_secret_key(key):
    k = re.sub(r'[^a-z]', '', str(key).lower())
    return any(s.replace('_', '') == k or s.replace('_', '') in k
               for s in _SECRET_FIELDS)


def _strip_secrets(obj):
    """Recursively drop secret-bearing keys and secret-shaped values.

    A COUNT is not a secret. `"cookies": 318` and `"autofill_count": 42` are
    exactly the exposure indicators an analyst needs, and an earlier version
    of this function discarded them along with the values, silently zeroing
    the cookie/autofill intelligence. So a secret-keyed field survives ONLY
    when its value is a bare number; every string, dict and list under such a
    key is still dropped whole.
    """
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if _is_secret_key(k):
                if isinstance(v, bool) or not isinstance(v, (int, float)):
                    continue      # the actual secret payload - dropped
                out[k] = v        # a count - kept
                continue
            out[k] = _strip_secrets(v)
        return out
    if isinstance(obj, list):
        return [_strip_secrets(v) for v in obj]
    if isinstance(obj, str):
        for rx in _SECRET_VALUE_RES:
            if rx.search(obj):
                return '[REDACTED]'
    return obj


def _assert_no_secrets(record):
    """Final gate. Raises rather than returning a record that carries a secret,
    because silently shipping one is far worse than losing the finding."""
    blob = json.dumps(record, default=str)
    for k in ('password', 'passwd', 'cookie_value', 'token', 'private_key'):
        if re.search(rf'"{k}"\s*:', blob, re.I):
            raise ValueError(f'refusing to emit record carrying {k}')
    for rx in _SECRET_VALUE_RES:
        if rx.search(blob):
            raise ValueError('refusing to emit record carrying a secret-shaped value')
    return record


# ---------------------------------------------------------------------------
# Configuration (base URL + operator cookiejar)
# ---------------------------------------------------------------------------

def get_config():
    raw = _r().hgetall(_CFG_KEY) or {}
    return {
        'base_url': raw.get('base_url') or DEFAULT_BASE_URL,
        'cookiejar_uuid': raw.get('cookiejar_uuid') or None,
        'enabled': (raw.get('enabled') or '1') == '1',
    }


def set_config(base_url=None, cookiejar_uuid=None, enabled=None):
    mapping = {}
    if base_url is not None:
        mapping['base_url'] = base_url.strip()
    if cookiejar_uuid is not None:
        mapping['cookiejar_uuid'] = cookiejar_uuid.strip()
    if enabled is not None:
        mapping['enabled'] = '1' if enabled else '0'
    if mapping:
        _r().hset(_CFG_KEY, mapping=mapping)
    return get_config()


# ---------------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------------

def _first(rec, *names):
    for n in names:
        if n in rec and rec[n] not in (None, '', []):
            return rec[n]
    lowered = {str(k).lower(): v for k, v in rec.items()}
    for n in names:
        v = lowered.get(n.lower())
        if v not in (None, '', []):
            return v
    return None


def _as_int(v):
    try:
        if isinstance(v, bool):
            return None
        return int(str(v).replace(',', '').strip())
    except (TypeError, ValueError):
        return None


def _iso(v):
    """Normalise a timestamp to ISO-8601, or None. Never invents a value."""
    if v in (None, '', 0):
        return None
    if isinstance(v, (int, float)) or (isinstance(v, str) and v.isdigit()):
        try:
            return datetime.fromtimestamp(int(v), tz=timezone.utc).isoformat()
        except (ValueError, OSError, OverflowError):
            return None
    s = str(v).strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d',
                '%d.%m.%Y', '%d/%m/%Y', '%b %d, %Y', '%d %b %Y'):
        try:
            return datetime.strptime(s[:len(fmt) + 6].strip(), fmt).replace(
                tzinfo=timezone.utc).isoformat()
        except ValueError:
            continue
    return s or None


def normalize_bot(raw, base_url=None, matched_query=None):
    """One marketplace listing -> one normalised, redacted bot record.

    Every field the source did not provide stays absent rather than being
    filled with a plausible default - a fabricated country or OS would be
    indistinguishable from a real one downstream.
    """
    if not isinstance(raw, dict):
        return None
    raw = _strip_secrets(raw)

    bot_id = _first(raw, 'id', 'bot_id', 'botid', 'log_id', 'uuid', 'hash')
    domains = _first(raw, 'domains', 'resources', 'affected_domains', 'urls') or []
    if isinstance(domains, str):
        domains = [d.strip() for d in re.split(r'[,\s;]+', domains) if d.strip()]
    domains = [str(d).strip() for d in domains if str(d).strip()][:200]

    creds = _first(raw, 'credential_count', 'credentials', 'passwords_count',
                   'resources_count', 'count')
    cookie_ct = _first(raw, 'cookie_count', 'cookies_count', 'cookies')
    autofill_ct = _first(raw, 'autofill_count', 'autofills', 'forms_count')

    listing_url = _first(raw, 'url', 'link', 'listing_url')
    if listing_url and base_url and str(listing_url).startswith('/'):
        listing_url = urljoin(base_url, listing_url)

    tags = _first(raw, 'tags', 'labels', 'classifications') or []
    if isinstance(tags, str):
        tags = [t.strip() for t in re.split(r'[,;]+', tags) if t.strip()]

    record = {
        # identity
        'bot_id': str(bot_id) if bot_id is not None else None,
        'source': SOURCE_NAME,
        'source_kind': SOURCE_KIND,
        'listing_url': listing_url,
        # asset linkage
        'affected_domains': domains,
        'affected_domain_count': len(domains),
        'account': _first(raw, 'email', 'username', 'user', 'login', 'account'),
        # host context
        'country': _first(raw, 'country', 'geo', 'country_code', 'location'),
        'os': _first(raw, 'os', 'operating_system', 'system'),
        'stealer_family': _first(raw, 'stealer', 'family', 'malware',
                                 'infostealer', 'stealer_family'),
        'vendor': _first(raw, 'seller', 'vendor', 'shop', 'owner'),
        # scale - counts only, never contents
        'credential_count': _as_int(creds),
        'cookie_count': _as_int(cookie_ct),
        'autofill_count': _as_int(autofill_ct),
        'log_size': _first(raw, 'size', 'log_size', 'filesize'),
        'price': _first(raw, 'price', 'cost'),
        # THREE distinct times - conflating them misdates the exposure
        'infected_at': _iso(_first(raw, 'infected', 'infection_date',
                                   'infected_at', 'compromised_at')),
        'listed_at': _iso(_first(raw, 'listed', 'listing_date', 'published',
                                 'date', 'added')),
        'collected_at': datetime.now(timezone.utc).isoformat(),
        # marketplace state
        'status': _first(raw, 'status', 'availability', 'state') or 'unknown',
        'tags': tags,
        'matched_query': matched_query,
    }
    # Presence indicators derived from counts - the ONLY thing recorded about
    # cookies/autofill, since their values are the sellable secret.
    record['has_cookies'] = bool(record['cookie_count'])
    record['has_autofill'] = bool(record['autofill_count'])
    return _assert_no_secrets(record)


def build_match_reason(record, query):
    """Evidence-based justification, derived from what the listing actually
    contains. Says so plainly when the link cannot be pinned to a field."""
    q = (query or '').lower().strip()
    hits = []
    for d in (record.get('affected_domains') or []):
        if q and q in str(d).lower():
            hits.append(str(d))
    parts = [f'{SOURCE_NAME} listing matched "{query}"']
    if hits:
        shown = ', '.join(hits[:3])
        more = f' (+{len(hits) - 3} more)' if len(hits) > 3 else ''
        parts.append(f'compromised host holds credentials for {shown}{more}')
    elif q and q in str(record.get('account') or '').lower():
        parts.append('matched on the captured account identifier')
    else:
        parts.append('returned by the marketplace search but the term does not '
                     'appear verbatim in the retrieved fields')
    if record.get('stealer_family'):
        parts.append(f"stealer family {record['stealer_family']}")
    if record.get('credential_count'):
        parts.append(f"{record['credential_count']} credentials in log")
    return '; '.join(parts)


def dedupe_key(record):
    """Canonical identity: the marketplace's own bot id, else the listing URL.
    Never a content hash - a listing's price/status changes constantly."""
    return record.get('bot_id') or record.get('listing_url')


# ---------------------------------------------------------------------------
# Live search
# ---------------------------------------------------------------------------

_CAPTCHA_RES = (
    re.compile(r'name=["\']captcha', re.I),
    re.compile(r'captcha_image', re.I),
    re.compile(r'\bg-recaptcha\b|\bhcaptcha\b', re.I),
)
_LOGIN_RES = (
    re.compile(r'name=["\']password["\']', re.I),
    re.compile(r'action=["\'][^"\']*/login', re.I),
    re.compile(r'you must (?:be )?log(?:ged)? ?in', re.I),
)


def classify_response(status_code, body):
    """Precise source status. CAPTCHA is checked BEFORE the login wall: the
    marketplace's gate carries both, and reporting it as 'auth_required' would
    imply a stored session could fix it when a CAPTCHA still stands in front."""
    if status_code == 429:
        return RM_RATE_LIMITED, 'HTTP 429 - rate limited by the marketplace'
    if status_code and status_code >= 500:
        return RM_UNAVAILABLE, f'HTTP {status_code}'
    text = body or ''
    if any(rx.search(text) for rx in _CAPTCHA_RES):
        return RM_CAPTCHA, ('marketplace served an interactive CAPTCHA - not '
                            'solved by this platform by design')
    if status_code in (401, 403) or any(rx.search(text) for rx in _LOGIN_RES):
        return RM_AUTH, ('marketplace requires an authenticated session '
                         '(no valid operator cookiejar attached)')
    if status_code != 200:
        return RM_UNAVAILABLE, f'HTTP {status_code}'
    return None, None


def _load_cookies(uuid):
    if not uuid:
        return []
    try:
        jar = crawlers.Cookiejar(uuid)
        if not jar.exists():
            return []
        return [{'name': c['name'], 'value': c['value'],
                 'domain': c.get('domain') or ''}
                for c in jar.get_cookies() if c.get('name') and c.get('value')]
    except Exception:
        return []


def search(query, max_pages=None, logger=None):
    """Search the marketplace for `query` (a domain or keyword).

    Returns (records, status, detail). Never raises, never fabricates, and
    never returns a record carrying a secret. A gated/blocked source yields
    ([], RM_AUTH|RM_CAPTCHA|..., reason) so the caller can carry on with the
    rest of the intelligence search.
    """
    def _log(msg):
        if logger:
            logger(f'[russian-market] {msg}')

    cfg = get_config()
    if not cfg.get('enabled'):
        return [], RM_NOT_CONFIGURED, 'source disabled in configuration'
    base = (cfg.get('base_url') or '').rstrip('/')
    if not base:
        return [], RM_NOT_CONFIGURED, 'no base URL configured'
    if not query or not str(query).strip():
        return [], RM_EMPTY, 'no query supplied'

    import requests
    session = requests.Session()
    session.headers.update({
        'User-Agent': ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                       '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'),
        'Accept': 'application/json, text/html;q=0.9',
    })
    for c in _load_cookies(cfg.get('cookiejar_uuid')):
        try:
            session.cookies.set(c['name'], c['value'], domain=c['domain'] or None)
        except Exception:
            continue

    records, seen = [], set()
    pages = int(max_pages or MAX_PAGES)
    status, detail = RM_EMPTY, None

    for page in range(1, pages + 1):
        url = f'{base}/search/?query={quote(str(query))}&page={page}'
        try:
            resp = session.get(url, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        except requests.exceptions.Timeout:
            _log(f'page {page} -> TIMEOUT')
            return records, (RM_OK if records else RM_TIMEOUT), \
                f'timed out after {REQUEST_TIMEOUT}s'
        except requests.exceptions.RequestException as e:
            _log(f'page {page} -> {type(e).__name__}')
            return records, (RM_OK if records else RM_UNAVAILABLE), type(e).__name__

        body = resp.text or ''
        bad, why = classify_response(resp.status_code, body)
        if bad:
            _log(f'page {page} -> {bad}')
            # Partial results already collected stay valid and are returned.
            return records, (RM_OK if records else bad), why

        try:
            payload = resp.json()
        except Exception:
            _log(f'page {page} -> non-JSON response')
            return records, (RM_OK if records else RM_BAD_PAYLOAD), \
                'response was not valid JSON'

        rows = payload
        if isinstance(payload, dict):
            rows = (payload.get('results') or payload.get('bots')
                    or payload.get('data') or payload.get('items'))
        if not isinstance(rows, list) or not rows:
            break

        new_this_page = 0
        for raw in rows:
            try:
                rec = normalize_bot(raw, base_url=base, matched_query=query)
            except ValueError as e:
                _log(f'record dropped: {e}')      # secret gate tripped
                continue
            if not rec:
                continue
            key = dedupe_key(rec)
            if not key or key in seen:
                continue
            seen.add(key)
            rec['match_reason'] = build_match_reason(rec, query)
            records.append(rec)
            new_this_page += 1

        _log(f'page {page}: {len(rows)} rows, {new_this_page} new')
        if new_this_page == 0:
            break     # repeated page - stop rather than loop

    if records:
        # Newest first. Listing time is the marketplace event; infection time
        # is when the host was compromised. Sorted on listing, falling back to
        # infection, so a record missing one still orders sensibly.
        records.sort(key=lambda r: (r.get('listed_at') or r.get('infected_at') or ''),
                     reverse=True)
        status, detail = RM_OK, None
        _log(f'{len(records)} bot records for "{query}"')
    return records, status, detail


def remember(records):
    """Persist canonical ids so a later run can tell NEW exposures from ones
    already reported. Only ids and normalised (already redacted) records."""
    if not records:
        return 0
    r = _r()
    fresh = 0
    for rec in records:
        key = dedupe_key(rec)
        if not key:
            continue
        if r.sadd(_SEEN_KEY, key):
            fresh += 1
        r.hset(_CACHE_KEY, key, json.dumps(_assert_no_secrets(rec)))
    return fresh


def is_new(record):
    key = dedupe_key(record)
    return bool(key) and not _r().sismember(_SEEN_KEY, key)
