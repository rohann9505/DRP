#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Domain Intelligence Extraction
===================

Deterministic, reproducible entity extraction and domain-match
classification over a single document's plain text. Pure functions -
no DB access, no side effects - so behaviour is fully auditable and
testable in isolation.

Reuses the same extraction patterns already used elsewhere in AIL
(bin/modules/Mail.py's email regex, bin/lib/psl_faup.py for
domain/subdomain parsing) rather than inventing new ones.
"""

import os
import re
import sys
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers

# Same pattern as bin/modules/Mail.py
EMAIL_REGEX = re.compile(r"[\w._+-]+@[\w.-]+\.\w{2,63}")

# The email regex is also a valid match for filenames like "logo@2x.png" (a
# common web-asset naming convention). Excluding known asset extensions from
# the "TLD" position keeps those out of extracted-email results.
_NON_EMAIL_TLDS = {
    'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico', 'bmp', 'avif',
    'css', 'js', 'mjs', 'map', 'json', 'woff', 'woff2', 'ttf', 'eot', 'otf',
}

# Same generic v4 pattern used across the codebase for coarse IP extraction
IPV4_REGEX = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b")

URL_REGEX = re.compile(r"\b[a-zA-Z][a-zA-Z0-9+.-]*://[^\s\"'<>()\[\]]+")

# Conservative, low-confidence "handle" heuristic - explicit prefix only,
# never a bare word, to avoid over-claiming usernames from ordinary text.
USERNAME_HINT_REGEX = re.compile(
    r"(?:^|[\s(\[])(?:user(?:name)?|handle|login|account)\s*[:=]\s*[@]?([A-Za-z0-9_.\-]{3,32})",
    re.IGNORECASE,
)
MENTION_REGEX = re.compile(r"(?<![\w@])@([A-Za-z0-9_]{3,32})\b")


def extract_emails(text):
    found = EMAIL_REGEX.findall(text)
    return sorted(set(e for e in found if e.rsplit('.', 1)[-1].lower() not in _NON_EMAIL_TLDS))


def extract_ips(text):
    return sorted(set(IPV4_REGEX.findall(text)))


def extract_urls(text):
    return sorted(set(m.rstrip('.,;)\'"') for m in URL_REGEX.findall(text)))


def extract_usernames(text):
    usernames = set(USERNAME_HINT_REGEX.findall(text))
    usernames |= set(MENTION_REGEX.findall(text))
    return sorted(usernames)


def _decode_url(url):
    try:
        return crawlers.unpack_url(url)
    except Exception:
        return None


def extract_entities(text):
    return {
        'emails': extract_emails(text),
        'usernames': extract_usernames(text),
        'urls': extract_urls(text),
        'ips': extract_ips(text),
    }


# Heuristic, keyword-based sensitive-content signals. This is intentionally a
# coarse, explainable classifier (not ML) so every risk score is traceable
# back to a specific matched keyword - grep the report for `signals` to see
# exactly why a page was scored the way it was.
SENSITIVE_SIGNAL_PATTERNS = {
    'credentials': re.compile(r"\b(password|passwd|pwd|login:|combo\s*list|credential[s]?|cookie[s]?\s*dump)\b", re.IGNORECASE),
    'leak_breach': re.compile(r"\b(leak(ed)?|breach(ed)?|dump(ed)?|database\s*for\s*sale|stealer\s*log)\b", re.IGNORECASE),
    'financial': re.compile(r"\b(credit\s*card|cvv|iban|swift|bank\s*account|wallet\s*seed|seed\s*phrase|btc\s*address|wallet\.dat)\b", re.IGNORECASE),
    'access_sale': re.compile(r"\b(rdp\s*access|ssh\s*access|shell\s*access|admin\s*panel|for\s*sale|selling|vouch(ed)?)\b", re.IGNORECASE),
    'exploit': re.compile(r"\b(exploit|0day|zero-day|ransomware|malware|c2\s*server|payload)\b", re.IGNORECASE),
}


# darkforums.ru posts routinely substitute look-alike Cyrillic characters for
# Latin ones inside trigger words (e.g. "ransоmware" with a Cyrillic 'о', not
# Latin 'o') specifically to dodge naive keyword scanners - confirmed on a
# real post that named "the Everest ransоmware grоup" this way. Normalizing
# before keyword/pattern matching keeps detection accurate; the *displayed*
# text (narrative paragraphs, snippets) still shows the original characters
# exactly as posted, this normalization is only used to decide what matches.
_HOMOGLYPH_MAP = str.maketrans({
    'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x', 'і': 'i',
    'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O',
    'Р': 'P', 'С': 'C', 'Т': 'T', 'У': 'Y', 'Х': 'X',
})


def normalize_homoglyphs(text):
    return text.translate(_HOMOGLYPH_MAP)


def detect_sensitive_signals(text):
    """Returns the sorted list of sensitive-content categories detected in text."""
    normalized = normalize_homoglyphs(text)
    return sorted(name for name, pat in SENSITIVE_SIGNAL_PATTERNS.items() if pat.search(normalized))


_MATCH_BASE_SCORE = {
    'exact_domain': 35,
    'url': 30,
    'email_domain': 40,
    'subdomain': 25,
    'contextual': 10,
    'keyword_mention': 25,
}


def score_document_risk(matches, entities, sensitive_signals):
    """
    Deterministic 0-100 risk score for a single matched document.
    Every contribution is explainable:
      - base score from the strongest match type found on the page
      - +18 per distinct sensitive-content category detected (credentials,
        leak/breach language, financial data, access-for-sale, exploit talk)
      - +4 per extracted email/IP beyond the first (data co-located with the
        domain mention), capped
    Returns (score:int, level:str) where level in LOW/MEDIUM/HIGH/CRITICAL.
    """
    base = max((_MATCH_BASE_SCORE.get(m['match_type'], 10) for m in matches), default=10)
    signal_score = min(len(sensitive_signals) * 18, 54)
    co_located = len(entities.get('emails', [])) + len(entities.get('ips', []))
    co_located_score = min(max(co_located - 1, 0) * 4, 20)
    score = min(base + signal_score + co_located_score, 100)

    if score >= 75 or len(sensitive_signals) >= 2:
        level = 'CRITICAL'
    elif score >= 50 or sensitive_signals:
        level = 'HIGH'
    elif score >= 25:
        level = 'MEDIUM'
    else:
        level = 'LOW'
    return score, level


# Maps a forum's own board/category (from the URL path) to a human-readable
# attack-vector label. Falls back to sensitive-signal-based labelling when the
# URL doesn't match a known board layout (e.g. MyBB-style "Forum-<Name>" paths).
BOARD_ATTACK_VECTOR = {
    'databases': 'Database Leak',
    'stealer-logs': 'Stealer Log',
    'stealerlogs': 'Stealer Log',
    'combolists': 'Combolist / Credential Stuffing',
    'doxes': 'Doxxing',
    'dox': 'Doxxing',
    'cracked-accounts': 'Cracked Account Listing',
    'crackedaccounts': 'Cracked Account Listing',
    'sellers-place': 'Data-for-Sale Listing',
    'sellersplace': 'Data-for-Sale Listing',
    'other-leaks': 'General Leak',
    'source-codes': 'Source Code Leak',
    'ransomware': 'Ransomware Leak',
}

_SIGNAL_ATTACK_VECTOR = {
    'leak_breach': 'Data Leak / Breach',
    'credentials': 'Credential Exposure',
    'financial': 'Financial Data Exposure',
    'access_sale': 'Access-for-Sale Listing',
    'exploit': 'Exploit / Malware',
}


def classify_attack_vector(url, sensitive_signals):
    """Best-effort, explainable attack-vector label for a single document.
    Prefers the forum's own board/category (from the URL path) since that's
    the most reliable signal; falls back to detected sensitive-content type,
    then to a generic label if neither is available."""
    if url:
        path = re.sub(r'^https?://[^/]+/?', '', url).lower()
        slug = re.split(r'[/?]', path)[0]
        slug = re.sub(r'^forum-', '', slug)
        label = BOARD_ATTACK_VECTOR.get(slug)
        if label:
            return label
    for sig in sensitive_signals:
        if sig in _SIGNAL_ATTACK_VECTOR:
            return _SIGNAL_ATTACK_VECTOR[sig]
    return 'Unclassified Mention'


def _link_density(content, idx, radius=150):
    """How nav/pagination-heavy the text around `idx` is - counts markdown
    link openings nearby. Real prose has near-zero density; breadcrumb/
    pagination clusters (e.g. 'forum-10-page-5.html' link lists) have many."""
    lo, hi = max(0, idx - radius), min(len(content), idx + radius)
    return content.count('](', lo, hi)


# MyBB decorates several different in-page links to the SAME thread with
# navigation-only query params - "jump to last post" (?action=lastpost),
# "previous/next thread in this board" (?action=nextoldest/newthread),
# "jump to first unread" (?action=newpost), a specific-post permalink
# (?pid=NNN#pidNNN), etc. None of these represent a genuinely different
# real-world finding - they're all still the same thread, just scrolled to a
# different spot in it. Left unstripped, a keyword/domain search that lands
# near several of these in-page variants (confirmed: happens routinely on
# any thread with more than a couple of replies) turns one real leak into
# three or four duplicate "findings".
#
# `page=` is dropped too, but ONLY on a /Thread-.../ URL - on a *listing*
# page (Forum-Databases?page=2 vs ?page=3) it genuinely selects a different
# set of thread teasers and must stay distinct; on a thread page it's just
# "which batch of replies", still the same underlying leak.
_MYBB_NAV_ONLY_QUERY_KEYS = {'action', 'pid', 'tid'}
_THREAD_PATH_REGEX = re.compile(r'/Thread-', re.IGNORECASE)

# XenForo (e.g. xforums.st) gives every thread TWO working URL forms - a
# numeric-only one (/threads/670685/) and a slug+id one
# (/threads/flipkart-com-free-database.10335/) - both resolve to the exact
# same thread. Confirmed: a domain mentioned in a homepage activity-feed
# teaser (numeric form) and the thread's own page (slug form) produced two
# separate findings for one real leak until both forms are folded down to
# the same canonical /threads/<id>/. Pagination is a path segment here
# (/threads/slug.123/page-4), not a query param - still the same underlying
# thread, so it's stripped the same way MyBB's ?page= is for /Thread-.../.
_XENFORO_THREAD_PATH_REGEX = re.compile(r'^(.*/threads/)(?:[^/]*\.)?(\d+)/(?:page-\d+/?)?$', re.IGNORECASE)


def _canonicalize_forum_url(url):
    if not url:
        return url
    parts = urlsplit(url)
    path = parts.path
    xf_match = _XENFORO_THREAD_PATH_REGEX.match(path)
    if xf_match:
        path = f'{xf_match.group(1)}{xf_match.group(2)}/'
    drop_keys = set(_MYBB_NAV_ONLY_QUERY_KEYS)
    if _THREAD_PATH_REGEX.search(path):
        drop_keys.add('page')
    kept = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
            if k not in drop_keys]
    return urlunsplit((parts.scheme, parts.netloc, path, urlencode(kept), ''))


_NAV_LINK_TITLE_REGEX = re.compile(
    r'^[«»<>]*\s*(?:(?:next|previous|prev|first|last|newest|oldest|jump(?:\s+to\s+page)?)\s*)+[«»<>]*$',
    re.IGNORECASE,
)


def extract_match_snippet(content, matched_value, base_url=None, window=180):
    """
    Finds the specific spot `matched_value` actually occurs at in `content` and
    returns (snippet, specific_url) - the exact surrounding text (preferring a
    full markdown link title if the match sits inside one, e.g. a forum thread
    title) plus that link's own URL if one is present, so a finding points at
    the specific thread it came from rather than just the board index page.

    The same value can legitimately appear more than once on a page (a
    breadcrumb/pagination widget near the top, the real thread title further
    down) - every occurrence is considered and the least nav-dense one wins,
    rather than always taking the first, so a finding doesn't end up pointing
    at a scrap of pagination markup instead of the actual content.
    Returns (None, None) if the value isn't found (shouldn't normally happen).
    """
    lowered = content.lower()
    target = (matched_value or '').lower()
    if not target:
        return None, None
    occurrences = []
    start = 0
    while True:
        idx = lowered.find(target, start)
        if idx == -1:
            break
        occurrences.append(idx)
        start = idx + 1
    if not occurrences:
        return None, None

    # Tolerates one level of nested [..] inside the title - confirmed real:
    # xforums.st renders category-tag-prefixed thread teasers as
    # "[[JSON] telefonica.com 700k](/threads/...)", where a naive
    # "[^\]]*" capture stops at the FIRST "]" (closing the inner "[JSON]"
    # tag) and never recognizes the outer construct as a link at all - the
    # match then falls through to the no-link fallback, loses its resolvable
    # thread URL, and stops merging with the same thread's other mentions.
    link_re = re.compile(r'\[((?:[^\[\]]|\[[^\[\]]*\])*)\]\(([^)\s]+)\)')
    all_links = list(link_re.finditer(content))

    # Prefer an occurrence that sits inside a real markdown link with a
    # substantial, non-numeric title (e.g. a thread title, not a bare page
    # number link like "[5](forum-10-page-5.html)") - among those, the least
    # nav-dense one. Also excludes pagination-control link text ("«
    # Previous", "Next »", "Jump to page", ...) - confirmed: "« Previous" is
    # 10 non-numeric characters, easily clearing the length check, so without
    # this it can win as the "best link" on a deep reply page and become the
    # entire match_snippet/description, pointing the finding at a pagination
    # widget instead of any real content.
    best_link = None
    for idx in occurrences:
        for m in all_links:
            if m.start() <= idx <= m.end():
                title = re.sub(r'\s+', ' ', m.group(1)).strip(' |')
                if len(title) >= 8 and not title.isdigit() and not _NAV_LINK_TITLE_REGEX.match(title):
                    if best_link is None or _link_density(content, idx) < _link_density(content, best_link[0]):
                        best_link = (idx, m)
                break
    if best_link:
        _, m = best_link
        title = re.sub(r'\s+', ' ', m.group(1)).strip(' |')
        href = m.group(2).strip()
        if href.startswith('http'):
            pass
        elif base_url:
            scheme_host = re.match(r'(https?://[^/]+)', base_url)
            href = (scheme_host.group(1) if scheme_host else '') + '/' + href.lstrip('/')
        else:
            href = None
        if href:
            href = _canonicalize_forum_url(href)
        if title:
            return title, href

    # No good link anywhere - fall back to the least nav-dense raw occurrence
    # (e.g. the match sitting inside plain bold text on a thread's own page,
    # rather than a link at all).
    idx = min(occurrences, key=lambda i: _link_density(content, i))
    start_i = max(0, idx - window)
    end_i = min(len(content), idx + len(matched_value) + window)
    snippet = content[start_i:end_i]
    snippet = re.sub(r'\s+', ' ', snippet).strip()
    if start_i > 0:
        snippet = '...' + snippet
    if end_i < len(content):
        snippet = snippet + '...'
    return snippet, None


def extract_analysis_window(content, matched_value, radius=2000):
    """
    Text to run entity/sensitive-signal/risk analysis over - the full page
    for a small/focused document, otherwise a merged window around every
    occurrence of `matched_value`. A busy multi-thread listing page (a forum
    homepage's "recent activity" feed, a board index) mentions the searched
    domain once but is otherwise full of OTHER unrelated threads' content;
    scanning the whole page for entities/signals then attributes those other
    threads' credentials/breach/financial keywords to this domain's finding.
    Confirmed: inflated a finding to CRITICAL/89 with "financial, exploit,
    leak_breach" signals that actually belonged to different leaks also
    listed on the same xforums.st homepage. Windowing keeps analysis honestly
    scoped to content actually near the match, at the cost of possibly
    missing entities that are genuinely part of the same post but far from
    where the domain itself is mentioned - an acceptable trade given a false
    CRITICAL is worse than an under-counted entity list.
    """
    if not matched_value or len(content) <= radius * 2:
        return content
    lowered = content.lower()
    target = matched_value.lower()
    spans = []
    start = 0
    while True:
        idx = lowered.find(target, start)
        if idx == -1:
            break
        spans.append((max(0, idx - radius), min(len(content), idx + len(matched_value) + radius)))
        start = idx + 1
    if not spans:
        return content
    spans.sort()
    merged = [spans[0]]
    for s, e in spans[1:]:
        ls, le = merged[-1]
        if s <= le:
            merged[-1] = (ls, max(le, e))
        else:
            merged.append((s, e))
    return '\n...\n'.join(content[s:e] for s, e in merged)


# MyBB (darkforums.ru's own forum software) renders a thread's own page as
# a bold title immediately followed by "by <name> - <date>" for the ORIGINAL
# poster. A board listing page instead shows a linked username then a date
# for the most recent reply on that thread - real data, but a different
# person. Keeping these as two separate, explicitly-labelled patterns avoids
# quietly presenting "whoever last bumped the thread" as the leak's author.
_AUTHOR_DATE_REGEX = re.compile(
    r"\d{1,2}-\d{1,2}-\d{2,4},?\s*\d{1,2}:\d{2}\s*[APap][Mm]"
)
_THREAD_OP_REGEX = re.compile(
    r"\*\*[^*]{0,300}\*\*\s*\n+\s*by\s+([A-Za-z0-9_.\-]{2,32})\s*-\s*"
    r"(\d{1,2}-\d{1,2}-\d{2,4},?\s*\d{1,2}:\d{2}\s*[APap][Mm])"
)
_LISTING_LASTPOST_REGEX = re.compile(
    r"by\s+\[([A-Za-z0-9_.\-]{2,32})\]\([^)]*\)\s*\n\s*"
    r"(\d{1,2}-\d{1,2}-\d{2,4},?\s*\d{1,2}:\d{2}\s*[APap][Mm])"
)
# XenForo's own thread-page equivalent of _THREAD_OP_REGEX (confirmed
# against real xforums.st captures: "* __ Thread starter [<name>](...)"
# immediately followed by "* __ Start date [<date>](...)" - a completely
# different markup and date format from MyBB's, so the MyBB-only regex
# above always missed it and every XenForo finding showed "not identified"
# even when the page plainly names the poster.
_XENFORO_THREAD_OP_REGEX = re.compile(
    r"Thread\s+starter\s*\[([^\]]{1,80})\]\([^)]*\)"
    r"[\s\S]{0,60}?Start\s+date\s*\[([^\]]{1,40})\]",
    re.IGNORECASE,
)


def extract_thread_authorship(content, matched_value):
    """
    Best-effort "who posted this, and when" - grounded in darkforums.ru's own
    MyBB page structure rather than guessed:
      - on an actual thread page, the bold thread title is immediately
        followed by "by <name> - <date>" for the ORIGINAL poster -> high
        confidence, author_confidence='op'.
      - on a board listing page, each row instead shows a linked username
        then a date for the most recent reply, not necessarily the original
        poster -> author_confidence='last_post'. Only the row nearest the
        actual match is used, not just the first one on the page.
    Returns {'author', 'author_confidence', 'published'} - all None if
    neither pattern is found on this page.
    """
    op_match = _THREAD_OP_REGEX.search(content)
    if op_match:
        return {'author': op_match.group(1), 'author_confidence': 'op', 'published': op_match.group(2)}

    xf_op_match = _XENFORO_THREAD_OP_REGEX.search(content)
    if xf_op_match:
        return {'author': xf_op_match.group(1), 'author_confidence': 'op', 'published': xf_op_match.group(2)}

    idx = content.lower().find((matched_value or '').lower())
    window = content[idx:idx + 600] if idx != -1 else content
    lp_match = _LISTING_LASTPOST_REGEX.search(window)
    if lp_match:
        return {'author': lp_match.group(1), 'author_confidence': 'last_post', 'published': lp_match.group(2)}

    return {'author': None, 'author_confidence': None, 'published': None}


_SEVERITY_LABELS = {'LOW': 'Low Threat', 'MEDIUM': 'Medium Threat', 'HIGH': 'High Threat', 'CRITICAL': 'Critical Threat'}


def severity_label(risk_level):
    return _SEVERITY_LABELS.get(risk_level, 'Unclassified')


def guess_victim_organisation(domain):
    """Readable label derived purely from the domain's own root name (e.g.
    'underarmour.com' -> 'Underarmour') - not looked up against any company
    registry, so this is a formatted stand-in for the domain, not a verified
    legal entity name."""
    root = domain.split('.')[0]
    root = re.sub(r'[-_]+', ' ', root).strip()
    return root.title() if root else domain


# Small, explainable keyword classifier - same coarse heuristic approach as
# classify_attack_vector. Not a verified industry classification, just the
# best-scoring keyword match over the page text.
_INDUSTRY_KEYWORDS = {
    'Government & Public Sector': ['government', 'ministry', 'municipal', 'electoral', 'tribunal', 'federal', '.gov', 'public sector', 'city of', 'state of'],
    'Financial Services': ['bank', 'banking', 'finance', 'financial', 'credit union', 'insurance', 'investment', 'payment processor'],
    'Healthcare': ['hospital', 'clinic', 'health', 'medical', 'patient', 'pharma', 'healthcare'],
    'Retail & E-commerce': ['shop', 'store', 'retail', 'e-commerce', 'ecommerce', 'marketplace', 'apparel', 'sportswear', 'fashion'],
    'Technology': ['software', 'saas', 'cloud', 'tech company', 'platform', 'api', 'app'],
    'Telecommunications': ['telecom', 'mobile carrier', 'isp', 'broadband'],
    'Education': ['university', 'college', 'school', 'student', 'academic'],
    'Energy & Utilities': ['energy', 'utility', 'power grid', 'oil', 'gas', 'electric'],
}


def guess_industry(text):
    lowered = text.lower()
    best_label, best_count = None, 0
    for label, keywords in _INDUSTRY_KEYWORDS.items():
        count = sum(lowered.count(kw) for kw in keywords)
        if count > best_count:
            best_label, best_count = label, count
    return best_label or 'Unclassified'


# Region/country inferred from the domain's own country-code TLD - a real,
# documented ISO mapping, not a guess. Generic TLDs (.com/.net/.org/...)
# carry no country signal at all, so they stay Unclassified rather than
# being forced into a guess.
_CCTLD_REGION_COUNTRY = {
    'us': ('North America', 'United States'), 'ca': ('North America', 'Canada'),
    'mx': ('Latin America', 'Mexico'), 'cr': ('Latin America', 'Costa Rica'),
    'br': ('Latin America', 'Brazil'), 'ar': ('Latin America', 'Argentina'),
    'cl': ('Latin America', 'Chile'), 'co': ('Latin America', 'Colombia'),
    'uk': ('Europe', 'United Kingdom'), 'de': ('Europe', 'Germany'),
    'fr': ('Europe', 'France'), 'es': ('Europe', 'Spain'), 'it': ('Europe', 'Italy'),
    'nl': ('Europe', 'Netherlands'), 'ru': ('Europe', 'Russia'), 'se': ('Europe', 'Sweden'),
    'ch': ('Europe', 'Switzerland'), 'pl': ('Europe', 'Poland'), 'ie': ('Europe', 'Ireland'),
    'cn': ('Asia-Pacific', 'China'), 'jp': ('Asia-Pacific', 'Japan'), 'in': ('Asia-Pacific', 'India'),
    'au': ('Asia-Pacific', 'Australia'), 'sg': ('Asia-Pacific', 'Singapore'), 'kr': ('Asia-Pacific', 'South Korea'),
    'nz': ('Asia-Pacific', 'New Zealand'),
    'za': ('Africa', 'South Africa'), 'ng': ('Africa', 'Nigeria'), 'eg': ('Africa', 'Egypt'),
    'ae': ('Middle East', 'United Arab Emirates'), 'sa': ('Middle East', 'Saudi Arabia'), 'il': ('Middle East', 'Israel'),
}


def guess_region_country(domain):
    tld = domain.rsplit('.', 1)[-1].lower()
    region, country = _CCTLD_REGION_COUNTRY.get(tld, (None, None))
    return region or 'Unclassified', country or 'Unclassified'


# Real breach posts (this one included, when tested against darkforums.ru)
# often contain actual prose describing what happened, not just a bare
# domain mention - e.g. "In November 2025, the Everest ransomware group
# claimed Under Armour as a victim... obtained access to 343GB of data."
# Pulling that real sentence out beats generating a generic templated one.
_NARRATIVE_KEYWORD_RE = re.compile(
    r"\b(leak(ed)?|breach(ed)?|hack(ed)?|ransomware|compromis(ed|e)|exposed|"
    r"stolen|extort(ed|ion)?|claimed|database|records?|dump(ed)?|victim|"
    r"attack(ed)?|customers?|accounts?)\b",
    re.IGNORECASE,
)


# Each post on a MyBB thread page carries a post-number badge like
# "**[#1](...)**" (OP) or "**[#9](...)**" (a reply). On a busy thread this is
# the only reliable boundary between the ORIGINAL post and its replies in
# the extracted text - without it, narrative/keyword extraction over the
# whole page can accidentally pick up a reply's text (confirmed on a real
# thread: a one-line reply "Bravo!! How much for all the data?" got pulled
# in as the "description" instead of the actual breach writeup).
_POST_NUMBER_BADGE_RE = re.compile(
    r'\*\*\[#\d+\]\(.*?\)\*\*\s*\d{1,2}-\d{1,2}-\d{2,4},?\s*\d{1,2}:\d{2}\s*[APap][Mm]'
    r'(?:\s*\(This\s+post\s+was\s+last\s+modified:.*?\.\))?',
    re.DOTALL,
)


def extract_op_post_text(content):
    """Isolates the original post's own text on a thread page - from its
    post-number badge up to the next post's badge (or end of page).
    Returns None if the page doesn't have this structure (e.g. a board
    listing page, which has none of these badges at all)."""
    matches = list(_POST_NUMBER_BADGE_RE.finditer(content))
    if not matches:
        return None
    start = matches[0].end()
    end = matches[1].start() if len(matches) > 1 else len(content)
    return content[start:end]


def _strip_leading_markup(text, max_iterations=4):
    """Peels off leading markdown image/link wrappers (e.g. a linked image
    '[![alt](imgurl)](wrapping_url)' immediately before a post's own text -
    a real, observed pattern) so extracted narrative text starts at the
    actual prose, not mid-markup."""
    for _ in range(max_iterations):
        text = text.lstrip()
        if text[:1] in ('!', '[', ']'):
            idx = text.find(')')
            if idx == -1:
                break
            text = text[idx + 1:]
        else:
            break
    return text.lstrip()


def extract_narrative_paragraph(content, min_len=100, max_len=700):
    """Best real prose paragraph on the page - the first one that's long
    enough, mentions breach-relevant language, and isn't itself a nav/
    pagination link cluster. Returns None if nothing qualifies (most pages,
    e.g. plain board listings, won't have one).

    Only the leading `max_len` slice of each paragraph is what actually gets
    judged and returned - a real post's own narrative often runs straight
    into a PoC/sample data block with no blank line in between (confirmed on
    a real post: prose then a comma-separated dump, same "paragraph"), which
    would otherwise make the whole thing look like one giant, link-dense blob
    and get rejected outright even though its opening sentences are exactly
    the real narrative."""
    for para in re.split(r'\n\s*\n', content):
        clean = _strip_leading_markup(re.sub(r'\s+', ' ', para).strip())
        if len(clean) < min_len:
            continue
        candidate = clean[:max_len]
        if candidate.count('](') > 2:
            continue
        if not _NARRATIVE_KEYWORD_RE.search(normalize_homoglyphs(candidate)):
            continue
        # Prose commonly runs straight into a PoC/sample/code block with no
        # blank line - cut there rather than spilling raw sample data into
        # what's meant to be a narrative description.
        cutoff = re.search(r'\b(PoC|Sample|Code)\s*:', candidate)
        if cutoff and cutoff.start() >= min_len:
            candidate = candidate[:cutoff.start()].rstrip()
        elif len(clean) > max_len:
            candidate = candidate.rsplit(' ', 1)[0] + '...'
        return candidate
    return None


# Common "breach overview" style structured fields seen on darkforums.ru
# breach reposts (mirrors the HaveIBeenPwned-style layout some posts copy).
# Real, present-or-absent data - never fabricated when missing.
_BREACH_OVERVIEW_LABELS = ['Affected Accounts', 'Breach Occurred', 'Added to HIBP', 'Attribution']


def extract_breach_overview_fields(content):
    fields = {}
    for label in _BREACH_OVERVIEW_LABELS:
        m = re.search(re.escape(label) + r':?\s*\n?\s*([^\n]{1,120})', content)
        if m:
            fields[label] = m.group(1).strip()
    return fields


def extract_compromised_data_types(content):
    """The bullet list under a 'Compromised Data' header, if the page has
    one - e.g. ['Dates of birth', 'Email addresses', 'Names', ...]."""
    m = re.search(r'Compromised Data\s*\n((?:[A-Za-z][A-Za-z /]{2,40}\n){1,15})', content)
    if not m:
        return []
    return [line.strip() for line in m.group(1).splitlines() if line.strip()][:10]


# Distinguishes "who actually did this" (a named attacking group, when the
# post content itself credits one) from "who posted/reshared this on the
# forum" (extract_thread_authorship) - conflating the two overstates what a
# forum account/moderator reposting a breach write-up actually did.
_ACTOR_GROUP_REGEX = re.compile(
    r"\bthe\s+([A-Z][A-Za-z0-9]{2,30})\s+(?:ransomware|hacking|threat|extortion)\s+group\b"
)


def extract_named_actor_group(content):
    """Returns (name, source_label) for a group explicitly credited in the
    page's own text - e.g. ('Everest', 'named in post content') or
    ('DeHashed', 'Attribution field on this page') - or (None, None)."""
    m = _ACTOR_GROUP_REGEX.search(normalize_homoglyphs(content))
    if m:
        return m.group(1), 'named in post content'
    overview = extract_breach_overview_fields(content)
    if overview.get('Attribution'):
        return overview['Attribution'], 'Attribution field on this page'
    return None, None


def summarize_document(matches, entities, sensitive_signals, domain):
    """One-paragraph, deterministic natural-language summary of what was found
    on a single matched document - what a client actually wants to read
    instead of a raw entity dump."""
    match_types = sorted(set(m['match_type'] for m in matches))
    type_labels = {
        'exact_domain': 'a direct mention of the domain',
        'url': 'an outbound link to the domain',
        'subdomain': 'a link to a subdomain of the domain',
        'email_domain': 'an email address on the domain',
        'contextual': 'a loose textual mention of the domain',
        'keyword_mention': 'a mention of the search term',
    }
    found_desc = ', '.join(type_labels.get(t, t) for t in match_types)
    parts = [f"This page contains {found_desc} for {domain}."]

    extras = []
    if entities.get('emails'):
        extras.append(f"{len(entities['emails'])} email address(es)")
    if entities.get('ips'):
        extras.append(f"{len(entities['ips'])} IP address(es)")
    if entities.get('usernames'):
        extras.append(f"{len(entities['usernames'])} user handle(s)")
    other_urls = len(entities.get('urls', []))
    if other_urls:
        extras.append(f"{other_urls} other outbound link(s)")
    if extras:
        parts.append("Also present on the page: " + ", ".join(extras) + ".")

    if sensitive_signals:
        parts.append(
            "Sensitive-content signals detected: " + ", ".join(sensitive_signals) +
            " - manual review recommended."
        )
    else:
        parts.append("No credential, leak, financial, or exploit-related language detected on this page.")

    return " ".join(parts)


def classify_matches(text, target_domain):
    """
    Deterministic domain-match classification. Returns a list of
    {match_type, matched_value, confidence} - possibly more than one
    per document (e.g. both an exact mention and a subdomain mention).

    match_type / confidence, most to least specific:
      exact_domain     high    - the bare domain appears in the text
      subdomain        high    - a subdomain of the domain appears (found via
                                  an extracted URL - a bare-word scan without a
                                  URL scheme is deliberately not done, it is a
                                  noisy, expensive full-text scan that mostly
                                  matches CSS/JS tokens, not real mentions)
      url              high    - a URL containing the domain appears
      email_domain     medium  - an extracted email's domain matches
      contextual       low     - domain substring appears but not as a clean token
                                  (e.g. inside a longer word) - reported, not discarded

    Every URL in the document is decoded at most once (memoized), so cost is
    O(unique urls + unique emails) per document, not O(all text tokens).
    """
    matches = []
    domain_re = re.compile(r'(?<![A-Za-z0-9.-])' + re.escape(target_domain) + r'(?![A-Za-z0-9-])')

    if domain_re.search(text):
        matches.append({'match_type': 'exact_domain', 'matched_value': target_domain, 'confidence': 'high'})

    seen_subdomains = set()
    for url in extract_urls(text):
        decoded = _decode_url(url)
        if not decoded or decoded.get('domain') != target_domain:
            continue
        matches.append({'match_type': 'url', 'matched_value': url, 'confidence': 'high'})
        subdomain = decoded.get('subdomain')
        if subdomain and subdomain not in seen_subdomains:
            seen_subdomains.add(subdomain)
            matches.append({'match_type': 'subdomain', 'matched_value': f'{subdomain}.{target_domain}', 'confidence': 'high'})

    for email in extract_emails(text):
        email_domain = email.rsplit('@', 1)[-1].lower()
        if email_domain == target_domain:
            matches.append({'match_type': 'email_domain', 'matched_value': email, 'confidence': 'medium'})

    if not matches and target_domain.lower() in text.lower():
        matches.append({'match_type': 'contextual', 'matched_value': target_domain, 'confidence': 'low'})

    return matches


def classify_keyword_matches(text, keyword):
    """
    Free-text/organisation-name search variant of classify_matches - for
    when the thing worth searching for (a company or agency name) is never
    written as a domain in the post at all, only named in prose. No
    domain-specific classification applies here (there's nothing to check a
    URL or email's domain against), so this is a single, honest match_type -
    the phrase is either found (case-insensitive) or it isn't.
    """
    if not keyword:
        return []
    # Word-boundary anchored, not a bare substring search - confirmed a bare
    # search made "meta" match the username "MetaCloud" and would equally
    # match "metadata"/"metaverse"/etc., none of which are actually about
    # the searched term. \b sits at a word-char/non-word-char transition,
    # which correctly excludes "meta" inside "MetaCloud" (a-to-C is not a
    # boundary) while still matching it standalone or next to punctuation
    # ("Meta's servers", "at meta.com").
    if re.search(rf'\b{re.escape(keyword)}\b', text, re.IGNORECASE):
        return [{'match_type': 'keyword_mention', 'matched_value': keyword, 'confidence': 'high'}]
    return []


# Labeled only, same conservative approach as USERNAME_HINT_REGEX above - a
# bare run-of-digits scan over forum text mostly finds thread IDs, post
# counts, and dates, not phone numbers. Requiring an explicit label keeps
# false positives out of what's supposed to be a short, trustworthy list.
PHONE_HINT_REGEX = re.compile(
    r'(?:phone|mobile|tel(?:ephone)?|contact\s*no\.?|whatsapp)\s*[:=]\s*(\+?[\d][\d\-.\s()]{6,18}\d)',
    re.IGNORECASE,
)


def extract_phones(text):
    found = set()
    for m in PHONE_HINT_REGEX.finditer(text):
        digits = re.sub(r'\D', '', m.group(1))
        if 8 <= len(digits) <= 15:
            found.add(m.group(1).strip())
    return sorted(found)


def _split_credential_blob(blob):
    """
    A combo-list line (`url:user:pass` or `url|user|pass`, the standard
    stealer-log/leak-dump format) gets captured whole by URL_REGEX, since
    that regex only stops at whitespace/quotes/brackets, not ':' or '|' -
    confirmed on real xforums.st content like
    "https://portal.azure.com:mawere:Lynettvongai1997" coming back as a
    single "url" entity rather than three fields. This splits one of those
    blobs back into (url, second_field, third_field), or None if it isn't
    actually shaped like one (a plain URL with no trailing fields).
    """
    scheme_end = blob.find('://')
    if scheme_end == -1:
        return None
    for sep in ('|', ':'):
        if sep == '|':
            if sep not in blob:
                continue
            parts = blob.split(sep)
            if len(parts) < 3:
                continue
            url, fields = parts[0], parts[1:]
        else:
            rest = blob[scheme_end + 3:]
            if sep not in rest:
                continue
            head, _, tail = rest.partition(sep)
            if not tail:
                continue
            url = blob[:scheme_end + 3] + head
            fields = tail.split(sep)
        if len(fields) >= 2 and url.lower().startswith(('http://', 'https://')):
            return url, fields[0], sep.join(fields[1:])
    return None


def extract_credential_records(text, domain=None, keyword=None):
    """
    Individual leaked-credential records - one dict per unique credential,
    each with only the fields actually present (some subset of email,
    username, password) - scoped to combo-list-style `url:user:pass` /
    `url|user|pass` lines. Each of these is a distinct real leak, not a
    narrative mention, so each becomes its own finding rather than being
    bundled with everything else found on the same page.

    domain=<a domain>: only combo lines whose URL actually resolves to that
    domain count - this is what makes a domain-type search's findings
    trustworthy (a combo line for some unrelated site sitting on the same
    page must never be attributed to the searched domain).

    keyword=<a keyword> (with domain=None): keyword-search mode WITH
    attribution - a combo line counts only when the searched keyword actually
    appears in that line's OWN URL host/domain. This is what stops a combo
    dump (one forum post pasting hundreds of `url:user:pass` lines for many
    unrelated sites, e.g. a CryptBB "DM me for more!" thread) from attributing
    every line to the searched keyword just because ONE line on the page was
    an accounts.google.com match. It keeps the genuine on-keyword case
    ("tgpecatsindia.tatamotors.com-18-818" for a "tatamotors" search, whose
    combo URL host contains the keyword) while dropping the airbnb/64tbajee
    noise sitting in the same dump.

    domain=None and keyword=None: legacy unscoped keyword mode - every
    combo-shaped line in `text` is returned. Only safe when the caller has
    already tightly scoped `text` to a single on-topic record; prefer passing
    `keyword` so cross-site combos in a shared dump are not misattributed.
    """
    seen = set()
    records = []
    kw = (keyword or '').strip().lower()
    for blob in extract_urls(text):
        split = _split_credential_blob(blob)
        if not split:
            continue
        url, field2, field3 = split
        if domain is not None:
            decoded = _decode_url(url)
            if not decoded or decoded.get('domain') != domain:
                continue
        elif kw:
            # Attribution gate: the combo's own URL must actually relate to the
            # searched keyword, else an unrelated line sharing the dump is a
            # false positive for this keyword.
            decoded = _decode_url(url)
            host = ((decoded or {}).get('host') or (decoded or {}).get('domain') or '').lower()
            if kw not in host:
                continue
        # A field that is itself the generic field-name word (rather than a
        # real value), or that contains more than one '@', means this blob
        # wasn't actually stealer-log combo data - it's forum prose (e.g.
        # "...newuser: Username: password Email: dimafo6633@acname.com...")
        # that happened to have a URL and two colons in it. Confirmed on
        # real xforums.st content: a search-results snippet produced
        # {'username': 'password', 'password': 'dimafo6633@dimafo6633@acname.com'}
        # from exactly this shape - a fabricated-looking credential sitting
        # right next to the same page's genuine, cleanly-extracted email.
        if _looks_like_field_label(field2) or _looks_like_field_label(field3):
            continue
        if field2.count('@') > 1 or field3.count('@') > 1:
            continue
        record = {}
        if '@' in field2:
            record['email'] = field2
        elif field2:
            record['username'] = field2
        if field3:
            record['password'] = field3
        if not record:
            continue
        key = tuple(sorted(record.items()))
        if key in seen:
            continue
        seen.add(key)
        records.append(record)
    return records


_CREDENTIAL_FIELD_LABEL_WORDS = {
    'username', 'user', 'password', 'pass', 'pwd', 'email', 'e-mail',
    'login', 'mail', 'account',
}


def _looks_like_field_label(value):
    return value.strip().lower().rstrip(':') in _CREDENTIAL_FIELD_LABEL_WORDS


_TITLE_BOILERPLATE_SUBSTRINGS = (
    'not responsible', 'contact admin', 'disclaimer', 'terms of service',
    'all rights reserved', 'jump to page',
)


def extract_thread_title(content):
    """
    Best-effort thread title, sourced ONLY from the original post's own text
    (extract_op_post_text) - never from the raw page, which is mostly site
    furniture (nav links, forum-wide disclaimers) shared by every page on
    the forum and just as likely to get picked as an actual title. Returns
    None (never a placeholder) whenever the page isn't a real thread page,
    or nothing in the post text reads like a headline.
    """
    op_text = extract_op_post_text(content)
    if not op_text:
        return None
    for line in op_text.splitlines()[:15]:
        line = line.strip().lstrip('#').strip()
        if not line or len(line) < 8 or len(line) > 180:
            continue
        low = line.lower()
        if any(b in low for b in _TITLE_BOILERPLATE_SUBSTRINGS):
            continue
        if line.startswith('[') or line.startswith('!['):
            continue
        if re.match(r'^[A-Za-z0-9]', line):
            return line
    return None
