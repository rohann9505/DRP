#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Per-forum crawl metrics and history.

Stores one record per crawl run so the dashboard can answer "is the problem
fetching, parsing, deduplication, or storage?" without reading logs. This is
the reporting layer the audit found missing: previously a forum exposed only
`document_count` and `last_crawl_status`, so a crawl that was blocked on page 1
was indistinguishable from one that collected everything - both showed
'success'.

Kvrocks layout (same connection + key-prefix convention as the rest of the
crawler-adjacent features):
    forumcrawl:runs:<forum_id>     LIST of json blobs, newest first (capped)
    forumcrawl:last:<forum_id>     HASH, latest run summary
    forumcrawl:cursor:<forum_id>   HASH, incremental state
    forumcrawl:state:<forum_id>    HASH, live status (running/idle + progress)
"""

import os
import sys
import json
import time

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers

MAX_RUNS_KEPT = 50


def _r():
    return crawlers.r_crawler


def record_run(forum_id, metrics_dict):
    r = _r()
    payload = dict(metrics_dict)
    payload['recorded_at'] = int(time.time())
    r.lpush(f'forumcrawl:runs:{forum_id}', json.dumps(payload))
    r.ltrim(f'forumcrawl:runs:{forum_id}', 0, MAX_RUNS_KEPT - 1)
    # A Kvrocks hash stores strings, so str(None) used to persist the literal
    # "None" - which reads back TRUTHY and rendered in the UI as
    # `The source responded: "None"`. Absent values are stored empty and
    # decoded back to None in _coerce().
    r.hset(f'forumcrawl:last:{forum_id}', mapping={
        k: json.dumps(v) if isinstance(v, (list, dict))
        else ('' if v is None else str(v))
        for k, v in payload.items()
    })
    return payload


def get_last_run(forum_id):
    raw = _r().hgetall(f'forumcrawl:last:{forum_id}')
    if not raw:
        return None
    return _coerce(raw)


def list_runs(forum_id, limit=MAX_RUNS_KEPT):
    out = []
    for blob in _r().lrange(f'forumcrawl:runs:{forum_id}', 0, limit - 1):
        try:
            out.append(json.loads(blob))
        except Exception:
            continue
    return out


def _coerce(raw):
    out = {}
    int_fields = {'pages_fetched', 'documents_discovered', 'documents_parsed',
                  'documents_stored', 'duplicates_skipped', 'documents_rejected',
                  'attachments_discovered', 'errors', 'retries', 'duration',
                  'stale_results',
                  'started_at', 'recorded_at'}
    # Tri-state: True / False / None ("we could not determine"). Must come back
    # as a real bool, because the string 'False' is truthy in a template.
    bool_fields = {'block_proxy_may_help'}
    for k, v in raw.items():
        if k in int_fields:
            try:
                out[k] = int(v)
            except (TypeError, ValueError):
                out[k] = 0
        elif k == 'error_details':
            try:
                out[k] = json.loads(v)
            except Exception:
                out[k] = []
        elif k in bool_fields:
            out[k] = {'True': True, 'False': False}.get(v)
        else:
            # '' is the new encoding for absent; 'None' is the legacy one, still
            # present in already-recorded runs and decoded here rather than
            # requiring a data migration.
            out[k] = None if v in ('', 'None') else v
    return out


# ---------------------------------------------------------------------------
# Incremental cursor
# ---------------------------------------------------------------------------

def get_cursor(forum_id):
    raw = _r().hgetall(f'forumcrawl:cursor:{forum_id}')
    if not raw:
        return {}
    out = dict(raw)
    if 'highest_thread_id' in out:
        try:
            out['highest_thread_id'] = int(out['highest_thread_id'])
        except (TypeError, ValueError):
            out['highest_thread_id'] = None
    return out


def set_cursor(forum_id, highest_thread_id=None, last_url=None, last_timestamp=None):
    mapping = {'updated_at': int(time.time())}
    if highest_thread_id is not None:
        mapping['highest_thread_id'] = int(highest_thread_id)
    if last_url:
        mapping['last_url'] = last_url
    if last_timestamp:
        mapping['last_timestamp'] = last_timestamp
    _r().hset(f'forumcrawl:cursor:{forum_id}', mapping=mapping)


def reset_cursor(forum_id):
    """Full crawl / resync: forget incremental state so the next run walks
    the available history again from page 1."""
    _r().delete(f'forumcrawl:cursor:{forum_id}')


# ---------------------------------------------------------------------------
# Live crawl state (for the LIVE CRAWL indicator + overlap prevention)
# ---------------------------------------------------------------------------

RUNNING_TTL = 3600  # a crawl that somehow never clears its lock self-heals


def mark_running(forum_id, job_id=None):
    """Claim the crawl lock. Returns False if a crawl is already running for
    this forum - the overlap guard required for a 1-minute schedule."""
    r = _r()
    key = f'forumcrawl:running:{forum_id}'
    if not r.set(key, job_id or str(int(time.time())), nx=True, ex=RUNNING_TTL):
        return False
    r.hset(f'forumcrawl:state:{forum_id}', mapping={
        'status': 'crawling', 'started_at': int(time.time()),
        'pages': 0, 'documents': 0, 'new': 0,
    })
    return True


def is_running(forum_id):
    return bool(_r().exists(f'forumcrawl:running:{forum_id}'))


def update_progress(forum_id, pages=None, documents=None, new=None):
    mapping = {}
    if pages is not None:
        mapping['pages'] = pages
    if documents is not None:
        mapping['documents'] = documents
    if new is not None:
        mapping['new'] = new
    if mapping:
        _r().hset(f'forumcrawl:state:{forum_id}', mapping=mapping)


def mark_finished(forum_id, status='idle', summary=None):
    r = _r()
    r.delete(f'forumcrawl:running:{forum_id}')
    mapping = {'status': status, 'finished_at': int(time.time())}
    if summary:
        mapping.update({k: str(v) for k, v in summary.items()})
    r.hset(f'forumcrawl:state:{forum_id}', mapping=mapping)


def get_state(forum_id):
    raw = _r().hgetall(f'forumcrawl:state:{forum_id}')
    if not raw:
        return {'status': 'idle'}
    out = dict(raw)
    for k in ('pages', 'documents', 'new', 'started_at', 'finished_at'):
        if k in out:
            try:
                out[k] = int(out[k])
            except (TypeError, ValueError):
                pass
    out['running'] = is_running(forum_id)
    return out


# ---------------------------------------------------------------------------
# Crawl job queue
#
# The UI must never run a crawl inside the Flask request - a full paginated
# walk takes minutes. Routes enqueue here and ForumMonitorWorker executes,
# reusing the same worker architecture as the rest of the platform rather than
# spawning an independent loop inside the web process.
# ---------------------------------------------------------------------------
QUEUE_KEY = 'forumcrawl:queue'


def enqueue_crawl(forum_id, full_resync=False):
    _r().rpush(QUEUE_KEY, json.dumps({'forum_id': forum_id,
                                      'full_resync': bool(full_resync),
                                      'queued_at': int(time.time())}))
    _r().hset(f'forumcrawl:state:{forum_id}', mapping={'status': 'queued'})


def pop_crawl_job():
    raw = _r().lpop(QUEUE_KEY)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def queue_depth():
    return _r().llen(QUEUE_KEY) or 0


def record_skipped_run(forum_id, why='previous crawl still running'):
    """A deferred run is recorded rather than dropped, so a 1-minute schedule
    that keeps colliding with a long crawl is visible instead of silent."""
    r = _r()
    r.hincrby(f'forumcrawl:state:{forum_id}', 'skipped_runs', 1)
    r.hset(f'forumcrawl:state:{forum_id}', mapping={
        'last_skipped_at': int(time.time()), 'last_skipped_reason': why})
