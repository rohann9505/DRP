#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Alert Dispatch
===================

Push delivery for watchlist alerts (webhook / Telegram / email), adapted
from the pattern in the open-source VoidAccess project's monitor/alerts.py
(MIT licensed) - reused here rather than hand-rolled from scratch, per the
explicit "use open source pieces instead of building everything ourselves"
direction.

Deliberately queued, not called inline: watchlist.record_alert() runs
inside Crawler.py's single-threaded capture loop (via
forum_collector._check_watchlist -> record_forum_document), and a
webhook/SMTP/Telegram call can take several real seconds on a slow network -
doing that synchronously there would stall every other queued capture behind
one alert delivery, the exact bug already fixed once this session for
evidence-screenshot capture (see intel_jobs.py's deferred-evidence-capture
comment). record_alert() only ever does a fast RPUSH here; the actual
network calls happen in AlertDispatchWorker.py, a separate process.

Channel configuration is global (one webhook/Telegram/email setup for the
whole platform, not per-watch) - the goal is "configure once, every match
pushes itself out with zero further action", not a per-watch setup chore.
"""

import json
import os
import smtplib
import sys
from email.mime.text import MIMEText

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers
from lib import watchlist
from lib import asset_data

r_crawler = crawlers.r_crawler

CONFIG_KEY = 'alert_channels:config'
DISPATCH_QUEUE_KEY = 'alert_dispatch:queue'


def get_channel_config():
    data = r_crawler.hgetall(CONFIG_KEY) or {}
    return {
        'webhook_url': data.get('webhook_url') or '',
        'telegram_bot_token': data.get('telegram_bot_token') or '',
        'telegram_chat_id': data.get('telegram_chat_id') or '',
        'smtp_host': data.get('smtp_host') or '',
        'smtp_port': int(data.get('smtp_port') or 587),
        'smtp_user': data.get('smtp_user') or '',
        'smtp_pass': data.get('smtp_pass') or '',
        'email_to': data.get('email_to') or '',
    }


def set_channel_config(**fields):
    r_crawler.hset(CONFIG_KEY, mapping=fields)
    return get_channel_config()


def queue_alert_delivery(alert_id):
    """Fast, non-blocking: called from watchlist.record_alert() itself."""
    r_crawler.rpush(DISPATCH_QUEUE_KEY, alert_id)


def pop_queued_delivery(timeout=5):
    popped = r_crawler.blpop([DISPATCH_QUEUE_KEY], timeout=timeout)
    if not popped:
        return None
    return popped[1]


def _send_webhook(url, payload, timeout=10):
    try:
        resp = requests.post(url, json=payload, timeout=timeout)
        return 200 <= resp.status_code < 300
    except Exception as e:
        print(f'send_webhook failed: {e}')
        return False


def _send_telegram(token, chat_id, text, timeout=10):
    try:
        api = f'https://api.telegram.org/bot{token}/sendMessage'
        resp = requests.post(api, json={'chat_id': chat_id, 'text': text[:4096]}, timeout=timeout)
        return resp.status_code == 200
    except Exception as e:
        print(f'send_telegram failed: {e}')
        return False


def _send_email(host, port, user, password, to, subject, body):
    try:
        msg = MIMEText(body, 'plain', 'utf-8')
        msg['Subject'] = subject
        msg['From'] = user or 'anorphix@localhost'
        msg['To'] = to
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.ehlo()
            if user and password:
                smtp.starttls()
                smtp.ehlo()
                smtp.login(user, password)
            smtp.sendmail(msg['From'], [to], msg.as_string())
        return True
    except Exception as e:
        print(f'send_email failed: {e}')
        return False


def _format_alert_message(alert, source):
    if source == 'asset':
        return (
            f"[Anorphix Alert] Asset Intelligence - {alert.get('alert_type')} on {alert.get('fqdn')} "
            f"(target {alert.get('target_id')}) - {alert.get('severity')} severity.\n"
            f"{alert.get('message') or ''}"
        )
    return (
        f"[Anorphix Alert] Watch \"{alert.get('watch_query')}\" ({alert.get('watch_query_type')}) "
        f"matched on {alert.get('forum_name')} - {alert.get('risk_level')} risk ({alert.get('risk_score')}).\n"
        f"Match: {alert.get('match_type')} = {alert.get('matched_value')}\n"
        f"{(alert.get('snippet') or '')[:300]}\n"
        f"Source: {alert.get('url')}"
    )


def _get_alert_by_id(alert_id):
    """Alerts come from two independent sources (watchlist matches, Asset
    Intelligence back-online/critical-vuln events) sharing this one
    delivery pipeline - try each store in turn rather than encoding source
    into the alert_id format, so neither store needs to know the other
    exists."""
    alerts = watchlist.list_alerts(limit=1000)
    alert = next((a for a in alerts if a.get('id') == alert_id), None)
    if alert:
        return alert, 'watchlist'
    alert = asset_data.get_alert(alert_id)
    if alert:
        return alert, 'asset'
    return None, None


def dispatch_one(alert_id):
    """
    Sends one queued alert out over every configured channel. Never raises -
    a delivery failure on one channel doesn't block the others, and the
    worker loop calling this must keep running regardless of what happens
    to any single alert.
    """
    alert, source = _get_alert_by_id(alert_id)
    if not alert:
        return []

    config = get_channel_config()
    text = _format_alert_message(alert, source)
    delivered = []

    if config['webhook_url']:
        payload = {'alert': alert, 'message': text}
        if _send_webhook(config['webhook_url'], payload):
            delivered.append('webhook')

    if config['telegram_bot_token'] and config['telegram_chat_id']:
        if _send_telegram(config['telegram_bot_token'], config['telegram_chat_id'], text):
            delivered.append('telegram')

    if config['smtp_host'] and config['email_to']:
        subject_value = alert.get('watch_query') if source == 'watchlist' else alert.get('fqdn')
        subject = f"Anorphix Alert: {subject_value}"
        if _send_email(config['smtp_host'], config['smtp_port'], config['smtp_user'],
                        config['smtp_pass'], config['email_to'], subject, text):
            delivered.append('email')

    return delivered
