#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Forum crawl engine
==================

The paginating collection loop that the platform previously did not have.

Before this, `forum_collector.collect_forum()` enqueued a single Lacus browser
capture at depth=2 and let the browser's own link-following decide what got
collected. There was no page loop, no next-page logic, no per-forum metrics and
no way to tell a real page from a block page - so a forum whose board sat
behind an anti-bot challenge (breached.st) stored the challenge interstitial
itself as a "document", four times over, while never reaching a single thread.

This module implements the loop the task specifies:

    START -> fetch page -> parse -> dedupe -> store -> determine next page
          -> repeat -> stop only on an explicit terminal condition

Every stop is attributed to a reason and reported; nothing terminates silently.

Fetching goes through Tor via the existing `requests`+SOCKS path so pages can
be walked at a controlled rate. Lacus/Playwright remains the right tool for a
single evidence capture with a screenshot, but it is a full browser per page -
unusable for walking dozens of listing pages, and it is what made pagination
impractical to add before.
"""

import os
import sys
import time
import random
import traceback
from urllib.parse import urlparse

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_providers
from lib.forum_providers import base as fp_base
from lib import forum_metrics


# ---------------------------------------------------------------------------
# Configurable safety limits.
#
# These are SAFETY limits, not collection targets: the crawl is expected to
# stop because it ran out of pages, not because it hit one of these. When one
# IS hit the job reports it verbatim ("Stopped at configured safety limit")
# rather than implying the crawl completed - the audit found forums sitting at
# 1 document with status 'success', which is exactly the silent-truncation
# behaviour these reports exist to prevent.
#
# Every value is overridable per forum (forum_registry.set_crawl_limits) and
# globally by environment variable.
# ---------------------------------------------------------------------------
def _env_int(name, default):
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


FORUM_CRAWL_MAX_PAGES = _env_int('FORUM_CRAWL_MAX_PAGES', 200)
FORUM_CRAWL_MAX_DOCUMENTS = _env_int('FORUM_CRAWL_MAX_DOCUMENTS', 5000)
FORUM_CRAWL_PAGE_SIZE = _env_int('FORUM_CRAWL_PAGE_SIZE', 20)

# Politeness. "Maximum accessible coverage" explicitly must not mean hammering
# a source: a fixed delay plus jitter between page fetches keeps the request
# rate roughly one page per couple of seconds, which is what kept xforums.st
# from tripping its DNSPROXY antibot during testing.
REQUEST_DELAY_SECONDS = float(os.environ.get('FORUM_CRAWL_DELAY', '2.0'))
REQUEST_JITTER_SECONDS = 1.0
REQUEST_TIMEOUT = 60
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 4  # seconds; 4, 8, 16

# Default transport when no route is resolved by the caller. Kept so a direct
# call to _session()/FetchBackend() with no route behaves exactly as it did
# before per-forum routing existed. forum_registry.resolve_route() is the
# authority for real crawls - see forum_ingest.run_forum_crawl.
TOR_PROXY = os.environ.get('FORUM_CRAWL_TOR_PROXY', 'socks5h://127.0.0.1:9050')

USER_AGENT = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

# Retryable transport-level HTTP statuses. 403 is deliberately NOT here: a 403
# from a WAF is a block, and retrying it fast is how you turn a block into a
# ban. It aborts the forum with an explicit access-failure reason instead.
_RETRY_STATUSES = {429, 500, 502, 503, 504, 408}

# Sentinel distinguishing "caller passed nothing" from "caller passed None
# meaning direct/no-proxy". Needed because None is a valid, meaningful value.
_UNSET = object()


class CrawlMetrics:
    """Per-forum collection metrics, reported verbatim by the job/dashboard."""

    def __init__(self, forum_id, provider_id):
        self.forum_id = forum_id
        self.provider = provider_id
        self.pages_fetched = 0
        self.documents_discovered = 0
        self.documents_parsed = 0
        self.documents_stored = 0
        self.duplicates_skipped = 0
        self.documents_rejected = 0
        self.attachments_discovered = 0
        self.errors = 0
        self.retries = 0
        self.started_at = int(time.time())
        self.duration = 0
        self.termination_reason = None
        self.error_details = []
        # Access-failure classification (see forum_providers.base.classify_block).
        # Persisted so crawl history distinguishes an IP block from a CAPTCHA
        # from an anti-spam account rejection instead of lumping them together.
        self.block_category = None
        self.block_info = {}
        # A search hit whose target 404s is the SOURCE's index being stale
        # (question deleted after indexing), not a fault of ours. Counted
        # separately so it never inflates a forum's error count and make a
        # healthy source look broken.
        self.stale_results = 0

    def note_error(self, msg):
        self.errors += 1
        if len(self.error_details) < 20:
            self.error_details.append(str(msg)[:300])

    def finish(self, reason):
        self.termination_reason = reason
        self.duration = int(time.time()) - self.started_at
        return self

    def to_dict(self):
        return {
            'forum_id': self.forum_id,
            'provider': self.provider,
            'pages_fetched': self.pages_fetched,
            'documents_discovered': self.documents_discovered,
            'documents_parsed': self.documents_parsed,
            'documents_stored': self.documents_stored,
            'duplicates_skipped': self.duplicates_skipped,
            'documents_rejected': self.documents_rejected,
            'attachments_discovered': self.attachments_discovered,
            'errors': self.errors,
            'retries': self.retries,
            'duration': self.duration,
            'termination_reason': self.termination_reason,
            'error_details': self.error_details,
            'started_at': self.started_at,
            'stale_results': self.stale_results,
            'block_category': self.block_category,
            'block_label': (fp_base.BLOCK_CATEGORY_LABELS.get(self.block_category)
                            if self.block_category else None),
            'block_message': (self.block_info or {}).get('message'),
            'block_proxy_may_help': (self.block_info or {}).get('proxy_may_help'),
        }


def load_cookiejar(cookiejar_uuid):
    """Load a stored cookiejar as plain cookie dicts.

    This is the LEGITIMATE route past an authentication wall: an operator has
    already logged into the forum and saved that session here. It supplies the
    analyst's own credentials - it does not defeat, guess, or bypass any
    access control.
    """
    if not cookiejar_uuid:
        return []
    try:
        from lib import crawlers as _c
        jar = _c.Cookiejar(cookiejar_uuid)
        if not jar.exists():
            return []
        out = []
        for meta in jar.get_cookies():
            name, value = meta.get('name'), meta.get('value')
            if not name or value is None:
                continue
            out.append({
                'name': name, 'value': value,
                'domain': meta.get('domain') or '',
                'path': meta.get('path') or '/',
            })
        return out
    except Exception:
        return []


class FetchBackend:
    """Two-tier fetcher: plain HTTP through Tor, with a real browser as the
    fallback for forums that answer with a JS anti-bot challenge.

    The browser is started lazily and only for a forum that actually needs it,
    then kept open for the whole crawl so challenge-clearance cookies are
    reused across pages instead of being re-earned on every request.
    """

    def __init__(self, allow_browser=True, cookiejar_uuid=None, route=None,
                 forum_id=None):
        # `route` is a resolved route dict from forum_registry.resolve_route().
        # Both transports are built from the SAME dict, so the browser fallback
        # can never silently egress somewhere different from the HTTP tier.
        self.route = route or {}
        self.route_mode = self.route.get('mode', 'tor')
        self.route_display = self.route.get('display', TOR_PROXY)
        if route is None:
            # Pre-routing default: Tor, exactly as before.
            http_proxy = TOR_PROXY
            self._browser_proxy = None  # BrowserSession's own Tor default
        else:
            http_proxy = self.route.get('http')
            self._browser_proxy = self.route.get('browser')
        self.http = _session(http_proxy)
        self.allow_browser = allow_browser
        self.cookiejar_uuid = cookiejar_uuid
        self.forum_id = forum_id
        self.browser = None
        self.using_browser = False
        # A persistent per-forum browser profile, if one has been established
        # (a human logged in once). Both tiers reuse it: the browser launches
        # from it directly, and its live cookies are synced onto the HTTP tier
        # after the browser first runs (see _sync_browser_cookies), so the two
        # transports never diverge on authenticated state.
        self._user_data_dir = None
        self._engine = None
        if forum_id:
            try:
                from lib import forum_session
                if forum_session.has_profile(forum_id):
                    self._user_data_dir = forum_session.profile_dir(forum_id)
                # Engine the profile was created with (Firefox for onion sites
                # that refuse Chromium). The browser tier MUST match it: a
                # Chromium cannot drive a Firefox profile, and some onions only
                # answer Firefox at all.
                self._engine = forum_session._engine_for(forum_id)
            except Exception:
                self._user_data_dir = None
        self.cookies = load_cookiejar(cookiejar_uuid) if cookiejar_uuid else []
        for c in self.cookies:
            try:
                self.http.cookies.set(c['name'], c['value'], domain=c.get('domain') or None)
            except Exception:
                continue

    def _ensure_browser(self):
        if self.browser is None:
            from lib import forum_browser
            if not forum_browser.is_available():
                return None
            kwargs = {'cookies': self.cookies}
            if self._user_data_dir:
                kwargs['user_data_dir'] = self._user_data_dir
            if self._engine:
                kwargs['engine'] = self._engine
            if self.route:
                # Explicit None means DIRECT - pass it through rather than
                # letting BrowserSession fall back to its Tor default.
                kwargs['proxy'] = self._browser_proxy
                kwargs['use_default_proxy'] = False
            self.browser = forum_browser.BrowserSession(**kwargs).start()
            self.using_browser = True
        return self.browser

    def _sync_browser_cookies(self):
        """Copy the live browser session's cookies onto the HTTP tier, so a
        later cheap HTTP page carries the same authenticated/clearance state the
        browser holds. Only values the source itself set - nothing invented."""
        if self.browser is None:
            return
        try:
            for c in self.browser.storage_cookies():
                self.http.cookies.set(c['name'], c['value'],
                                      domain=c.get('domain') or None)
        except Exception:
            pass

    def close(self):
        if self.browser is not None:
            self.browser.close()
            self.browser = None


def _is_onion_url(url):
    try:
        from urllib.parse import urlparse as _up
        return (_up(url).hostname or '').lower().endswith(('.onion', '.i2p'))
    except Exception:
        return False


def _session(proxy_url=_UNSET):
    """Build the requests transport.

    proxy_url=None means DIRECT (no proxy) - distinct from the default, which
    is Tor. The sentinel keeps "not specified" and "explicitly direct" apart,
    since None is a meaningful value here.
    """
    s = requests.Session()
    # TLS verification is NOT disabled globally. `fetch` turns it off only for
    # .onion/.i2p requests, where the hidden-service address is itself the
    # cryptographic identity and a self-signed cert is normal - a clearnet
    # host still gets full certificate validation.
    s.headers.update({
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    })
    if proxy_url is _UNSET:
        proxy_url = TOR_PROXY
    if proxy_url:
        s.proxies = {'http': proxy_url, 'https': proxy_url}
    else:
        # Direct: leave requests' proxies empty AND neutralise any ambient
        # http_proxy/HTTPS_PROXY environment variables, so "direct" really is
        # direct rather than silently inheriting a system proxy.
        s.proxies = {}
        s.trust_env = False
    return s


_TRANSPORT_DROP_SIGNS = (
    'ConnectionError', 'ConnectionResetError', 'RemoteDisconnected',
    'Connection aborted', 'ChunkedEncodingError', 'ProtocolError',
    'ERR_EMPTY_RESPONSE',
)


def _is_transport_drop(err):
    """True when the HTTP tier got NO response because the peer dropped the
    connection, rather than an HTTP status/body we could read. This is the
    signature of an anti-bot that refuses non-browser clients outright - a
    real browser can sometimes get past it where plain HTTP never can."""
    if not err:
        return False
    return any(sign in err for sign in _TRANSPORT_DROP_SIGNS)


def fetch(session, url, metrics, allow_retry=True):
    """
    Fetch one URL. Returns (html, error_or_None).

    `session` may be a plain requests.Session or a FetchBackend. With a
    FetchBackend, a block on the cheap HTTP path automatically escalates to a
    real browser (which has the JS runtime the challenge requires) before the
    forum is declared inaccessible - verified necessary, since both registered
    HTML forums block plain HTTP but serve a browser normally. A raw connection
    DROP (no HTTP response at all) escalates the same way, since a site that
    refuses the plain-HTTP client outright may still answer a real browser.

    Raises BlockedError only when BOTH tiers are blocked, so the caller aborts
    the forum with an explicit reason instead of storing the challenge page
    (the breached.st bug) or retrying into a ban.

    A single bad page never kills the crawl: transient failures are retried
    with exponential backoff and, if still failing, recorded as an error and
    returned as (None, msg) so the loop can continue to the next page.
    """
    backend = session if isinstance(session, FetchBackend) else None
    http = backend.http if backend else session

    # A forum already known to need the browser skips the doomed HTTP attempt.
    if backend and backend.using_browser:
        return _browser_fetch(backend, url, metrics)

    try:
        html, err = _http_fetch(http, url, metrics, allow_retry)
    except fp_base.AccessRejected:
        # An account-level rejection (banned / flagged as a known spammer) is
        # not something a browser can clear - escalating would just re-request
        # a page the site already refused. Propagate it verbatim.
        raise
    except fp_base.BlockedError as block_err:
        if not backend or not backend.allow_browser:
            raise
        br = backend._ensure_browser()
        if br is None:
            raise
        metrics.note_error(f'HTTP blocked ({block_err}); escalating to browser')
        return _browser_fetch(backend, url, metrics)

    # The HTTP tier got NO response - the peer dropped the connection (an
    # anti-bot that refuses non-browser clients does exactly this). Plain HTTP
    # can never get past it, but the forum's configured browser might, so try
    # it once. On success the backend stays in browser mode for the rest of the
    # crawl (one session, reused); if the browser can't help either, revert so
    # a later page can still retry HTTP and this page is a skip, not a
    # forum-wide abort. (A recognised challenge/auth block raised by the
    # browser still propagates, so the stop reason names the real cause.)
    if (backend and backend.allow_browser and not backend.using_browser
            and html is None and _is_transport_drop(err)):
        br = backend._ensure_browser()
        if br is not None:
            metrics.note_error(f'HTTP connection dropped ({err}); escalating to browser')
            b_html, b_err = _browser_fetch(backend, url, metrics)
            if b_html is not None:
                return b_html, None
            backend.using_browser = False
            backend.close()
            return None, b_err or err
    return html, err


def _browser_fetch(backend, url, metrics):
    br = backend._ensure_browser()
    if br is None:
        raise fp_base.BlockedError('browser backend unavailable')
    html, err = br.fetch(url)
    if err == 'challenge did not clear':
        # Classify from the challenge page itself so the banner quotes the
        # source's own wording where there is any. Without an explicit
        # category here the handler below used to fall back to BLOCK_NETWORK,
        # reporting a browser challenge as a "Network/IP block" and advising a
        # route change that cannot clear a JS challenge.
        info = fp_base.classify_block(_strip_tags(html or ''), html)
        if not info or info.get('category') != fp_base.BLOCK_CHALLENGE:
            info = fp_base.build_block_info(
                fp_base.BLOCK_CHALLENGE,
                message=(info or {}).get('message'),
                signature=(info or {}).get('signature'),
                reason='anti-bot challenge did not clear in browser')
        raise fp_base.BlockedError(
            'anti-bot challenge did not clear in browser', info=info)
    if err:
        # The browser tier reports an account-level rejection with the site's
        # own wording; surface it as such instead of as a generic fetch error,
        # so the crawl's termination reason names the real cause.
        info = fp_base.classify_block(_strip_tags(html or ''), html)
        if info and info['category'] in (fp_base.BLOCK_ANTISPAM, fp_base.BLOCK_AUTH,
                                         fp_base.BLOCK_SESSION):
            raise fp_base.AccessRejected(err, info=info)
        return None, err
    # Success: unify state so the HTTP tier can carry the browser's cookies.
    backend._sync_browser_cookies()
    return html, None


def _http_fetch(session, url, metrics, allow_retry=True):
    attempts = MAX_RETRIES if allow_retry else 1
    last_err = None
    for attempt in range(attempts):
        if attempt:
            metrics.retries += 1
            time.sleep(RETRY_BACKOFF_BASE * (2 ** (attempt - 1)))
        try:
            resp = session.get(url, verify=not _is_onion_url(url), timeout=REQUEST_TIMEOUT, allow_redirects=True)
        except requests.exceptions.RequestException as e:
            last_err = f'{type(e).__name__}: {e}'
            continue

        status = resp.status_code
        body = resp.text or ''

        # A WAF/anti-bot block can arrive as 403, or as a 200/302 carrying a
        # challenge body - both must be detected, since the latter is exactly
        # what got stored as a document before. An anti-spam/banned-account
        # rejection is also commonly served as a plain HTTP 200.
        info = fp_base.classify_block(_strip_tags(body), body)
        if info and info['category'] in (fp_base.BLOCK_ANTISPAM, fp_base.BLOCK_AUTH,
                                         fp_base.BLOCK_SESSION):
            detail = f"{info['reason']}: {info['message']}" if info.get('message') else info['reason']
            raise fp_base.AccessRejected(detail, info=info)
        if status in (401, 403) or info:
            # Carry the classification when we have one. A bare 401 is
            # unambiguously an auth wall; a bare 403 is NOT - it is just as
            # likely a WAF/edge refusal - so it stays deliberately
            # unclassified rather than being guessed at.
            if info:
                block_info = info
            elif status == 401:
                block_info = fp_base.build_block_info(
                    fp_base.BLOCK_AUTH, reason='HTTP 401 (authentication required)')
            else:
                block_info = None
            raise fp_base.BlockedError(
                (f"blocked: {info['signature']}" if info else f'HTTP {status} (access denied)'),
                info=block_info)

        if status in _RETRY_STATUSES:
            last_err = f'HTTP {status}'
            # Honour Retry-After for 429 rather than using our own backoff.
            if status == 429:
                try:
                    wait = int(resp.headers.get('Retry-After', '0'))
                    if 0 < wait <= 300:
                        time.sleep(wait)
                except (TypeError, ValueError):
                    pass
            continue

        if status >= 400:
            return None, f'HTTP {status}'
        return body, None

    return None, last_err or 'unknown fetch error'


import re as _re
import html as _html
_TAG_STRIP = _re.compile(r'<script.*?</script>|<style.*?</style>|<[^>]+>',
                         _re.IGNORECASE | _re.DOTALL)


def _strip_tags(html):
    if not html:
        return ''
    # Order matters: strip tags, THEN decode HTML entities, THEN collapse
    # whitespace. Without the unescape step the visible text keeps raw entities
    # (&nbsp;, &#36;, &#160;, &amp;) - a DB-dump post then renders as unreadable
    # "&nbsp;&nbsp;&nbsp;" soup in the extract/PDF. Decoding turns a run of
    # &nbsp; into real (non-breaking) spaces, which the final \s+ pass - which
    # matches U+00A0 too, on a str pattern - collapses to clean single spaces.
    text = _TAG_STRIP.sub(' ', html)
    text = _html.unescape(text)
    return _re.sub(r'\s+', ' ', text).strip()


def _polite_pause():
    time.sleep(REQUEST_DELAY_SECONDS + random.random() * REQUEST_JITTER_SECONDS)


def crawl_forum(forum_id, board_url, provider_id=None, max_pages=None,
                max_documents=None, incremental=True, cursor=None,
                on_thread=None, logger=print, metrics=None, session=None):
    """
    Walk a forum's board listing page by page, yielding discovered threads.

    Returns (threads, metrics). `on_thread(thread)` is called for each newly
    discovered thread so the caller can fetch/store it; it should return one
    of 'stored' | 'duplicate' | 'rejected' so metrics stay accurate.

    `cursor` carries incremental state: the highest thread id seen on the last
    successful run. When `incremental` is set and a page yields only threads at
    or below that id, the crawl stops with an explicit
    'reached previously-seen content' reason instead of re-walking all history.
    """
    provider = forum_providers.get_provider(forum_id, provider_id)
    # The caller may pass in the metrics object so its on_thread callback can
    # read live progress (pages/documents) while the crawl is still running.
    if metrics is None:
        metrics = CrawlMetrics(forum_id, provider.id)
    max_pages = int(max_pages or FORUM_CRAWL_MAX_PAGES)
    max_documents = int(max_documents or FORUM_CRAWL_MAX_DOCUMENTS)

    # Share the caller's backend so a browser started for the listing pages is
    # reused (with its clearance cookies) when fetching the threads themselves.
    owns_session = session is None
    if owns_session:
        session = new_session()
    threads_all = []
    seen_ids = set()
    prev_page_ids = None
    highest_id = _as_int(cursor)
    new_highest = highest_id
    reason = None
    page_no = 1

    try:
        while True:
            if page_no > max_pages:
                reason = (f'Stopped at configured safety limit: '
                          f'{metrics.documents_stored} documents / {page_no - 1} pages')
                break
            if metrics.documents_stored >= max_documents:
                reason = (f'Stopped at configured safety limit: '
                          f'{metrics.documents_stored} documents / {metrics.pages_fetched} pages')
                break

            url = provider.page_url(board_url, page_no)
            if not url:
                reason = fp_base.STOP_NO_MORE_PAGES
                break

            html, err = fetch(session, url, metrics)
            if err:
                metrics.note_error(f'page {page_no} ({url}): {err}')
                logger(f'[{forum_id}] page {page_no} failed: {err}')
                # A single bad page must not end the crawl - advance and keep
                # going. Only an unbroken run of failures is terminal.
                if metrics.errors >= 5 and metrics.pages_fetched == 0:
                    reason = f'{fp_base.STOP_FATAL}: {err}'
                    break
                page_no += 1
                _polite_pause()
                continue

            metrics.pages_fetched += 1
            threads = provider.extract_threads(html, url)
            metrics.documents_discovered += len(threads)

            page_ids = {t.get('thread_id') or t['url'] for t in threads}

            # Guard: a forum that clamps an out-of-range page back to the last
            # real one would otherwise loop forever returning the same set.
            if prev_page_ids is not None and page_ids and page_ids == prev_page_ids:
                reason = fp_base.STOP_NO_MORE_PAGES
                break
            prev_page_ids = page_ids

            if not threads:
                # No threads at all on a page that fetched fine: genuinely the
                # end of the listing (or a board with no threads).
                reason = fp_base.STOP_NO_NEW_RESULTS
                break

            page_had_new = False
            for t in threads:
                key = t.get('thread_id') or t['url']
                if key in seen_ids:
                    continue
                seen_ids.add(key)

                tid_int = _as_int(t.get('thread_id'))
                if tid_int is not None and (new_highest is None or tid_int > new_highest):
                    new_highest = tid_int
                if incremental and highest_id is not None and tid_int is not None:
                    if tid_int <= highest_id:
                        continue  # already collected on a previous run
                page_had_new = True
                threads_all.append(t)
                metrics.documents_parsed += 1

                if on_thread:
                    try:
                        outcome = on_thread(t)
                    except fp_base.BlockedError:
                        raise
                    except Exception as e:
                        metrics.note_error(f'thread {t.get("url")}: {e}')
                        outcome = 'rejected'
                    if outcome == 'stored':
                        metrics.documents_stored += 1
                    elif outcome == 'duplicate':
                        metrics.duplicates_skipped += 1
                    elif outcome == 'attachment':
                        metrics.documents_stored += 1
                    else:
                        metrics.documents_rejected += 1
                if metrics.documents_stored >= max_documents:
                    break

            # Incremental catch-up: a full page of already-seen threads means
            # we've reached content collected on a previous run.
            if incremental and highest_id is not None and not page_had_new:
                reason = fp_base.STOP_INCREMENTAL_CAUGHT_UP
                break

            if provider.is_last_page(html, threads, page_no):
                reason = fp_base.STOP_NO_MORE_PAGES
                break

            page_no += 1
            _polite_pause()

    except fp_base.AccessRejected as e:
        # Reported with the source's own wording and WITHOUT the generic
        # "authentication/access failure" prefix, so the crawl history names
        # the actual cause (e.g. a known-spammer rejection) rather than
        # implying an anti-bot challenge.
        metrics.note_error(str(e))
        metrics.block_category = e.category
        metrics.block_info = e.info
        reason = str(e)
        logger(f'[{forum_id}] ACCESS REJECTED: {e}')
    except fp_base.BlockedError as e:
        metrics.note_error(str(e))
        info = getattr(e, 'info', None) or {}
        # An unclassified block is reported as unclassified. Defaulting it to
        # BLOCK_NETWORK asserted a cause we had not established and sent the
        # operator to the routing settings for blocks a route change cannot fix.
        metrics.block_category = info.get('category')
        metrics.block_info = info
        reason = f'{fp_base.STOP_ACCESS_DENIED}: {e}'
        logger(f'[{forum_id}] BLOCKED: {e}')
    except fp_base.FatalProviderError as e:
        metrics.note_error(str(e))
        reason = f'{fp_base.STOP_FATAL}: {e}'
    except Exception as e:
        metrics.note_error(f'{type(e).__name__}: {e}')
        traceback.print_exc()
        reason = f'{fp_base.STOP_FATAL}: {e}'

    finally_reason = reason or fp_base.STOP_NO_MORE_PAGES
    if owns_session:
        try:
            session.close()
        except Exception:
            pass
    metrics.finish(finally_reason)
    return threads_all, metrics, new_highest


def _as_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def fetch_thread(session, url, metrics):
    """Fetch a single thread page. Returns (html, text, error)."""
    html, err = fetch(session, url, metrics)
    if err:
        return None, None, err
    return html, _strip_tags(html), None


# ---------------------------------------------------------------------------
# Route diagnostic
#
# Proves the transport ACTUALLY in use rather than echoing configuration back.
# It does that by fetching an external "what is my IP" endpoint through the
# resolved route and comparing the observed egress IP against the server's own
# direct IP - a configuration check would happily report "proxy" for a proxy
# that is dead or silently ignored.
# ---------------------------------------------------------------------------
IP_ECHO_URLS = ('https://check.torproject.org/api/ip',
                'https://api.ipify.org?format=json')


def _probe_ip(session, timeout=45):
    """Return (ip, is_tor, error) as observed through `session`."""
    last_err = None
    for url in IP_ECHO_URLS:
        try:
            r = session.get(url, timeout=timeout)
            if r.status_code != 200:
                last_err = f'HTTP {r.status_code} from {urlparse(url).netloc}'
                continue
            data = r.json()
            ip = data.get('IP') or data.get('ip')
            is_tor = data.get('IsTor')
            if ip:
                return ip, is_tor, None
            last_err = f'no IP field in response from {urlparse(url).netloc}'
        except Exception as e:
            last_err = f'{type(e).__name__}: {str(e)[:160]}'
    return None, None, last_err


def diagnose_route(route, check_browser=False):
    """
    Actively verify a resolved route. Returns a dict with the observed egress
    IP for the requests transport, the server's own direct IP for comparison,
    and (optionally) the browser transport's egress IP so the two tiers can be
    proven identical.

    Never returns or logs credentials - only route['display'], which is masked.
    """
    result = {
        'mode': route.get('mode'),
        'reason': route.get('reason'),
        'display': route.get('display'),
        'ok': False,
    }
    if route.get('mode') == 'invalid':
        result['error'] = route.get('error')
        return result

    # Baseline: the server's own unproxied IP.
    try:
        direct_ip, _, _ = _probe_ip(_session(None))
    except Exception:
        direct_ip = None
    result['direct_ip'] = direct_ip

    sess = _session(route.get('http'))
    ip, is_tor, err = _probe_ip(sess)
    result['egress_ip'] = ip
    result['is_tor_exit'] = is_tor
    if err:
        result['error'] = err
        return result

    # The actual proof: for a non-direct route the egress must DIFFER from the
    # server's own IP; for a direct route it must match.
    if route.get('mode') == 'direct':
        result['ok'] = bool(ip) and (direct_ip is None or ip == direct_ip)
        result['verdict'] = ('egress matches server IP - traffic is direct'
                             if result['ok'] else
                             'egress does NOT match server IP - unexpected for a direct route')
    elif route.get('mode') == 'tor':
        result['ok'] = bool(ip) and (is_tor is True or (direct_ip and ip != direct_ip))
        result['verdict'] = ('egress is a Tor exit node' if is_tor
                             else ('egress differs from server IP' if result['ok']
                                   else 'egress equals server IP - traffic is NOT going through Tor'))
    else:  # proxy
        # Reaching the endpoint AT ALL through a proxied session already proves
        # the proxy accepted and forwarded the request: a dead, unreachable or
        # auth-rejecting proxy raises ProxyError instead of returning a body.
        # The IP comparison is reported as corroboration, but it is NOT the
        # pass condition - a proxy on localhost or in the same egress network
        # legitimately shows the server's own IP, and failing it there would be
        # a false negative.
        result['ok'] = bool(ip)
        if not ip:
            result['verdict'] = 'no response through the proxy - not usable'
        elif direct_ip and ip != direct_ip:
            result['verdict'] = ('proxy reached and egress differs from the server IP '
                                 '- traffic is going through the proxy')
        else:
            result['verdict'] = ('proxy reached and forwarded the request; egress IP '
                                 'matches the server (expected for a local or '
                                 'same-network proxy)')

    if check_browser:
        result['browser'] = _diagnose_browser(route)
    return result


def _diagnose_browser(route):
    """Prove the browser tier egresses through the same route as requests."""
    out = {'ok': False}
    try:
        from lib import forum_browser
        if not forum_browser.is_available():
            out['error'] = 'playwright unavailable'
            return out
        br = forum_browser.BrowserSession(proxy=route.get('browser'),
                                          use_default_proxy=False).start()
        try:
            html, err = br.fetch('https://api.ipify.org?format=json')
            if err:
                out['error'] = err
                return out
            import re as _re, json as _json
            m = _re.search(r'\{.*?\}', _re.sub(r'<[^>]+>', '', html or ''), _re.DOTALL)
            if m:
                out['egress_ip'] = _json.loads(m.group(0)).get('ip')
                out['ok'] = bool(out['egress_ip'])
        finally:
            br.close()
    except Exception as e:
        out['error'] = f'{type(e).__name__}: {str(e)[:160]}'
    return out


def diagnose_access(forum_id, url=None, compare_route=None):
    """
    Determine WHY a forum is refusing us, and - where technically possible -
    whether the refusal follows the network or the account.

    Fetches the forum over its configured route and classifies the response.
    When `compare_route` is supplied (a second resolved route, e.g. direct or a
    proxy), the same URL is fetched again through it and the two
    classifications are compared:

      * same anti-spam rejection through a DIFFERENT egress IP
            -> the match is NOT purely IP-based; it follows the username or
               email, and changing networks will not by itself restore access.
      * rejection disappears through the other route
            -> the block is IP/network-bound for this source.
      * only one route reachable
            -> reported as indeterminate rather than guessed.

    This ONLY observes and compares. It never creates or rotates an account,
    never retries a rejection, and never attempts to defeat the restriction.
    """
    from lib import forum_registry
    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        return {'error': 'unknown forum'}
    target = url or forum.get('url')
    primary = forum_registry.resolve_route(forum_id)

    def probe(route):
        metrics = CrawlMetrics(forum_id, 'diagnostic')
        backend = FetchBackend(allow_browser=False, route=route,
                               cookiejar_uuid=forum_registry.get_cookiejar(forum_id),
                               forum_id=forum_id)
        out = {'route_mode': route.get('mode'), 'route_reason': route.get('reason')}
        try:
            html, err = fetch(backend, target, metrics, allow_retry=False)
            if err:
                out['error'] = err
                return out
            info = fp_base.classify_block(_strip_tags(html or ''), html)
            out['blocked'] = bool(info)
            out['category'] = info['category'] if info else None
            out['label'] = info['label'] if info else 'Normal forum response'
            out['message'] = info.get('message') if info else None
            out['content_length'] = len(html or '')
        except fp_base.AccessRejected as e:
            out.update({'blocked': True, 'category': e.category,
                        'label': fp_base.BLOCK_CATEGORY_LABELS.get(e.category),
                        'message': (e.info or {}).get('message')})
        except fp_base.BlockedError as e:
            info = getattr(e, 'info', None) or {}
            out.update({'blocked': True,
                        'category': info.get('category') or fp_base.BLOCK_NETWORK,
                        'label': fp_base.BLOCK_CATEGORY_LABELS.get(
                            info.get('category') or fp_base.BLOCK_NETWORK),
                        'message': info.get('message') or str(e)})
        except Exception as e:
            out['error'] = f'{type(e).__name__}: {str(e)[:160]}'
        finally:
            backend.close()
        return out

    result = {'forum_id': forum_id, 'url': target, 'primary': probe(primary)}

    if compare_route is not None:
        result['comparison'] = probe(compare_route)
        a, b_ = result['primary'], result['comparison']
        if a.get('error') or b_.get('error'):
            result['verdict'] = ('Could not compare routes - one of them failed to '
                                 'complete a request.')
            result['ip_bound'] = None
        elif a.get('category') == fp_base.BLOCK_ANTISPAM and \
                b_.get('category') == fp_base.BLOCK_ANTISPAM:
            result['ip_bound'] = False
            result['verdict'] = ('The same anti-spam rejection is returned through a '
                                 'different network path, so the match is not purely '
                                 'IP-based - it follows the username or email. A '
                                 'different proxy will not by itself restore access.')
        elif a.get('blocked') and not b_.get('blocked'):
            result['ip_bound'] = True
            result['verdict'] = ('The source serves normal content through the other '
                                 'route, so this block is bound to the network path.')
        elif not a.get('blocked'):
            result['ip_bound'] = None
            result['verdict'] = 'The configured route is not currently blocked.'
        else:
            result['ip_bound'] = None
            result['verdict'] = ('Both routes are refused, but with different causes - '
                                 'see each route\'s reported message.')
    return result


def new_session(allow_browser=True, cookiejar_uuid=None, route=None, forum_id=None):
    """Fetch backend for a crawl. Browser escalation is on by default because
    the registered HTML forums require it; pass allow_browser=False to force
    HTTP-only (used by tests that assert the block path).

    `route` is a resolved route dict (forum_registry.resolve_route). Omitting
    it keeps the pre-routing default of Tor. `forum_id` lets the backend reuse
    that forum's persistent authenticated profile when one exists."""
    return FetchBackend(allow_browser=allow_browser, cookiejar_uuid=cookiejar_uuid,
                        route=route, forum_id=forum_id)
