#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Asset Intelligence scan report -> human-readable PDF.

Renders the same report dict that asset_jobs writes as JSON
(query/summary/findings/assets/target_intel/provider_telemetry) into a
paginated, readable PDF: an executive summary, a severity-ranked findings
table, a dedicated dependency-CVE (OSV/nuclei) table, a per-asset inventory,
and provider run telemetry. Pure reportlab (already vendored) - no HTML
engine or system binary. build_pdf(report) -> bytes; it never mutates the
report and tolerates older reports missing the newer keys.
"""

import io
from datetime import datetime, timezone

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, KeepTogether)

SEVERITY_ORDER = ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO')
SEVERITY_COLOR = {
    'CRITICAL': colors.HexColor('#8b0000'),
    'HIGH': colors.HexColor('#c0392b'),
    'MEDIUM': colors.HexColor('#c77f0a'),
    'LOW': colors.HexColor('#2a6df0'),
    'INFO': colors.HexColor('#6b7688'),
}
_ACCENT = colors.HexColor('#2a6df0')
_INK = colors.HexColor('#1b2333')
_MUTED = colors.HexColor('#5a667e')
_GRID = colors.HexColor('#d5dbe6')
_HEAD_BG = colors.HexColor('#0c1220')
_ROW_ALT = colors.HexColor('#f4f6fa')


def _styles():
    ss = getSampleStyleSheet()
    out = {
        'h1': ParagraphStyle('h1', parent=ss['Title'], fontSize=20, textColor=_INK,
                             spaceAfter=2, alignment=TA_LEFT),
        'sub': ParagraphStyle('sub', parent=ss['Normal'], fontSize=9.5, textColor=_MUTED,
                              spaceAfter=2),
        'h2': ParagraphStyle('h2', parent=ss['Heading2'], fontSize=13, textColor=_ACCENT,
                             spaceBefore=14, spaceAfter=6),
        'cell': ParagraphStyle('cell', parent=ss['Normal'], fontSize=8.3, leading=10.5,
                               textColor=_INK),
        'cellm': ParagraphStyle('cellm', parent=ss['Normal'], fontSize=8.3, leading=10.5,
                                textColor=_MUTED),
        'head': ParagraphStyle('head', parent=ss['Normal'], fontSize=8.2, leading=10,
                               textColor=colors.white, fontName='Helvetica-Bold'),
        'sev': ParagraphStyle('sev', parent=ss['Normal'], fontSize=8.2, leading=10,
                              fontName='Helvetica-Bold'),
        'note': ParagraphStyle('note', parent=ss['Normal'], fontSize=8.5, textColor=_MUTED,
                               spaceBefore=2, spaceAfter=2),
    }
    return out


def _esc(v):
    s = '' if v is None else str(v)
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def _hx(color):
    """reportlab intra-paragraph <font color> needs a leading '#'."""
    return '#' + color.hexval()[2:]


def _sev_para(sev, S):
    sev = (sev or 'INFO').upper()
    c = SEVERITY_COLOR.get(sev, SEVERITY_COLOR['INFO'])
    return Paragraph(f'<font color="{_hx(c)}">&#9632; {sev}</font>', S['sev'])


def _table(data, col_widths, S, header=True):
    style = [
        ('BACKGROUND', (0, 0), (-1, 0), _HEAD_BG),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ('LEFTPADDING', (0, 0), (-1, -1), 5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 5),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('GRID', (0, 0), (-1, -1), 0.4, _GRID),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, _ROW_ALT]),
    ]
    t = Table(data, colWidths=col_widths, repeatRows=1 if header else 0)
    t.setStyle(TableStyle(style))
    return t


def _fmt_epoch(v):
    try:
        return datetime.fromtimestamp(int(v), tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    except (TypeError, ValueError):
        return str(v or '-')


def build_pdf(report):
    S = _styles()
    story = []
    q = report.get('query') or {}
    summary = report.get('summary') or {}
    target = q.get('target_id') or 'unknown target'

    # ---- Header ----------------------------------------------------------
    story.append(Paragraph(f'Asset Intelligence Report', S['h1']))
    story.append(Paragraph(f'<b>{_esc(target)}</b>', S['sub']))
    gen = q.get('generated_at') or datetime.now(timezone.utc).isoformat()
    story.append(Paragraph(f'Generated {_esc(gen)} &nbsp;·&nbsp; '
                           f'{len(q.get("categories") or [])} scan categories', S['sub']))
    story.append(Spacer(1, 6))

    # ---- Executive summary ----------------------------------------------
    story.append(Paragraph('Executive Summary', S['h2']))
    sev = summary.get('severity_counts') or {}
    stat_cells = [
        ['Assets', 'Live', 'Disconnected', 'Back online', 'Findings'],
        [str(summary.get('asset_count', 0)), str(summary.get('live_count', 0)),
         str(summary.get('disconnected_count', 0)), str(summary.get('back_online_count', 0)),
         str(summary.get('finding_count', 0))],
    ]
    st = Table(stat_cells, colWidths=[35 * mm] * 5)
    st.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), _HEAD_BG),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 1), 9),
        ('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 1), (-1, 1), 15),
        ('TEXTCOLOR', (0, 1), (-1, 1), _INK),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 0.4, _GRID),
    ]))
    story.append(st)
    story.append(Spacer(1, 6))
    # Severity chips line
    chips = []
    for s in SEVERITY_ORDER:
        n = sev.get(s, 0)
        if n:
            chips.append(f'<font color="{_hx(SEVERITY_COLOR[s])}"><b>{s}: {n}</b></font>')
    if chips:
        story.append(Paragraph('Findings by severity: &nbsp;' + ' &nbsp; '.join(chips), S['note']))

    # ---- Findings --------------------------------------------------------
    findings = sorted(report.get('findings') or [],
                      key=lambda f: SEVERITY_ORDER.index(f['severity'])
                      if f.get('severity') in SEVERITY_ORDER else len(SEVERITY_ORDER))
    story.append(Paragraph(f'Findings ({len(findings)})', S['h2']))
    if findings:
        rows = [[Paragraph('Severity', S['head']), Paragraph('Category', S['head']),
                 Paragraph('Host', S['head']), Paragraph('Finding', S['head'])]]
        for f in findings:
            rows.append([
                _sev_para(f.get('severity'), S),
                Paragraph(_esc(f.get('category')), S['cellm']),
                Paragraph(_esc(f.get('fqdn')), S['cell']),
                Paragraph(f"<b>{_esc(f.get('title'))}</b><br/>{_esc(f.get('detail'))}", S['cell']),
            ])
        story.append(_table(rows, [22 * mm, 22 * mm, 42 * mm, 84 * mm], S))
    else:
        story.append(Paragraph('No findings were recorded on the last scan.', S['note']))

    # ---- Dependency / CVE detail (OSV + nuclei) -------------------------
    vuln_rows = []
    for a in (report.get('assets') or []):
        for v in (a.get('vulnerabilities') or []):
            ids = v.get('ids') or {}
            cve = (v.get('cve_ids') or [None])[0] or ids.get('cve') or ids.get('ghsa') or ids.get('osv') or '-'
            pkg = f"{v.get('package')}@{v.get('affected_version')}" if v.get('package') else (v.get('template_id') or '-')
            fixed = ', '.join(v.get('fixed_versions') or []) or '-'
            src = v.get('source') or 'nuclei'
            vuln_rows.append([
                _sev_para(v.get('severity'), S),
                Paragraph(_esc(a.get('fqdn')), S['cell']),
                Paragraph(_esc(cve), S['cell']),
                Paragraph(_esc(pkg), S['cellm']),
                Paragraph(_esc(fixed), S['cell']),
                Paragraph(_esc(src), S['cellm']),
            ])
    if vuln_rows:
        story.append(Paragraph(f'Known Vulnerabilities &amp; CVEs ({len(vuln_rows)})', S['h2']))
        head = [Paragraph(t, S['head']) for t in ('Severity', 'Host', 'ID', 'Package / Template', 'Fixed in', 'Source')]
        story.append(_table([head] + vuln_rows,
                            [20 * mm, 38 * mm, 30 * mm, 40 * mm, 26 * mm, 16 * mm], S))

    # ---- Asset inventory -------------------------------------------------
    assets = report.get('assets') or []
    story.append(Paragraph(f'Asset Inventory ({len(assets)})', S['h2']))
    if assets:
        rows = [[Paragraph(t, S['head']) for t in ('Host', 'Status', 'IP(s)', 'Open ports', 'Technologies')]]
        for a in sorted(assets, key=lambda x: (x.get('current_status') != 'live', x.get('fqdn') or '')):
            ips = ', '.join((a.get('resolved_ips') or [])[:3]) or '-'
            ports = ', '.join(str(p.get('port')) for p in (a.get('ports') or [])) or '-'
            techs = ', '.join((a.get('technologies') or [])[:6]) or '-'
            status = a.get('current_status') or '-'
            scolor = '#1e7d4d' if status == 'live' else '#8a94a6'
            rows.append([
                Paragraph(_esc(a.get('fqdn')), S['cell']),
                Paragraph(f'<font color="{scolor}"><b>{_esc(status)}</b></font>', S['cell']),
                Paragraph(_esc(ips), S['cellm']),
                Paragraph(_esc(ports), S['cell']),
                Paragraph(_esc(techs), S['cellm']),
            ])
        story.append(_table(rows, [46 * mm, 18 * mm, 36 * mm, 26 * mm, 44 * mm], S))

    # ---- Provider telemetry ---------------------------------------------
    tel = report.get('provider_telemetry') or {}
    if tel:
        story.append(Paragraph('Scanner Provider Telemetry', S['h2']))
        rows = [[Paragraph(t, S['head']) for t in ('Provider', 'Category', 'Status', 'Duration', 'Results', 'Validated', 'Deduped')]]
        for pid, r in sorted(tel.items(), key=lambda kv: kv[1].get('category') or ''):
            dur = r.get('duration_ms')
            dur = f'{dur/1000:.1f}s' if isinstance(dur, (int, float)) else '-'
            rows.append([
                Paragraph(_esc(pid), S['cell']),
                Paragraph(_esc(r.get('category')), S['cellm']),
                Paragraph(_esc(r.get('status')), S['cell']),
                Paragraph(dur, S['cellm']),
                Paragraph(_esc(r.get('result_count')), S['cell']),
                Paragraph(_esc(r.get('validated_count') if r.get('validated_count') is not None else '-'), S['cellm']),
                Paragraph(_esc(r.get('deduplicated_count') if r.get('deduplicated_count') is not None else '-'), S['cellm']),
            ])
        story.append(_table(rows, [30 * mm, 30 * mm, 22 * mm, 20 * mm, 18 * mm, 20 * mm, 20 * mm], S))

    story.append(Spacer(1, 10))
    story.append(Paragraph('Generated by Anorphix Asset Intelligence. Metadata-only; secret values are '
                           'redacted at collection.', S['note']))

    # ---- Build -----------------------------------------------------------
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title=f'Asset Intelligence Report - {target}',
                            leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=14 * mm, bottomMargin=14 * mm)

    def _footer(canvas, d):
        canvas.saveState()
        canvas.setFont('Helvetica', 7.5)
        canvas.setFillColor(_MUTED)
        canvas.drawString(14 * mm, 8 * mm, f'Anorphix · {target}')
        canvas.drawRightString(A4[0] - 14 * mm, 8 * mm, f'Page {d.page}')
        canvas.restoreState()

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()
