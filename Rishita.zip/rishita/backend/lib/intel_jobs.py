#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Domain Intelligence Jobs
===================

Client workflow: domain -> query the persistent, indexed forum corpus ->
extract/correlate -> structured, source-traceable JSON report.

Jobs never trigger a forum re-crawl to find matches - they only ever query
the already collected, already indexed corpus (lib.search_engine's
'intel_docs' Meilisearch index, populated by forum_collector.py at
collection time). This keeps a client domain search fast and decoupled
from collection. The one narrow exception: a CRITICAL-risk finding
triggers a single bounded, screenshot-enabled re-capture of that specific
page for evidence purposes (see _capture_critical_evidence) - bulk/board
collection stays text-only by default to keep screenshot storage
proportional to what's actually significant.

Jobs run via a simple Kvrocks-backed queue (QUEUED -> RUNNING ->
COMPLETED/FAILED) so a large search never blocks the requesting browser;
see bin/intel/DomainIntelWorker.py for the consumer process.
"""

import json
import os
import re
import sys
import time
import uuid
from datetime import datetime, timezone

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers
from lib import forum_ingest
from lib import forum_registry
from lib import gentlemen_intel
from lib import intel_extraction
from lib import leak_intel
from lib import ransomware_live
from lib import russian_market
from lib import search_engine
from lib.ConfigLoader import ConfigLoader
from lib import correlations_engine

config_loader = ConfigLoader()
AIL_HOME = os.environ.get('AIL_HOME') or os.path.dirname(os.environ['AIL_BIN'].rstrip('/'))
REPORTS_FOLDER = os.path.join(AIL_HOME, config_loader.get_config_str('Directories', 'intel_reports'))
config_loader = None

os.makedirs(REPORTS_FOLDER, exist_ok=True)

r_crawler = crawlers.r_crawler

QUEUE_KEY = 'intel:jobs:queue'
STATUSES = {'QUEUED', 'RUNNING', 'COMPLETED', 'FAILED'}

# How many stored forum native-search documents to fold into one job's combined
# finding as source evidence. A backstop against an enormous report, not a
# collection target - the corpus itself is unbounded.
FORUM_DOC_EVIDENCE_CAP = 100
# How many stored documents (newest first) to SCAN per forum when folding
# corpus evidence, and how many matching forum_document findings to keep per
# forum. Scanning more than the append cap lets a domain match that sits deeper
# in the corpus (collected under a different query) still be surfaced, while the
# append cap keeps the report bounded.
SEARCH_FOLD_SCAN_CAP = 500

# Upper bound on NEW authenticated screenshots captured per job so a finding's
# evidence shot is highlighted on the searched term (not the collection term).
# Cached (doc, term) shots are free and don't count; only genuine first-time
# misses do, top (already-sorted, most-relevant) findings first. Kept modest so
# a search stays responsive; the rest reuse the base shot and fill in on a
# repeat search.
TERM_SHOT_CAP_PER_JOB = int(os.environ.get('INTEL_TERM_SHOT_CAP', 20))


_GENERIC_LABELS = {'www', 'www2', 'm', 'mobile', 'mail', 'webmail', 'login',
                   'secure', 'portal', 'app', 'apps', 'api', 'net', 'online',
                   'netbanking', 'account', 'accounts', 'my', 'home'}
_TLD_LABELS = {'com', 'net', 'org', 'co', 'io', 'in', 'bank', 'gov', 'edu',
               'info', 'biz', 'us', 'uk', 'ru', 'to', 'st', 'as'}


def _brand_label(domain):
    """The organisation/brand token of a domain: 'hdfc' for 'hdfc.bank.in',
    'hdfcbank' for 'netbanking.hdfcbank.com', 'google' for 'www.google.com'.
    Used so a DOMAIN search still surfaces documents that name the org by
    NAME (bank breach dumps say "HDFC Bank", never the domain). Returns None
    when nothing substantive remains (e.g. a bare 'bank.in')."""
    labels = [l for l in (domain or '').lower().split('.') if l]
    while len(labels) > 1 and labels[0] in _GENERIC_LABELS:
        labels.pop(0)
    if labels and len(labels[0]) >= 3 and labels[0] not in _TLD_LABELS \
            and labels[0] not in _GENERIC_LABELS:
        return labels[0]
    return None


def _brand_word_re(brand):
    return re.compile(r'(?<![0-9a-z])' + re.escape(brand) + r'(?![0-9a-z])', re.IGNORECASE)


def _domain_token_re(domain):
    """Whole-token matcher for a registrable domain and ANY subdomain of it:
    'google.com' matches 'google.com', 'accounts.google.com', 'm.google.com'
    but NOT 'google.company.com' or 'notgoogle.com'. This is what lets a domain
    search mine the corpus for real occurrences without the substring false
    positives a naive `'google.com' in text` would produce."""
    return re.compile(r'(?<![\w-])(?:[a-z0-9-]+\.)*' + re.escape(domain.lower()) + r'(?![\w-])',
                      re.IGNORECASE)

# A listing whose actual data is withheld behind hidden content, a
# reply-to-unlock wall, or an off-site channel (Telegram). Used only to EXPLAIN
# why such a finding has no leaked-data categories - the values were never on
# the page we collected, so none are fabricated.
_GATED_RE = re.compile(
    r'\[hide\]|hidden content|reply to (?:view|see|unlock)|'
    r'you (?:do not|don\'t) have permission|t\.me/|telegram\s*(?:channel|:|@)',
    re.IGNORECASE)


def _job_key(job_id):
    return f'inteljob:meta:{job_id}'


# Requires at least two labels (a name + a TLD), each 1-63 chars of
# letters/digits/hyphens, TLD at least 2 letters. Rejects bare words/TLDs
# like "de" or "com" that aren't actually a domain someone meant to search.
DOMAIN_FORMAT_REGEX = re.compile(
    r'^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$'
)


QUERY_TYPES = {'domain', 'keyword'}


def create_job(domain, forum_ids, query_type='domain', live=False):
    """
    query_type='domain' (default): `domain` must look like an actual domain
    (e.g. example.com) and matching uses the domain-specific classifier
    (exact/subdomain/url/email-domain/contextual) - this is what makes a
    finding's "Victim Site" trustworthy.

    query_type='keyword': `domain` is treated as a free-text search term
    (e.g. an organisation name like "Tribunal Supremo de Elecciones") for
    the case a breach post never actually writes out the victim's domain
    in the text - a real, observed gap, not hypothetical. Matching is a
    plain case-insensitive phrase search; there's no domain to validate
    against, so fields that are normally domain-derived (Victim Site,
    Targeted Region/Country) are left as "not applicable"/"Unclassified"
    for these jobs rather than guessed from a keyword.

    live=True: before querying the corpus, run_job() first triggers a fresh,
    targeted search/capture against every selected forum that isn't
    currently circuit-broken (see forum_registry.is_circuit_open), and waits
    (bounded) for it to land - so results reflect what's on the forum right
    now, not just whatever happened to be collected previously. A forum
    whose circuit is open, or that times out, is skipped for the live step
    without failing the job - the job still returns whatever's in the corpus
    for the other, healthy forums. This is the failover: querying several
    forums and silently proceeding without the unreachable ones, rather than
    the whole search failing because one forum is down.
    """
    query_type = query_type if query_type in QUERY_TYPES else 'domain'
    domain = (domain or '').strip()
    if query_type == 'domain':
        domain = domain.lower()
        if not domain:
            return {'status': 'error', 'reason': 'Missing domain'}, 400
        if not DOMAIN_FORMAT_REGEX.match(domain):
            return {'status': 'error', 'reason': f'"{domain}" does not look like a valid domain (e.g. example.com)'}, 400
    else:
        if len(domain) < 2:
            return {'status': 'error', 'reason': 'Search term must be at least 2 characters'}, 400
        if len(domain) > 100:
            return {'status': 'error', 'reason': 'Search term is too long (max 100 characters)'}, 400

    valid_forum_ids = []
    for forum_id in forum_ids or []:
        forum, code = forum_registry.get_forum(forum_id)
        if code == 200:
            valid_forum_ids.append(forum_id)
    if not valid_forum_ids:
        # A domain search is no longer forum-only. ransomware.live and the
        # Russian Market stealer-log marketplace are INDEPENDENT sources that
        # need no forum corpus, so refusing the whole search here would hide
        # marketplace exposure from anyone whose forum pool happens to be
        # empty. Proceed with the non-forum sources; the corpus query simply
        # examines zero documents.
        try:
            rm_enabled = russian_market.get_config().get('enabled')
        except Exception:
            rm_enabled = False
        if not rm_enabled:
            return {'status': 'error',
                    'reason': 'No valid registered forums selected and no '
                              'non-forum intelligence source is enabled'}, 400

    # Re-running the same search (same query text + same query type) reuses
    # its existing history entry instead of piling up a new row every time -
    # confirmed: repeatedly searching "Instagram" while iterating on a fix
    # left five duplicate "Instagram" rows in the dashboard, each with a
    # different finding count, which reads as five different searches
    # instead of one search re-run five times. One entry per query, always
    # showing that query's latest result.
    existing_id = None
    for job in list_jobs(limit=100000):
        # Only reuse a NORMAL job row - a native-search row (darkforums.as) for
        # the same term is a distinct source result and must not be clobbered.
        if job.get('native_forum_id'):
            continue
        if job.get('query_type') == query_type and (job.get('domain') or '').lower() == domain.lower():
            existing_id = job['id']
            break

    now = int(time.time())
    job_id = existing_id or str(uuid.uuid4())
    if existing_id:
        old_report_path = (get_job(existing_id)[0] or {}).get('report_path')
        if old_report_path and os.path.isfile(old_report_path):
            os.remove(old_report_path)

    r_crawler.hset(_job_key(job_id), mapping={
        'id': job_id,
        'domain': domain,
        'query_type': query_type,
        'forum_ids': json.dumps(valid_forum_ids),
        'live': 1 if live else 0,
        'live_status': '',
        'status': 'QUEUED',
        'created_at': now,
        'started_at': '',
        'completed_at': '',
        'sources_searched': len(valid_forum_ids),
        'documents_examined': 0,
        'matches_found': 0,
        'findings_count': 0,
        'report_path': '',
        'error': '',
    })
    r_crawler.rpush(QUEUE_KEY, job_id)
    return get_job(job_id)


def record_native_search_job(forum_id, query, findings_count):
    """Record a forum NATIVE-search run as a normal intelligence job so it
    appears in Dashboard -> Recent Intelligence Jobs alongside every other
    search, using the SAME persistence (inteljob:meta:*) and the SAME dashboard
    rendering - it is not a second data model.

    It does NOT enqueue run_job(): the DarkForums document is already collected,
    enriched and stored by the native-search endpoint, so this only writes the
    job row (status COMPLETED) and marks it as a native-search job via
    `native_forum_id`, which the dashboard/history use to link the row straight
    to the stored document instead of the breach-report view. Same
    one-row-per-query update semantics as create_job()."""
    query = (query or '').strip()
    if not query:
        return None
    now = int(time.time())
    # One row per (forum, query): reuse only THIS forum's own native row, never
    # a normal keyword/domain job for the same term.
    existing_id = None
    for job in list_jobs(limit=100000):
        if job.get('native_forum_id') == forum_id and (job.get('domain') or '').lower() == query.lower():
            existing_id = job['id']
            break
    job_id = existing_id or str(uuid.uuid4())
    if existing_id:
        old_report_path = (get_job(existing_id)[0] or {}).get('report_path')
        if old_report_path and os.path.isfile(old_report_path):
            os.remove(old_report_path)
    r_crawler.hset(_job_key(job_id), mapping={
        'id': job_id,
        'domain': query,
        'query_type': 'keyword',
        'forum_ids': json.dumps([forum_id]),
        'live': 0,
        'live_status': '',
        'status': 'COMPLETED',
        'created_at': now,
        'started_at': now,
        'completed_at': now,
        'sources_searched': 1,
        'documents_examined': findings_count,
        'matches_found': findings_count,
        'findings_count': findings_count,
        'report_path': '',
        'error': '',
        'native_forum_id': forum_id,
    })
    return job_id


def _excerpt_around(text, needle, size=4000, lead=600):
    """Extract window CENTRED on the first occurrence of the searched term, so
    the matched keyword/domain is actually visible (and can be highlighted) in
    the finding - not hidden past the top-of-thread cut-off. Falls back to the
    head of the text when the term is not present verbatim."""
    text = text or ''
    q = (needle or '').strip()
    if not q:
        return text[:size]
    i = text.lower().find(q.lower())
    if i < 0:
        return text[:size]
    start = max(0, i - lead)
    seg = text[start:start + size]
    return ('…' + seg) if start > 0 else seg


def purge_native_search_jobs():
    """Migration: the separate per-source DarkForums job rows are replaced by
    the single combined-query finding, so drop them. The underlying forum
    documents in the corpus are NOT touched - only the redundant job rows."""
    removed = 0
    for job in list_jobs(limit=100000):
        if job.get('native_forum_id'):
            res, code = delete_job(job['id'])
            if code == 200:
                removed += 1
    return removed


def pop_queued_job(timeout=5):
    popped = r_crawler.blpop([QUEUE_KEY], timeout=timeout)
    if not popped:
        return None
    return popped[1]


def recover_orphaned_jobs():
    """
    Re-queue any job left stuck in RUNNING - the only way a job gets here is
    the worker process dying mid-run_job() (confirmed: restarting the worker
    screen window to deploy a code change killed it while it was still
    processing one, and that job then sat on "running" forever - nothing
    else ever transitions status away from RUNNING, so without this it's
    stuck until someone notices and manually re-runs it). Safe to call on
    every worker startup: run_job() is idempotent per job_id (it always
    rebuilds the report from scratch and overwrites it), so re-running one
    that actually did finish just before the crash costs a redundant search,
    not a wrong result.
    """
    requeued = []
    for job in list_jobs(limit=100000):
        if job.get('status') == 'RUNNING':
            r_crawler.rpush(QUEUE_KEY, job['id'])
            requeued.append(job['id'])
    return requeued


def get_job(job_id):
    data = r_crawler.hgetall(_job_key(job_id))
    if not data:
        return {'status': 'error', 'reason': 'Unknown job'}, 404
    return _job_to_dict(data, key=_job_key(job_id)), 200


def list_jobs(limit=100):
    jobs = []
    for key in r_crawler.scan_iter(match='inteljob:meta:*', count=200):
        data = r_crawler.hgetall(key)
        if data:
            jobs.append(_job_to_dict(data, key=key))
    jobs.sort(key=lambda j: j.get('created_at') or 0, reverse=True)
    return jobs[:limit]


def _job_to_dict(data, key=None):
    d = dict(data)
    # A partially-written record can lack its own `id` field (only the Kvrocks
    # key carries it) - recover the id from the key so the job stays viewable
    # AND deletable. Without this the UI renders an empty job_id, whose delete
    # URL collapses to a GET-only route and returns 405 Method Not Allowed.
    if not (d.get('id') or '').strip() and key:
        k = key.decode() if isinstance(key, (bytes, bytearray)) else str(key)
        d['id'] = k.rsplit('inteljob:meta:', 1)[-1]
    if not (d.get('domain') or '').strip():
        d['domain'] = '(unknown)'
    d['forum_ids'] = json.loads(d.get('forum_ids') or '[]')
    d['query_type'] = d.get('query_type') or 'domain'  # older jobs predate this field
    d['live'] = bool(int(d.get('live') or 0))
    d['live_status'] = json.loads(d['live_status']) if d.get('live_status') else {}
    for int_field in ('created_at', 'started_at', 'completed_at', 'sources_searched',
                       'documents_examined', 'matches_found', 'findings_count',
                       'source_count'):
        if d.get(int_field) not in (None, ''):
            d[int_field] = int(d[int_field])
        else:
            d[int_field] = None
    return d


def _set_job_fields(job_id, **fields):
    r_crawler.hset(_job_key(job_id), mapping=fields)


def delete_job(job_id):
    """Removes a job and its saved report from history/dashboard views. Does
    not touch the underlying forum corpus or collected documents - this only
    forgets that this particular search was run, same as clearing one row
    from a search history list."""
    job, code = get_job(job_id)
    if code != 200:
        return job, code
    report_path = job.get('report_path')
    if report_path and os.path.isfile(report_path):
        os.remove(report_path)
    r_crawler.delete(_job_key(job_id))
    return {'status': 'ok', 'deleted': job_id}, 200


def delete_all_jobs():
    """Clears every job from history/dashboard views in one go - same scope
    as delete_job, just applied to all of them. Does not touch the
    underlying forum corpus or collected documents."""
    count = 0
    for job in list_jobs(limit=100000):
        res, code = delete_job(job['id'])
        if code == 200:
            count += 1
    return {'status': 'ok', 'deleted_count': count}, 200


_MATCH_CONFIDENCE_RANK = {'high': 2, 'medium': 1, 'low': 0}

# darkforums.ru's Cloudflare challenge has taken anywhere from ~30s to ~90s
# in real captures this session, occasionally much longer under load - 60s
# was cutting it close even for the "normal" case and routinely timed out
# on slower ones, which (before the fallback fix below existed) caused a
# finding to silently show a stale, unrelated document instead of no
# screenshot at all. 120s covers the real observed range with headroom.
EVIDENCE_CAPTURE_TIMEOUT = 120  # seconds - bounded wait, never blocks the job indefinitely
EVIDENCE_CAPTURE_POLL_INTERVAL = 5

# darkforums.ru sits behind Cloudflare, which sometimes forces an extra
# reload mid-capture (the same "Frame was detached" turbulence documented
# for bulk collection) - when that happens right as the screenshot is taken,
# Crawler.py's in-browser crop script (isolating the matched post from the
# rest of the forum theme) can lose the race and the result comes back as a
# full, uncropped page. A genuinely cropped evidence screenshot is a single
# forum post, never anywhere near this tall - anything past this is treated
# as "the crop didn't take" and retried once, rather than trusting in-browser
# timing alone.
CROPPED_SCREENSHOT_MAX_HEIGHT = 2000


def _screenshot_item_id(forum_id, url, start_time):
    """Polls for `url` to show up in the forum's document tracking with a
    screenshot attached, returning its item_id, or None if none showed up in
    time.

    Deliberately matches on (url, recency) rather than "hash is new" - two
    findings can point at the exact same URL within one job (e.g. a domain
    mentioned both on a thread page and on the board listing that links to
    it). Content-hash dedup means the second capture of that same URL is
    correctly NOT a new hash, so a "new hash appeared" check would wrongly
    report no screenshot for the second finding even though a fresh one was
    just captured and is sitting right there under the existing hash.

    Compares canonicalized URLs rather than raw strings: `url` here is
    already the canonicalized (e.g. XenForo numeric-only) form used for
    finding dedup, but Crawler.py records whatever URL it actually resolved
    to (e.g. XenForo's canonical slug form after redirect) - an exact-string
    compare between those two never matches, which meant evidence screenshots
    for XenForo findings could poll for the full timeout and still come back
    empty even though the capture succeeded and the screenshot was sitting
    right there under a differently-spelled URL.
    """
    from lib import forum_collector
    target = intel_extraction._canonicalize_forum_url(url)
    deadline = time.time() + EVIDENCE_CAPTURE_TIMEOUT
    while time.time() < deadline:
        time.sleep(EVIDENCE_CAPTURE_POLL_INTERVAL)
        for h in forum_collector.get_forum_document_hashes(forum_id):
            meta = forum_collector.get_forum_document_meta(forum_id, h)
            if not meta or intel_extraction._canonicalize_forum_url(meta.get('url')) != target:
                continue
            try:
                if int(meta.get('last_seen', 0)) < start_time:
                    continue
            except (TypeError, ValueError):
                continue
            item_id = meta.get('item_id')
            if not item_id:
                continue
            corr = correlations_engine.get_correlations('item', '', item_id, filter_types=['screenshot'])
            if corr.get('screenshot'):
                return item_id
    return None


def _screenshot_looks_cropped(item_id):
    """True if the item's screenshot exists and is short enough to be a
    single cropped post rather than a full, uncropped page."""
    from lib.objects.Screenshots import Screenshot
    corr = correlations_engine.get_correlations('item', '', item_id, filter_types=['screenshot'])
    screenshot_ids = corr.get('screenshot')
    if not screenshot_ids:
        return False
    try:
        from PIL import Image
        filepath = Screenshot(next(iter(screenshot_ids)).lstrip(':')).get_filepath()
        with Image.open(filepath) as im:
            return im.size[1] <= CROPPED_SCREENSHOT_MAX_HEIGHT
    except Exception:
        return False


def _item_has_real_screenshot(item_id):
    """True only if item_id has a screenshot correlation AND the PNG file it
    points to actually still exists on disk. Correlation records in the DB
    can outlive the file they reference (confirmed: a screenshot deleted in
    an earlier cleanup left its correlation record behind) - trusting the
    correlation alone can point a brand-new finding at a stale, unrelated,
    or simply missing image."""
    if not item_id:
        return False
    from lib.objects.Screenshots import Screenshot
    corr = correlations_engine.get_correlations('item', '', item_id, filter_types=['screenshot'])
    screenshot_ids = corr.get('screenshot')
    if not screenshot_ids:
        return False
    filepath = Screenshot(next(iter(screenshot_ids)).lstrip(':')).get_filepath()
    return bool(filepath) and os.path.isfile(filepath)


def _capture_critical_evidence(forum_id, url):
    """
    Triggers a fresh, screenshot-enabled capture of `url` and waits (bounded)
    for a screenshot to actually show up for it, returning the item_id to use
    for screenshot lookups, or None if it didn't complete in time (the finding
    just won't have a screenshot yet - not a hard failure). Retries once if
    the result came back looking like an uncropped full page (see
    CROPPED_SCREENSHOT_MAX_HEIGHT) - a single bounded retry, not a loop, so a
    persistently uncroppable page (e.g. a board listing with no single post
    to isolate) still returns its best available result instead of hanging.
    """
    from lib import forum_collector
    start_time = int(time.time())
    res, code = forum_collector.capture_evidence_screenshot(forum_id, url)
    if code != 200:
        return None

    item_id = _screenshot_item_id(forum_id, url, start_time)
    if item_id and not _screenshot_looks_cropped(item_id):
        retry_start_time = int(time.time())
        res, code = forum_collector.capture_evidence_screenshot(forum_id, url)
        if code == 200:
            retry_item_id = _screenshot_item_id(forum_id, url, retry_start_time)
            if retry_item_id and _screenshot_looks_cropped(retry_item_id):
                item_id = retry_item_id
    return item_id


# Bounded per-forum wait for a live search step - matches
# EVIDENCE_CAPTURE_TIMEOUT's 120s, and for the same reason: a Tor +
# Cloudflare-challenged capture routinely takes 30-90s on its own (see
# EVIDENCE_CAPTURE_TIMEOUT's comment), and on top of that this live-search
# task shares the single Crawler worker with whatever else is already
# running - confirmed live: a real search capture that took ~45s of actual
# browser time still missed a 70s budget because it landed behind an
# in-progress ForumMonitorWorker RSS poll of the same forum, which is
# routine (RSS polling runs every 10 min - see ForumMonitorWorker.py -
# regardless of whether a live search happens to be running at the same
# moment). 70s was cutting it close even without that overlap; short of
# giving live search a dedicated worker (out of scope for now), 120s gives
# enough margin that ordinary contention doesn't look like a dead forum.
# Worst case for a job touching N forums is roughly N * this, since there's
# only one Crawler worker (see the standing "just Crawler + workers" infra
# decision) - these can't actually run in parallel at the browser level even
# though they're fired off back-to-back here.
LIVE_SEARCH_TIMEOUT_PER_FORUM = 120
LIVE_SEARCH_POLL_INTERVAL = 4


def _trigger_live_capture(forum_id, query, query_type):
    """
    Kicks off a fresh, targeted capture for `query` against one forum, using
    whatever search mechanism that forum is configured with (see
    forum_registry.set_search_url) - a direct GET template for a forum whose
    search is a plain link (MyBB), or the in-browser form-submit trick for
    one that needs a real form submission (XenForo) - see
    forum_collector.search_forum. Returns the epoch time to wait from, or
    None if this forum can't be live-searched right now (no search_url
    configured, disabled, or - the failover case - its circuit breaker is
    open) so the caller can skip straight to using whatever's already in the
    corpus for it instead of blocking on a forum that's known to be down.
    """
    from lib import forum_collector
    from urllib.parse import quote

    search_url = forum_registry.get_search_url(forum_id)
    if not search_url:
        return None, 'no search_url configured for this forum'

    start_time = int(time.time())
    if '{query}' in search_url:
        res, code = forum_collector.capture_page(forum_id, search_url.format(query=quote(query)))
    else:
        res, code = forum_collector.search_forum(forum_id, search_url, query)

    if code != 200:
        return None, res.get('reason', 'capture could not be queued')
    return start_time, None


def _wait_for_live_capture(forum_id, start_time, timeout=LIVE_SEARCH_TIMEOUT_PER_FORUM):
    """True once *any* document for this forum with last_seen >= start_time
    shows up (the live search's own results page, or - since a search
    capture goes through the exact same record_forum_document path as any
    other collection - any page it happened to pull in). Doesn't try to
    match a specific URL the way evidence-screenshot polling does, because a
    live search's actual landing URL is only known after Lacus resolves the
    form submission (e.g. XenForo's '/search/104051X/?q=...') - the caller
    doesn't have it in advance to match against."""
    from lib import forum_collector
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(LIVE_SEARCH_POLL_INTERVAL)
        for h in forum_collector.get_forum_document_hashes(forum_id):
            meta = forum_collector.get_forum_document_meta(forum_id, h)
            if not meta:
                continue
            try:
                if int(meta.get('last_seen', 0)) >= start_time:
                    return True
            except (TypeError, ValueError):
                continue
    return False


# A forum with a native search adapter (currently DarkForums via mybb_search)
# is searched through its OWN authenticated session on the direct route, not the
# legacy Lacus capture. Same 30s per-forum manual-search cooldown key the UI
# uses, so the two paths coordinate and never hammer the session back-to-back.
NATIVE_SEARCH_COOLDOWN_SECONDS = 30


def _native_search_eligible(forum_id):
    """True when this forum has a native search adapter, so a keyword search
    should query the forum directly instead of only the existing corpus."""
    try:
        from lib import forum_search
        return forum_search.get_search_provider(forum_id) is not None
    except Exception:
        return False


def _run_native_forum_searches(query, forum_ids):
    """For each selected forum that has a native search adapter, run its OWN
    search for `query` through the authenticated session (direct/Tor route,
    dedup/redaction/storage pipeline), so its fresh documents are stored before
    the corpus fold examines them. Works for BOTH keyword and domain queries -
    the engine's domain fallback (label search + exact-domain gate) handles a
    dotted domain. Never raises.

    Returns {forum_id: status} where status is one of 'searched',
    'skipped: searched recently (cooldown)', or 'blocked: <reason>' - so the
    report panel can state what ACTUALLY happened for each source instead of a
    blanket "live: searched" that also covered a cooldown skip."""
    from lib import forum_search
    status = {}
    for forum_id in forum_ids:
        if not _native_search_eligible(forum_id):
            continue
        # Respect the shared per-forum cooldown - do NOT re-hit the session.
        ck = f'forumsearch:cooldown:{forum_id}'
        try:
            if r_crawler.get(ck):
                status[forum_id] = 'skipped: searched recently (cooldown)'
                continue
            r_crawler.set(ck, int(time.time()), ex=NATIVE_SEARCH_COOLDOWN_SECONDS)
        except Exception:
            pass
        try:
            # max_pages left at the engine default (FORUM_SEARCH_MAX_PAGES) so
            # the search follows pagination through the matching results up to
            # the existing safety limit, newest-first - not just page 1.
            metrics = forum_search.run_search_collection(
                forum_id, queries=[query], follow_results=True)
            if isinstance(metrics, dict) and metrics.get('block_category'):
                status[forum_id] = f'blocked: {metrics.get("block_category")}'
            else:
                status[forum_id] = 'searched'
        except Exception as e:
            print(f'Native forum search failed for {forum_id}: {e}')
            status[forum_id] = f'blocked: {type(e).__name__}'
            continue
        # No separate dashboard row is created here any more. The forum's
        # freshly stored documents are folded into THIS job's single combined
        # finding (see run_job's forum-document evidence step), so one user
        # query produces exactly one finding across all sources.
    return status


def _record_corpus_only_status(job_id, forum_ids):
    """Live search unticked: no forum was crawled live for this job. Record a
    per-source status so the report panel is honest about that. ransomware.live
    is still always checked via its real-time API (independent of the live
    flag), so it keeps its own message."""
    live_status = {}
    for forum_id in forum_ids:
        if forum_id == 'ransomware.live':
            live_status[forum_id] = 'checked separately via the real-time ransomware.live API (see Findings)'
        else:
            live_status[forum_id] = 'from stored corpus (no live crawl this run)'
    _set_job_fields(job_id, live_status=json.dumps(live_status))


def _run_live_search_step(job_id, query, query_type, forum_ids, native_status=None):
    """
    The failover step: for every forum in this job that isn't circuit-broken,
    trigger a fresh live capture and wait (bounded, one forum at a time -
    see LIVE_SEARCH_TIMEOUT_PER_FORUM) for it to land, before the normal
    corpus query runs. A forum that's down, disabled, or has no search_url
    configured is simply skipped - the job proceeds using whatever's already
    in the corpus for it, and every forum's outcome is recorded in
    live_status so the report can show which sources were actually live and
    which fell back to prior collection. Never raises - a total failure here
    still leaves the job free to fall through to the existing corpus search.

    `native_status` is what _run_native_forum_searches actually did per forum
    ('searched' / 'skipped: cooldown' / 'blocked: ...'), so the panel reports
    the TRUTH for native-searched forums instead of a blanket "live: searched".
    """
    native_status = native_status or {}
    live_status = {}
    for forum_id in forum_ids:
        if forum_id == 'ransomware.live':
            # Not part of this generic forum-capture mechanism at all - it's
            # checked separately, always, via the dedicated real-time API
            # (see ransomware_live.py / the report's ransomware_live_checked
            # flag), regardless of forum selection. Reporting it here as
            # "skipped: no search_url" was confirmed confusing: it read as
            # "ransomware.live wasn't checked" right next to findings that
            # came from checking it.
            live_status[forum_id] = 'checked separately via the real-time ransomware.live API (see Findings)'
            continue
        if _native_search_eligible(forum_id):
            # Reflect what the native search ACTUALLY did this run.
            outcome = native_status.get(forum_id)
            if outcome == 'searched':
                live_status[forum_id] = 'live: searched via native authenticated session'
            elif outcome and outcome.startswith('skipped'):
                live_status[forum_id] = f'{outcome} - showing stored corpus'
            elif outcome and outcome.startswith('blocked'):
                live_status[forum_id] = f'{outcome} - showing stored corpus'
            else:
                live_status[forum_id] = 'live: searched via native authenticated session'
            continue
        if forum_registry.is_circuit_open(forum_id):
            live_status[forum_id] = 'skipped: forum unreachable (circuit breaker open)'
            continue
        start_time, skip_reason = _trigger_live_capture(forum_id, query, query_type)
        if start_time is None:
            live_status[forum_id] = f'skipped: {skip_reason}'
            continue
        if _wait_for_live_capture(forum_id, start_time):
            live_status[forum_id] = 'live: fresh capture landed'
        else:
            live_status[forum_id] = 'timed out waiting for live capture - using existing corpus'
    _set_job_fields(job_id, live_status=json.dumps(live_status))


# ---------------------------------------------------------------------------
# Leak-disclosure enrichment
# ---------------------------------------------------------------------------

# Categories inferred from the group's own claim text. Only used to badge WHAT
# KIND of data is claimed - never to assert a count of actual records.
_CLAIM_PATTERNS = [
    ('pii',          r'\bssn\b|social secur|passport|driver.?s? licen|personal information|\bpii\b|medical|health'),
    ('financial',    r'financial|payroll|invoice|bank|accounting|tax\b|billing'),
    ('confidential', r'confidential|internal|\bnda\b|proprietary'),
    ('hr',           r'employee|personnel|\bhr\b|staff'),
    ('customer',     r'client|customer|subscriber'),
    ('source_code',  r'source code|repositor'),
    ('database',     r'database|\bdb dump|backup'),
]


def _claim_text_categories(text):
    """Normalised data categories mentioned in a group's claim description."""
    if not text:
        return []
    low = str(text).lower()
    return [cat for cat, pattern in _CLAIM_PATTERNS if re.search(pattern, low)]


# Leak-site disclosure APIs are .onion services; the fetch is best-effort and
# strictly bounded. A failure just means the finding carries the ransomware.live
# data alone - it never fails the job.
_DISCLOSURE_TIMEOUT = 45


# Disclosure fetch outcomes. Previously every failure collapsed into a bare
# None, so "the hidden service is offline", "Tor could not resolve it", "it
# timed out", "it demanded a login" and "it answered fine but had no
# disclosures" were indistinguishable - both in the logs and in the UI.
DISCLOSURE_OK = 'retrieved'
DISCLOSURE_NOT_APPLICABLE = 'not_published'    # claim URL is not an API endpoint
DISCLOSURE_TOR_FAILURE = 'tor_failure'         # onion descriptor/DNS resolution failed
DISCLOSURE_TIMEOUT = 'timeout'
DISCLOSURE_UNREACHABLE = 'unavailable'         # connection refused/reset, service down
DISCLOSURE_AUTH = 'auth_required'              # 401/403/login wall/anti-bot
DISCLOSURE_EMPTY = 'empty'                     # valid response, no disclosure records
DISCLOSURE_BAD_PAYLOAD = 'invalid_payload'     # 200 but not usable JSON

# SOCKS/Tor resolution failures surface as these substrings. A hidden service
# with no published descriptor ("No more HSDir available to query" in tor's own
# log) reaches us as a SOCKS "host unreachable"/"general failure" - that is a
# DIFFERENT condition from a TCP timeout and is reported as such.
_TOR_RESOLVE_MARKERS = (
    'host unreachable', 'general socks server failure', 'ttl expired',
    'name or service not known', 'socks5', 'connection not allowed',
    'unable to connect to', 'no more hsdir',
)


def _is_onion(url):
    try:
        from urllib.parse import urlparse as _up
        return (_up(url).hostname or '').endswith('.onion')
    except Exception:
        return False


def _fetch_disclosure(url, logger=None):
    """
    Fetch and structure a leak-site disclosure API response.

    Returns (parsed_or_None, status, detail) where `status` is one of the
    DISCLOSURE_* constants above. Always routed through Tor (these are hidden
    services), never raises, and never logs response bodies or credentials -
    only the status, the URL and a short transport-level reason.
    """
    def _log(msg):
        if logger:
            logger(f'[disclosure] {msg}')

    if not url:
        return None, DISCLOSURE_NOT_APPLICABLE, 'no claim URL on this record'
    if '/api/' not in url:
        return None, DISCLOSURE_NOT_APPLICABLE, 'claim URL is not a structured disclosure endpoint'

    import requests
    proxy = os.environ.get('FORUM_CRAWL_TOR_PROXY', 'socks5h://127.0.0.1:9050')
    try:
        resp = requests.get(url, timeout=_DISCLOSURE_TIMEOUT,
                            proxies={'http': proxy, 'https': proxy},
                            headers={'User-Agent': 'Mozilla/5.0'})
    except requests.exceptions.Timeout:
        # A .onion that times out is almost always a descriptor-resolution
        # failure, not a slow server: tor holds the SOCKS connection open while
        # it retries the HSDir hashring and only gives up on OUR timeout, so
        # the offline-hidden-service case surfaces as a timeout rather than a
        # SOCKS error (confirmed against tor's own log: "resolve failed ...
        # No more HSDir available to query"). Reporting that as a plain timeout
        # would imply a transient slowdown and hide a service that is simply
        # gone.
        if _is_onion(url):
            detail = ('Tor could not resolve the hidden service within '
                      f'{_DISCLOSURE_TIMEOUT}s - no descriptor published '
                      '(service offline or address retired)')
            _log(f'{url} -> TOR RESOLVE FAILURE (descriptor lookup timed out)')
            return None, DISCLOSURE_TOR_FAILURE, detail
        detail = f'timed out after {_DISCLOSURE_TIMEOUT}s'
        _log(f'{url} -> TIMEOUT ({detail})')
        return None, DISCLOSURE_TIMEOUT, detail
    except requests.exceptions.RequestException as e:
        text = f'{type(e).__name__}: {e}'.lower()
        if any(m in text for m in _TOR_RESOLVE_MARKERS):
            detail = ('Tor could not resolve the hidden service - no descriptor '
                      'published (service offline or address retired)')
            _log(f'{url} -> TOR RESOLVE FAILURE')
            return None, DISCLOSURE_TOR_FAILURE, detail
        detail = f'{type(e).__name__}'
        _log(f'{url} -> UNREACHABLE ({detail})')
        return None, DISCLOSURE_UNREACHABLE, detail

    # Auth / anti-bot wall. Classified with the shared forum block detector so
    # a login wall here reads the same way it does for forum collection.
    if resp.status_code in (401, 403):
        _log(f'{url} -> AUTH REQUIRED (HTTP {resp.status_code})')
        return None, DISCLOSURE_AUTH, f'HTTP {resp.status_code}'
    body = resp.text or ''
    try:
        from lib.forum_providers import base as _fp
        info = _fp.classify_block(re.sub(r'<[^>]+>', ' ', body)[:4000], body)
    except Exception:
        info = None
    if info and info['category'] in ('auth', 'antispam', 'session', 'challenge'):
        _log(f"{url} -> AUTH/BLOCK ({info['category']})")
        return None, DISCLOSURE_AUTH, info['reason']

    if resp.status_code != 200:
        _log(f'{url} -> HTTP {resp.status_code}')
        return None, DISCLOSURE_UNREACHABLE, f'HTTP {resp.status_code}'

    try:
        data = resp.json()
    except Exception:
        _log(f'{url} -> INVALID PAYLOAD (not JSON)')
        return None, DISCLOSURE_BAD_PAYLOAD, 'response was not valid JSON'

    records = data
    if isinstance(data, dict):
        records = data.get('results') or data.get('disclosures') or data.get('data')
    if not isinstance(records, list) or not records:
        # A VALID response that simply carries no disclosures is a real and
        # distinct state - the group has published nothing for this company.
        _log(f'{url} -> VALID RESPONSE, NO DISCLOSURE RECORDS')
        return None, DISCLOSURE_EMPTY, 'endpoint responded but published no disclosure records'

    parsed = leak_intel.parse_disclosure(records[0], source_url=url)
    if not parsed:
        return None, DISCLOSURE_BAD_PAYLOAD, 'disclosure record could not be parsed'
    if isinstance(data, dict) and data.get('total_active_disclosures') is not None:
        parsed['total_active_disclosures'] = data.get('total_active_disclosures')
    _log(f"{url} -> OK ({len(parsed.get('files') or [])} files, "
         f"{len(parsed.get('tags') or [])} tags, "
         f"{len(parsed.get('screenshots') or [])} screenshots)")
    return parsed, DISCLOSURE_OK, None


def _finding_recency(f):
    """Best-effort UTC epoch of a finding's OWN date, for newest-first sorting.
    Forum posts carry `published_at` (a parsed epoch); leak-site / ransomware
    claims carry `attack_date` (ISO). A finding with no usable date sorts last."""
    pa = f.get('published_at')
    if pa not in (None, ''):
        try:
            return float(pa)
        except (TypeError, ValueError):
            pass
    ad = f.get('attack_date')
    if ad:
        try:
            return datetime.fromisoformat(str(ad).replace('Z', '+00:00')).timestamp()
        except (TypeError, ValueError):
            pass
    return 0.0


def run_job(job_id):
    """
    Execute a queued job synchronously. Called by the worker process.

    Findings are individual leaked credentials, not "this page mentions the
    domain" - a page that only mentions the target with no actual
    email/username/password data attached is not reported at all (see
    intel_extraction.extract_credential_records). Every finding requires a
    verified screenshot before it's included (see _capture_critical_evidence
    below) - a leak this pipeline can't put evidence behind isn't reported
    either. That trade-off means a job now does a live evidence re-crawl for
    every distinct source URL with a real finding on it (up to
    EVIDENCE_CAPTURE_TIMEOUT seconds each), so this can take noticeably
    longer than a bare corpus search - the cost of every finding being
    something you can actually show someone, not just a text claim.
    """
    job, code = get_job(job_id)
    if code != 200:
        return
    domain = job['domain']
    query_type = job.get('query_type', 'domain')
    forum_ids = job['forum_ids']

    _set_job_fields(job_id, status='RUNNING', started_at=int(time.time()))

    # Retire any leftover per-source DarkForums rows (superseded by the single
    # combined finding). Cheap, idempotent, and self-heals older jobs.
    try:
        purge_native_search_jobs()
    except Exception:
        pass

    # A Keyword / Organisation search treats every native-search-capable forum
    # (DarkForums) as one of its sources: run the forum's OWN authenticated
    # search first so its fresh, deduped, redacted documents are stored and
    # indexed before the corpus query below examines them. Runs on the worker,
    # never the request thread, and is cooldown-bounded so it can't hammer the
    # session. Domain searches keep their existing behaviour untouched.
    # Corpus-FIRST by default: findings are derived from the already-stored,
    # indexed documents (instant, no network). Live crawling - the native
    # authenticated forum search for keyword jobs, and the Lacus capture for
    # the rest - happens ONLY when the operator ticked "Live search". This is
    # what the search form promises ("Leave unchecked to search only what's
    # already been collected (instant)") and keeps an unticked keyword search
    # from silently doing a slow Tor crawl (CryptBB's 30s flood pacing etc.).
    if job.get('live'):
        # Run the native authenticated forum search for the term - for BOTH
        # keyword AND domain queries. Previously this was keyword-only, so a
        # LIVE domain search never actually crawled the forums yet was still
        # labelled "live: searched"; that is the "finished in 1s, searched
        # nothing" bug. The engine's domain fallback handles a dotted domain.
        native_status = {}
        try:
            native_status = _run_native_forum_searches(domain, forum_ids) or {}
        except Exception as e:
            print(f'Native forum search step failed for job {job_id}: {e}')
        try:
            _run_live_search_step(job_id, domain, query_type, forum_ids,
                                  native_status=native_status)
        except Exception as e:
            # Live search is a best-effort freshness step, not a
            # requirement - a bug here must never fail a job that could
            # otherwise still return good results from the existing corpus.
            print(f'Live search step failed for job {job_id}: {e}')
    else:
        # Corpus-only: no live crawl. Record each source's status honestly so
        # the report's "Search Sources" panel reads "from stored corpus"
        # rather than implying a fresh live search happened.
        try:
            _record_corpus_only_status(job_id, forum_ids)
        except Exception as e:
            print(f'Corpus-only status step failed for job {job_id}: {e}')

    findings = []
    documents_examined = 0
    matches_found = 0
    seen_credentials = set()
    screenshot_cache = {}

    try:
        if search_engine.Engine is None:
            raise RuntimeError('Meilisearch is not enabled')

        from lib import forum_collector

        result = search_engine.Engine.search_intel_docs(domain, forum_ids)
        hits = result.get('hits', [])

        for hit in hits:
            documents_examined += 1
            content = hit.get('content') or ''
            forum_id = hit.get('forum_id')
            content_hash = hit.get('uuid')
            # Canonicalize away MyBB's navigation-only URL variants (post
            # permalinks, "next/previous" action links) so a document whose
            # own capture URL happens to be one of those variants is still
            # correctly identified as the same real thread as its canonical
            # form - see intel_extraction._canonicalize_forum_url.
            url = intel_extraction._canonicalize_forum_url(hit.get('url'))
            doc_meta = None
            try:
                doc_meta = forum_collector.get_forum_document_meta(forum_id, content_hash)
            except Exception:
                doc_meta = None

            if query_type == 'keyword':
                matches = intel_extraction.classify_keyword_matches(content, domain)
            else:
                matches = intel_extraction.classify_matches(content, domain)
            if not matches:
                continue

            matches_found += len(matches)
            best_match = max(matches, key=lambda m: _MATCH_CONFIDENCE_RANK.get(m['confidence'], 0))
            # Scope credential/entity extraction to content actually near the
            # match rather than the whole page - see extract_analysis_window
            # for why (a busy listing page's OTHER threads were bleeding
            # their own credentials into this domain's findings).
            analysis_text = intel_extraction.extract_analysis_window(content, best_match['matched_value'])

            if query_type == 'keyword':
                # No target domain to check a combo line's URL against, so
                # every combo-shaped credential line near the match counts
                # (see extract_credential_records' domain=None mode) - a
                # keyword search still needs to catch leaks whose usernames
                # aren't email addresses (e.g. a stealer-log combo line like
                # "url|100a460|Holihai@2026"), not just bare emails.
                cred_records = intel_extraction.extract_credential_records(
                    analysis_text, domain=None, keyword=domain)
                seen_emails = {r['email'] for r in cred_records if 'email' in r}
                # Only bare emails whose OWN domain relates to the searched
                # keyword are on-topic findings; an unrelated email sharing a
                # combo dump (bookings@newcastlelodge.com under a "google"
                # search) is a false positive. The thread itself is still
                # surfaced as a forum_document finding.
                _kw = (domain or '').strip().lower()
                for e in intel_extraction.extract_emails(analysis_text):
                    if e in seen_emails:
                        continue
                    edom = e.rsplit('@', 1)[-1].lower()
                    if _kw and _kw not in edom:
                        continue
                    cred_records.append({'email': e})
                    seen_emails.add(e)
            else:
                cred_records = intel_extraction.extract_credential_records(analysis_text, domain)
                seen_emails = {r['email'] for r in cred_records if 'email' in r}
                for m in matches:
                    if m['match_type'] == 'email_domain' and m['matched_value'] not in seen_emails:
                        cred_records.append({'email': m['matched_value']})
                        seen_emails.add(m['matched_value'])
            # Standalone phone numbers carry no domain/keyword of their own, so
            # in a KEYWORD search a phone merely sitting near the matched word
            # (a CompTIA cert thread, a fake-documents Telegram ad) cannot be
            # attributed to the keyword and is a false positive. Only surface a
            # phone in DOMAIN mode, where the surrounding record is already
            # scoped to the searched domain.
            if query_type != 'keyword':
                for phone in intel_extraction.extract_phones(analysis_text):
                    cred_records.append({'phone': phone})

            if not cred_records:
                continue

            match_snippet, specific_url = intel_extraction.extract_match_snippet(
                content, best_match['matched_value'], base_url=url)
            # The specific thread URL (when resolvable) is the real, unique
            # "where this was found" - a board-listing page is just wherever
            # we happened to see it.
            source_url = specific_url or url

            forum_meta, _ = forum_registry.get_forum(forum_id)
            source_forum_name = forum_meta.get('name') if forum_meta else forum_id
            item_id = (doc_meta or {}).get('item_id')
            first_seen = (doc_meta or {}).get('first_seen') or hit.get('first')
            last_seen = (doc_meta or {}).get('last_seen') or hit.get('last')

            # Traceability: correlate the target domain to the source item, if we
            # know it, so the finding is graph-reachable from the domain object too.
            if item_id and query_type == 'domain':
                try:
                    correlations_engine.add_obj_correlation('domain', '', domain, 'item', '', item_id)
                except Exception:
                    pass

            authorship = intel_extraction.extract_thread_authorship(content, best_match['matched_value'])
            named_actor, _named_actor_source = intel_extraction.extract_named_actor_group(content)
            if named_actor:
                attacker = named_actor
            elif authorship['author'] and authorship['author_confidence'] == 'op':
                attacker = authorship['author']
            else:
                attacker = None
            campaign = intel_extraction.extract_thread_title(content)

            # Evidence screenshot - required, not best-effort. One capture
            # per unique source_url, reused across every credential found on
            # that same page rather than re-crawling once per credential.
            if source_url not in screenshot_cache:
                screenshot_cache[source_url] = _capture_critical_evidence(forum_id, source_url)
            evidence_item_id = screenshot_cache[source_url]
            if not evidence_item_id or not _item_has_real_screenshot(evidence_item_id):
                continue

            for record in cred_records:
                key = (domain, tuple(sorted(record.items())))
                if key in seen_credentials:
                    continue
                seen_credentials.add(key)

                if 'password' in record:
                    risk_level = 'CRITICAL'
                elif 'email' in record or 'username' in record:
                    risk_level = 'HIGH'
                else:
                    risk_level = 'MEDIUM'

                finding = {
                    'domain': domain,
                    'credential': record,
                    'source_forum': source_forum_name,
                    'source_url': source_url,
                    'first_seen': first_seen,
                    'last_seen': last_seen,
                    'document_id': evidence_item_id,
                    'risk_level': risk_level,
                }
                if attacker:
                    finding['attacker'] = attacker
                if campaign:
                    finding['campaign'] = campaign
                # Query-driven provenance, when this document entered the
                # corpus because a configured search term matched it. Absent
                # for link-crawled documents rather than invented for them.
                try:
                    prov = forum_ingest.get_search_provenance(forum_id, content_hash)
                except Exception:
                    prov = {}
                if prov:
                    finding.update(prov)
                findings.append(finding)

        # Ransomware.live victim check - a distinct signal from the
        # forum-credential findings above ("this domain was itself named
        # as a ransomware victim", not "a leaked password was found for
        # it"). Every matching record is included, not just the first -
        # a domain can legitimately be named by more than one gang, or
        # claimed more than once. ransomware_live_checked distinguishes
        # "checked, nothing found" from "couldn't check" (rate-limited/
        # unreachable) - the latter must never be presented as a
        # confirmed absence.
        ransomware_records, ransomware_live_checked = ransomware_live.search_victims(domain, query_type)
        for record in ransomware_records:
            screenshot_url = record.get('screenshot')
            if not screenshot_url:
                # Screenshot is a hard requirement for every finding (see
                # the module docstring above) - a victim record with no
                # evidence image behind it isn't reported.
                continue
            # Everything ransomware.live actually provides is carried into the
            # finding now. It was previously reduced to six fields here, so
            # sector, country, the group's own claim text, discovery time,
            # press attribution and the infostealer compromise counts never
            # reached the report or the UI.
            claim_url = record.get('claim_url') or record.get('reference_url')
            infostealer = leak_intel.parse_infostealer(record.get('infostealer'))

            categories = {}
            if infostealer and infostealer.get('total_infections'):
                # Infostealer hits are credential compromises by definition -
                # counted, never itemised, and no credential value is stored.
                categories['credentials'] = infostealer['total_infections']
            for cat in _claim_text_categories(record.get('description')):
                categories.setdefault(cat, 1)

            finding = {
                'domain': domain,
                'victim': record.get('victim'),
                'attacker': record.get('group'),
                'attack_date': record.get('attackdate'),
                'source_url': claim_url,
                'screenshot_url': screenshot_url,
                'risk_level': 'CRITICAL',
                # provenance
                'source_forum': 'ransomware.live',
                'source_kind': 'live API check',
                'discovered_at': record.get('discovered'),
                'collected_at': datetime.now(timezone.utc).isoformat(),
                'reference_url': record.get('reference_url'),
                # victim context
                'sector': record.get('activity'),
                'country': record.get('country'),
                'claim_text': record.get('description'),
                'data_size': record.get('data_size'),
                'ransom': record.get('ransom'),
                'press': record.get('press'),
                'infostealer': infostealer,
                'indicators': leak_intel.build_indicators(categories),
            }
            # If the claim URL is a leak-site disclosure API, structure it.
            # Availability is recorded explicitly: a missing disclosure because
            # the .onion is unreachable is a meaningful intelligence condition,
            # not something to hide behind an empty section.
            disclosure, d_status, d_detail = _fetch_disclosure(claim_url, logger=print)
            finding['disclosure_status'] = d_status
            if d_detail:
                finding['disclosure_detail'] = d_detail
            if disclosure:
                finding['disclosure'] = disclosure
                merged = dict(categories)
                for k, v in (disclosure.get('categories') or {}).items():
                    merged[k] = merged.get(k, 0) + v
                finding['indicators'] = leak_intel.build_indicators(merged)
            findings.append(finding)

        # ---- Russian Market: stealer-log marketplace exposure -----------
        # A THIRD signal, distinct from a forum credential paste and a
        # ransomware claim: a live host holding credentials for this asset is
        # currently listed for sale. Runs inside the same pipeline and lands
        # in the same findings list - not a separate workflow.
        #
        # Availability is recorded explicitly. A gated marketplace must never
        # read as "checked, nothing found", so the status is carried into the
        # report exactly like ransomware_live_checked is.
        rm_status, rm_detail = russian_market.RM_NOT_CONFIGURED, None
        try:
            rm_records, rm_status, rm_detail = russian_market.search(domain, logger=print)
        except Exception as e:
            rm_records = []
            rm_status, rm_detail = russian_market.RM_UNAVAILABLE, type(e).__name__
        for rec in rm_records:
            # Counts and presence flags only - the adapter guarantees no
            # password, cookie, token or autofill value ever reaches here.
            categories = {}
            if rec.get('credential_count'):
                categories['credentials'] = rec['credential_count']
            if rec.get('has_cookies'):
                categories['session_tokens'] = rec.get('cookie_count') or 1
            findings.append({
                'domain': domain,
                'risk_level': 'CRITICAL' if rec.get('credential_count') else 'HIGH',
                # provenance
                'source_forum': russian_market.SOURCE_NAME,
                'source_kind': russian_market.SOURCE_KIND,
                'source_url': rec.get('listing_url'),
                'collected_at': rec.get('collected_at'),
                'collection_mode': 'search',
                'matched_query': rec.get('matched_query'),
                'match_reason': rec.get('match_reason'),
                # the normalised, redacted marketplace record
                'stealer_bot': rec,
                'indicators': leak_intel.build_indicators(categories),
            })

        # ---- Leak-site victim-name check (The Gentlemen etc.) -------------
        # A FOURTH signal: the searched asset's name appears on a ransomware
        # leak site's open victim list. Name-level only and flagged for analyst
        # confirmation - the per-victim detail behind that site's own CAPTCHA is
        # never touched. Read through the operator's established browser session
        # (the site drops non-browser clients). Status is carried like the
        # others so "checked, no name match" never reads as "not checked".
        gm_status, gm_detail = gentlemen_intel.GM_NOT_CONFIGURED, None
        try:
            gm_records, gm_status, gm_detail = gentlemen_intel.search(domain, query_type, logger=print)
        except Exception as e:
            gm_records = []
            gm_status, gm_detail = gentlemen_intel.GM_UNAVAILABLE, type(e).__name__
        for rec in gm_records:
            findings.append({
                'domain': domain,
                'risk_level': 'MEDIUM',   # a name match is a lead, not a proven breach
                'source_forum': rec['source_name'],
                'source_kind': gentlemen_intel.SOURCE_KIND,
                'source_url': rec.get('source_url'),
                'collected_at': rec.get('collected_at'),
                'collection_mode': 'victim-list name match',
                'matched_query': rec.get('matched_query'),
                'match_reason': rec.get('match_reason'),
                'victim_name': rec.get('victim_name'),
                'needs_confirmation': True,
                'indicators': leak_intel.build_indicators({}),
            })

        # ---- Forum NATIVE-search documents as first-class evidence ---------
        # DarkForums (and any forum searched via its own authenticated native
        # search) stores enriched, deduped, redacted documents in the corpus
        # keyed by matched_query. Fold those directly into THIS combined
        # finding, grouped under their source, so a query's forum results live
        # in the ONE aggregated finding instead of a separate dashboard row.
        # Deduped by (source, url) against anything the credential pipeline
        # already produced, so the same thread is never shown twice.
        seen_doc_urls = {(f.get('source_forum'), f.get('source_url')) for f in findings}
        # STRICT relevance test, unified across search types: a stored document
        # is surfaced when the SEARCHED TERM actually occurs in its title/text -
        # NOT merely because it was collected under a matching query. A domain
        # search ("google.com") therefore mines every stored doc that genuinely
        # contains that domain (token-aware, so subdomains count and lookalikes
        # like "google.company.com" don't), exactly the way a keyword search
        # ("google") mines the corpus. This is the fix for domain searches
        # under-reporting: they were keyed on matched_query==domain, which no
        # doc carries unless a live domain search was run, so they returned
        # almost nothing while the same corpus answered the keyword form.
        if query_type == 'domain':
            _dom_re = _domain_token_re(domain)
            _brand = _brand_label(domain)
            _brand_re = _brand_word_re(_brand) if _brand else None
            def _term_hits(doc):
                # 'exact' = the exact domain appears (highest confidence);
                # 'brand' = the organisation is named but not as this domain
                # (what makes a bank/company DOMAIN search productive - the dump
                # says "HDFC Bank", never "hdfc.bank.in"). Honestly distinguished
                # in the finding, never conflated.
                text = doc.get('text') or ''
                title = doc.get('title') or ''
                if _dom_re.search(text) or _dom_re.search(title):
                    return 'exact'
                if _brand_re and (_brand_re.search(text) or _brand_re.search(title)):
                    return 'brand'
                return None
        else:
            _kw = domain.lower()
            def _term_hits(doc):
                return ('keyword' if (_kw in (doc.get('text') or '').lower()
                        or _kw in (doc.get('title') or '').lower()) else None)
        for forum_id in forum_ids:
            fmeta, _fc = forum_registry.get_forum(forum_id)
            fname = (fmeta or {}).get('name') or forum_id
            _kept_for_forum = 0
            for d in forum_ingest.list_documents(forum_id, limit=SEARCH_FOLD_SCAN_CAP):
                if _kept_for_forum >= FORUM_DOC_EVIDENCE_CAP:
                    break
                if d.get('collection_mode') != 'search':
                    continue
                _tier = _term_hits(d)
                if not _tier:
                    continue
                url = d.get('post_url') or d.get('thread_url') or ''
                if (fname, url) in seen_doc_urls:
                    continue
                seen_doc_urls.add((fname, url))
                _kept_for_forum += 1
                documents_examined += 1
                findings.append({
                    'domain': domain,
                    'evidence_kind': 'forum_document',
                    'risk_level': 'MEDIUM',
                    'source_forum': fname,
                    'source_kind': 'native forum search',
                    'source_url': url,
                    'title': d.get('title'),
                    'timestamp': d.get('timestamp'),
                    'published_at': d.get('published_at') or None,
                    'first_seen': d.get('first_seen'),
                    'last_seen': d.get('last_seen'),
                    # Excerpt framed around what actually matched: the exact
                    # domain, or (brand tier) the organisation name.
                    'text_excerpt': _excerpt_around(
                        d.get('text') or '',
                        _brand if _tier == 'brand' else domain),
                    'domains': (d.get('domains') or [])[:20],
                    'attachments': d.get('attachments') or [],
                    'images': d.get('images') or [],
                    'doc_indicators': d.get('indicators') or {},
                    'data_gated': (bool(_GATED_RE.search(d.get('text') or ''))
                                   and not (d.get('indicators') or {}).get('credentials')),
                    'matched_query': domain,
                    'match_tier': _tier,
                    'match_reason': (
                        f'Mentions the organisation "{_brand}" '
                        f'(the exact domain "{domain}" is not present in this post)'
                        if _tier == 'brand' else
                        (d.get('match_reason')
                         if (d.get('matched_query') or '').lower() == domain.lower()
                         else (f'Stored {fname} document contains "{domain}"'
                               + (f' (originally collected via search "{d.get("matched_query")}")'
                                  if d.get('matched_query') else '')))),
                    'match_snippet': d.get('match_snippet'),
                    'collection_mode': 'search',
                    # Authenticated thread evidence screenshot (sha256 id),
                    # captured at collection time by forum_screenshots. 'none'
                    # marks an attempted-but-failed capture - treat as absent.
                    'doc_screenshot_id': (d.get('screenshot_id')
                                          if d.get('screenshot_id') not in (None, '', 'none')
                                          else None),
                    # The term this finding actually matched on - the screenshot
                    # shown must be highlighted on THIS, not on the (possibly
                    # different) term the thread was originally collected under.
                    # Resolved to a term-specific shot just below.
                    'screenshot_focus_term': (_brand if _tier == 'brand' else domain),
                    '_forum_id': forum_id,
                    '_doc_id': d.get('doc_id'),
                    '_base_focus': d.get('matched_query') or '',
                })

        _RISK_ORDER = {'CRITICAL': 3, 'HIGH': 2, 'MEDIUM': 1, 'LOW': 0}
        # Exact-domain / credential evidence ranks above mere brand mentions, so
        # a domain search shows its highest-confidence hits first.
        _TIER_ORDER = {'exact': 2, 'keyword': 2, None: 2, 'brand': 0}
        # Newest-first: the most recent post/claim leads, so a fresh breach is
        # never buried under an older high-value one. Severity then tier break
        # ties (same date), and dateless findings fall to the bottom.
        findings.sort(key=lambda f: (_finding_recency(f),
                                     _RISK_ORDER.get(f['risk_level'], 0),
                                     _TIER_ORDER.get(f.get('match_tier'), 2)),
                      reverse=True)
        # Stable flat index so the per-finding PDF link survives source grouping
        # in the template (which regroups the list and loses loop position).
        for _i, _f in enumerate(findings):
            _f['_idx'] = _i

        # Make each forum-document finding's evidence screenshot follow the
        # SEARCHED term (so it matches the highlighted extract) instead of the
        # term the thread was originally collected under. Cached (doc, term)
        # shots resolve for free; only genuine misses cost a bounded number of
        # Tor captures, top (most-relevant, already-sorted) findings first.
        try:
            from lib import forum_screenshots
            _cap_items, _fmap = [], {}
            for _f in findings:
                if _f.get('evidence_kind') != 'forum_document':
                    continue
                _fid, _did = _f.get('_forum_id'), _f.get('_doc_id')
                _term = _f.get('screenshot_focus_term')
                _url = _f.get('source_url')
                if not (_fid and _did and _term and _url):
                    continue
                # Cheap: reuse a shot already known to be highlighted on this
                # exact term. (The base doc_screenshot_id stays as the last-
                # resort fallback if a capture can't be made below.)
                _sid = forum_screenshots.resolve_cached_term_shot(_fid, _did, _term)
                if _sid:
                    _f['doc_screenshot_id'] = _sid
                else:
                    _fmap[(_fid, _did, forum_screenshots._norm_term(_term))] = _f
                    _cap_items.append({'forum_id': _fid, 'doc_id': _did,
                                       'url': _url, 'term': _term})
            if _cap_items:
                _got = forum_screenshots.capture_for_findings(
                    _cap_items, cap=TERM_SHOT_CAP_PER_JOB, logger=print)
                for _key, _sid in _got.items():
                    _f = _fmap.get(_key)
                    if _f is not None and _sid and _sid != 'none':
                        _f['doc_screenshot_id'] = _sid
        except Exception as _e:
            print(f'term-screenshot resolution failed: {_e}')

        # Drop the internal-only fields before persisting the report.
        for _f in findings:
            for _k in ('_forum_id', '_doc_id', '_base_focus', 'screenshot_focus_term'):
                _f.pop(_k, None)

        # One query = one combined finding across N sources.
        source_count = len({f.get('source_forum') for f in findings if f.get('source_forum')})

        report = {
            'query': {
                'domain': domain,
                'query_type': query_type,
                'generated_at': datetime.now(timezone.utc).isoformat(),
                'sources_searched': len(forum_ids),
            },
            'summary': {
                'documents_examined': documents_examined,
                'findings_count': len(findings),
                'source_count': source_count,
                'total_matches': len(findings),
                'ransomware_live_checked': ransomware_live_checked,
                'russian_market_status': rm_status,
                'russian_market_detail': rm_detail,
                'russian_market_bots': sum(1 for f in findings if f.get('stealer_bot')),
                'leak_site_status': gm_status,
                'leak_site_detail': gm_detail,
                'leak_site_name_matches': sum(1 for f in findings if f.get('victim_name')),
            },
            'findings': findings,
        }
        report_path = os.path.join(REPORTS_FOLDER, f'{job_id}.json')
        # Write atomically (temp file + rename) so a second writer for the same
        # job_id (e.g. a stray concurrent run) can never interleave with this
        # one and corrupt the file - the rename is atomic, the old open()+write
        # was not.
        tmp_path = f'{report_path}.tmp-{os.getpid()}'
        with open(tmp_path, 'w') as f:
            json.dump(report, f, indent=2, sort_keys=True)
        os.replace(tmp_path, report_path)

        _set_job_fields(
            job_id,
            status='COMPLETED',
            completed_at=int(time.time()),
            documents_examined=documents_examined,
            matches_found=matches_found,
            findings_count=len(findings),
            source_count=source_count,
            report_path=report_path,
        )
    except Exception as e:
        _set_job_fields(job_id, status='FAILED', completed_at=int(time.time()), error=str(e))
        return


def get_report(job_id):
    job, code = get_job(job_id)
    if code != 200:
        return job, code
    if job['status'] != 'COMPLETED' or not job.get('report_path'):
        return {'status': 'error', 'reason': f"Job is {job['status']}, no report available"}, 409
    with open(job['report_path']) as f:
        return json.load(f), 200
