#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Forum document model: parsing, attachment metadata, canonical identity.

Replaces "the document is whatever html2text produced, keyed by its sha256"
with a structured record that keeps the fields the intelligence layer needs
(source, thread/post id, author, timestamp, links, domains, keywords,
attachment metadata) and a stable identity that survives re-capture.

Why identity matters here specifically: content-hash-only dedupe produced a
FALSE NEGATIVE on breached.st (each anti-bot challenge embeds a fresh nonce,
so four captures of the same blocked URL hashed differently and were all
counted as new documents) and risks the mirrored FALSE POSITIVE the task
warns about (two genuinely different posts sharing a title/author/timestamp
collapsing into one). `forum + thread/post id` fixes both: it is stable across
re-captures and unique across distinct posts.

Attachment handling is metadata-only and deliberately non-executing: file
names, extensions, sizes and URLs are recorded; nothing is downloaded,
executed, or served to the browser.
"""

import os
import re
import sys
import json
import time
from hashlib import sha256
from urllib.parse import urljoin, urlparse, unquote

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers

# ---------------------------------------------------------------------------
# Attachment / file-reference extraction
# ---------------------------------------------------------------------------
INTERESTING_EXTENSIONS = {
    # text/data dumps
    'txt': 'text', 'csv': 'text', 'sql': 'database', 'log': 'text',
    'json': 'data', 'xml': 'data', 'tsv': 'text', 'ldif': 'data',
    # archives
    'zip': 'archive', 'rar': 'archive', '7z': 'archive', 'tar': 'archive',
    'gz': 'archive', 'bz2': 'archive', 'xz': 'archive',
    # documents
    'pdf': 'document', 'doc': 'document', 'docx': 'document',
    'xls': 'spreadsheet', 'xlsx': 'spreadsheet', 'ppt': 'document',
    'pptx': 'document', 'rtf': 'document',
    # executables / scripts - metadata only, NEVER downloaded or executed
    'exe': 'executable', 'dll': 'executable', 'msi': 'executable',
    'bat': 'script', 'ps1': 'script', 'sh': 'script', 'py': 'script',
    'js': 'script', 'vbs': 'script', 'jar': 'executable', 'apk': 'executable',
    'bin': 'executable', 'elf': 'executable',
}

# Types that must never be fetched, previewed, or offered as a download.
UNSAFE_TYPES = {'executable', 'script'}

# Real, in-post evidence images (user-attached screenshots), kept SEPARATE from
# downloadable file attachments above - an image is displayed, a file is not.
IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'}

# Site-chrome links that appear in the footer/header of EVERY forum page and are
# not thread attachments - most notably the forum's own warrant canary, which
# was being reported as a `canary.txt` attachment on every single thread.
_CHROME_FILENAMES = {'canary.txt'}
_CHROME_LABELS = {'canary', 'warrant canary'}

_ATTACH_ANCHOR_RE = re.compile(
    r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL)
_TAG_RE = re.compile(r'<[^>]+>')
_SIZE_RE = re.compile(r'\(?\s*([\d.,]+)\s*(KB|MB|GB|B)\b\s*\)?', re.IGNORECASE)


def _ext_of(path):
    name = os.path.basename(urlparse(path).path)
    name = unquote(name)
    if '.' not in name:
        return None, name
    ext = name.rsplit('.', 1)[-1].lower()
    return ext, name


def extract_attachments(html, base_url):
    """
    Return attachment metadata found in a thread page.

    Metadata ONLY - filename, extension, type, size (when the forum prints
    it), source and attachment URL. Nothing is downloaded; executables and
    scripts are additionally flagged unsafe so no part of the UI offers them
    as a preview or download.
    """
    if not html:
        return []
    out = []
    seen = set()
    for m in _ATTACH_ANCHOR_RE.finditer(html):
        href, inner = m.group(1), m.group(2)
        if href.startswith(('#', 'mailto:', 'javascript:')):
            continue
        url = urljoin(base_url, href)
        ext, filename = _ext_of(url)
        label = re.sub(r'\s+', ' ', _TAG_RE.sub('', inner)).strip()

        # Drop site-chrome links (the forum's own warrant canary, etc.) - they
        # are not thread attachments and must never be shown as one.
        if filename.lower() in _CHROME_FILENAMES or label.lower() in _CHROME_LABELS:
            continue

        # The link text often carries the real filename when the href is an
        # opaque /attachments/<id>/ style URL.
        if not ext or ext not in INTERESTING_EXTENSIONS:
            lext, lname = _ext_of(label)
            if lext and lext in INTERESTING_EXTENSIONS:
                ext, filename = lext, lname
        if not ext or ext not in INTERESTING_EXTENSIONS:
            continue

        key = (filename.lower(), url)
        if key in seen:
            continue
        seen.add(key)

        ftype = INTERESTING_EXTENSIONS[ext]
        size = None
        tail = html[m.end():m.end() + 120]
        sm = _SIZE_RE.search(label) or _SIZE_RE.search(tail)
        if sm:
            size = f'{sm.group(1)} {sm.group(2).upper()}'

        out.append({
            'filename': filename[:250],
            'extension': ext,
            'file_type': ftype,
            'size': size,
            'attachment_url': url,
            'source_url': base_url,
            'unsafe': ftype in UNSAFE_TYPES,
            # No hash: obtaining one would require downloading the file, which
            # is explicitly out of scope for executables/malware.
            'hash': None,
            'preview_available': ftype in ('text', 'data') and not (ftype in UNSAFE_TYPES),
        })
    return out


_IMG_SRC_RE = re.compile(r'<img[^>]+src=["\']([^"\']+)["\']', re.IGNORECASE)
# Theme/smilie/avatar/rank/button images are page chrome, not evidence.
_CHROME_IMG_HINTS = ('/images/', '/smilies/', '/smilie', '/avatar', 'avatars/',
                     'blank.gif', 'spacer', 'logo', 'reputation', '/star',
                     'buddy', '/styles/', '/icons/', '/icon_', 'newpost',
                     'button', 'rank', 'emoji', 'sprite', 'flags/')


def extract_images(html, base_url, cap=12):
    """Real, in-post evidence images ONLY - the screenshots a user attached to a
    thread - never the forum's own theme/smilie/avatar chrome.

    Metadata level, consistent with the rest of this module: the image URL is
    recorded so the finding can DISPLAY the source image; nothing is downloaded
    or re-hosted here. A same-host image is kept only when it is a genuine MyBB
    attachment (attachment.php / /attachments/); user-posted inline images are
    normally on an external host and are kept when they carry an image
    extension.
    """
    if not html:
        return []
    host = (urlparse(base_url).hostname or '').lower()
    out, seen = [], set()
    for m in _IMG_SRC_RE.finditer(html):
        src = (m.group(1) or '').strip()
        if not src or src.startswith('data:'):
            continue
        url = urljoin(base_url, src)
        low = url.lower()
        if any(h in low for h in _CHROME_IMG_HINTS):
            continue
        ext, _n = _ext_of(url)
        is_native = 'attachment.php' in low or '/attachments/' in low
        if not is_native and (not ext or ext not in IMAGE_EXTENSIONS):
            continue
        # A same-host, non-attachment image with an image extension is a theme
        # asset, not evidence.
        if (urlparse(url).hostname or '').lower() == host and not is_native:
            continue
        if url in seen:
            continue
        seen.add(url)
        out.append({'url': url, 'native_attachment': is_native})
        if len(out) >= cap:
            break
    return out


# ---------------------------------------------------------------------------
# Canonical document identity
# ---------------------------------------------------------------------------

def canonical_doc_id(forum_id, thread_id=None, post_id=None, url=None, content=None):
    """
    Stable identity for a forum document.

    Preference order, per the task's "prefer a canonical source identifier":
      1. forum + thread id (+ post id)  - stable across re-captures/edits
      2. forum + normalised URL         - stable when no numeric id exists
      3. forum + content hash           - last resort only

    Never falls back to title/author/timestamp, which are the fields most
    likely to collide between genuinely different posts.
    """
    if thread_id:
        base = f'{forum_id}|t:{thread_id}'
        if post_id:
            base = f'{base}|p:{post_id}'
        return sha256(base.encode()).hexdigest()
    if url:
        norm = normalise_url(url)
        return sha256(f'{forum_id}|u:{norm}'.encode()).hexdigest()
    if content:
        return sha256(f'{forum_id}|c:{content}'.encode()).hexdigest()
    return None


_TRACKING_PARAMS = {'utm_source', 'utm_medium', 'utm_campaign', 'utm_term',
                    'utm_content', 'fbclid', 'gclid', 's', 'sessionid',
                    '__cf_chl_tk', '__cf_chl_rt_tk', '__cf_chl_f_tk'}


def normalise_url(url):
    """Strip session tokens, tracking params, fragments and trailing slashes.

    The Cloudflare `__cf_chl_*` tokens are stripped explicitly: they change on
    every request, so leaving them in would make the same URL look new forever.
    """
    try:
        p = urlparse(url)
    except Exception:
        return url or ''
    from urllib.parse import parse_qsl, urlencode
    q = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True)
         if k.lower() not in _TRACKING_PARAMS]
    q.sort()
    path = p.path.rstrip('/') or '/'
    netloc = p.netloc.lower()
    return f'{p.scheme}://{netloc}{path}' + (f'?{urlencode(q)}' if q else '')


# ---------------------------------------------------------------------------
# Content extraction
# ---------------------------------------------------------------------------

MAX_STORED_TEXT = int(os.environ.get('FORUM_DOC_MAX_TEXT', 500000))

_AUTHOR_RES = (
    re.compile(r'data-author=["\']([^"\']{1,80})["\']', re.IGNORECASE),
    re.compile(r'class=["\'][^"\']*username[^"\']*["\'][^>]*>([^<]{1,80})<', re.IGNORECASE),
    re.compile(r'<span[^>]+itemprop=["\']author["\'][^>]*>([^<]{1,80})<', re.IGNORECASE),
)
_TIME_RES = (
    re.compile(r'<time[^>]+datetime=["\']([^"\']+)["\']', re.IGNORECASE),
    re.compile(r'data-time=["\'](\d{9,13})["\']', re.IGNORECASE),
)
# MyBB (and most classic forums) print the post date as plain text, e.g.
# "06-23-2021, 07:14 PM" (CryptBB, MM-DD-YYYY) or "17-11-24, 09:54 PM"
# (darkforums, DD-MM-YY). The FIRST such absolute date on a thread page is the
# opening post's publish date - "Today/Yesterday, HH:MM" (relative) has no date
# part and is skipped, so the visit-time header line never wins.
_FORUM_DATE_RE = re.compile(
    r'\b(\d{1,2})-(\d{1,2})-(\d{2,4}),?\s+(\d{1,2}):(\d{2})\s*(AM|PM)\b', re.IGNORECASE)


def parse_forum_timestamp(raw, prefer='mdy'):
    """Parse a forum date string ('06-23-2021, 07:14 PM') to a UTC epoch (int),
    or None. `prefer` ('mdy' or 'dmy') disambiguates when both leading numbers
    are <=12; a number >12 is unambiguously the day and overrides `prefer`."""
    if not raw:
        return None
    m = _FORUM_DATE_RE.search(raw)
    if not m:
        return None
    a, b, y, hh, mm, ap = m.groups()
    a, b, y, hh, mm = int(a), int(b), int(y), int(hh), int(mm)
    if a > 12:            # first field must be the day
        day, mon = a, b
    elif b > 12:          # second field must be the day
        mon, day = a, b
    elif prefer == 'dmy':
        day, mon = a, b
    else:
        mon, day = a, b
    if y < 100:
        y += 2000
    if not (1 <= mon <= 12 and 1 <= day <= 31):
        return None
    hh = hh % 12 + (12 if ap.upper() == 'PM' else 0)
    try:
        import datetime as _dt
        return int(_dt.datetime(y, mon, day, hh, mm, tzinfo=_dt.timezone.utc).timestamp())
    except Exception:
        return None
_TITLE_RE = re.compile(r'<title[^>]*>(.*?)</title>', re.IGNORECASE | re.DOTALL)


def parse_document(html, text, url, forum_id, thread_id=None, title=None):
    """Build the full structured document record for one thread/post page."""
    doc = {
        'forum_id': forum_id,
        'thread_url': url,
        'post_url': url,
        'thread_id': thread_id,
        'post_id': None,
        'title': title,
        'author': None,
        'timestamp': None,
        'text': None,
        'text_truncated': False,
        'links': [],
        'domains': [],
        'keywords': [],
        'attachments': [],
        'images': [],
        'indicators': {},
        'credentials_detected': False,
        'collected_at': int(time.time()),
    }

    if not doc['title'] and html:
        m = _TITLE_RE.search(html)
        if m:
            doc['title'] = re.sub(r'\s+', ' ', _TAG_RE.sub('', m.group(1))).strip()[:400]

    if html:
        for rx in _AUTHOR_RES:
            m = rx.search(html)
            if m:
                doc['author'] = m.group(1).strip()[:80]
                break
        for rx in _TIME_RES:
            m = rx.search(html)
            if m:
                doc['timestamp'] = m.group(1).strip()
                break
        doc['attachments'] = extract_attachments(html, url)
        doc['images'] = extract_images(html, url)
        doc['links'] = _extract_links(html, url)

    if text:
        # Indicators are derived from the ORIGINAL text so the counts are
        # accurate, then the text is redacted before it is stored anywhere.
        doc['indicators'] = _extract_indicators(text)
        redacted, secret_counts = redact_secrets(text)
        if secret_counts:
            doc['indicators']['credentials'] = secret_counts
            doc['credentials_detected'] = True
        if len(redacted) > MAX_STORED_TEXT:
            doc['text'] = redacted[:MAX_STORED_TEXT]
            doc['text_truncated'] = True
        else:
            doc['text'] = redacted

    doc['domains'] = _extract_domains(doc['text'] or '', doc['links'])

    # Forum publish date: prefer machine-readable markup (already tried above);
    # otherwise take the opening post's printed date from the text. `timestamp`
    # keeps the source's own string; `published_at` is the parsed UTC epoch used
    # for consistent, timezone-aware display across the tool.
    if not doc.get('timestamp'):
        m = _FORUM_DATE_RE.search(doc.get('text') or '')
        if m:
            doc['timestamp'] = m.group(0).strip()
    prefer = 'dmy' if str(forum_id) == 'darkforums.as' else 'mdy'
    doc['published_at'] = parse_forum_timestamp(doc.get('timestamp') or '', prefer=prefer)
    return doc


_LINK_RE = re.compile(r'<a[^>]+href=["\']([^"\']+)["\']', re.IGNORECASE)


def _extract_links(html, base_url, cap=300):
    out, seen = [], set()
    for m in _LINK_RE.finditer(html or ''):
        href = m.group(1)
        if href.startswith(('#', 'mailto:', 'javascript:')):
            continue
        url = urljoin(base_url, href).split('#')[0]
        if url in seen:
            continue
        seen.add(url)
        out.append(url)
        if len(out) >= cap:
            break
    return out


_DOMAIN_RE = re.compile(
    r'\b((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24})\b', re.IGNORECASE)
_COMMON_NOISE = {'www.w3.org', 'schema.org', 'gstatic.com', 'googleapis.com',
                 'jquery.com', 'bootstrapcdn.com', 'cloudflare.com'}

# A filename like `dump-1001.sql` matches the domain shape exactly, so the TLD
# has to be validated against real suffixes rather than "2-24 letters" - other-
# wise every attachment name in a leak post is reported as a discovered domain.
_FILE_SUFFIXES = {
    'sql', 'txt', 'csv', 'log', 'json', 'xml', 'zip', 'rar', 'gz', 'bz2', 'xz',
    'tar', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'exe', 'dll',
    'msi', 'bat', 'ps1', 'sh', 'py', 'js', 'vbs', 'jar', 'apk', 'bin', 'elf',
    'png', 'jpg', 'jpeg', 'gif', 'svg', 'ico', 'css', 'html', 'htm', 'php',
    'asp', 'aspx', 'jsp', 'md', 'yml', 'yaml', 'ini', 'conf', 'bak', 'tmp',
    'db', 'sqlite', 'mdb', 'rtf', 'ttf', 'woff', 'woff2', 'mp4', 'mp3', 'avi',
}


def _extract_domains(text, links, cap=200):
    found = set()
    for m in _DOMAIN_RE.finditer(text or ''):
        d = m.group(1).lower()
        if d in _COMMON_NOISE:
            continue
        if d.rsplit('.', 1)[-1] in _FILE_SUFFIXES:
            continue
        found.add(d)
    for l in links or []:
        try:
            h = urlparse(l).netloc.split(':')[0].lower()
            if h and h not in _COMMON_NOISE:
                found.add(h)
        except Exception:
            continue
    return sorted(found)[:cap]


# ---------------------------------------------------------------------------
# Secret redaction
#
# Forum leak posts routinely embed usable credentials inline (user:pass combo
# lines, API tokens, private keys). Storing those verbatim would turn the
# intelligence corpus into a copy of the stolen data. Redaction happens BEFORE
# storage, so the raw secret is never written to Kvrocks or the search index -
# not merely hidden in the template.
#
# What is preserved is the intelligence value: that credentials are present,
# what kind, and how many.
# ---------------------------------------------------------------------------
_PRIVATE_KEY_RE = re.compile(
    r'-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----',
    re.DOTALL | re.IGNORECASE)
# user:pass / email:pass combo lines - the dominant credential-dump format.
_COMBO_RE = re.compile(
    r'^[ \t]*([\w.+-]{2,64}@[\w-]+\.[\w.-]{2,24}|[\w.\-]{3,32})[:|]([^\s:|]{4,64})[ \t]*$',
    re.MULTILINE)
_TOKEN_RE = re.compile(
    r'\b((?:ghp|gho|ghs|github_pat|xox[baprs]|sk-[A-Za-z0-9]{2,}|AKIA|ASIA|AIza)[A-Za-z0-9_\-]{10,})\b')
_PASSWORD_FIELD_RE = re.compile(
    r'((?:pass(?:word|wd)?|pwd|secret|api[_-]?key|token|auth)\s*[=:]\s*)(\S{3,120})',
    re.IGNORECASE)
# Payment-card numbers: a 13-19 digit run (optionally space/hyphen grouped).
# A Luhn check gates it so long non-card digit strings (order ids, phone runs)
# are not mistaken for cards. The VALUE is never kept - only redacted + counted.
_CARD_RE = re.compile(r'\b(?:\d[ -]?){13,19}\b')


def _luhn_ok(digits):
    total, alt = 0, False
    for ch in reversed(digits):
        d = ord(ch) - 48
        if alt:
            d *= 2
            if d > 9:
                d -= 9
        total += d
        alt = not alt
    return total % 10 == 0


def _redact_cards(text):
    """Replace Luhn-valid card numbers with a marker; return (text, count).
    The card number itself is discarded here and never stored."""
    count = 0

    def repl(m):
        nonlocal count
        digits = ''.join(c for c in m.group(0) if c.isdigit())
        if 13 <= len(digits) <= 19 and _luhn_ok(digits):
            count += 1
            return '[REDACTED CARD]'
        return m.group(0)

    return _CARD_RE.sub(repl, text), count


def redact_secrets(text):
    """Return (redacted_text, {category: count}).

    Replaces directly-usable secrets with a marker while keeping the
    surrounding context readable for analysis.
    """
    if not text:
        return text, {}
    counts = {}

    def _bump(name, n=1):
        if n:
            counts[name] = counts.get(name, 0) + n

    def _sub(rx, repl, name, s):
        found = len(rx.findall(s))
        if found:
            _bump(name, found)
            s = rx.sub(repl, s)
        return s

    text = _sub(_PRIVATE_KEY_RE, '[REDACTED PRIVATE KEY]', 'private_keys', text)
    # Field form (`api_key: sk-...`) runs BEFORE the bare-token pattern so a
    # token that is also a field value is replaced once, not twice - otherwise
    # the inner substitution leaves a mangled '[REDACTED] TOKEN]' fragment.
    text = _sub(_PASSWORD_FIELD_RE, r'\1[REDACTED]', 'secret_fields', text)
    text = _sub(_TOKEN_RE, '[REDACTED TOKEN]', 'tokens', text)

    text, n_cards = _redact_cards(text)
    if n_cards:
        _bump('payment_cards', n_cards)

    n_combo = len(_COMBO_RE.findall(text))
    if n_combo:
        _bump('credential_pairs', n_combo)
        text = _COMBO_RE.sub(lambda m: f'{m.group(1)}:[REDACTED]', text)

    return text, counts


# Category counts only - never the secret values themselves.
_INDICATOR_RES = {
    'emails': re.compile(r'\b[\w.+-]+@[\w-]+\.[\w.-]{2,}\b'),
    'ipv4': re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b'),
    'btc': re.compile(r'\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b'),
    'onion': re.compile(r'\b[a-z2-7]{16,56}\.onion\b', re.IGNORECASE),
    'hashes': re.compile(r'\b[a-f0-9]{32,64}\b', re.IGNORECASE),
}


def _extract_indicators(text):
    out = {}
    for name, rx in _INDICATOR_RES.items():
        n = len(set(rx.findall(text or '')))
        if n:
            out[name] = n
    return out
