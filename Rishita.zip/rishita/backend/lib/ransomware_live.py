#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Ransomware.live Victim Check
===================

Ransomware.live (https://ransomware.live) publishes a structured JSON API
tracking which companies ransomware gangs have named as victims on their
leak sites. This is a genuinely different signal from the forum-credential
findings in intel_jobs.py - not "a leaked password", but "this domain was
itself named as a ransomware victim, by which gang, when".

Scraping the site's own search page is unreliable - its victim list is
populated client-side via JS after page load, so a plain page capture just
shows an empty "No victims found" shell. The API is the real, complete data
source; this module calls it directly (never guessing/hallucinating a
result - a network failure or empty match list returns an empty list, not a
fabricated finding) rather than trying to scrape rendered HTML for it.

Two tiers, both reached via the same search_victims() call:
  - No API key configured: the free v2 API (api.ransomware.live), which
    rate-limits to 1 request/minute per endpoint (confirmed directly from
    its own 429 body: {"message": "1 per 1 minute"}) - self-throttled below
    so a job waits out the real window instead of guessing at short retries.
  - API key configured (see get_api_key/set_api_key - stored in Kvrocks,
    managed from the System page, never hardcoded here): the PRO API
    (api-pro.ransomware.live), 500,000 calls/month, no per-minute wait.
    Free at https://www.ransomware.live/my (passwordless, magic-link
    signup - there's no separate "create account" page, entering an email
    there both creates and logs into the account).

Both tiers' responses are normalized to the same record shape before
returning, so callers (intel_jobs.py) never need to know which tier
answered: {'domain', 'victim', 'group', 'attackdate', 'claim_url',
'screenshot'}.

Routed through Tor (same SOCKS5 port Lacus itself uses) rather than a
direct clearnet request, consistent with this platform never touching a
target/third-party service from its own real IP.
"""

import json
import os
import sys
import time

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers

FREE_API_BASE = 'https://api.ransomware.live/v2'
PRO_API_BASE = 'https://api-pro.ransomware.live'
TOR_PROXY = 'socks5h://127.0.0.1:9050'
REQUEST_TIMEOUT = 25

# Free tier only - the PRO tier's 500k/month quota needs no self-throttling.
_LAST_CALL_KEY = 'ransomware_live:last_call'
RATE_LIMIT_WINDOW = 65  # a few seconds of safety margin over the API's exact 60s
MAX_WAIT = 70

CONFIG_KEY = 'ransomware_live:config'

# Re-searching the same domain shortly after (a common pattern - re-running
# a search to see the current write-up, or a client asking about the same
# domain twice) shouldn't spend another API call for an answer that hasn't
# had time to change. Only successful checks are cached - a failed/
# rate-limited check must never get "stuck" as a cached failure, so the
# very next search for that domain gets a real, fresh attempt instead of
# replaying "couldn't check" for a full day.
CACHE_TTL = 24 * 60 * 60

r_crawler = crawlers.r_crawler


def _cache_key(query, query_type):
    return f'ransomware_live:cache:{query_type}:{(query or "").strip().lower()}'


def get_api_key():
    return r_crawler.hget(CONFIG_KEY, 'api_key') or ''


def set_api_key(api_key):
    r_crawler.hset(CONFIG_KEY, 'api_key', (api_key or '').strip())


def _throttle():
    last_call = r_crawler.get(_LAST_CALL_KEY)
    if last_call:
        elapsed = time.time() - float(last_call)
        remaining = RATE_LIMIT_WINDOW - elapsed
        if remaining > 0:
            time.sleep(min(remaining, MAX_WAIT))
    r_crawler.set(_LAST_CALL_KEY, time.time())


def _domain_matches(record_domain, target_domain):
    record_domain = (record_domain or '').strip().lower()
    target_domain = (target_domain or '').strip().lower()
    if not record_domain or not target_domain:
        return False
    return record_domain == target_domain or record_domain.endswith('.' + target_domain)


# Fields both tiers expose beyond the six the UI originally kept. These were
# being silently discarded at normalisation: the API returns the victim's
# sector, country, a group-written description of what was stolen, the
# discovery timestamp, press attribution, and - most valuable of all - an
# `infostealer` block with real per-family compromise counts (confirmed live on
# versa-networks.com: 128 users, 4 employees, 9 stealer families). None of that
# reached the report, so the UI could only ever show victim/domain/group/date.
def _common_extra(r):
    return {
        'activity': r.get('activity'),          # victim's sector
        'country': r.get('country'),
        'description': r.get('description'),    # group's own claim text
        'discovered': r.get('discovered'),      # when ransomware.live saw it
        'data_size': r.get('data_size'),
        'ransom': r.get('ransom'),
        'infostealer': r.get('infostealer') if isinstance(r.get('infostealer'), dict) else None,
        'press': r.get('press') if isinstance(r.get('press'), dict) else None,
        'reference_url': r.get('url'),          # ransomware.live's own record page
    }


def _normalize_pro(r):
    out = {
        'domain': r.get('website'),
        'victim': r.get('post_title'),
        'group': r.get('group_name'),
        'attackdate': r.get('published'),
        'claim_url': r.get('post_url') or r.get('permalink'),
        'screenshot': r.get('screenshot'),
    }
    out.update(_common_extra(r))
    return out


def _normalize_free(r):
    out = {
        'domain': r.get('domain'),
        'victim': r.get('victim'),
        'group': r.get('group'),
        'attackdate': r.get('attackdate'),
        'claim_url': r.get('claim_url') or r.get('url'),
        'screenshot': r.get('screenshot'),
    }
    out.update(_common_extra(r))
    return out


def _fetch_pro(query, api_key):
    """Returns (records_or_None, ok). PRO tier: no self-throttling needed
    (500k/month quota) - a 429 here means the account's own monthly quota
    is actually exhausted, which is surfaced as not-ok rather than retried."""
    try:
        resp = requests.get(
            f'{PRO_API_BASE}/victims/search',
            params={'q': query},
            headers={'X-API-KEY': api_key},
            proxies={'http': TOR_PROXY, 'https': TOR_PROXY},
            timeout=REQUEST_TIMEOUT,
        )
    except Exception:
        return None, False
    if resp.status_code != 200:
        return None, False
    try:
        data = resp.json()
    except Exception:
        return None, False
    records = data.get('victims') if isinstance(data, dict) else None
    if not isinstance(records, list):
        return None, False
    return [_normalize_pro(r) for r in records], True


def _fetch_free(query):
    """Returns (records_or_None, ok). Free tier: self-throttled to the
    API's real 1/min limit (see RATE_LIMIT_WINDOW)."""
    for attempt in range(2):
        _throttle()
        try:
            resp = requests.get(
                f'{FREE_API_BASE}/searchvictims/{query}',
                proxies={'http': TOR_PROXY, 'https': TOR_PROXY},
                timeout=REQUEST_TIMEOUT,
            )
        except Exception:
            return None, False
        if resp.status_code == 429:
            continue  # one full extra window's wait via _throttle(), then give up
        if resp.status_code != 200:
            return None, False
        try:
            records = resp.json()
        except Exception:
            return None, False
        if not isinstance(records, list):
            return None, False
        return [_normalize_free(r) for r in records], True
    return None, False


def search_victims(query, query_type='domain'):
    """
    Returns (records, ok). `records` is every ransomware.live victim record
    relevant to `query` - every match, not just the first one or two (a
    company can be, and often is, named by more than one gang, or claimed
    more than once). `ok` is False when the check itself could not be
    completed (network error, quota exhausted, or still rate-limited after
    retries) - the caller must surface that as "not checked", not silently
    treat it as "checked, nothing found".

    For a domain search, only records whose OWN domain field is the
    queried domain (or a subdomain of it) are returned - the API's search
    is free-text and also matches a domain merely mentioned in another
    victim's leak description (e.g. "notable clients included Netflix"),
    which is not the same claim as "this domain was itself attacked".
    For a keyword search there's no domain field to check, so every
    text-relevant result the API itself returns is kept.

    Results are cached for CACHE_TTL - re-searching the same query within
    that window reuses the cached answer instead of spending another call.
    """
    cache_key = _cache_key(query, query_type)
    cached = r_crawler.get(cache_key)
    if cached is not None:
        try:
            return json.loads(cached), True
        except Exception:
            pass  # corrupt cache entry - fall through to a real fetch

    api_key = get_api_key()
    records, ok = _fetch_pro(query, api_key) if api_key else _fetch_free(query)
    if not ok:
        return [], False
    if query_type != 'keyword':
        records = [r for r in records if _domain_matches(r.get('domain'), query)]
    r_crawler.setex(cache_key, CACHE_TTL, json.dumps(records))
    return records, True
