#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Domain Intelligence PDF Export
===================

Renders a single finding as a standalone, downloadable PDF advisory - the
same fields shown in the finding's advisory table in the UI (search_result
.html), so the PDF is never a second source of truth, just a portable copy
of what's already displayed.

Uses reportlab (pure Python, no external binary/service dependency like
wkhtmltopdf or a headless browser would need). Text is rendered with a
bundled-with-the-OS DejaVu Sans TTF rather than reportlab's built-in
Helvetica: real finding text on this forum includes Cyrillic homoglyph
evasion characters (see intel_extraction.normalize_homoglyphs) and other
non-Latin-1 content, which Helvetica's WinAnsi encoding cannot render.
"""

import io
import os
from datetime import datetime, timezone
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, HRFlowable,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

_FONT_REGULAR = 'Helvetica'
_FONT_BOLD = 'Helvetica-Bold'
_DEJAVU_REGULAR = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
_DEJAVU_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
try:
    if os.path.isfile(_DEJAVU_REGULAR) and os.path.isfile(_DEJAVU_BOLD):
        pdfmetrics.registerFont(TTFont('DejaVuSans', _DEJAVU_REGULAR))
        pdfmetrics.registerFont(TTFont('DejaVuSans-Bold', _DEJAVU_BOLD))
        _FONT_REGULAR = 'DejaVuSans'
        _FONT_BOLD = 'DejaVuSans-Bold'
except Exception:
    pass  # falls back to Helvetica - fine for pure-ASCII findings, other
    # scripts render as blank glyphs rather than a crash

_RISK_COLORS = {
    'LOW': colors.HexColor('#22c55e'),
    'MEDIUM': colors.HexColor('#d97706'),
    'HIGH': colors.HexColor('#ef4444'),
    'CRITICAL': colors.HexColor('#b91c1c'),
}

def _credential_lines(f):
    cred = f.get('credential') or {}
    lines = []
    if cred.get('email'):
        lines.append(f'Email: {cred["email"]}')
    if cred.get('username'):
        lines.append(f'Username: {cred["username"]}')
    if cred.get('password'):
        lines.append(f'Password: {cred["password"]}')
    if cred.get('phone'):
        lines.append(f'Phone: {cred["phone"]}')
    return '\n'.join(lines)


# Only rows with an actual value get rendered (see the row-building loop
# below) - an empty getter result means the field is omitted entirely, not
# printed as "Not applicable"/"Unknown". Credential/Victim are mutually
# exclusive depending on which kind of finding this is (a forum-credential
# leak vs. a ransomware.live named-victim match).
def _fmt_epoch(value):
    """A unix epoch (seconds) -> 'YYYY-MM-DD HH:MM UTC'; anything else passes
    through unchanged (or '' when empty). Keeps PDF dates in one format."""
    if value in (None, '', 0, '0'):
        return ''
    try:
        n = float(value)
        if n > 1e12:
            n = n / 1000.0
        return datetime.fromtimestamp(n, timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    except (TypeError, ValueError):
        return str(value)


_ADVISORY_ROWS = [
    ('Credential', _credential_lines),
    ('Ransomware Victim', lambda f: f.get('victim') or ''),
    ('Domain', lambda f: f.get('domain') or ''),
    # Forum-document fields (empty on credential/ransomware findings, so they
    # simply don't render there).
    ('Thread', lambda f: f.get('title') or ''),
    ('Posted on Forum', lambda f: _fmt_epoch(f.get('published_at')) or f.get('timestamp') or ''),
    ('Matched Query', lambda f: f.get('matched_query') or ''),
    ('Match Reason', lambda f: f.get('match_reason') or ''),
    ('Source', lambda f: f.get('source_url') or ''),
    ('Source Forum', lambda f: f.get('source_forum') or ''),
    ('Attacker', lambda f: f.get('attacker') or ''),
    ('Campaign', lambda f: f.get('campaign') or ''),
    ('Attack Date', lambda f: _fmt_epoch(f.get('attack_date')) or ''),
    ('Collected', lambda f: _fmt_epoch(f.get('first_seen')) or ''),
    ('Domains Referenced', lambda f: ', '.join(f.get('domains') or [])),
    ('Extract', lambda f: f.get('text_excerpt') or ''),
]


def _fetch_remote_screenshot(url):
    """Ransomware.live findings have no local screenshot file - their
    evidence image is hosted on ransomware.live itself. Fetched through Tor
    like every other third-party request this platform makes. Returns None
    (never raises) on any failure - the PDF still generates, just without
    the image embedded."""
    try:
        import io
        import requests
        resp = requests.get(url, proxies={'http': 'socks5h://127.0.0.1:9050', 'https': 'socks5h://127.0.0.1:9050'}, timeout=25)
        if resp.status_code == 200 and resp.content:
            return io.BytesIO(resp.content)
    except Exception:
        pass
    return None


def generate_finding_pdf(job, finding, screenshot_path=None, screenshot_url=None):
    """
    Returns PDF bytes for one finding. `job` is an intel_jobs job dict
    (for the query/domain/forum header); `finding` is one entry from a
    job's report['findings'] list; `screenshot_path` is an optional local
    filepath to the finding's evidence screenshot (verified to exist by
    the caller - this module doesn't touch the DB/correlation layer).
    `screenshot_url` is the externally-hosted alternative used by
    ransomware.live findings, which have no local file at all.
    """
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=16 * mm, rightMargin=16 * mm, topMargin=12 * mm, bottomMargin=12 * mm,
        title=f"Threat Intelligence Report - {job.get('domain', '')}",
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('IntelTitle', parent=styles['Title'], fontName=_FONT_BOLD,
                                  fontSize=16, leading=19, alignment=TA_LEFT, spaceAfter=2)
    meta_style = ParagraphStyle('IntelMeta', parent=styles['Normal'], fontName=_FONT_REGULAR,
                                 fontSize=8.5, textColor=colors.HexColor('#555555'), spaceAfter=6)
    label_style = ParagraphStyle('IntelLabel', parent=styles['Normal'], fontName=_FONT_BOLD,
                                  fontSize=8.5, textColor=colors.HexColor('#333333'), leading=11.5)
    value_style = ParagraphStyle('IntelValue', parent=styles['Normal'], fontName=_FONT_REGULAR,
                                  fontSize=8.5, textColor=colors.HexColor('#111111'), leading=11.5)
    section_style = ParagraphStyle('IntelSection', parent=styles['Normal'], fontName=_FONT_BOLD,
                                    fontSize=10.5, textColor=colors.HexColor('#111111'), spaceBefore=8, spaceAfter=4)
    footer_style = ParagraphStyle('IntelFooter', parent=styles['Normal'], fontName=_FONT_REGULAR,
                                   fontSize=7, textColor=colors.HexColor('#888888'))

    query_type = job.get('query_type') or 'domain'
    query_label = 'Keyword Search' if query_type == 'keyword' else 'Domain Search'

    story = []
    story.append(Paragraph('Threat Intelligence Report', title_style))
    story.append(Paragraph(
        f'{escape(str(job.get("domain", "")))} &middot; {escape(query_label)} &middot; '
        f'Source: {escape(str(finding.get("source_forum") or ""))}',
        meta_style,
    ))
    story.append(HRFlowable(width='100%', thickness=0.75, color=colors.HexColor('#dddddd')))
    story.append(Spacer(1, 5))

    risk_level = (finding.get('risk_level') or 'MEDIUM').upper()
    risk_color = _RISK_COLORS.get(risk_level, colors.HexColor('#666666'))
    risk_table = Table(
        [[Paragraph(f'{escape(risk_level)} RISK',
                    ParagraphStyle('RiskBadge', fontName=_FONT_BOLD, fontSize=10, textColor=colors.white))]],
        colWidths=[None],
    )
    risk_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), risk_color),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(risk_table)
    story.append(Spacer(1, 8))

    # Capped well below what the page can technically hold - a full-size
    # evidence screenshot plus an 11-row advisory table (some rows, like
    # Description, routinely wrap to 5+ lines) comfortably clears one A4
    # page at this size; a taller cap was confirmed to push the table onto
    # a second, mostly-empty page.
    image_source = screenshot_path if (screenshot_path and os.path.isfile(screenshot_path)) else None
    if not image_source and screenshot_url:
        image_source = _fetch_remote_screenshot(screenshot_url)
    if image_source:
        try:
            img = Image(image_source)
            max_w = doc.width
            max_h = 55 * mm
            scale = min(max_w / img.imageWidth, max_h / img.imageHeight, 1.0)
            img.drawWidth = img.imageWidth * scale
            img.drawHeight = img.imageHeight * scale
            story.append(Paragraph('Screenshot Evidence', section_style))
            story.append(img)
            story.append(Spacer(1, 4))
        except Exception:
            pass  # a broken/unreadable image file shouldn't block the rest of the report

    story.append(Paragraph('Advisory Details', section_style))
    rows = []
    for label, getter in _ADVISORY_ROWS:
        try:
            value = getter(finding)
        except Exception:
            value = ''
        if not value:
            continue
        rows.append([
            Paragraph(escape(label), label_style),
            Paragraph(escape(str(value)).replace('\n', '<br/>'), value_style),
        ])
    table = Table(rows, colWidths=[38 * mm, doc.width - 38 * mm])
    table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e0e0e0')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f7f7f7')),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
    ]))
    story.append(table)

    story.append(Spacer(1, 8))
    generated = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    story.append(HRFlowable(width='100%', thickness=0.5, color=colors.HexColor('#eeeeee')))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        f'Generated by Anorphix on {generated} &middot; '
        f'Job {escape(job.get("id", ""))} &middot; For authorized internal use only.',
        footer_style,
    ))

    doc.build(story)
    return buf.getvalue()
