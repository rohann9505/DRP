#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Asset Data
===================

Per-asset (a target's root domain, plus every discovered subdomain) storage
for Asset Intelligence. Each asset is backed by two things:

  - a real lib.objects.Domains.Domain(fqdn) object - the same object type
    Dark Web crawling already uses, reused here for identity/first_seen/
    last_seen/ports (Domain.add_ports() has existed unused since before this
    module was built - this is what finally populates it), so a domain
    Asset Intelligence discovers naturally merges with anything the Dark Web
    crawler independently observed about it.
  - a flat Kvrocks hash (crawlers.r_crawler, 'asset:meta:{target_id}:{fqdn}')
    for the ASM-specific fields Domain has no concept of: DNS records,
    WHOIS, technologies, vulnerabilities, security findings, directory-enum
    results, and live/disconnected status history.

Findings are stored per (target_id, fqdn) rather than just per fqdn because
the same subdomain could in principle be discovered under two different
scanned targets (e.g. a shared CDN host) - keeping results scoped to the
target that discovered them avoids one target's scan silently overwriting
another's view of a shared asset.
"""

import json
import os
import sys
import time
import uuid

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers
from lib.objects import Domains

r_crawler = crawlers.r_crawler

STATUS_HISTORY_MAX = 20
ASSET_ALERTS_ZSET = 'asset_alerts:zset'
MAX_ALERTS = 2000

_JSON_FIELDS = ('resolved_ips', 'dns_records', 'dns_ttls', 'whois', 'technologies',
                'vulnerabilities', 'security_findings', 'directories', 'status_history',
                'tls', 'ports', 'waf', 'security_headers')

# Target-wide (not per-asset) results: DNSSEC, email authentication, crawl
# rules, security.txt, page metadata, redirect chain, archive history and
# the merged severity-ranked findings list. These are properties of the
# registered domain rather than of any one discovered host, so they live in
# their own record instead of being duplicated onto - or hidden inside - the
# root domain's asset row.
_TARGET_INTEL_JSON_FIELDS = ('dnssec', 'mail_config', 'crawl_rules', 'security_txt',
                             'metadata', 'redirects', 'archive', 'findings', 'webcheck')


def _asset_key(target_id, fqdn):
    return f'asset:meta:{target_id}:{fqdn}'


def _assets_index_key(target_id):
    return f'assettarget:assets:{target_id}'


def _today_int():
    return int(time.strftime('%Y%m%d', time.gmtime()))


def _target_intel_key(target_id):
    return f'assettarget:intel:{target_id}'


def set_target_intel(target_id, **fields):
    """Stores the target-wide check results (see _TARGET_INTEL_JSON_FIELDS)."""
    to_store = {}
    for k, v in fields.items():
        to_store[k] = json.dumps(v) if k in _TARGET_INTEL_JSON_FIELDS else v
    if to_store:
        to_store['updated_at'] = int(time.time())
        r_crawler.hset(_target_intel_key(target_id), mapping=to_store)


def get_target_intel(target_id):
    data = r_crawler.hgetall(_target_intel_key(target_id))
    if not data:
        return {}
    out = dict(data)
    for field in _TARGET_INTEL_JSON_FIELDS:
        if field in out:
            try:
                out[field] = json.loads(out[field])
            except (ValueError, TypeError):
                out[field] = None
    return out


def add_domain_port(fqdn, port):
    """Records an open port on the shared Domain object. Domains.py has had
    add_ports() since long before this module existed with nothing ever
    calling it; port scanning is the thing it was waiting for."""
    try:
        # str, not int: get_ports() reads them back off Kvrocks as strings,
        # so adding an int would let 443 and '443' coexist in the same set.
        Domains.Domain(fqdn).add_ports(str(int(port)))
    except Exception:
        # A port record is never worth failing a scan over.
        pass


def upsert_asset(target_id, fqdn, **fields):
    """Merge `fields` into the asset's record, creating it if new. Any
    field named in _JSON_FIELDS is JSON-encoded before storage and JSON-
    decoded back out by get_asset(). Also touches the backing Domain object
    (update_daterange) so first_seen/last_seen stay accurate."""
    fqdn = (fqdn or '').strip().lower()
    if not fqdn:
        return

    key = _asset_key(target_id, fqdn)
    is_new = not r_crawler.exists(key)

    domain = Domains.Domain(fqdn)
    domain.update_daterange(_today_int())

    to_store = {}
    if is_new:
        to_store['fqdn'] = fqdn
        to_store['target_id'] = target_id
        to_store['first_discovered'] = int(time.time())
        to_store.setdefault('current_status', 'discovered')
        to_store.setdefault('status_history', json.dumps([]))
    for k, v in fields.items():
        if k in _JSON_FIELDS:
            to_store[k] = json.dumps(v)
        else:
            to_store[k] = v
    to_store['last_checked'] = int(time.time())

    r_crawler.hset(key, mapping=to_store)
    r_crawler.sadd(_assets_index_key(target_id), fqdn)


def get_asset(target_id, fqdn):
    data = r_crawler.hgetall(_asset_key(target_id, fqdn))
    if not data:
        return None
    return _asset_to_dict(data)


def _asset_to_dict(data):
    d = dict(data)
    for field in _JSON_FIELDS:
        if d.get(field):
            try:
                d[field] = json.loads(d[field])
            except (TypeError, ValueError):
                d[field] = [] if field != 'whois' and field != 'dns_records' else {}
        else:
            d[field] = [] if field not in ('whois', 'dns_records') else {}
    for int_field in ('first_discovered', 'last_checked'):
        d[int_field] = int(d[int_field]) if d.get(int_field) not in (None, '') else None
    return d


def list_assets(target_id):
    assets = []
    for fqdn in r_crawler.smembers(_assets_index_key(target_id)):
        asset = get_asset(target_id, fqdn)
        if asset:
            assets.append(asset)
    assets.sort(key=lambda a: a.get('fqdn') or '')
    return assets


def record_status_transition(target_id, fqdn, new_status):
    """Updates current_status and appends to the capped status_history log.
    Returns True if this is a 'back online' event (disconnected -> live) -
    the caller uses that to decide whether to raise an alert."""
    asset = get_asset(target_id, fqdn)
    old_status = (asset or {}).get('current_status')
    if old_status == new_status:
        return False

    history = (asset or {}).get('status_history') or []
    history.append({'status': new_status, 'at': int(time.time())})
    history = history[-STATUS_HISTORY_MAX:]

    upsert_asset(target_id, fqdn, current_status=new_status, status_history=history)
    return old_status == 'disconnected' and new_status == 'live'


def target_summary_counts(target_id):
    assets = list_assets(target_id)
    live = sum(1 for a in assets if a.get('current_status') == 'live')
    disconnected = sum(1 for a in assets if a.get('current_status') == 'disconnected')
    return {'asset_count': len(assets), 'live_count': live, 'disconnected_count': disconnected}


def delete_target_assets(target_id):
    for fqdn in r_crawler.smembers(_assets_index_key(target_id)):
        r_crawler.delete(_asset_key(target_id, fqdn))
    r_crawler.delete(_assets_index_key(target_id))


# ---------------------------------------------------------------------------
# Alerts - same shape/plumbing as watchlist.py's record_alert/list_alerts,
# so alert_dispatch.py's generic channel-delivery machinery (webhook/
# Telegram/SMTP, queue_alert_delivery) can be reused as-is; only
# alert_dispatch.dispatch_one()'s lookup/formatting needs to know about both
# shapes (see that file's _get_alert_by_id).
# ---------------------------------------------------------------------------

def _alert_key(alert_id):
    return f'assetalert:meta:{alert_id}'


def record_alert(target_id, fqdn, alert_type, message, severity='HIGH'):
    """alert_type: 'back_online' | 'critical_vulnerability'."""
    alert_id = str(uuid.uuid4())
    now = int(time.time())
    r_crawler.hset(_alert_key(alert_id), mapping={
        'id': alert_id,
        'target_id': target_id,
        'fqdn': fqdn,
        'alert_type': alert_type,
        'message': message or '',
        'severity': severity,
        'created_at': now,
    })
    r_crawler.zadd(ASSET_ALERTS_ZSET, {alert_id: now})

    try:
        from lib import alert_dispatch
        alert_dispatch.queue_alert_delivery(alert_id)
    except Exception as e:
        print(f'Failed to queue asset alert delivery for {alert_id}: {e}')

    total = r_crawler.zcard(ASSET_ALERTS_ZSET)
    if total > MAX_ALERTS:
        oldest = r_crawler.zrange(ASSET_ALERTS_ZSET, 0, total - MAX_ALERTS - 1)
        if oldest:
            r_crawler.zrem(ASSET_ALERTS_ZSET, *oldest)
            for old_id in oldest:
                r_crawler.delete(_alert_key(old_id))

    return alert_id


def get_alert(alert_id):
    data = r_crawler.hgetall(_alert_key(alert_id))
    if not data:
        return None
    d = dict(data)
    d['created_at'] = int(d['created_at']) if d.get('created_at') else None
    return d


def list_alerts(limit=100):
    alert_ids = r_crawler.zrevrange(ASSET_ALERTS_ZSET, 0, limit - 1)
    alerts = []
    for alert_id in alert_ids:
        alert = get_alert(alert_id)
        if alert:
            alerts.append(alert)
    return alerts
