#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Asset Target Registry
===================

Tracks which target domains Asset Intelligence has scanned or is scheduled
to scan. Unlike forum_registry.py's admin-curated allowlist, there is no
gate here - Asset Intelligence is a "type a domain, get a dashboard"
workflow (Censys-style), so a target record is created automatically the
first time someone scans a domain (see get_or_create_target). Admins can
still pause/resume/delete a target and set its recurring scan_frequency.

Flat Kvrocks hash (crawlers.r_crawler, the same 'Kvrocks_Crawler' namespace
already shared by intel_jobs/forum_registry/watchlist/alert_dispatch - kept
apart purely by key prefix, per that existing convention) rather than a
full AIL object type: a target doesn't need Forum's correlation-graph
machinery, just simple CRUD + the same circuit-breaker shape forum_registry
already proved out for "this thing's infrastructure keeps failing, stop
hammering it".
"""

import os
import sys
import time

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers
from lib import psl_faup

r_crawler = crawlers.r_crawler

VALID_FREQUENCIES = {'manual', 'hourly', 'daily', 'weekly', 'monthly'}
ALL_TARGETS_KEY = 'assettarget:all'


def _target_key(target_id):
    return f'assettarget:meta:{target_id}'


def _normalize_domain(value):
    value = (value or '').strip().lower()
    if not value:
        return None
    if '://' not in value:
        value = f'http://{value}'
    try:
        return psl_faup.get_domain(value)
    except Exception:
        return None


def get_or_create_target(domain_or_url, scan_frequency='manual'):
    """Idempotent on domain - re-submitting the same domain reuses its
    existing target record rather than creating a duplicate."""
    domain = _normalize_domain(domain_or_url)
    if not domain:
        return {'status': 'error', 'reason': 'Could not parse a domain from the supplied value'}, 400

    key = _target_key(domain)
    if not r_crawler.exists(key):
        now = int(time.time())
        r_crawler.hset(key, mapping={
            'id': domain,
            'enabled': 1,
            'scan_frequency': scan_frequency if scan_frequency in VALID_FREQUENCIES else 'manual',
            'created_at': now,
            'last_scan_triggered': '',
            'last_scan_completed': '',
            'last_scan_status': 'never',
            'last_scan_error': '',
            'asset_count': 0,
            'live_count': 0,
            'disconnected_count': 0,
            'consecutive_failures': 0,
            'circuit_state': 'closed',
            'circuit_opened_at': '',
        })
        r_crawler.sadd(ALL_TARGETS_KEY, domain)
    return get_target(domain)


def get_target(target_id):
    data = r_crawler.hgetall(_target_key(target_id))
    if not data:
        return {'status': 'error', 'reason': 'Unknown target'}, 404
    return _target_to_dict(data), 200


def list_targets():
    targets = []
    for target_id in r_crawler.smembers(ALL_TARGETS_KEY):
        data = r_crawler.hgetall(_target_key(target_id))
        if data:
            targets.append(_target_to_dict(data))
    targets.sort(key=lambda t: t.get('id') or '')
    return targets


def _target_to_dict(data):
    d = dict(data)
    for int_field in ('enabled', 'created_at', 'asset_count', 'live_count', 'disconnected_count', 'consecutive_failures'):
        d[int_field] = int(d.get(int_field) or 0)
    d['enabled'] = bool(d['enabled'])
    return d


def set_enabled(target_id, enabled):
    if not r_crawler.exists(_target_key(target_id)):
        return {'status': 'error', 'reason': 'Unknown target'}, 404
    r_crawler.hset(_target_key(target_id), 'enabled', 1 if enabled else 0)
    return get_target(target_id)


def set_scan_frequency(target_id, scan_frequency):
    if scan_frequency not in VALID_FREQUENCIES:
        return {'status': 'error', 'reason': f'Invalid scan_frequency, must be one of {sorted(VALID_FREQUENCIES)}'}, 400
    if not r_crawler.exists(_target_key(target_id)):
        return {'status': 'error', 'reason': 'Unknown target'}, 404
    r_crawler.hset(_target_key(target_id), 'scan_frequency', scan_frequency)
    return get_target(target_id)


def delete_target(target_id):
    if not r_crawler.exists(_target_key(target_id)):
        return {'status': 'error', 'reason': 'Unknown target'}, 404
    r_crawler.delete(_target_key(target_id))
    r_crawler.srem(ALL_TARGETS_KEY, target_id)
    return {'status': 'ok', 'deleted': target_id}, 200


def record_scan_triggered(target_id):
    if not r_crawler.exists(_target_key(target_id)):
        return
    r_crawler.hset(_target_key(target_id), mapping={
        'last_scan_triggered': int(time.time()),
        'last_scan_status': 'running',
    })


def record_scan_result(target_id, success, error=None, asset_count=None, live_count=None, disconnected_count=None):
    key = _target_key(target_id)
    if not r_crawler.exists(key):
        return
    now = int(time.time())
    fields = {'last_scan_completed': now}
    if success:
        fields['last_scan_status'] = 'success'
        fields['last_scan_error'] = ''
    else:
        fields['last_scan_status'] = 'error'
        if error:
            fields['last_scan_error'] = error
    if asset_count is not None:
        fields['asset_count'] = asset_count
    if live_count is not None:
        fields['live_count'] = live_count
    if disconnected_count is not None:
        fields['disconnected_count'] = disconnected_count
    r_crawler.hset(key, mapping=fields)
    _update_circuit_state(target_id, success)


# ---------------------------------------------------------------------------
# Circuit breaker - same shape/thresholds as forum_registry.py's, reused for
# targets whose infrastructure repeatedly fails to resolve/respond, so a
# dead target doesn't get hammered by every recurring scan cycle.
# ---------------------------------------------------------------------------

CIRCUIT_FAILURE_THRESHOLD = 3
CIRCUIT_COOLDOWN_SECONDS = 900


def _update_circuit_state(target_id, success):
    key = _target_key(target_id)
    if success:
        r_crawler.hset(key, mapping={'consecutive_failures': 0, 'circuit_state': 'closed', 'circuit_opened_at': ''})
        return

    failures = int(r_crawler.hget(key, 'consecutive_failures') or 0) + 1
    fields = {'consecutive_failures': failures}
    was_half_open = r_crawler.hget(key, 'circuit_state') == 'half_open'
    if was_half_open or failures >= CIRCUIT_FAILURE_THRESHOLD:
        fields['circuit_state'] = 'open'
        fields['circuit_opened_at'] = int(time.time())
    r_crawler.hset(key, mapping=fields)


def is_circuit_open(target_id):
    key = _target_key(target_id)
    if not r_crawler.exists(key):
        return False
    state = r_crawler.hget(key, 'circuit_state') or 'closed'
    if state != 'open':
        return False
    opened_at = int(r_crawler.hget(key, 'circuit_opened_at') or 0)
    if int(time.time()) - opened_at >= CIRCUIT_COOLDOWN_SECONDS:
        r_crawler.hset(key, 'circuit_state', 'half_open')
        return False
    return True
