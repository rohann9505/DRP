#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Forum ingestion orchestrator
============================

Runs one complete crawl for one forum:

    resolve provider -> walk board pages -> for each new thread:
        fetch -> parse -> canonical dedupe -> store full document
        -> index for search -> run watchlist
    -> persist metrics + incremental cursor -> report termination reason

Storage keys (same Kvrocks connection / prefix convention as the rest):
    forumdoc:id:<forum_id>            SET of canonical doc ids
    forumdoc:full:<forum_id>:<doc_id> HASH, the full structured document
    forumdoc:hash:<forum_id>          SET of content hashes (legacy, kept so
                                      existing counts/readers keep working)

The document is written here SYNCHRONOUSLY. That is deliberate: the previous
pipeline handed the body to the asynchronous 'Importers' queue while counting
the document immediately, and with no Importers module running the count grew
while the content never landed on disk - 280 counted documents against 25
files. Storing the text in Kvrocks alongside the metadata makes the count and
the retrievable corpus the same thing by construction.
"""

import os
import sys
import json
import time
import traceback
from hashlib import sha256

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers
from lib import forum_registry
from lib import forum_crawl
from lib import forum_metrics
from lib import forum_documents
from lib import forum_providers
from lib.forum_providers import base as fp_base
from lib import intel_extraction
from lib import search_engine
from lib import watchlist

MAX_TEXT_INDEXED = 200000


def _r():
    return crawlers.r_crawler


def run_forum_crawl(forum_id, full_resync=False, max_pages=None,
                    max_documents=None, logger=print):
    """
    Execute one complete crawl. Returns the metrics dict.

    `full_resync=True` ignores the incremental cursor and walks the available
    history again (the administrator's FULL CRAWL / RESYNC operation).
    """
    forum, status = forum_registry.get_forum(forum_id)
    if status != 200:
        return {'error': 'unknown forum', 'forum_id': forum_id}
    if not forum.get('enabled'):
        return {'error': 'forum disabled', 'forum_id': forum_id}
    if forum_registry.is_circuit_open(forum_id):
        return {'error': 'circuit breaker open', 'forum_id': forum_id}

    # Overlap guard: required for a 1-minute schedule. If a crawl is already
    # running for this forum the run is recorded as skipped, not started.
    if not forum_metrics.mark_running(forum_id):
        forum_metrics.record_skipped_run(forum_id)
        logger(f'[{forum_id}] skipped: previous crawl still running')
        return {'skipped': True, 'reason': 'previous crawl still running',
                'forum_id': forum_id}

    # Search-driven sources collect by querying the source's OWN search
    # function instead of walking a board. Routed here so EVERY caller -
    # scheduled collection, Collect Now, the monitor worker - picks it up,
    # which is what makes the configured queries re-run over time and
    # surface newly published matching content.
    if (forum_registry.get_search_queries(forum_id)
            and forum_registry.get_search_enabled(forum_id)):
        from lib import forum_search
        if forum_search.get_search_provider(forum_id) is not None:
            try:
                return forum_search.run_search_collection(forum_id, logger=logger)
            finally:
                forum_metrics.mark_finished(forum_id)

    board_url = forum.get('url')
    provider_id = forum.get('provider') or None
    limits = forum_registry.get_crawl_limits(forum_id)
    max_pages = max_pages or limits.get('max_pages')
    max_documents = max_documents or limits.get('max_documents')

    cursor = {} if full_resync else forum_metrics.get_cursor(forum_id)
    highest = cursor.get('highest_thread_id')

    # Resolve the network route ONCE, before any request is made, and use it
    # for both transports. resolve_route() is also where the .onion/.i2p
    # force-Tor rule is enforced, so a hidden service cannot be crawled over
    # clearnet no matter what is configured.
    route = forum_registry.resolve_route(forum_id)
    if route.get('mode') == 'invalid':
        # A broken route is reported explicitly rather than silently falling
        # back to Tor - otherwise an operator sees "success over Tor" for a
        # forum they believe is going through a proxy.
        reason = f"invalid route configuration: {route.get('error')}"
        forum_metrics.mark_finished(forum_id, status='error',
                                    summary={'last_reason': reason})
        forum_registry.record_crawl_result(forum_id, success=False, error=reason)
        logger(f'[{forum_id}] {reason}')
        return {'error': reason, 'forum_id': forum_id}

    # Reuse the forum's stored authenticated session if an operator configured
    # one - the supported way to collect from a login-walled forum.
    session = forum_crawl.new_session(
        cookiejar_uuid=forum_registry.get_cookiejar(forum_id), route=route,
        forum_id=forum_id)
    provider = forum_providers.get_provider(forum_id, provider_id)

    state = {'stored': 0, 'new': 0}
    metrics_ref = [None]
    try:
        # ransomware.live is an API, not a board - it has no listing pages to
        # paginate, so it takes the JSON path instead of the HTML page loop.
        if getattr(provider, 'is_api', False):
            metrics = _crawl_api(session, forum_id, forum, provider, logger,
                                 max_documents=max_documents)
        else:
            metrics_ref[0] = forum_crawl.CrawlMetrics(forum_id, provider.id)
            threads, metrics, new_highest = forum_crawl.crawl_forum(
                forum_id, board_url, provider_id=provider_id,
                max_pages=max_pages, max_documents=max_documents,
                incremental=not full_resync, cursor=highest,
                on_thread=_make_on_thread(session, forum_id, forum, provider,
                                          metrics_ref, state, logger),
                logger=logger, metrics=metrics_ref[0], session=session)
            if new_highest is not None:
                forum_metrics.set_cursor(forum_id, highest_thread_id=new_highest)

        payload = metrics.to_dict()
        forum_metrics.record_run(forum_id, payload)

        # A crawl that stored nothing because it was blocked is a FAILURE,
        # even though every individual HTTP call "worked". Recording it as
        # success is what made breached.st look healthy at 1 document.
        # Any classified access failure is a FAILED crawl, including an
        # anti-spam rejection - whose reason deliberately carries no
        # "access failure" prefix, so this must key off the classification
        # rather than substring-matching the human text.
        blocked = bool(getattr(metrics, 'block_category', None)) or \
            'access failure' in (metrics.termination_reason or '')
        forum_registry.record_crawl_result(
            forum_id, success=not blocked,
            error=metrics.termination_reason if blocked else None)
        forum_registry.set_document_count(forum_id, count_documents(forum_id))
        forum_metrics.mark_finished(forum_id, status='idle', summary={
            'last_new': payload.get('documents_stored', 0),
            'last_reason': payload.get('termination_reason', ''),
        })
        logger(f'[{forum_id}] {payload["documents_stored"]} stored / '
               f'{payload["pages_fetched"]} pages / {payload["termination_reason"]}')
        return payload
    except Exception as e:
        traceback.print_exc()
        forum_metrics.mark_finished(forum_id, status='error',
                                    summary={'last_reason': str(e)[:200]})
        forum_registry.record_crawl_result(forum_id, success=False, error=str(e)[:500])
        return {'error': str(e), 'forum_id': forum_id}
    finally:
        # Always release the browser/HTTP session and the crawl lock, or a
        # crashed run would block this forum's schedule until the TTL expired.
        try:
            session.close()
        except Exception:
            pass
        if forum_metrics.is_running(forum_id):
            forum_metrics.mark_finished(forum_id, status='idle')


def _make_on_thread(session, forum_id, forum, provider, metrics_ref, state, logger):
    def on_thread(thread):
        outcome = _ingest_thread(session, forum_id, forum.get('name') or forum_id,
                                 thread, provider, metrics_ref[0], logger)
        if outcome == 'stored':
            state['stored'] += 1
            state['new'] += 1
        m = metrics_ref[0]
        forum_metrics.update_progress(forum_id, pages=m.pages_fetched,
                                      documents=m.documents_parsed, new=state['new'])
        return outcome
    return on_thread


def _ingest_thread(session, forum_id, forum_name, thread, provider, metrics, logger):
    """fetch -> parse -> dedupe -> store one thread. Returns an outcome string."""
    url = thread.get('url')
    thread_id = thread.get('thread_id')

    doc_id = forum_documents.canonical_doc_id(forum_id, thread_id=thread_id, url=url)
    id_key = f'forumdoc:id:{forum_id}'
    r = _r()

    already = r.sismember(id_key, doc_id) if doc_id else False

    html, text, err = forum_crawl.fetch_thread(session, url, metrics)
    if err:
        if metrics:
            metrics.note_error(f'thread {url}: {err}')
        return 'rejected'

    # HARD GATE: an access/rejection page must never become a stored document
    # or reach the search index. This is the exact bug that gave breached.st
    # four "documents" of Cloudflare interstitial, and it applies equally to an
    # anti-spam rejection - "your username, email or IP matches that of a known
    # spammer" is not dark-web intelligence, it is the site refusing us.
    info = fp_base.classify_block(text, html)
    if info:
        if info['category'] in (fp_base.BLOCK_ANTISPAM, fp_base.BLOCK_AUTH,
                                fp_base.BLOCK_SESSION):
            detail = f"{info['reason']}: {info['message']}" if info.get('message') else info['reason']
            raise fp_base.AccessRejected(detail, info=info)
        raise fp_base.BlockedError(f"blocked: {info['signature']}", info=info)

    if not text or len(text.strip()) < 50:
        return 'rejected'

    doc = forum_documents.parse_document(html, text, url, forum_id,
                                         thread_id=thread_id,
                                         title=thread.get('title'))
    if metrics and doc.get('attachments'):
        metrics.attachments_discovered += len(doc['attachments'])

    content_hash = sha256((doc['text'] or '').encode()).hexdigest()

    if already:
        # Known document - refresh last_seen and any newly-added content, but
        # do not double count. Content is still updated because a thread gains
        # replies over time.
        r.hset(f'forumdoc:full:{forum_id}:{doc_id}', mapping={
            'last_seen': int(time.time()),
            'text': doc['text'] or '',
            'attachments': json.dumps(doc['attachments']),
            'content_hash': content_hash,
        })
        return 'duplicate'

    _store_document(forum_id, doc_id, doc, content_hash)
    _index_and_alert(forum_id, forum_name, doc_id, doc, content_hash)
    return 'stored'


def _store_document(forum_id, doc_id, doc, content_hash):
    r = _r()
    now = int(time.time())
    mapping = {
        'doc_id': doc_id,
        'forum_id': forum_id,
        'thread_url': doc.get('thread_url') or '',
        'post_url': doc.get('post_url') or '',
        'thread_id': doc.get('thread_id') or '',
        'post_id': doc.get('post_id') or '',
        'title': doc.get('title') or '',
        'author': doc.get('author') or '',
        'timestamp': doc.get('timestamp') or '',
        'published_at': doc.get('published_at') or '',
        'text': doc.get('text') or '',
        'text_truncated': '1' if doc.get('text_truncated') else '0',
        'links': json.dumps(doc.get('links') or []),
        'domains': json.dumps(doc.get('domains') or []),
        'keywords': json.dumps(doc.get('keywords') or []),
        'attachments': json.dumps(doc.get('attachments') or []),
        'images': json.dumps(doc.get('images') or []),
        'indicators': json.dumps(doc.get('indicators') or {}),
        'credentials_detected': '1' if doc.get('credentials_detected') else '0',
        # Search-collection provenance. A document found by querying the
        # source must record WHY it matched, or the Intelligence UI can only
        # show the hit without its justification.
        'matched_query': doc.get('matched_query') or '',
        'match_snippet': doc.get('match_snippet') or '',
        'match_category': doc.get('match_category') or '',
        'match_reason': doc.get('match_reason') or '',
        'collection_mode': doc.get('collection_mode') or 'crawl',
        'content_hash': content_hash,
        'first_seen': now,
        'last_seen': now,
    }
    r.hset(f'forumdoc:full:{forum_id}:{doc_id}', mapping=mapping)
    r.sadd(f'forumdoc:id:{forum_id}', doc_id)
    # Legacy content-hash set kept in sync so existing readers keep working.
    r.sadd(f'forumdoc:hash:{forum_id}', content_hash)
    r.hset(f'forumdoc:meta:{forum_id}:{content_hash}', mapping={
        'item_id': '', 'url': doc.get('thread_url') or '',
        'first_seen': now, 'last_seen': now, 'doc_id': doc_id,
    })


def store_external_document(forum_id, forum_name, doc):
    """Store a document that did NOT come from the thread crawler - e.g. a leak
    site's victim record read from a page a human cleared the anti-bot on. `doc`
    uses the same shape _store_document consumes (title/text/domains/...).
    Deduplicated by content hash; returns 'stored' or 'duplicate'. The caller
    refreshes the forum's document_count afterwards (set_document_count)."""
    r = _r()
    text = doc.get('text') or ''
    content_hash = sha256(text.encode()).hexdigest()
    if r.sismember(f'forumdoc:hash:{forum_id}', content_hash):
        return 'duplicate'
    # thread_id first so per-record identity is stable and unique; a URL whose
    # only distinguishing part is a #fragment would normalise to one id for all.
    doc_id = forum_documents.canonical_doc_id(
        forum_id, thread_id=doc.get('thread_id'),
        url=doc.get('thread_url') or doc.get('post_url'), content=text)
    if r.sismember(f'forumdoc:id:{forum_id}', doc_id):
        return 'duplicate'
    doc.setdefault('collection_mode', 'leak_list')
    _store_document(forum_id, doc_id, doc, content_hash)
    _index_and_alert(forum_id, forum_name, doc_id, doc, content_hash)
    return 'stored'


def _index_and_alert(forum_id, forum_name, doc_id, doc, content_hash):
    text = doc.get('text') or ''
    if search_engine.Engine is not None:
        try:
            search_engine.Engine.index_intel_doc(
                forum_id, content_hash, text[:MAX_TEXT_INDEXED],
                doc.get('thread_url') or '', int(time.time()), True)
        except Exception:
            pass
    try:
        _check_watchlist(forum_id, forum_name, doc, text)
    except Exception as e:
        print(f'watchlist check failed for {doc_id}: {e}')


_MATCH_CONFIDENCE_RANK = {'high': 2, 'medium': 1, 'low': 0}


def _check_watchlist(forum_id, forum_name, doc, text_content):
    """Same matching pipeline as the previous collector so a watch alert from
    continuous ingestion and one from a manual search stay consistent."""
    active = [w for w in watchlist.get_active_watches()
              if not w['forum_ids'] or forum_id in w['forum_ids']]
    if not active:
        return
    url = doc.get('thread_url') or ''
    for watch in active:
        if watch['query_type'] == 'keyword':
            matches = intel_extraction.classify_keyword_matches(text_content, watch['query'])
        else:
            matches = intel_extraction.classify_matches(text_content, watch['query'])
        if not matches:
            continue
        best = max(matches, key=lambda m: _MATCH_CONFIDENCE_RANK.get(m['confidence'], 0))
        window = intel_extraction.extract_analysis_window(text_content, best['matched_value'])
        entities = intel_extraction.extract_entities(window)
        signals = intel_extraction.detect_sensitive_signals(window)
        score, level = intel_extraction.score_document_risk(matches, entities, signals)
        snippet, specific_url = intel_extraction.extract_match_snippet(
            text_content, best['matched_value'], base_url=url)
        watchlist.record_alert(
            watch['id'], forum_id, forum_name, specific_url or url, '',
            best['match_type'], best['matched_value'], level, score, snippet)


# ---------------------------------------------------------------------------
# API-shaped source (ransomware.live)
# ---------------------------------------------------------------------------

def _crawl_api(session, forum_id, forum, provider, logger, max_documents=None):
    metrics = forum_crawl.CrawlMetrics(forum_id, provider.id)
    max_documents = int(max_documents or forum_crawl.FORUM_CRAWL_MAX_DOCUMENTS)
    # The API host is a property of the provider, not of the registered URL -
    # ransomware.live's registered site URL is the human-facing www host,
    # whose /api paths 404.
    root = getattr(provider, 'API_ROOT', None)
    if not root:
        from urllib.parse import urlparse as _up
        p = _up(forum.get('url') or 'https://ransomware.live/')
        root = f'{p.scheme}://{p.netloc}'

    # A syndication source's endpoint IS its registered URL - there is no
    # API root to join a path onto, and every feed sits at a different path.
    if getattr(provider, 'use_forum_url', False):
        candidate_urls = [forum.get('url')]
    else:
        candidate_urls = [f'{root}{path}' for path in provider.api_paths()]

    records = None
    last_err = None
    for url in candidate_urls:
        if not url:
            continue
        raw, err = forum_crawl.fetch(session, url, metrics)
        if err:
            last_err = err
            metrics.note_error(f'{url}: {err}')
            continue
        try:
            records = provider.parse_api(raw)
            metrics.pages_fetched += 1
            break
        except Exception as e:
            last_err = str(e)
            metrics.note_error(f'{url}: {e}')
            continue

    if records is None:
        metrics.finish(f'{fp_base.STOP_FATAL}: no usable API endpoint ({last_err})')
        return metrics

    metrics.documents_discovered = len(records)
    r = _r()
    id_key = f'forumdoc:id:{forum_id}'
    for rec in records:
        if metrics.documents_stored >= max_documents:
            metrics.finish(f'Stopped at configured safety limit: '
                           f'{metrics.documents_stored} documents / '
                           f'{metrics.pages_fetched} pages')
            return metrics
        metrics.documents_parsed += 1
        doc_id = forum_documents.canonical_doc_id(
            forum_id, thread_id=rec.get('thread_id'), url=rec.get('url'))
        if r.sismember(id_key, doc_id):
            metrics.duplicates_skipped += 1
            continue
        doc = {
            'forum_id': forum_id, 'thread_url': rec.get('url'),
            'post_url': rec.get('url'), 'thread_id': rec.get('thread_id'),
            'post_id': None, 'title': rec.get('title'),
            'author': rec.get('author'), 'timestamp': rec.get('timestamp'),
            'text': rec.get('text'), 'text_truncated': False,
            'links': [], 'domains': [], 'keywords': [], 'attachments': [],
            'indicators': {},
        }
        content_hash = sha256((doc['text'] or '').encode()).hexdigest()
        _store_document(forum_id, doc_id, doc, content_hash)
        _index_and_alert(forum_id, forum.get('name') or forum_id, doc_id, doc, content_hash)
        metrics.documents_stored += 1
        forum_metrics.update_progress(forum_id, pages=metrics.pages_fetched,
                                      documents=metrics.documents_parsed,
                                      new=metrics.documents_stored)

    metrics.finish(fp_base.STOP_NO_MORE_PAGES)
    return metrics


# ---------------------------------------------------------------------------
# Corpus accessors
# ---------------------------------------------------------------------------

def count_documents_by_mode(forum_id):
    """Split a forum's stored corpus by HOW it was collected.

    The distinction matters for judging a source: documents a link crawler
    scraped off a public index are not evidence that the forum's own search
    works, and conflating the two is exactly how a forum can look productive
    while its search endpoint is actually refusing us.
    """
    r = _r()
    out = {'search': 0, 'crawl': 0}
    for doc_id in r.smembers(f'forumdoc:id:{forum_id}'):
        mode = r.hget(f'forumdoc:full:{forum_id}:{doc_id}', 'collection_mode')
        out['search' if mode == 'search' else 'crawl'] += 1
    return out


def get_search_provenance(forum_id, content_hash=None, doc_id=None):
    """Query-driven collection provenance for a stored document.

    Returns {} for anything collected by link-crawling, so callers can show
    the "why this matched" block ONLY where a query genuinely produced the
    document rather than implying one everywhere.
    """
    r = _r()
    if not doc_id and content_hash:
        doc_id = r.hget(f'forumdoc:meta:{forum_id}:{content_hash}', 'doc_id')
    if not doc_id:
        return {}
    raw = r.hgetall(f'forumdoc:full:{forum_id}:{doc_id}')
    if not raw or raw.get('collection_mode') != 'search':
        return {}
    return {
        'matched_query': raw.get('matched_query') or '',
        'match_reason': raw.get('match_reason') or '',
        'match_snippet': raw.get('match_snippet') or '',
        'match_category': raw.get('match_category') or '',
        'collection_mode': 'search',
    }


def count_documents(forum_id):
    """Number of documents ACTUALLY stored and retrievable for this forum."""
    return _r().scard(f'forumdoc:id:{forum_id}') or 0


def list_documents(forum_id, limit=100, offset=0):
    r = _r()
    ids = sorted(r.smembers(f'forumdoc:id:{forum_id}'))
    out = []
    for doc_id in ids[offset:offset + limit]:
        raw = r.hgetall(f'forumdoc:full:{forum_id}:{doc_id}')
        if raw:
            out.append(_decode(raw))
    out.sort(key=lambda d: d.get('first_seen') or 0, reverse=True)
    return out


def list_search_documents(forum_id, limit=10):
    """Documents collected via the forum's OWN native search (collection_mode
    == 'search'), newest first. Powers the DarkForums section on the main
    dashboard - it reads the SAME corpus every other view reads, so nothing is
    duplicated and no separate store is introduced."""
    r = _r()
    out = []
    for doc_id in r.smembers(f'forumdoc:id:{forum_id}'):
        raw = r.hgetall(f'forumdoc:full:{forum_id}:{doc_id}')
        if raw and raw.get('collection_mode') == 'search':
            out.append(_decode(raw))
    out.sort(key=lambda d: d.get('first_seen') or 0, reverse=True)
    return out[:limit] if limit else out


def count_search_documents(forum_id):
    """How many of this forum's stored documents came from native search."""
    r = _r()
    n = 0
    for doc_id in r.smembers(f'forumdoc:id:{forum_id}'):
        if r.hget(f'forumdoc:full:{forum_id}:{doc_id}', 'collection_mode') == 'search':
            n += 1
    return n


def get_document(forum_id, doc_id):
    raw = _r().hgetall(f'forumdoc:full:{forum_id}:{doc_id}')
    return _decode(raw) if raw else None


def _decode(raw):
    out = dict(raw)
    for k in ('links', 'domains', 'keywords', 'attachments', 'images', 'indicators'):
        try:
            out[k] = json.loads(out.get(k) or ('{}' if k == 'indicators' else '[]'))
        except Exception:
            out[k] = {} if k == 'indicators' else []
    for k in ('first_seen', 'last_seen'):
        try:
            out[k] = int(out.get(k) or 0)
        except (TypeError, ValueError):
            out[k] = 0
    out['text_truncated'] = out.get('text_truncated') == '1'
    out['credentials_detected'] = out.get('credentials_detected') == '1'
    return out
