#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
RansomLook provider
===================

Pagination: NONE - /api/recent returns the newest ~100 victim posts in one
response. Incremental collection comes from the stable per-post identity
below, not from walking pages.

RansomLook is a public, free ransomware leak-site aggregator. It is a
SECOND, INDEPENDENT view of the same threat landscape ransomware.live
covers, which is exactly why it earns a place in the pool: the two disagree
often (different scrape cadence, different group coverage), so a victim
appearing in one and not the other is itself a signal - and the pool stops
depending on a single upstream for ransomware intelligence.

Confirmed live (2026-09-05): https://www.ransomlook.io/api/recent returns a
100-element JSON array; records carry post_title (the victim), group_name,
discovered, description (usually the victim's sector) and a site-relative
link.
"""

import json
import re

from .base import ForumProvider, FatalProviderError

API_ROOT = 'https://www.ransomlook.io'
_PATHS = ('/api/recent',)


class RansomLookProvider(ForumProvider):
    id = 'ransomlook'
    name = 'RansomLook API'
    pagination = 'none (recent-posts JSON API)'
    is_api = True
    API_ROOT = API_ROOT

    def api_paths(self):
        return _PATHS

    def page_url(self, board_url, page_no, state=None):
        return None

    def extract_threads(self, html, base_url):
        return []

    def parse_api(self, raw):
        try:
            data = json.loads(raw)
        except Exception as e:
            raise FatalProviderError(f'invalid JSON from ransomlook: {e}')
        if isinstance(data, dict):
            for key in ('data', 'results', 'posts'):
                if isinstance(data.get(key), list):
                    data = data[key]
                    break
        if not isinstance(data, list):
            raise FatalProviderError('unexpected ransomlook payload shape')

        out = []
        for rec in data:
            if not isinstance(rec, dict):
                continue
            victim = (rec.get('post_title') or rec.get('title') or '').strip()
            group = (rec.get('group_name') or rec.get('group') or '').strip()
            if not victim and not group:
                continue
            discovered = (rec.get('discovered') or rec.get('published') or '').strip()
            link = (rec.get('link') or '').strip()
            if link.startswith('/'):
                link = f'{API_ROOT}{link}'

            # group + victim is unique per disclosure and survives the record
            # being re-served with a new screenshot or MISP uuid; a content
            # hash would re-store it as a new document every time.
            ident = re.sub(r'\s+', '-', f'{group}-{victim}'.lower()).strip('-')
            parts = [
                f'Ransomware group: {group}' if group else '',
                f'Victim: {victim}' if victim else '',
                f'Sector: {rec.get("description") or ""}',
                f'Discovered: {discovered}' if discovered else '',
                f'Leak-site post: {link}' if link else '',
                'Bulk download advertised (magnet link published)' if rec.get('magnet') else '',
            ]
            out.append({
                'thread_id': ident[:180] or None,
                'title': f'{group} -> {victim}' if group and victim else (victim or group),
                'url': link or 'https://www.ransomlook.io/recent',
                'text': '\n'.join(p for p in parts if p and not p.endswith(': ')),
                'author': group or None,
                'timestamp': discovered or None,
                'raw': rec,
            })
        if not out:
            raise FatalProviderError('ransomlook returned no usable records')
        return out
