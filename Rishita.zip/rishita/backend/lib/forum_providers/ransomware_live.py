#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
ransomware.live provider
========================

Pagination: OFFSET over a JSON API - a third distinct mechanism, alongside
XenForo's path segments and MyBB's query parameters. This is the reason the
registry stores a provider per forum rather than assuming one shape.

ransomware.live is a public, free ransomware-victim disclosure API (not a
forum). It was showing "n/a" on the dashboard precisely because it has no
board pages to link-crawl: the browser crawler could only ever capture its
landing page, which is how it ended up with exactly 1 "document". Its data
lives behind /api/v2 endpoints, so each victim disclosure becomes one
document with real structure (group, victim, sector, country, discovery date).
"""

import json
import re

from .base import ForumProvider, FatalProviderError

# Confirmed live (2026-09-05): the API lives on the api. subdomain and the
# path has NO /api prefix - https://api.ransomware.live/v2/recentvictims
# returns the recent-victims array directly (~94KB). The www host's /api/...
# paths 404, and api.ransomware.live/api/... 302-redirects to the docs page,
# so both were probed and rejected rather than assumed.
API_ROOT = 'https://api.ransomware.live'
_RECENT_PATHS = (
    '/v2/recentvictims',
    '/v1/recentvictims',
)


class RansomwareLiveProvider(ForumProvider):
    id = 'ransomware_live'
    name = 'Ransomware.live API'
    pagination = 'offset (JSON API)'
    is_api = True
    API_ROOT = API_ROOT

    def api_paths(self):
        return _RECENT_PATHS

    def page_url(self, board_url, page_no, state=None):
        # Handled by the JSON fetch path in the crawl engine (fetch_api_page);
        # a page_no beyond the sliced dataset returns None to stop the loop.
        return None

    def extract_threads(self, html, base_url):
        return []

    def parse_api(self, raw):
        """Return a list of normalised victim records, or raise FatalProviderError."""
        try:
            data = json.loads(raw)
        except Exception as e:
            raise FatalProviderError(f'invalid JSON from ransomware.live: {e}')
        if isinstance(data, dict):
            for key in ('victims', 'data', 'results'):
                if isinstance(data.get(key), list):
                    data = data[key]
                    break
        if not isinstance(data, list):
            raise FatalProviderError('unexpected ransomware.live payload shape')

        out = []
        for rec in data:
            if not isinstance(rec, dict):
                continue
            victim = (rec.get('victim') or rec.get('post_title')
                      or rec.get('name') or '').strip()
            group = (rec.get('group') or rec.get('group_name') or '').strip()
            if not victim and not group:
                continue
            discovered = (rec.get('discovered') or rec.get('published')
                          or rec.get('date') or '')
            url = (rec.get('post_url') or rec.get('url')
                   or rec.get('claim_url') or '')
            # Stable identity: group + victim is unique per disclosure and
            # survives the record being re-served with an updated screenshot
            # or description - a content hash would not.
            ident = re.sub(r'\s+', '-', f'{group}-{victim}'.lower()).strip('-')
            body_parts = [
                f'Ransomware group: {group}' if group else '',
                f'Victim: {victim}' if victim else '',
                f'Sector: {rec.get("activity") or rec.get("sector") or ""}',
                f'Country: {rec.get("country") or ""}',
                f'Discovered: {discovered}',
                f'Domain: {rec.get("domain") or ""}',
                (rec.get('description') or '').strip(),
            ]
            text = '\n'.join(p for p in body_parts if p and not p.endswith(': '))
            out.append({
                'thread_id': ident[:180] or None,
                'title': f'{group} -> {victim}' if group and victim else (victim or group),
                'url': url or 'https://ransomware.live/',
                'text': text,
                'author': group or None,
                'timestamp': discovered or None,
                'raw': rec,
            })
        return out
