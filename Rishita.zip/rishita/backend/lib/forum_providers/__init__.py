#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Forum provider registry.

Maps a registered forum to the provider that knows its pagination and
parsing strategy. Selection order:
  1. explicit `provider` field on the forum record (operator override)
  2. per-domain mapping below
  3. platform auto-detection from page markup
  4. GenericProvider
"""

import re

from .base import (ForumProvider, BlockedError, FatalProviderError, detect_block,
                   same_host, set_query_param, get_query_param,
                   STOP_NO_MORE_PAGES, STOP_NO_NEW_RESULTS, STOP_MAX_PAGES,
                   STOP_MAX_DOCUMENTS, STOP_ACCESS_DENIED, STOP_FATAL,
                   STOP_INCREMENTAL_CAUGHT_UP)
from .xenforo import XenForoProvider
from .mybb import MyBBProvider
from .generic import GenericProvider
from .ransomware_live import RansomwareLiveProvider
from .ransomlook import RansomLookProvider
from .hibp import HIBPProvider
from .rss import RSSProvider

PROVIDERS = {
    'xenforo': XenForoProvider,
    'mybb': MyBBProvider,
    'generic': GenericProvider,
    'ransomware_live': RansomwareLiveProvider,
    'ransomlook': RansomLookProvider,
    'hibp': HIBPProvider,
    'rss': RSSProvider,
}

# Known platforms for the currently registered forums. Confirmed by
# inspecting each site's own markup rather than guessed from the name.
_DOMAIN_MAP = {
    'xforums.st': 'xenforo',
    'darkforums.as': 'mybb',
    'ransomware.live': 'ransomware_live',
    'ransomlook.io': 'ransomlook',
    'haveibeenpwned.com': 'hibp',
    # Syndication sources. One provider serves all of them - the feed URL is
    # the registered source URL, so no per-domain parsing logic is needed.
    'thehackernews.com': 'rss',
    'krebsonsecurity.com': 'rss',
    'therecord.media': 'rss',
    'cvefeed.io': 'rss',
    'darkreading.com': 'rss',
}


def detect_platform(html):
    """Auto-detect a forum platform from its markup."""
    if not html:
        return None
    low = html.lower()
    if 'xf-' in low and ('xenforo' in low or 'data-app="public"' in low):
        return 'xenforo'
    if 'xenforo' in low:
        return 'xenforo'
    if 'mybb' in low or 'showthread.php' in low or 'forumdisplay.php' in low:
        return 'mybb'
    return None


def get_provider(forum_id=None, provider_id=None, html=None):
    """Resolve a provider instance for a forum."""
    key = None
    if provider_id and provider_id in PROVIDERS:
        key = provider_id
    if not key and forum_id:
        key = _DOMAIN_MAP.get((forum_id or '').lower())
    if not key and html:
        key = detect_platform(html)
    return PROVIDERS.get(key, GenericProvider)()


def platform_for_forum(forum_id):
    """Mapped platform key for a forum id/host (e.g. 'darkforums.as' -> 'mybb'),
    or None. Shared with the search layer so a newly registered forum that has
    no explicit provider yet still resolves its native-search adapter the same
    way collection does."""
    return _DOMAIN_MAP.get((forum_id or '').lower())


def list_provider_ids():
    return sorted(PROVIDERS)
