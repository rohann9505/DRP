#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
XenForo provider (xforums.st, breached.st)
==========================================

Pagination: PATH SEGMENT. XenForo boards paginate as
`/forums/db-leaks/page-2`, not with a query parameter - which is exactly why
one shared pagination mechanism would not have worked across forums. Thread
URLs look like `/threads/<slug>.<thread_id>/` and that trailing numeric id is
the stable per-thread identity used for dedupe (see base.thread_id_for).
"""

import re
from urllib.parse import urljoin, urlparse

from .base import ForumProvider, same_host

# /threads/some-slug.670897/  ->  670897
_THREAD_RE = re.compile(r'/threads/(?:[^/]*?\.)?(\d+)/?', re.IGNORECASE)
_THREAD_HREF_RE = re.compile(r'href=["\']([^"\']*/threads/[^"\']+)["\']', re.IGNORECASE)
_TITLE_ATTR_RE = re.compile(
    r'<a[^>]+href=["\']([^"\']*/threads/[^"\']+)["\'][^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL)
_TAG_RE = re.compile(r'<[^>]+>')


class XenForoProvider(ForumProvider):
    id = 'xenforo'
    name = 'XenForo'
    pagination = 'path-segment (/page-N)'

    def page_url(self, board_url, page_no, state=None):
        if page_no <= 1:
            return board_url
        base = board_url.split('?')[0].rstrip('/')
        # A board URL may already carry a /page-N suffix if an operator
        # pasted one; strip it before appending our own.
        base = re.sub(r'/page-\d+$', '', base)
        suffix = board_url[len(board_url.split('?')[0]):]  # keep any query
        return f'{base}/page-{page_no}{suffix}'

    def extract_threads(self, html, base_url):
        if not html:
            return []
        host = urlparse(base_url).netloc.split(':')[0]
        seen = set()
        threads = []
        for m in _TITLE_ATTR_RE.finditer(html):
            href, inner = m.group(1), m.group(2)
            url = urljoin(base_url, href)
            if not same_host(url, host):
                continue
            tid = self.thread_id_for(url)
            if not tid or tid in seen:
                continue
            seen.add(tid)
            title = _TAG_RE.sub('', inner)
            title = re.sub(r'\s+', ' ', title).strip()
            threads.append({'url': url.split('#')[0], 'title': title or None,
                            'thread_id': tid})
        # Some themes render the link without inner text in the same anchor
        # (icon-only "unread" links); pick those up too so a board isn't
        # under-collected just because of a theme quirk.
        for m in _THREAD_HREF_RE.finditer(html):
            url = urljoin(base_url, m.group(1))
            if not same_host(url, host):
                continue
            tid = self.thread_id_for(url)
            if not tid or tid in seen:
                continue
            seen.add(tid)
            threads.append({'url': url.split('#')[0], 'title': None, 'thread_id': tid})
        return threads

    def is_last_page(self, html, threads, page_no, state=None):
        """Positive signals only.

        XenForo renders a pageNav block; when the current page is the highest
        numbered one there is no 'next' link. Absence of a next link on a page
        that HAS a nav block is a genuine end-of-listing signal. A short page
        is deliberately NOT treated as the end - XenForo filters moderated
        threads after applying the page size, so short pages occur mid-board.
        """
        if not html:
            return False
        low = html.lower()
        if 'pagenav' not in low and 'block--pagenav' not in low:
            # No pagination UI at all -> single-page board.
            return True
        # An explicit next-page control means there is more.
        if 'pagenav-jump--next' in low or 'rel="next"' in low or "rel='next'" in low:
            return False
        # Nav present but no next control -> last page.
        return True

    def thread_id_for(self, url, title=None):
        m = _THREAD_RE.search(url or '')
        return m.group(1) if m else None
