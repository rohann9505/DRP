#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Search-driven collection: provider contract
===========================================

Why this exists. Link-crawling assumes a source publishes a browsable index
of thread links. The onion diagnostic proved that assumption fails on real
hidden services: AuditTeam's leak site renders every victim as a
non-clickable <div class="card"> (0 anchors -> 0 documents), and DarkForums
(MyBB) shows a guest ZERO thread links on its front page. Both are reachable
and both hold real intelligence - link discovery simply cannot see it.

Every one of those sources DOES expose a native search function. Searching
for the things we actually care about is also a better collection model than
walking a whole board: it is far less traffic against the source, it needs no
account for sources whose search is public, and the result set is by
definition relevant.

A SearchProvider therefore describes one platform's SEARCH mechanism:

    build_search(base_url, query, page)  -> SearchRequest (url/method/data)
    extract_results(html, base_url, q)   -> [SearchResult, ...]
    is_last_page(html, results, page)    -> positive last-page signal only

Contract notes, each of which exists because of a real failure:

  * `is_last_page` must never be "fewer results than a full page". Forums
    routinely return a short page mid-listing after post-filtering. Only a
    positive signal counts: an explicit "no more results", an absent
    next-page link, or a repeat of the previous page's result set.

  * `extract_results` MUST return the match context (the snippet the source
    itself highlighted, and the query). The Intelligence UI has to be able to
    show WHY a document matched; a document stored without that is evidence
    with its provenance stripped off.

  * A provider parses search results ONLY. Fetching result pages, dedupe,
    redaction, storage, metrics and Tor routing all stay in the shared
    engine (lib/forum_search.py) so no forum-specific selector leaks into
    the generic crawler.
"""

import re
from urllib.parse import urljoin, urlparse

_TAGS = re.compile(r'<script.*?</script>|<style.*?</style>|<[^>]+>',
                   re.IGNORECASE | re.DOTALL)


def strip_tags(html):
    if not html:
        return ''
    return re.sub(r'\s+', ' ', _TAGS.sub(' ', html)).strip()


def same_onion_host(url, host):
    try:
        return (urlparse(url).hostname or '').lower() == (host or '').lower()
    except Exception:
        return False


class SearchRequest:
    """One HTTP request that performs a search on the source."""

    def __init__(self, url, method='GET', data=None, headers=None):
        self.url = url
        self.method = (method or 'GET').upper()
        self.data = data
        self.headers = headers or {}

    def __repr__(self):
        return f'<SearchRequest {self.method} {self.url}>'


class SearchResult:
    """One hit, with the context explaining why it matched."""

    def __init__(self, url, title=None, snippet=None, author=None,
                 timestamp=None, category=None, result_id=None):
        self.url = url
        self.title = title
        self.snippet = snippet          # the source's own match context
        self.author = author
        self.timestamp = timestamp
        self.category = category        # forum / board / section
        self.result_id = result_id      # platform-native id, when exposed

    def to_dict(self, query=None):
        return {
            'url': self.url, 'title': self.title, 'snippet': self.snippet,
            'author': self.author, 'timestamp': self.timestamp,
            'category': self.category, 'result_id': self.result_id,
            'matched_query': query,
        }


class SearchProvider:
    """One platform's native search mechanism."""

    id = 'search-base'
    name = 'Base search provider'
    # Set when the platform's search is members-only. Used to classify a
    # refusal as AUTH_REQUIRED/COOKIE_INVALID rather than a generic block.
    search_requires_auth = False
    # Whether results carry enough content to store without opening each hit.
    results_are_documents = False

    # --- persistent-session support (all optional) -----------------------
    # Substrings (case-insensitive) that let forum_session classify a probe
    # page WITHOUT ever storing it. A platform that never needs auth can leave
    # these empty; classification then stays conservative (`unknown`, never a
    # false `valid`).
    logged_in_markers = []        # present only when authenticated
    session_expired_markers = []  # "your session expired" style wording
    login_required_markers = []   # anonymous / login-wall wording
    # A members-only path used to probe whether the stored session is still
    # live. Relative to the forum root; None falls back to the forum base URL.
    session_probe_path = None

    def session_probe_url(self, base_url):
        """Absolute URL to validate the session against, or None to use base."""
        if not self.session_probe_path:
            return base_url
        from urllib.parse import urljoin, urlparse
        root = f'{urlparse(base_url).scheme}://{urlparse(base_url).netloc}/'
        return urljoin(root, self.session_probe_path.lstrip('/'))

    def build_search(self, base_url, query, page=1):
        raise NotImplementedError

    def extract_results(self, html, base_url, query):
        raise NotImplementedError

    def is_last_page(self, html, results, page, state=None):
        return False

    def search_retry_after(self, html):
        """Seconds to wait before this exact search can be retried, or None.

        Some platforms rate-limit their search with a soft "you searched too
        recently, wait N seconds" page: HTTP 200, no results, NOT an access
        block. Returning the wait here lets the engine pace and retry instead
        of silently recording the query as empty. Default: no throttle."""
        return None

    def result_doc_id(self, result):
        """Stable identity for a hit. Prefer the platform's own id, then the
        URL - never a content hash, which re-stores the same thread whenever
        a reply count or session token changes."""
        if result.result_id:
            return str(result.result_id)
        if result.url:
            return re.sub(r'[^A-Za-z0-9._:-]+', '-', result.url)[:180]
        return None
