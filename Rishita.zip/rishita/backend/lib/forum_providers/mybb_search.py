#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
MyBB native search adapter
==========================

Mechanism confirmed live against DarkForums
(darkfox...onion, 2026-09-05) by reading its own quick-search form:

    <form action="http://<host>/search.php">
      <input name="keywords">
      <input type="hidden" name="action" value="do_search">
      <input type="hidden" name="postthread" value="1">
    </form>

MyBB's do_search creates a server-side result set and redirects to
    search.php?action=results&sid=<generated>
so page 1 must be fetched with redirects followed, and every later page is
that RESOLVED url plus &page=N. Building page 2 from the original query URL
instead would silently re-run the search and renumber the results.

DarkForums' search is members-only: search.php returns HTTP 403 with MyBB's
board-message page to a guest AND to an expired session (verified - the
anonymous and stored-session responses are byte-identical at 19,509 bytes,
and usercp.php is 403 both ways). `search_requires_auth` is what lets the
engine report that as COOKIE_INVALID rather than a generic block.
"""

import re
from urllib.parse import urljoin, urlparse, parse_qs, urlencode, urlunparse

from .search_base import SearchProvider, SearchRequest, SearchResult, strip_tags

# A MyBB results row links a thread three ways, ALL accepted:
#   showthread.php?tid=123                     (classic)
#   thread-123.html                            (numeric SEO rewrite)
#   Thread-Some-Title-Slug                     (title SEO rewrite - DarkForums)
# The previous pattern required a DIGIT right after "thread-", so a title-slug
# URL whose title starts with a letter (e.g. "Thread-Deloitte-com-Source-Code")
# never matched and the thread was dropped from the results - which is why a
# manual "deloitte" search showed a full page while our collection stored zero.
# A real numeric tid is taken from ?tid= only; title-slug threads carry no tid
# and are identified by their canonical (query-stripped) URL instead.
_THREAD_RE = re.compile(
    r'<a[^>]+href="([^"]*(?:showthread\.php\?[^"]*|thread-[^"]+))"[^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL)
_NO_RESULTS = re.compile(
    r'no results (?:were )?(?:found|returned)|returned no results|'
    r'search returned no', re.IGNORECASE)
# MyBB search flood control: after a search it refuses the next one for a
# configurable interval with a "please wait N seconds" board message (HTTP
# 200, no redirect to action=results, no thread rows). This is a rate limit,
# NOT an auth/access block, so it must be paced-and-retried, never stored or
# treated as "no results". Observed on CryptBB (30s window).
# CryptBB's exact wording (MyBB core "error_searchflooding" string):
#   "Sorry, but you can only perform one search every 30 seconds. Please wait
#    another 26 seconds before attempting to search again."
_SEARCH_FLOOD_RE = re.compile(
    r'you can only perform (?:one|\d+) search(?:es)? every'
    r'|please wait[^.]{0,80}?before (?:attempting to search|searching|you can search)'
    r'|(?:cannot|can not|can\'t)\s+(?:perform|conduct|do)\s+another search'
    r'|search(?:ing)?\s+(?:again\s+)?(?:so soon|too (?:soon|quickly|often))',
    re.IGNORECASE)
# Prefer the REMAINING wait ("another N seconds") over the interval it quotes.
_FLOOD_REMAIN_RE = re.compile(r'wait another\s+(\d+)\s*second', re.IGNORECASE)
_FLOOD_SECONDS_RE = re.compile(r'(\d+)\s*second', re.IGNORECASE)
# "Last Post" cell anchor text is a date/time (e.g. "20-10-25, 12:04 PM"); it
# links the same thread and must not be mistaken for a second result.
_DATE_TEXT_RE = re.compile(r'^\d{1,2}-\d{1,2}-\d{2,4}[, ]')


def _set_page(url, page):
    p = urlparse(url)
    q = parse_qs(p.query)
    q['page'] = [str(page)]
    return urlunparse(p._replace(query=urlencode(q, doseq=True)))


class MyBBSearchProvider(SearchProvider):
    id = 'mybb_search'
    name = 'MyBB native search'
    search_requires_auth = True   # true for DarkForums; harmless elsewhere

    # Session validation markers. The User CP is the natural probe: MyBB serves
    # it only to a logged-in account and answers a guest with a permission
    # notice, so the two states are unambiguous without storing the page.
    session_probe_path = 'usercp.php'
    logged_in_markers = ['usercp.php', 'logout.php',
                         'member.php?action=logout', 'Welcome back']
    login_required_markers = [
        'You are not logged in or you do not have permission',
        'member.php?action=login', 'You must be a registered',
        'you do not have permission to access this page']
    session_expired_markers = ['your session has expired',
                               'you have been logged out']

    def build_search(self, base_url, query, page=1, state=None):
        host_root = f'{urlparse(base_url).scheme}://{urlparse(base_url).netloc}'
        # Later pages go against the RESOLVED results URL (carries the sid).
        resolved = (state or {}).get('results_url')
        if page > 1 and resolved:
            return SearchRequest(_set_page(resolved, page))
        # sortby=lastpost + order=desc are MyBB do_search's own result-ordering
        # parameters, so the generated result set is ranked newest-active first
        # by the source itself - not reordered by us. This is what lets the
        # engine honestly present recent matching threads first.
        # MyBB's search form is method="post" (do_search validates a POST body
        # and 302-redirects to action=results&sid=...). A GET is silently
        # re-rendered as the empty search form by MyBB installs that gate
        # do_search on the request method (observed on CryptBB), yielding zero
        # results with no error. POSTing is the canonical, form-declared flow
        # and returns the real result set; `_fetch_search` follows the redirect
        # so page 1's resolved URL (carrying the sid) is captured for paging.
        return SearchRequest(
            urljoin(host_root + '/', 'search.php'),
            method='POST',
            data={'keywords': query, 'action': 'do_search', 'postthread': '1',
                  'showresults': 'threads', 'sortby': 'lastpost', 'order': 'desc'})

    def extract_results(self, html, base_url, query):
        if not html:
            return []
        host = (urlparse(base_url).hostname or '')
        out, seen = [], set()
        for m in _THREAD_RE.finditer(html):
            href = m.group(1)
            title = strip_tags(m.group(2))
            # A single-digit inner text ("2", "3") is a "Pages: 1 2 3" link
            # inside the row, not a thread; the length gate drops it. A date is
            # the "Last Post" link's text, not a title - drop it too.
            if not title or len(title) < 2:
                continue
            if _DATE_TEXT_RE.match(title):
                continue
            parsed = urlparse(urljoin(base_url, href))
            if (parsed.hostname or '') != host:
                continue
            # Canonical thread URL so the title link, its pagination links and
            # its last-post link all collapse to ONE thread. A classic
            # showthread.php link keeps its tid; a title-slug link drops
            # ?highlight=/?page=/?pid= and the fragment (its slug IS its id).
            q = parse_qs(parsed.query)
            tid = (q.get('tid') or [None])[0]
            new_query = f'tid={tid}' if tid else ''
            thread_url = urlunparse(parsed._replace(query=new_query, fragment=''))
            key = tid or thread_url.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append(SearchResult(url=thread_url, title=title, result_id=tid,
                                    snippet=self._row_context(html, m.start()),
                                    category=self._row_forum(html, m.start())))
        return out

    @staticmethod
    def _row_context(html, pos):
        """The surrounding result row, as the source rendered it - this is the
        match context the UI shows to explain WHY a document matched."""
        start = html.rfind('<tr', 0, pos)
        end = html.find('</tr>', pos)
        if start < 0 or end < 0:
            return None
        text = strip_tags(html[start:end])
        return text[:400] or None

    @staticmethod
    def _row_forum(html, pos):
        start = html.rfind('<tr', 0, pos)
        end = html.find('</tr>', pos)
        if start < 0 or end < 0:
            return None
        m = re.search(r'forumdisplay\.php\?[^"]*fid=\d+"[^>]*>(.*?)</a>',
                      html[start:end], re.I | re.S)
        return strip_tags(m.group(1)) if m else None

    def search_retry_after(self, html):
        if not html:
            return None
        text = strip_tags(html)[:2000]
        if not _SEARCH_FLOOD_RE.search(text):
            return None
        # Honour the remaining wait it states ("another N seconds"); else the
        # quoted interval; else MyBB's default (30s).
        m = _FLOOD_REMAIN_RE.search(text) or _FLOOD_SECONDS_RE.search(text)
        return int(m.group(1)) if m else 30

    def is_last_page(self, html, results, page, state=None):
        if not results:
            return True
        if _NO_RESULTS.search(strip_tags(html or '')[:2000]):
            return True
        # Positive signal only: MyBB renders a "next" link while more exist.
        return not re.search(r'class="pagination_next"|>\s*Next\s*<', html or '', re.I)
