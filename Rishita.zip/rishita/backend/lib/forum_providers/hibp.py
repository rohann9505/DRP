#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Have I Been Pwned (breaches) provider
=====================================

Pagination: NONE - /api/v3/breaches returns the FULL catalogue of publicly
catalogued breaches in one response (1034 records as of 2026-09-05).

This is the only source in the pool that is a curated, corroborated breach
CATALOGUE rather than an attacker claim: ransomware.live and RansomLook
report what a group asserts on its leak site, whereas HIBP records breaches
that have been verified and loaded. Having both kinds in the pool is what
lets an analyst separate "a group claims this" from "this is confirmed".

The /breaches endpoint is deliberately the one used: it is public and needs
no API key. The account-lookup endpoints DO require a paid key and are NOT
called here - this provider only ever reads the public catalogue and never
submits an email address or any other subject identifier to a third party.

DataClasses (the categories of data exposed) are recorded as CATEGORY NAMES
only - the counterpart of the leak-intelligence rule that a disclosure shows
the category and presence of a secret, never a value.
"""

import json
import re

from .base import ForumProvider, FatalProviderError

API_ROOT = 'https://haveibeenpwned.com'
_PATHS = ('/api/v3/breaches',)

_TAGS = re.compile(r'<[^>]+>')


class HIBPProvider(ForumProvider):
    id = 'hibp'
    name = 'Have I Been Pwned (breach catalogue)'
    pagination = 'none (full catalogue JSON API)'
    is_api = True
    API_ROOT = API_ROOT

    def api_paths(self):
        return _PATHS

    def page_url(self, board_url, page_no, state=None):
        return None

    def extract_threads(self, html, base_url):
        return []

    def parse_api(self, raw):
        try:
            data = json.loads(raw)
        except Exception as e:
            raise FatalProviderError(f'invalid JSON from HIBP: {e}')
        if not isinstance(data, list):
            raise FatalProviderError('unexpected HIBP payload shape')

        out = []
        for rec in data:
            if not isinstance(rec, dict):
                continue
            name = (rec.get('Name') or '').strip()
            title = (rec.get('Title') or name).strip()
            if not name and not title:
                continue
            domain = (rec.get('Domain') or '').strip()
            classes = [c for c in (rec.get('DataClasses') or []) if c]
            description = re.sub(r'\s+', ' ', _TAGS.sub(' ', rec.get('Description') or '')).strip()
            pwn_count = rec.get('PwnCount')

            flags = [k for k in ('IsVerified', 'IsSensitive', 'IsFabricated',
                                 'IsRetired', 'IsSpamList', 'IsMalware')
                     if rec.get(k)]
            parts = [
                f'Breach: {title}' if title else '',
                f'Domain: {domain}' if domain else '',
                f'Breach date: {rec.get("BreachDate") or ""}',
                f'Added to catalogue: {rec.get("AddedDate") or ""}',
                f'Accounts affected: {pwn_count:,}' if isinstance(pwn_count, int) else '',
                # Category names only - never any exposed value.
                f'Exposed data categories ({len(classes)}): {", ".join(classes)}' if classes else '',
                f'Flags: {", ".join(flags)}' if flags else '',
                description,
            ]
            out.append({
                # HIBP's Name is its own permanent primary key.
                'thread_id': re.sub(r'[^A-Za-z0-9._-]+', '-', name or title)[:180] or None,
                'title': f'{title} ({pwn_count:,} accounts)' if isinstance(pwn_count, int) else title,
                'url': f'{API_ROOT}/PwnedWebsites#{name}' if name else API_ROOT,
                'text': '\n'.join(p for p in parts if p and not p.endswith(': ')),
                'author': domain or None,
                'timestamp': rec.get('AddedDate') or rec.get('BreachDate') or None,
                'raw': {'data_classes': classes, 'pwn_count': pwn_count, 'flags': flags},
            })
        if not out:
            raise FatalProviderError('HIBP returned no usable records')
        return out
