#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Torch onion-search adapter
==========================

Torch is a hidden-service search engine reachable only over Tor. It earns a
place here for two reasons: its search is PUBLIC (no account, so the whole
search->results->pagination->extraction->storage path can be proven
end-to-end against a real onion service), and its index is itself dark-web
discovery - a query surfaces onion forums we do not yet monitor.

Mechanism confirmed live (2026-09-05):
    http://<torch>.onion/search?query=<q>&page=<n>
    <article class="result">
      <h2 class="result-title"><a href="http://<target>.onion/...">Title</a></h2>
      ...snippet...
    </article>
    <p class="result-count">Your search <b>q</b> returned <b>402</b> results.</p>
"""

import re
from urllib.parse import urlparse, quote

from .search_base import SearchProvider, SearchRequest, SearchResult, strip_tags

_RESULT_RE = re.compile(
    r'<article[^>]+class="[^"]*result[^"]*"[^>]*>(.*?)</article>',
    re.IGNORECASE | re.DOTALL)
_TITLE_RE = re.compile(
    r'<h2[^>]+class="[^"]*result-title[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL)
_COUNT_RE = re.compile(r'returned\s*<b>\s*([\d,]+)\s*</b>\s*results', re.I)
# The source's own description of the hit - this is the match context the
# Intelligence UI shows to explain WHY a document is in the corpus. Falling
# back to "strip the title and keep the rest" yielded only the result URL,
# which explains nothing.
_DESC_RE = re.compile(
    r'<p[^>]+class="[^"]*result-desc[^"]*"[^>]*>(.*?)</p>', re.IGNORECASE | re.DOTALL)
_URLBLOCK_RE = re.compile(
    r'<p[^>]+class="[^"]*result-url[^"]*"[^>]*>.*?</p>', re.IGNORECASE | re.DOTALL)
_ZERO_RE = re.compile(r'returned\s*<b>?\s*0\s*</b>?\s*results', re.I)


class TorchSearchProvider(SearchProvider):
    id = 'torch_search'
    name = 'Torch (onion search engine)'
    search_requires_auth = False
    # Torch's snippet is all the content it exposes; the engine may still
    # follow the hit to collect the target page itself.
    results_are_documents = True

    def build_search(self, base_url, query, page=1, state=None):
        p = urlparse(base_url)
        root = f'{p.scheme}://{p.netloc}'
        return SearchRequest(f'{root}/search?query={quote(query)}&page={int(page)}')

    def extract_results(self, html, base_url, query):
        if not html:
            return []
        out, seen = [], set()
        for block in _RESULT_RE.finditer(html):
            body = block.group(1)
            m = _TITLE_RE.search(body)
            if not m:
                continue
            url, title = m.group(1), strip_tags(m.group(2))
            if not url.startswith('http') or url in seen:
                continue
            seen.add(url)
            desc = _DESC_RE.search(body)
            if desc:
                snippet = strip_tags(desc.group(1))[:400] or None
            else:
                # Drop the title and the echoed URL block before falling back,
                # so the snippet is never just the link again.
                rest = _URLBLOCK_RE.sub(' ', _TITLE_RE.sub(' ', body))
                snippet = strip_tags(rest)[:400] or None
            out.append(SearchResult(
                url=url, title=title or url, snippet=snippet,
                category=(urlparse(url).hostname or None)))
        return out

    def result_count(self, html):
        m = _COUNT_RE.search(html or '')
        if not m:
            return None
        try:
            return int(m.group(1).replace(',', ''))
        except ValueError:
            return None

    def is_last_page(self, html, results, page, state=None):
        if not results:
            return True
        if _ZERO_RE.search(html or ''):
            return True
        total = self.result_count(html)
        if total is not None and page * max(len(results), 1) >= total:
            return True
        return False
