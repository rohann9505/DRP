#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Generic RSS / Atom provider
===========================

Pagination: NONE - a syndication feed is a single document that already
carries the newest N items. That is a fourth distinct mechanism alongside
XenForo's path segments, MyBB's query parameters and the JSON-API offset
walk, and it is why the registry stores a provider per source rather than
assuming every source is a paginated board.

Why this exists: the collection pool needs sources that can ACTUALLY be
crawled. Every HTML forum currently registered sits behind an anti-bot edge
(xforums.st -> DNSPROXY, breached.st -> Cloudflare, darkforums.as ->
anti-spam rejection), and this platform does not defeat those by design. A
feed is a publisher-sanctioned machine-readable endpoint - the one route to
real, continuously-updating documents that involves no circumvention at all.

Identity: an item's <guid>/<id> is the publisher's own stable identifier and
survives the item being re-served with an edited title or body, so it is
preferred over the link, and both are preferred over a content hash (a hash
re-counts the same item whenever a tracking parameter or timestamp changes -
the exact bug that gave breached.st four "documents" of the same challenge
page).
"""

import re
import xml.etree.ElementTree as ET

from .base import ForumProvider, FatalProviderError

_ATOM = 'http://www.w3.org/2005/Atom'
_DC = 'http://purl.org/dc/elements/1.1/'
_CONTENT = 'http://purl.org/rss/1.0/modules/content/'

_TAGS = re.compile(r'<script.*?</script>|<style.*?</style>|<[^>]+>',
                   re.IGNORECASE | re.DOTALL)


def _strip(html):
    if not html:
        return ''
    return re.sub(r'\s+', ' ', _TAGS.sub(' ', html)).strip()


def _first(el, *paths):
    """First non-empty text (or href) among `paths`, which may be namespaced."""
    for path in paths:
        found = el.find(path)
        if found is None:
            continue
        value = (found.text or '').strip() or (found.get('href') or '').strip()
        if value:
            return value
    return ''


class RSSProvider(ForumProvider):
    id = 'rss'
    name = 'RSS / Atom feed'
    pagination = 'none (syndication feed)'
    is_api = True
    # The feed URL is the registered source URL itself - there is no separate
    # API root to join a path onto (see forum_ingest._crawl_api).
    use_forum_url = True

    def api_paths(self):
        return ['']

    def page_url(self, board_url, page_no, state=None):
        return None

    def extract_threads(self, html, base_url):
        return []

    def parse_api(self, raw):
        """Return normalised records from an RSS 2.0 or Atom feed."""
        if not raw or not raw.strip():
            raise FatalProviderError('empty feed response')
        try:
            root = ET.fromstring(raw.strip())
        except ET.ParseError as e:
            raise FatalProviderError(f'feed is not valid XML: {e}')

        items = root.findall('.//item') or root.findall(f'.//{{{_ATOM}}}entry')
        if not items:
            raise FatalProviderError('feed contains no <item>/<entry> elements')

        out = []
        for item in items:
            title = _first(item, 'title', f'{{{_ATOM}}}title')
            link = _first(item, 'link', f'{{{_ATOM}}}link')
            # Atom puts the URL in link/@href; ET returns '' for its text.
            if not link:
                atom_link = item.find(f'{{{_ATOM}}}link')
                if atom_link is not None:
                    link = (atom_link.get('href') or '').strip()
            guid = _first(item, 'guid', f'{{{_ATOM}}}id')
            body = _first(item, 'description', f'{{{_CONTENT}}}encoded',
                          f'{{{_ATOM}}}summary', f'{{{_ATOM}}}content')
            author = _first(item, 'author', f'{{{_DC}}}creator',
                            f'{{{_ATOM}}}author/{{{_ATOM}}}name')
            published = _first(item, 'pubDate', f'{{{_DC}}}date',
                               f'{{{_ATOM}}}published', f'{{{_ATOM}}}updated')

            if not title and not link:
                continue  # not a usable item

            # Publisher's own id first, link second - never a content hash.
            ident = guid or link
            ident = re.sub(r'[^A-Za-z0-9._:-]+', '-', ident).strip('-')[:180]

            text = _strip(body)
            categories = [c.text.strip() for c in item.findall('category')
                          if c is not None and c.text and c.text.strip()]
            parts = [
                f'Title: {title}' if title else '',
                f'Published: {published}' if published else '',
                f'Author: {author}' if author else '',
                f'Tags: {", ".join(categories)}' if categories else '',
                text,
            ]
            out.append({
                'thread_id': ident or None,
                'title': title or link,
                'url': link or guid,
                'text': '\n'.join(p for p in parts if p),
                'author': author or None,
                'timestamp': published or None,
                'raw': {'categories': categories},
            })
        if not out:
            raise FatalProviderError('feed parsed but yielded no usable items')
        return out
