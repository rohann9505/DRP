#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Forum Provider base classes
===========================

Before this package existed there was no such thing as a "forum provider":
forum_collector.collect_forum() enqueued ONE Lacus browser capture at
depth=2 and whatever pages Lacus happened to follow became the corpus.
That has three consequences the audit confirmed live (2026-09-05):

  * No pagination existed anywhere in the codebase. Not "a low page limit" -
    no concept of a page 2 at all. breached.st therefore had exactly one URL
    in its corpus (its seed board page), captured 4 times.
  * Nothing distinguished a real forum page from an anti-bot interstitial,
    so Cloudflare's "Performing security verification" page was stored as a
    document - and because each challenge embeds a fresh nonce/ray id, the
    content-hash dedupe saw every re-capture as a NEW document. That is how
    breached.st reached a "document count" of 4 while holding zero forum
    content.
  * Discovery depended entirely on Lacus following links, so a board whose
    threads sit behind a challenge or a JS-rendered listing yielded nothing.

A provider owns ONE forum platform's answers to: how do I turn a board URL
into page 1, page 2, page N; how do I recognise the last page; how do I pull
thread links out of a listing; and how do I tell a real page from a block
page. Each provider implements its own strategy because the strategies are
genuinely different - MyBB counts pages in the query string, XenForo uses
/page-N path segments, a JSON API uses an offset or a cursor. Assuming one
mechanism for all of them is what produced the "just fetch the seed" behaviour
this replaces.
"""

import os
import re
import sys
import time
from urllib.parse import urljoin, urlparse, urlencode, parse_qsl, urlunparse

sys.path.append(os.environ['AIL_BIN'])


# ---------------------------------------------------------------------------
# Termination reasons. A crawl must always report WHY it stopped - the audit
# found forums silently sitting at 1 document with last_crawl_status='success',
# which reads as "we collected everything" when it actually meant "we were
# blocked on page 1". These are surfaced verbatim in the per-forum metrics.
# ---------------------------------------------------------------------------
STOP_NO_MORE_PAGES = 'no more pages'
STOP_NO_NEW_RESULTS = 'forum reported no more results'
STOP_MAX_PAGES = 'configured safety limit: pages'
STOP_MAX_DOCUMENTS = 'configured safety limit: documents'
STOP_ACCESS_DENIED = 'authentication/access failure'
STOP_FATAL = 'provider fatal error'
STOP_INCREMENTAL_CAUGHT_UP = 'reached previously-seen content (incremental)'


class BlockedError(Exception):
    """Raised when a fetch returns an anti-bot / auth wall rather than content.

    Deliberately distinct from a transient network error: a block is NOT
    retryable at speed and must abort the forum's crawl with an explicit
    reason, instead of being retried into a rate-limit ban or - worse -
    stored as if it were a document.

    Carries the classification dict (see classify_block/build_block_info) so
    the crawl reports the ACTUAL category. A raise site that omits it used to
    leave the handler defaulting to BLOCK_NETWORK, which mislabelled an
    uncleared browser challenge as a "Network/IP block" and told the operator
    to change egress route for a problem a different IP would not fix.
    """

    def __init__(self, message, info=None):
        super().__init__(message)
        self.info = info or {}

    @property
    def category(self):
        return self.info.get('category')


class AccessRejected(BlockedError):
    """The source explicitly rejected this crawler's identity or account.

    Distinct from a generic BlockedError because it is NOT retryable by any
    means available to this crawler: no amount of waiting, JS execution or
    browser escalation clears an anti-spam flag or a banned account. Carries
    the classification and, where available, the server's own wording.

    Subclasses BlockedError so existing `except BlockedError` handlers keep
    working; handlers that care can catch this specifically. `info`/`category`
    are inherited from BlockedError.
    """


class FatalProviderError(Exception):
    """Unrecoverable provider-level failure; aborts this forum only."""


# ---------------------------------------------------------------------------
# Anti-bot / block detection.
#
# This is the single most important correctness gate in the whole pipeline.
# Without it the collector stores challenge pages as documents (proven live on
# breached.st: 4 stored "documents", every one of them the text "Performing
# security verification ... verifies you are not a bot").
#
# Matching is done on the extracted TEXT and the raw HTML, because some
# challenges render almost no text.
# ---------------------------------------------------------------------------
# Block categories. These are NOT interchangeable - each implies a different
# operator action, and reporting the wrong one sends an analyst down the wrong
# path. Confirmed live on darkforums.as (2026-09-05): the forum returns an
# explicit anti-spam account rejection, which the previous flat signature list
# mis-reported as "anti-bot challenge did not clear in browser" - i.e. as a
# CAPTCHA problem, when the actual cause is that the account/email/IP is
# flagged as a known spammer. A residential proxy does not necessarily fix
# that: a username/email-based rejection follows the account, not the network.
BLOCK_NETWORK = 'network'        # IP/WAF/anti-bot edge block
BLOCK_CHALLENGE = 'challenge'    # interactive CAPTCHA - not solvable by design
BLOCK_AUTH = 'auth'              # login required / insufficient permission
BLOCK_SESSION = 'session'        # session expired or invalidated
BLOCK_ANTISPAM = 'antispam'      # account/email/IP flagged as spammer
BLOCK_RATE = 'rate'              # rate limited / flooding control

BLOCK_CATEGORY_LABELS = {
    BLOCK_NETWORK:   'Network/IP block',
    BLOCK_CHALLENGE: 'CAPTCHA/challenge',
    BLOCK_AUTH:      'Authentication required',
    BLOCK_SESSION:   'Session expired',
    BLOCK_ANTISPAM:  'Anti-spam/account rejection',
    BLOCK_RATE:      'Rate limited',
}

# Whether a different egress IP could plausibly change the outcome. This is the
# honest answer to "will a proxy fix it?" - and for an anti-spam rejection the
# answer is explicitly "unknown", because the server itself says the match may
# be on username OR email OR IP and does not tell us which.
BLOCK_PROXY_MAY_HELP = {
    BLOCK_NETWORK:   True,
    BLOCK_RATE:      True,
    BLOCK_CHALLENGE: True,      # some challenges are IP-reputation driven
    BLOCK_AUTH:      False,
    BLOCK_SESSION:   False,
    BLOCK_ANTISPAM:  None,      # indeterminate - depends on username/email/IP
}

# (category, signature) in priority order. ANTI-SPAM IS CHECKED FIRST: its page
# often ALSO contains generic words like "administrator" or sits behind the same
# WAF, and misclassifying it as a challenge is exactly the bug being fixed.
_BLOCK_SIGNATURES = (
    # --- anti-spam / account rejection (MyBB, XenForo, IPB wording) ---
    (BLOCK_ANTISPAM, 'matches that of a known spammer'),
    (BLOCK_ANTISPAM, 'known spammer'),
    (BLOCK_ANTISPAM, 'flagged as a spammer'),
    (BLOCK_ANTISPAM, 'your account has been banned'),
    (BLOCK_ANTISPAM, 'you have been banned'),
    (BLOCK_ANTISPAM, 'you are banned from'),
    (BLOCK_ANTISPAM, 'account has been suspended'),
    (BLOCK_ANTISPAM, 'stopforumspam'),
    # --- session ---
    (BLOCK_SESSION, 'your session has expired'),
    (BLOCK_SESSION, 'session expired'),
    (BLOCK_SESSION, 'invalid session'),
    (BLOCK_SESSION, 'please log in again'),
    # --- rate limiting ---
    (BLOCK_RATE, 'you are posting too quickly'),
    (BLOCK_RATE, 'flood control'),
    (BLOCK_RATE, 'too many requests'),
    (BLOCK_RATE, 'rate limit'),
    # --- interactive CAPTCHA gates. NOT solvable by this crawler by design. ---
    # Leak-site entry gates. Confirmed live on the ShinyHunters DLS
    # (2026-09-06): the onion serves an 8.7KB splash whose only body is
    # <a class="eg-gate">click anywhere to enter</a>, with a .captchav2
    # element and a 60-second expiry timer behind it. Without these
    # signatures that splash classifies as NORMAL CONTENT and gets stored as
    # an 8.7KB "document" - the same defect that gave breached.st four
    # documents of Cloudflare interstitial.
    (BLOCK_CHALLENGE, 'click anywhere to enter'),
    (BLOCK_CHALLENGE, 'eg-gate'),
    (BLOCK_CHALLENGE, 'captchav2'),
    (BLOCK_CHALLENGE, 'captcha challenge'),
    (BLOCK_CHALLENGE, 'please complete the following captcha'),
    (BLOCK_CHALLENGE, 'grecaptcha'),
    (BLOCK_CHALLENGE, 'g-recaptcha'),
    (BLOCK_CHALLENGE, 'hcaptcha'),
    (BLOCK_CHALLENGE, 'layer7-protection'),
    # --- Cloudflare managed / JS challenge / Turnstile ---
    (BLOCK_CHALLENGE, 'just a moment'),
    (BLOCK_CHALLENGE, 'performing security verification'),
    (BLOCK_CHALLENGE, 'verifies you are not a bot'),
    (BLOCK_CHALLENGE, 'checking your browser before accessing'),
    # DarkForums' own JS anti-bot splash ("DARK FORUMS - Checking your browser.
    # Please move your mouse or press a key..."). Interactive (needs a real
    # pointer event), so it never clears headless and MUST be recognised - or
    # it is captured as a thread screenshot / stored as a document.
    (BLOCK_CHALLENGE, 'checking your browser'),
    (BLOCK_CHALLENGE, 'please move your mouse'),
    (BLOCK_CHALLENGE, 'move your mouse or press a key'),
    (BLOCK_CHALLENGE, 'enable javascript and cookies to continue'),
    (BLOCK_CHALLENGE, 'cf-browser-verification'),
    (BLOCK_CHALLENGE, 'cf_chl_opt'),
    (BLOCK_CHALLENGE, '_cf_chl_'),
    (BLOCK_CHALLENGE, 'cdn-cgi/challenge-platform'),
    (BLOCK_CHALLENGE, 'one more step - browser check'),
    (BLOCK_CHALLENGE, 'browser check'),
    # --- network / WAF edge blocks ---
    (BLOCK_NETWORK, 'attention required! | cloudflare'),
    (BLOCK_NETWORK, 'ray id'),
    (BLOCK_NETWORK, 'ddos-guard'),
    (BLOCK_NETWORK, 'dnsproxy'),
    (BLOCK_NETWORK, 'antibot'),
    (BLOCK_NETWORK, 'sucuri website firewall'),
    (BLOCK_NETWORK, 'access denied'),
    (BLOCK_NETWORK, 'request blocked'),
    (BLOCK_NETWORK, 'your ip has been blocked'),
    (BLOCK_NETWORK, 'ip address has been blocked'),
    # --- auth walls ---
    (BLOCK_AUTH, 'you must be logged in'),
    (BLOCK_AUTH, 'please log in to continue'),
    (BLOCK_AUTH, 'log in or sign up to view'),
    (BLOCK_AUTH, 'you do not have permission to view this page'),
    (BLOCK_AUTH, 'sorry, you do not have permission'),
    (BLOCK_AUTH, 'registration is required'),
)

# A page that trips a signature but is genuinely long-form forum content is
# possible in principle (a thread literally discussing Cloudflare). Requiring
# the page to ALSO be short guards against false positives: real thread pages
# carry substantial text, challenge pages carry a few hundred characters.
_BLOCK_MAX_TEXT_LEN = 2500

# Machine markers that are unambiguous even inside a long page.
_LONG_PAGE_SAFE = {
    'cf_chl_opt', '_cf_chl_', 'cdn-cgi/challenge-platform',
    'cf-browser-verification', 'matches that of a known spammer',
    'stopforumspam',
}

# Sentence-ish extraction so the server's OWN wording can be reported verbatim
# rather than paraphrased - required when we cannot tell whether the rejection
# matched on username, email or IP.
_SENTENCE_SPLIT = re.compile(r'(?<=[.!?])\s+')


def build_block_info(category, message=None, signature=None, reason=None):
    """Build a classification dict for a block detected OUTSIDE the signature
    table - e.g. a challenge page that a real browser still could not clear.

    Returns the same shape classify_block() does, so every raise site can carry
    a classification and no handler has to guess a default category.
    """
    label = BLOCK_CATEGORY_LABELS.get(category)
    return {
        'category': category,
        'label': label,
        'signature': signature,
        'message': message,
        'proxy_may_help': BLOCK_PROXY_MAY_HELP.get(category),
        'reason': reason or label,
    }


def _server_message(text, signature, max_len=300):
    """Return the source's own sentence containing `signature`, so the report
    quotes the server instead of guessing at the cause."""
    if not text:
        return None
    low = text.lower()
    idx = low.find(signature)
    if idx < 0:
        return None
    window = text[max(0, idx - 400): idx + 400]
    for sentence in _SENTENCE_SPLIT.split(window):
        if signature in sentence.lower():
            cleaned = ' '.join(sentence.split())
            # The window can begin mid-page (a title, nav text) before the
            # actual message. Trim to the start of the real sentence so the
            # quote is the server's statement, not surrounding page chrome.
            for opener in ('Sorry,', 'Your ', 'You ', 'This '):
                pos = cleaned.find(opener)
                if pos > 0:
                    cleaned = cleaned[pos:]
                    break
            return cleaned[:max_len]
    return ' '.join(window.split())[:max_len]


def classify_block(text, html=None):
    """
    Classify an access failure. Returns None for a normal forum response, or:

        {'category', 'label', 'signature', 'message', 'proxy_may_help', 'reason'}

    `message` is the SERVER'S OWN wording where it could be extracted - which
    matters for anti-spam rejections, where the site says the match may be on
    username, email or IP without saying which. In that case we report what the
    server said rather than asserting a cause we cannot determine.
    """
    haystacks = []
    if text:
        haystacks.append(text.lower())
    if html:
        haystacks.append(html.lower()[:20000])
    if not haystacks:
        return None

    text_len = len(text or '')
    for category, sig in _BLOCK_SIGNATURES:
        for hay in haystacks:
            if sig not in hay:
                continue
            if text_len > _BLOCK_MAX_TEXT_LEN and sig not in _LONG_PAGE_SAFE:
                continue
            message = _server_message(text, sig)
            label = BLOCK_CATEGORY_LABELS.get(category, 'Access failure')
            if category == BLOCK_ANTISPAM:
                reason = 'Access rejected — username/email/IP flagged as known spammer'
            else:
                reason = f'{label} — {sig}'
            return {
                'category': category,
                'label': label,
                'signature': sig,
                'message': message,
                'proxy_may_help': BLOCK_PROXY_MAY_HELP.get(category),
                'reason': reason,
            }
    return None


def detect_block(text, html=None):
    """Backwards-compatible string form of classify_block().

    Returns a short reason string, or None for a normal forum response. Every
    existing caller (fetch escalation, thread ingestion, the browser session's
    challenge-clear loop) keeps working unchanged; callers that need the
    category use classify_block() directly.
    """
    info = classify_block(text, html)
    if not info:
        return None
    if info['category'] == BLOCK_ANTISPAM:
        # Never collapse an anti-spam rejection into "blocked: <captcha-ish>" -
        # that is the misdiagnosis this classification exists to prevent.
        return info['reason'] if not info['message'] else f"{info['reason']}: {info['message']}"
    return f"blocked: {info['signature']}"


# ---------------------------------------------------------------------------
# URL helpers shared by the concrete providers
# ---------------------------------------------------------------------------

def set_query_param(url, key, value):
    """Return `url` with query parameter `key` set to `value`."""
    parts = urlparse(url)
    q = dict(parse_qsl(parts.query, keep_blank_values=True))
    q[key] = str(value)
    return urlunparse(parts._replace(query=urlencode(q)))


def get_query_param(url, key):
    parts = urlparse(url)
    return dict(parse_qsl(parts.query, keep_blank_values=True)).get(key)


def same_host(url, host):
    try:
        netloc = urlparse(url).netloc.lower()
    except Exception:
        return False
    netloc = netloc.split('@')[-1].split(':')[0]
    return netloc == host.lower() or netloc.endswith('.' + host.lower())


class ForumProvider:
    """
    One forum platform's pagination + parsing strategy.

    Subclasses MUST implement `page_url()` and `extract_threads()`, and SHOULD
    override `is_last_page()` when the platform gives a positive signal.

    Contract notes that exist because of real bugs found in the audit:

    * `page_url(board_url, page_no, state)` returns the URL for a 1-indexed
      page, or None when the strategy is cursor-based and the cursor is
      exhausted. Page numbering starts at 1 and page 1 MUST equal the board
      URL itself, so an unpaginated board still works.

    * `is_last_page()` must NOT be implemented as "this page returned fewer
      threads than a full page". The task specification calls that out
      explicitly and it is a real failure mode: forums routinely return a
      short page mid-listing (deleted/moderated threads are filtered after
      the page size is applied). Only a positive signal counts - an explicit
      "no more results" marker, an absent next-page link, or a repeat of the
      previous page's thread set.
    """

    id = 'base'
    name = 'Base'
    # Pagination mechanism, surfaced in the UI so an operator can see which
    # strategy a forum is actually using rather than guessing.
    pagination = 'none'

    def page_url(self, board_url, page_no, state=None):
        raise NotImplementedError

    def extract_threads(self, html, base_url):
        """Return a list of {'url', 'title', 'thread_id'} for a listing page."""
        raise NotImplementedError

    def is_last_page(self, html, threads, page_no, state=None):
        """Positive last-page detection only. Default: unknown -> keep going.

        The loop's own guards (no threads at all, repeated thread set, safety
        limits) terminate the crawl when this can't decide.
        """
        return False

    def thread_id_for(self, url, title=None):
        """Stable per-forum document identity.

        Dedupe by CONTENT HASH alone is what let breached.st count the same
        challenge page 4 times (each carries a fresh nonce, so every capture
        hashed differently). A canonical source identifier - forum + thread id
        parsed out of the URL - is stable across re-captures, edits, reply
        counts and session tokens, so it is preferred whenever the platform
        exposes one.
        """
        return None
