#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Generic provider - fallback for an unrecognised platform.

Tries the two most common query-parameter conventions (?page=N, then ?start=N
offset style) and harvests any same-host link that looks like a thread. It is
deliberately conservative: it exists so an unknown forum still gets multi-page
collection instead of a single seed capture, not to be as precise as a
platform-specific provider.
"""

import re
from urllib.parse import urljoin, urlparse

from .base import ForumProvider, same_host, set_query_param

_ANCHOR_RE = re.compile(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                        re.IGNORECASE | re.DOTALL)
_TAG_RE = re.compile(r'<[^>]+>')
# Paths that look like a discussion rather than nav/profile/asset chrome.
_THREADY = re.compile(
    r'/(?:threads?|topic|showthread|viewtopic|posts?|t)[-/=]|[?&](?:tid|t|topic|thread)=\d+',
    re.IGNORECASE)
_JUNK = re.compile(
    r'/(?:login|register|signup|logout|search|members?|profile|user|help|'
    r'terms|privacy|contact|misc|attachment|download|css|js|img|image|static)\b'
    r'|\.(?:css|js|png|jpe?g|gif|svg|ico|woff2?)(?:$|\?)',
    re.IGNORECASE)


class GenericProvider(ForumProvider):
    id = 'generic'
    name = 'Generic (auto)'
    pagination = 'query parameter (?page=N)'

    def page_url(self, board_url, page_no, state=None):
        if page_no <= 1:
            return board_url
        return set_query_param(board_url, 'page', page_no)

    def extract_threads(self, html, base_url):
        if not html:
            return []
        host = urlparse(base_url).netloc.split(':')[0]
        seen = set()
        threads = []
        for m in _ANCHOR_RE.finditer(html):
            href, inner = m.group(1), m.group(2)
            if href.startswith(('#', 'mailto:', 'javascript:')):
                continue
            url = urljoin(base_url, href).split('#')[0]
            if not same_host(url, host) or _JUNK.search(url):
                continue
            if not _THREADY.search(url):
                continue
            if url in seen:
                continue
            seen.add(url)
            title = re.sub(r'\s+', ' ', _TAG_RE.sub('', inner)).strip()
            threads.append({'url': url, 'title': title or None,
                            'thread_id': self.thread_id_for(url, title)})
        return threads

    def is_last_page(self, html, threads, page_no, state=None):
        if not html:
            return False
        low = html.lower()
        if 'rel="next"' in low or "rel='next'" in low or '>next<' in low:
            return False
        # No positive next-page signal AND no pagination UI -> assume single
        # page. If pagination UI exists but we can't read it, keep going and
        # let the repeated-page-set guard in the engine stop us.
        return 'pagination' not in low and 'pagenav' not in low

    def thread_id_for(self, url, title=None):
        m = re.search(r'(?:[?&](?:tid|t|topic|thread)=|/(?:threads?|topic|t)[-/])(\d+)',
                      url or '', re.IGNORECASE)
        if m:
            return m.group(1)
        m = re.search(r'\.(\d+)/?$', url or '')
        return m.group(1) if m else None
