#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
MyBB provider (darkforums.as and most classic dark-web boards)
==============================================================

Pagination: QUERY PARAMETER. MyBB uses `forumdisplay.php?fid=12&page=3`, a
completely different mechanism from XenForo's `/page-N` path segment - the
concrete reason each provider implements its own strategy instead of sharing
one. Threads are `showthread.php?tid=<id>`; `tid` is the stable identity.
"""

import re
from urllib.parse import urljoin, urlparse

from .base import ForumProvider, same_host, set_query_param

_TID_RE = re.compile(r'[?&]tid=(\d+)', re.IGNORECASE)
_THREAD_ANCHOR_RE = re.compile(
    r'<a[^>]+href=["\']([^"\']*(?:showthread\.php\?[^"\']*tid=\d+|/thread-\d+)[^"\']*)["\'][^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL)
# SEO-rewritten MyBB: /thread-1234-post-5.html
_SEO_TID_RE = re.compile(r'/thread-(\d+)', re.IGNORECASE)
_TAG_RE = re.compile(r'<[^>]+>')


class MyBBProvider(ForumProvider):
    id = 'mybb'
    name = 'MyBB'
    pagination = 'query parameter (?page=N)'

    def page_url(self, board_url, page_no, state=None):
        if page_no <= 1:
            return board_url
        return set_query_param(board_url, 'page', page_no)

    def extract_threads(self, html, base_url):
        if not html:
            return []
        host = urlparse(base_url).netloc.split(':')[0]
        seen = set()
        threads = []
        for m in _THREAD_ANCHOR_RE.finditer(html):
            href, inner = m.group(1), m.group(2)
            url = urljoin(base_url, href)
            if not same_host(url, host):
                continue
            tid = self.thread_id_for(url)
            if not tid or tid in seen:
                continue
            seen.add(tid)
            title = re.sub(r'\s+', ' ', _TAG_RE.sub('', inner)).strip()
            threads.append({'url': url.split('#')[0], 'title': title or None,
                            'thread_id': tid})
        return threads

    def is_last_page(self, html, threads, page_no, state=None):
        if not html:
            return False
        low = html.lower()
        # MyBB's pagination block renders a "Next" control while more pages
        # exist. No pagination block at all -> single page.
        if 'class="pagination' not in low and 'pagination_' not in low:
            return True
        if 'pagination_next' in low or '>next<' in low or 'rel="next"' in low:
            return False
        return True

    def thread_id_for(self, url, title=None):
        m = _TID_RE.search(url or '')
        if m:
            return m.group(1)
        m = _SEO_TID_RE.search(url or '')
        return m.group(1) if m else None
