#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Question2Answer (Q2A) native search adapter
===========================================

Q2A powers a whole family of onion discussion boards (Hidden Answers,
Deepweb Questions and Answers, Tor Questions and Answers, ...). Its search is
PUBLIC - no account - which makes it the platform that can actually prove
query-driven onion forum collection end to end.

Mechanism confirmed live against Hidden Answers (2026-09-06):

    GET  http://<host>/search?q=<query>&start=<offset>     (10 results/page)

    <div class="qa-q-list-item">
      <div class="qa-q-item-title"><a href="./10115/slug">Title</a></div>
      <span class="qa-q-item-who-data">author</span>
      <span class="qa-q-item-when-data">Mar 28, 2025</span>
      <span class="qa-q-item-where-data">Category</span>
    </div>

Pagination is OFFSET based (`start=0,10,20...`), not page-numbered - building
`page=N` here would silently re-request the first page forever.

Identity: Q2A's question id (the leading number in the result href) is the
board's own permanent key and survives re-titling, new answers and vote
changes, so it is preferred over the URL and never a content hash.
"""

import re
from urllib.parse import urljoin, urlparse, quote

from .search_base import SearchProvider, SearchRequest, SearchResult, strip_tags

RESULTS_PER_PAGE = 10

_ITEM_RE = re.compile(
    r'<div class="qa-q-list-item.*?(?=<div class="qa-q-list-item|<div class="qa-suggest-next|\Z)',
    re.IGNORECASE | re.DOTALL)
_TITLE_RE = re.compile(
    r'<div class="qa-q-item-title"[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL)
_QID_RE = re.compile(r'/(\d+)/')
_NO_RESULTS_RE = re.compile(r'No results found for', re.IGNORECASE)


def _field(block, cls):
    m = re.search(r'<[^>]+class="' + cls + r'"[^>]*>(.*?)</(?:span|div|a)>',
                  block, re.IGNORECASE | re.DOTALL)
    return strip_tags(m.group(1)) if m else None


class Q2ASearchProvider(SearchProvider):
    id = 'q2a_search'
    name = 'Question2Answer native search'
    search_requires_auth = False

    def build_search(self, base_url, query, page=1, state=None):
        p = urlparse(base_url)
        root = f'{p.scheme}://{p.netloc}'
        start = (max(1, int(page)) - 1) * RESULTS_PER_PAGE
        return SearchRequest(f'{root}/search?q={quote(query)}&start={start}')

    def extract_results(self, html, base_url, query):
        if not html or _NO_RESULTS_RE.search(html):
            return []
        out, seen = [], set()
        for block in _ITEM_RE.finditer(html):
            body = block.group(0)
            m = _TITLE_RE.search(body)
            if not m:
                continue
            href, title = m.group(1), strip_tags(m.group(2))
            if not title:
                continue
            url = urljoin(base_url, href).split('#')[0]
            qid = None
            qm = _QID_RE.search(href)
            if qm:
                qid = qm.group(1)
            key = qid or url
            if key in seen:
                continue
            seen.add(key)
            out.append(SearchResult(
                url=url, title=title, result_id=qid,
                author=_field(body, 'qa-q-item-who-data'),
                timestamp=_field(body, 'qa-q-item-when-data'),
                category=_field(body, 'qa-q-item-where-data'),
                # Q2A's list view shows the title as the match context; the
                # full body is collected by following the result.
                snippet=title))
        return out

    def is_last_page(self, html, results, page, state=None):
        if not results or _NO_RESULTS_RE.search(html or ''):
            return True
        # Positive signal only: Q2A renders a next-offset link while more exist.
        return not re.search(r'href="[^"]*start=\d+', html or '', re.I)
