#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Search-driven collection engine
===============================

Collects by asking each source's OWN search function for the things we care
about, instead of walking a board looking for thread links.

Why: the onion diagnostic proved link discovery cannot see real hidden-service
content. AuditTeam's leak site renders victims as non-clickable cards (0
anchors -> 0 documents) and DarkForums shows a guest zero thread links. Both
expose a working search. Searching is also far less traffic against the
source than a full board walk, and every document it returns is relevant by
construction.

This module owns everything that is NOT platform-specific - Tor routing,
cookiejar auth, pagination control, following hits, dedupe, redaction,
storage, metrics and block classification. Platform selectors live only in
the SearchProvider adapters (forum_providers/*_search.py), so no forum's
markup ever leaks into the generic engine.

Guarantees:
  * An access/rejection page is NEVER stored. The same hard gate the crawl
    path uses is applied to every search page and every followed hit.
  * The query and the source's own match context are stored with each
    document, so the Intelligence UI can show WHY a result matched.
  * Dedupe is by canonical identity (thread id / URL), never a content hash,
    so a thread that gains replies is updated rather than re-stored.
  * Runs repeatedly: each run re-issues the configured queries, so newly
    published matching content is picked up over time.
"""

import json
import os
import re
import sys
import time
from hashlib import sha256
from urllib.parse import urlparse

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import forum_crawl
from lib import forum_documents
from lib import forum_ingest
from lib import forum_metrics
from lib import forum_registry
from lib import forum_session
from lib.forum_providers import base as fp_base
from lib.forum_providers.search_base import strip_tags

# Safety limits. Backstops against a runaway loop, not collection targets.
MAX_PAGES_PER_QUERY = int(os.environ.get('FORUM_SEARCH_MAX_PAGES', 10))
MAX_RESULTS_PER_QUERY = int(os.environ.get('FORUM_SEARCH_MAX_RESULTS', 200))
# Politeness: search is cheaper than a board walk, but still paced.
PAGE_PAUSE_SECONDS = float(os.environ.get('FORUM_SEARCH_PAUSE', 1.5))
# Some forums rate-limit their SEARCH (MyBB's "wait N seconds" flood control).
# When a provider reports such a page, pace and retry the same search a bounded
# number of times instead of recording the query as empty. The wait honoured is
# the interval the board itself states, capped so a hostile value can't stall a
# scan indefinitely.
MAX_SEARCH_FLOOD_RETRIES = int(os.environ.get('FORUM_SEARCH_FLOOD_RETRIES', 2))
MAX_SEARCH_FLOOD_WAIT = int(os.environ.get('FORUM_SEARCH_FLOOD_MAX_WAIT', 45))

# A domain-shaped query: valid labels + a real TLD, no spaces. Plain keywords
# ("combolist", "ransomware", "credentials") never match, so they never take
# the domain fallback path below.
_DOMAIN_RE = re.compile(
    r'^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$', re.I)


def _is_domain_query(query):
    q = (query or '').strip()
    return bool(q) and ' ' not in q and '.' in q and bool(_DOMAIN_RE.match(q))


def _domain_fallback_keyword(query):
    """The registrable label MyBB actually indexes - 'gmail' for 'gmail.com',
    'company' for 'company.co.uk', 'example' for 'sub.example.com'. PSL-aware,
    so multi-part public suffixes (co.uk) are handled, not naively split."""
    try:
        from lib.psl_faup import PSLFaup
        f = PSLFaup()
        f.decode(query.strip())
        label = f.get_domain_without_tld()
        if label:
            return label
    except Exception:
        pass
    parts = (query or '').strip().split('.')
    return parts[-2] if len(parts) >= 2 else None


def get_search_provider(forum_id, provider_hint=None):
    """Resolve the search adapter for a forum. Explicit hint wins, then the
    platform recorded on the forum, then the host."""
    from lib.forum_providers.mybb_search import MyBBSearchProvider
    from lib.forum_providers.torch_search import TorchSearchProvider
    from lib.forum_providers.q2a_search import Q2ASearchProvider
    from lib.forum_providers.xenforo_search import XenForoSearchProvider

    registry = {'mybb_search': MyBBSearchProvider, 'mybb': MyBBSearchProvider,
                'torch_search': TorchSearchProvider, 'torch': TorchSearchProvider,
                'q2a_search': Q2ASearchProvider, 'q2a': Q2ASearchProvider,
                'xenforo_search': XenForoSearchProvider,
                'xenforo': XenForoSearchProvider}
    if provider_hint and provider_hint in registry:
        return registry[provider_hint]()
    forum, code = forum_registry.get_forum(forum_id)
    if code == 200:
        prov = (forum.get('search_provider') or forum.get('provider') or '').lower()
        if prov in registry:
            return registry[prov]()
        host = (urlparse(forum.get('url') or '').hostname or '').lower()
        if host.startswith('torch'):
            return TorchSearchProvider()
        # No explicit provider on the forum record (the common case right after
        # registration, which stores only source_type). Fall back to the SAME
        # per-domain platform map the collection side uses, so native search and
        # session validation resolve an adapter without a manual set_provider.
        from lib import forum_providers
        platform = (forum_providers.platform_for_forum(forum_id)
                    or forum_providers.platform_for_forum(host))
        if platform in registry:
            return registry[platform]()
    return None


def _fetch_search(backend, req, metrics):
    """Run one SearchRequest through the shared transport. Returns
    (html, final_url, error)."""
    try:
        if req.method == 'POST':
            resp = backend.http.post(req.url, data=req.data, timeout=90,
                                     allow_redirects=True)
        else:
            params = req.data if req.method == 'GET' else None
            resp = backend.http.get(req.url, params=params, timeout=90,
                                    allow_redirects=True)
    except Exception as e:
        return None, req.url, f'{type(e).__name__}: {str(e)[:160]}'

    metrics.pages_fetched += 1
    body = resp.text or ''
    if resp.status_code in (401, 403):
        return body, resp.url, f'HTTP {resp.status_code}'
    if resp.status_code != 200:
        return body, resp.url, f'HTTP {resp.status_code}'
    return body, resp.url, None


def _gate(html, provider, has_cookies):
    """HARD GATE - an access/rejection page must never become a document.
    Raises with a precise classification, or returns None when the page is
    genuinely content."""
    info = fp_base.classify_block(strip_tags(html or ''), html)
    if not info:
        return None
    if info['category'] in (fp_base.BLOCK_ANTISPAM, fp_base.BLOCK_AUTH,
                            fp_base.BLOCK_SESSION):
        detail = f"{info['reason']}: {info['message']}" if info.get('message') else info['reason']
        raise fp_base.AccessRejected(detail, info=info)
    raise fp_base.BlockedError(f"blocked: {info['signature']}", info=info)


def _walk_search(backend, forum_id, forum_name, provider, base_url, search_term,
                 metrics, follow_results, max_pages, has_cookies, logger,
                 matched_query=None, require_content=None):
    """Walk one search term's result pages, ingesting each hit. Returns
    (discovered_count, stop_reason).

    `matched_query` lets the domain fallback record the ORIGINAL user query on
    stored documents even though the SEARCH term was the registrable label.
    `require_content` is passed through to _ingest_result as the exact-match
    gate. Raises AccessRejected/BlockedError up to the caller, unchanged."""
    discovered = 0
    reason = None
    state = {}
    seen_sets = []
    for page in range(1, max_pages + 1):
        req = provider.build_search(base_url, search_term, page, state)
        html, final_url, err = _fetch_search(backend, req, metrics)
        # Search-flood pacing: a "wait N seconds before searching again" page is
        # HTTP 200 with no results and is NOT an access block. Honour the stated
        # interval and retry the identical search rather than losing the query.
        flood_tries = 0
        while err is None and flood_tries < MAX_SEARCH_FLOOD_RETRIES:
            wait = provider.search_retry_after(html)
            if not wait:
                break
            wait = min(int(wait) + 2, MAX_SEARCH_FLOOD_WAIT)
            logger(f'[{forum_id}] "{search_term}" p{page}: search rate-limited, '
                   f'waiting {wait}s (retry {flood_tries + 1}/{MAX_SEARCH_FLOOD_RETRIES})')
            time.sleep(wait)
            html, final_url, err = _fetch_search(backend, req, metrics)
            flood_tries += 1
        if err:
            metrics.note_error(f'search "{search_term}" p{page}: {err}')
            # Let a recognised challenge/anti-spam/auth PAGE classify itself.
            _gate(html, provider, has_cookies)
            # ONLY 401/403 are auth/session refusals on a members-only search.
            # A 404, 429, timeout or 5xx is a transport/upstream problem (e.g.
            # Cloudflare throttling a rapid second search) and must NOT flip the
            # stored session to "expired" - doing so is what made a working,
            # authenticated session read as expired after a single 404.
            if err in ('HTTP 401', 'HTTP 403') and provider.search_requires_auth:
                info = fp_base.build_block_info(
                    fp_base.BLOCK_SESSION if has_cookies else fp_base.BLOCK_AUTH,
                    reason=('stored session rejected by the forum'
                            if has_cookies else
                            'this forum\'s search requires an authenticated account'))
                raise fp_base.AccessRejected(
                    f'search requires authentication ({err})', info=info)
            break
        _gate(html, provider, has_cookies)

        if page == 1:
            state['results_url'] = final_url

        results = provider.extract_results(html, final_url, search_term)
        metrics.documents_discovered += len(results)
        discovered += len(results)
        logger(f'[{forum_id}] "{search_term}" page {page}: {len(results)} results')

        # Repeated result set = we are looping on the same page.
        fingerprint = tuple(sorted(r.url for r in results))
        if fingerprint and fingerprint in seen_sets:
            reason = fp_base.STOP_NO_NEW_RESULTS
            break
        seen_sets.append(fingerprint)

        for result in results:
            if metrics.documents_parsed >= MAX_RESULTS_PER_QUERY:
                break
            outcome = _ingest_result(backend, forum_id, forum_name, result,
                                     matched_query or search_term, provider,
                                     metrics, follow_results, logger,
                                     require_content=require_content)
            if outcome == 'stored':
                metrics.documents_stored += 1
            elif outcome == 'duplicate':
                metrics.duplicates_skipped += 1
            else:
                metrics.documents_rejected += 1
            metrics.documents_parsed += 1
            forum_metrics.update_progress(
                forum_id, pages=metrics.pages_fetched,
                documents=metrics.documents_parsed,
                new=metrics.documents_stored)

        if provider.is_last_page(html, results, page, state):
            reason = fp_base.STOP_NO_MORE_PAGES
            break
        time.sleep(PAGE_PAUSE_SECONDS)
    return discovered, reason


def run_search_collection(forum_id, queries=None, follow_results=True,
                          max_pages=None, logger=print):
    """Search `forum_id` for each configured query and store what matches.

    Returns the CrawlMetrics dict, with the same shape the crawl path
    produces so the dashboard, history and metrics all keep working.
    """
    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        return {'error': 'unknown forum'}
    queries = [q for q in (queries or forum_registry.get_search_queries(forum_id)) if q]
    if not queries:
        return {'error': 'no search queries configured for this forum'}

    provider = get_search_provider(forum_id)
    if provider is None:
        return {'error': f'no search adapter for {forum_id}'}

    route = forum_registry.resolve_route(forum_id)
    cookiejar_uuid = forum_registry.get_cookiejar(forum_id)
    # A forum with a persistent authenticated profile gets the browser tier so
    # its search runs through that established session; otherwise search stays
    # on the cheap HTTP path exactly as before.
    has_profile = forum_session.has_profile(forum_id)
    backend = forum_crawl.FetchBackend(allow_browser=has_profile, route=route,
                                       cookiejar_uuid=cookiejar_uuid,
                                       forum_id=forum_id)
    # "Do we hold an authenticated session?" - true only with real cookie
    # material or a profile last validated as live. A bare profile DIRECTORY is
    # not a session, so a 403 against it is a login wall (BLOCK_AUTH), not a
    # rejected session (BLOCK_SESSION). This keeps the classification honest.
    has_cookies = bool(backend.cookies) or (
        has_profile and forum_session.get_health(forum_id).get('state')
        == forum_session.SESSION_VALID)

    # Carry the authenticated persistent-profile session onto the HTTP tier the
    # native search actually uses. The browser tier is authenticated via the
    # profile, but _fetch_search runs over requests; without this the search
    # request is anonymous and a members-only search returns HTTP 403 even with
    # a valid session. Reuses the existing profile->requests cookie export - no
    # second auth system, no secret is ever logged. Only forums that have a
    # profile take this path, so onion/Tor forums are unaffected.
    if has_profile:
        # Verify/PRIME the session first rather than firing an anonymous HTTP
        # request at a members-only search. validate_session() fetches the
        # authenticated-only probe (usercp.php) THROUGH the persistent browser
        # profile, which both classifies the session and refreshes MyBB's
        # ephemeral session cookie in the profile - so the export below carries
        # a live, primed session instead of a stale one. This is the existing
        # session mechanism (no new auth, no CAPTCHA bypass); it is the fix for
        # the "unprimed session -> intermittent 403" race. Never fatal: a probe
        # that comes back expired/login-required still falls through to the
        # search, where the engine classifies and records health honestly.
        probe_url = provider.session_probe_url(forum.get('url'))
        if probe_url:
            try:
                state, _d = forum_session.validate_session(
                    forum_id, probe_url, provider=provider, route=route,
                    logger=logger)
                has_cookies = has_cookies or state == forum_session.SESSION_VALID
            except Exception as e:
                logger(f'[{forum_id}] session prime skipped: {type(e).__name__}')
        for _c in forum_session.export_cookies(forum_id, route=route):
            try:
                backend.http.cookies.set(_c['name'], _c['value'],
                                         domain=_c.get('domain') or None)
            except Exception:
                continue
    metrics = forum_crawl.CrawlMetrics(forum_id, provider.id)
    max_pages = int(max_pages or MAX_PAGES_PER_QUERY)
    base_url = forum.get('url')
    forum_name = forum.get('name') or forum_id
    reason = None

    logger(f'[{forum_id}] search collection via {provider.name} '
           f'({route.get("mode")}), {len(queries)} query/queries, '
           f'cookiejar={"yes" if has_cookies else "none"}')

    try:
        for query in queries:
            discovered, reason = _walk_search(
                backend, forum_id, forum_name, provider, base_url, query,
                metrics, follow_results, max_pages, has_cookies, logger)
            # DOMAIN FALLBACK: MyBB's full-text tokenizer strips punctuation, so
            # a dotted domain ("gmail.com") can return 0 even when it exists in
            # posts. Only for a domain-shaped query, and only when the exact
            # dotted form found nothing, recover candidates via the registrable
            # label ("gmail") and require the EXACT domain in the fetched thread
            # content before accepting (the require_content gate). Keyword
            # searches never reach this branch.
            if discovered == 0 and _is_domain_query(query):
                fb = _domain_fallback_keyword(query)
                if fb and fb.lower() != query.lower():
                    logger(f'[{forum_id}] domain "{query}": 0 native hits for the '
                           f'dotted form; controlled fallback via label "{fb}" '
                           f'with exact-content gate')
                    # Pace the second search - MyBB/Cloudflare throttle rapid
                    # back-to-back searches, which is what returned the 404.
                    time.sleep(PAGE_PAUSE_SECONDS)
                    _, reason = _walk_search(
                        backend, forum_id, forum_name, provider, base_url, fb,
                        metrics, True, max_pages, has_cookies, logger,
                        matched_query=query, require_content=query)

    except fp_base.AccessRejected as e:
        metrics.note_error(str(e))
        metrics.block_category = e.category
        metrics.block_info = e.info
        reason = str(e)
        logger(f'[{forum_id}] SEARCH ACCESS REJECTED: {e}')
    except fp_base.BlockedError as e:
        metrics.note_error(str(e))
        info = getattr(e, 'info', None) or {}
        metrics.block_category = info.get('category')
        metrics.block_info = info
        reason = f'{fp_base.STOP_ACCESS_DENIED}: {e}'
        logger(f'[{forum_id}] SEARCH BLOCKED: {e}')
    except Exception as e:
        metrics.note_error(f'{type(e).__name__}: {e}')
        reason = f'{fp_base.STOP_FATAL}: {e}'
    finally:
        backend.close()

    metrics.finish(reason or fp_base.STOP_NO_MORE_PAGES)
    payload = metrics.to_dict()
    forum_metrics.record_run(forum_id, payload)
    forum_registry.set_document_count(forum_id, forum_ingest.count_documents(forum_id))
    forum_registry.record_crawl_result(
        forum_id, success=not metrics.block_category and metrics.documents_stored >= 0
        and not str(reason or '').startswith(fp_base.STOP_FATAL),
        error=str(reason) if metrics.block_category else None)

    # Per-forum session health, derived from what the crawl actually hit. This
    # only speaks for a forum that has a persistent profile - it is how an
    # expired session on ONE forum surfaces (and pauses just that forum) while
    # every other forum keeps collecting. A challenge/expired page is never
    # stored; only its classification is recorded here.
    if has_profile:
        cat = metrics.block_category
        if cat == fp_base.BLOCK_SESSION:
            forum_session.record_health(forum_id, forum_session.SESSION_EXPIRED,
                                        'stored session rejected during search')
        elif cat == fp_base.BLOCK_AUTH:
            forum_session.record_health(forum_id, forum_session.SESSION_LOGIN_REQUIRED,
                                        'search requires an authenticated account')
        elif cat in (fp_base.BLOCK_CHALLENGE, fp_base.BLOCK_NETWORK):
            forum_session.record_health(forum_id, forum_session.SESSION_CHALLENGE,
                                        'anti-bot challenge during search')
        elif not cat:
            forum_session.record_health(forum_id, forum_session.SESSION_VALID)

    logger(f'[{forum_id}] search done: {metrics.documents_stored} stored / '
           f'{metrics.documents_discovered} discovered / {reason}')

    # Collection-time evidence screenshots: capture authenticated per-thread
    # screenshots for stored documents that don't have one yet, so every
    # finding surfaced from this forum carries a real screenshot of the thread
    # (rendered through the persistent logged-in session, never a login wall).
    # Bounded and best-effort - one browser session for the whole pass, capped
    # per run; the rest are picked up on the next collection or a backfill. A
    # block (expired session/challenge) skips it: no point shooting a wall.
    if has_profile and not metrics.block_category:
        try:
            from lib import forum_screenshots
            shot_stats = forum_screenshots.capture_missing(forum_id, logger=logger)
            if shot_stats.get('captured') or shot_stats.get('failed'):
                logger(f'[{forum_id}] evidence screenshots: '
                       f'{shot_stats.get("captured", 0)} captured, '
                       f'{shot_stats.get("failed", 0)} failed')
        except Exception as e:
            logger(f'[{forum_id}] screenshot pass skipped: {type(e).__name__}: {e}')
    return payload


def _build_match_reason(forum_name, query, result, doc):
    """Explicit, human-readable justification for this document's presence.

    Derived from what the source actually returned - never asserted. If the
    query cannot be located in any retrieved field, that is said plainly
    rather than claiming a match we cannot point to.
    """
    where = []
    q = (query or '').lower()
    if q and q in (result.title or '').lower():
        where.append('thread title')
    if q and q in (result.snippet or '').lower():
        where.append('search snippet')
    if q and q in (doc.get('text') or '').lower():
        where.append('post content')
    location = ', '.join(where) if where else None
    parts = [f'Returned by {forum_name} native search for query "{query}"']
    if location:
        parts.append(f'matched in {location}')
    else:
        parts.append('the source ranked it as a match but the term does not '
                     'appear verbatim in the retrieved fields')
    if result.category:
        parts.append(f'category "{result.category}"')
    if result.author:
        parts.append(f'author "{result.author}"')
    return '; '.join(parts)


def _ingest_result(backend, forum_id, forum_name, result, query, provider,
                   metrics, follow_results, logger, require_content=None):
    """Turn one search hit into a stored canonical document.

    `require_content` is the domain-fallback exact-match gate: when set, the
    fetched thread content MUST contain that exact string (case-insensitive) or
    the hit is rejected. This is what keeps the label fallback (searching
    "gmail" to recover "gmail.com" candidates MyBB's tokenizer missed) honest -
    a thread that only mentions "gmail" but not "gmail.com" is never stored."""
    r = forum_ingest._r()
    doc_id = forum_documents.canonical_doc_id(
        forum_id, thread_id=result.result_id, url=result.url)
    if not doc_id:
        return 'rejected'
    id_key = f'forumdoc:id:{forum_id}'
    already = r.sismember(id_key, doc_id)

    html = text = None
    if follow_results and result.url:
        try:
            html, text, err = forum_crawl.fetch_thread(backend, result.url, metrics)
            if err:
                # 404/410 means the source's own search index still lists a
                # thread that has since been removed. That is upstream
                # staleness, not a collection failure - counting it as an
                # error made a working forum report errors it did not cause.
                if '404' in str(err) or '410' in str(err):
                    metrics.stale_results += 1
                else:
                    metrics.note_error(f'result {result.url}: {err}')
                html = text = None
        except fp_base.BlockedError:
            # A blocked HIT must not abort the whole search - the rest of the
            # result set is still collectable.
            html = text = None
        except Exception as e:
            metrics.note_error(f'result {result.url}: {type(e).__name__}')
            html = text = None

    if html and text:
        gate = fp_base.classify_block(text, html)
        if gate:
            # Never store an access page as a document.
            html = text = None

    # Domain-fallback exact-match gate. The exact domain must actually occur in
    # the RETRIEVED thread content; if it doesn't (or the thread couldn't be
    # fetched to verify), reject rather than store a label-only match.
    if require_content is not None:
        if not text or require_content.lower() not in text.lower():
            return 'rejected'

    reparsed = bool(html and text and len(text.strip()) >= 50)
    if reparsed:
        doc = forum_documents.parse_document(html, text, result.url, forum_id,
                                             thread_id=result.result_id,
                                             title=result.title)
        if metrics and doc.get('attachments'):
            metrics.attachments_discovered += len(doc['attachments'])
        # The search LISTING often carries author/date/category that the thread
        # page markup does not expose to the generic parser. Keep the source's
        # own values rather than discarding them for an empty extraction.
        for field, value in (('author', result.author),
                             ('timestamp', result.timestamp)):
            if value and not doc.get(field):
                doc[field] = value
    else:
        # Fall back to the search result itself. Still a real document - the
        # source's own title + match context - never fabricated content.
        body = result.snippet or result.title or ''
        if not body.strip():
            return 'rejected'
        redacted, _secret_counts = forum_documents.redact_secrets(body)
        doc = {
            'forum_id': forum_id, 'thread_url': result.url,
            'post_url': result.url, 'thread_id': result.result_id,
            'post_id': None, 'title': result.title, 'author': result.author,
            'timestamp': result.timestamp,
            'text': redacted,
            'text_truncated': False, 'links': [], 'domains': [],
            'keywords': [], 'attachments': [], 'indicators': {},
        }

    # Match context - why this document is in the corpus. `match_snippet` is
    # the source's own words; `match_reason` is the explicit justification the
    # UI shows, naming the query, where it hit and which field carried it.
    doc['matched_query'] = query
    doc['match_snippet'] = (result.snippet or '')[:400]
    doc['match_category'] = result.category or ''
    doc['collection_mode'] = 'search'
    doc['match_reason'] = _build_match_reason(forum_name, query, result, doc)

    content_hash = sha256((doc.get('text') or '').encode()).hexdigest()
    if already:
        update = {
            'last_seen': int(time.time()),
            'text': doc.get('text') or '',
            'matched_query': query,
            'match_snippet': doc['match_snippet'],
            # Keep the justification consistent with the query this document is
            # NOW attributed to - otherwise a thread first collected under one
            # query and re-matched by another shows a stale reason naming the
            # wrong query (matched_query says X, match_reason says Y).
            'match_reason': doc['match_reason'],
            'match_category': doc.get('match_category') or '',
            'collection_mode': 'search',
            'content_hash': content_hash,
        }
        # Refresh attachments/images too, but ONLY when the thread was actually
        # re-fetched and parsed - otherwise a follow that failed would wipe an
        # existing document's evidence. This is what corrects already-stored
        # documents (e.g. dropping the bogus canary.txt, adding real images) on
        # the next search without a destructive re-collection.
        if reparsed:
            update['attachments'] = json.dumps(doc.get('attachments') or [])
            update['images'] = json.dumps(doc.get('images') or [])
        r.hset(f'forumdoc:full:{forum_id}:{doc_id}', mapping=update)
        return 'duplicate'

    forum_ingest._store_document(forum_id, doc_id, doc, content_hash)
    forum_ingest._index_and_alert(forum_id, forum_name, doc_id, doc, content_hash)
    return 'stored'
