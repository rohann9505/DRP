#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Leak / disclosure intelligence structuring.

Turns a leak-site disclosure payload (and the ransomware.live victim record
that points at it) into structured intelligence the UI can render as tables
instead of a raw JSON blob.

Two problems this solves, both observed live:

 1. Ransomware-group leak sites expose a real disclosure API - the Silent
    group's, for example, returns `files`, `screenshots`, `tag_details`,
    `filesCount`, `filesSizes`, `zip_link`, `unix_date`, `company_name`. All of
    that was being shown to the analyst as an unreadable JSON string baked into
    a screenshot image, with the finding table carrying only victim/domain/
    attacker/date.

 2. ransomware.live's own record carries sector, country, the group's claim
    text, discovery time, press attribution and an `infostealer` block with
    per-family compromise counts. The normaliser dropped all of it.

Nothing here invents data: every field is emitted only when the source
actually provides it, and `parse_disclosure` records which keys it did not
recognise (`extra`) rather than discarding them.

SECURITY: this module classifies and COUNTS sensitive data. It never emits a
password, token, key or other usable secret - see classify_indicators() and
forum_documents.redact_secrets(), which is reused for sample text.
"""

import os
import re
import sys
from datetime import datetime, timezone

sys.path.append(os.environ['AIL_BIN'])


# ---------------------------------------------------------------------------
# File-type classification
#
# Drives both the "what kind of leak is this" badges and the unsafe-attachment
# warning. Shares its vocabulary with forum_documents.INTERESTING_EXTENSIONS so
# a .sql means the same thing in a forum post and in a disclosure listing.
# ---------------------------------------------------------------------------
FILE_CATEGORIES = {
    'database':    {'sql', 'db', 'sqlite', 'mdb', 'bak', 'dump', 'bson'},
    'archive':     {'zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'tgz'},
    'document':    {'pdf', 'doc', 'docx', 'rtf', 'odt', 'ppt', 'pptx'},
    'spreadsheet': {'xls', 'xlsx', 'csv', 'ods'},
    'source_code': {'py', 'js', 'java', 'c', 'cpp', 'cs', 'go', 'rb', 'php',
                    'ts', 'rs', 'swift', 'kt', 'sh'},
    'config':      {'env', 'ini', 'conf', 'cfg', 'yaml', 'yml', 'toml',
                    'properties', 'pem', 'key', 'pfx', 'p12', 'keystore'},
    'executable':  {'exe', 'dll', 'msi', 'bin', 'elf', 'apk', 'jar', 'so',
                    'bat', 'ps1', 'vbs', 'scr', 'com'},
    'image':       {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'svg', 'webp', 'tif'},
    'email':       {'eml', 'msg', 'pst', 'ost', 'mbox'},
    'text':        {'txt', 'log', 'json', 'xml', 'md', 'tsv'},
}

# Categories whose contents must never be fetched, previewed or offered as a
# download - only described.
UNSAFE_CATEGORIES = {'executable'}
# Config/key material is not "unsafe to run" but IS secret-bearing, so it gets
# the same no-preview treatment.
SECRET_BEARING_CATEGORIES = {'config'}


def classify_file(filename, declared_type=None):
    """Return (category, extension) for a leaked file reference."""
    name = (filename or '').strip()
    ext = ''
    if '.' in name:
        ext = name.rsplit('.', 1)[-1].lower()
        ext = re.sub(r'[^a-z0-9]', '', ext)
    if declared_type:
        d = str(declared_type).strip().lower().lstrip('.')
        if d and (not ext or d in {c for s in FILE_CATEGORIES.values() for c in s}):
            ext = d or ext
    for category, exts in FILE_CATEGORIES.items():
        if ext in exts:
            return category, ext
    return ('unknown', ext)


def is_unsafe(category):
    return category in UNSAFE_CATEGORIES


def previewable(category):
    """Only plain-text-ish content may be sampled, and even then the sample is
    redacted before storage. Executables and key material never are."""
    return category in ('text', 'source_code') and category not in SECRET_BEARING_CATEGORIES


# ---------------------------------------------------------------------------
# Sensitive-data indicators
#
# Tag names on leak sites are the group's own labels ("Full", "Accounting",
# "HR", "Client", "Confidentially" in the observed Silent payload). Mapping
# them to a normalised category lets the UI badge what kind of data is claimed
# without inventing anything - the original label is always kept alongside.
# ---------------------------------------------------------------------------
TAG_CATEGORY_PATTERNS = [
    ('credentials',   r'credential|password|passwd|login|account.?data|auth'),
    ('financial',     r'financ|account(ing|s)?\b|invoice|payroll|bank|payment|tax|billing'),
    ('pii',           r'\bpii\b|personal|passport|ssn|social.?secur|identity|driver|patient|medical|health'),
    ('hr',            r'\bhr\b|human.?resour|employee|staff|personnel'),
    ('customer',      r'client|customer|subscriber|user.?data'),
    ('confidential',  r'confidential|internal|nda|private|secret|proprietar'),
    ('source_code',   r'source.?code|repositor|git\b|svn'),
    ('database',      r'database|\bdb\b|dump|backup'),
    ('legal',         r'legal|contract|agreement|litigation'),
    ('full_dump',     r'^full$|complete|all.?data|entire'),
]

# Which normalised categories are treated as high-value intelligence. Used for
# badge severity, so the UI can highlight what matters without making every
# row shout.
CATEGORY_SEVERITY = {
    'credentials':  'CRITICAL',
    'api_keys':     'CRITICAL',
    'private_keys': 'CRITICAL',
    'pii':          'HIGH',
    'financial':    'HIGH',
    'database':     'HIGH',
    'source_code':  'HIGH',
    'confidential': 'HIGH',
    'customer':     'HIGH',
    'hr':           'MEDIUM',
    'legal':        'MEDIUM',
    'full_dump':    'CRITICAL',
    'malware':      'HIGH',
}

CATEGORY_LABELS = {
    'credentials':  'Credentials',
    'api_keys':     'API tokens',
    'private_keys': 'Private keys',
    'pii':          'PII',
    'financial':    'Financial data',
    'database':     'Database dump',
    'source_code':  'Source code',
    'confidential': 'Confidential/internal',
    'customer':     'Customer data',
    'hr':           'Employee/HR data',
    'legal':        'Legal documents',
    'full_dump':    'Full data dump',
    'malware':      'Executable/malware',
}


def categorise_tag(name):
    """Map a leak-site tag label to a normalised category, or None."""
    label = (name or '').strip().lower()
    if not label:
        return None
    for category, pattern in TAG_CATEGORY_PATTERNS:
        if re.search(pattern, label):
            return category
    return None


def _fmt_epoch(value):
    """Unix timestamp -> ISO-8601 UTC. Returns None for 0/absent, which the
    observed payload uses as 'no date' rather than 1970."""
    try:
        ts = int(value)
    except (TypeError, ValueError):
        return None
    if ts <= 0:
        return None
    if ts > 1e12:  # milliseconds
        ts = ts // 1000
    try:
        return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
    except (OSError, OverflowError, ValueError):
        return None


def _abs_url(path, base_url):
    """Leak sites return media paths relative to the disclosure host
    (e.g. '/media/screenshots/doc.jpg'). Resolve against the source URL so the
    analyst gets the real, copyable location."""
    if not path:
        return None
    path = str(path).strip()
    if path.startswith(('http://', 'https://')):
        return path
    if not base_url:
        return path
    from urllib.parse import urljoin
    return urljoin(base_url, path)


# ---------------------------------------------------------------------------
# Disclosure parsing
# ---------------------------------------------------------------------------

# Keys consumed by parse_disclosure. Anything else on the record is preserved
# under 'extra' rather than dropped, so a leak site that adds a field does not
# silently lose it.
_KNOWN_KEYS = {
    'id', 'title', 'description', 'company', 'company_name', 'status',
    'view_number', 'zip_link', 'unix_date', 'filesCount', 'filesSizes',
    'files', 'screenshots', 'tag_details', 'tags',
}


def parse_disclosure(record, source_url=None):
    """
    Structure ONE disclosure record from a leak site's API.

    Shaped from the real Silent-group payload:
        {"id":2,"title":"Full","filesCount":950221,"filesSizes":"854GB",
         "description":null,"view_number":14,"status":true,"zip_link":null,
         "unix_date":0,"company":2,"company_name":"Versa Networks",
         "screenshots":[{"id":6,"url":"/media/screenshots/doc.jpg"},...],
         "tag_details":[{"id":5,"name":"Full","status":true},...],
         "files":[]}

    Every field is optional - absent ones are simply not emitted.
    """
    if not isinstance(record, dict):
        return None

    out = {
        'disclosure_id': record.get('id'),
        'title': record.get('title') or None,
        'description': record.get('description') or None,
        'company_id': record.get('company'),
        'company_name': record.get('company_name') or None,
        'status': record.get('status'),
        'view_number': record.get('view_number'),
        'source_url': source_url,
        'files_count': record.get('filesCount'),
        'files_total_size': record.get('filesSizes') or None,
        'zip_link': None,
        'zip_available': False,
        'posted_at_unix': record.get('unix_date'),
        'posted_at': _fmt_epoch(record.get('unix_date')),
        'files': [],
        'screenshots': [],
        'tags': [],
        'categories': {},
        'extra': {},
    }

    # ZIP/download status. A null zip_link is meaningful intelligence ("the
    # group has not published a bulk download yet"), so it is reported as an
    # explicit status rather than an empty cell.
    zip_link = record.get('zip_link')
    if zip_link:
        out['zip_link'] = _abs_url(zip_link, source_url)
        out['zip_available'] = True

    # ---- files ----------------------------------------------------------
    for f in (record.get('files') or []):
        if not isinstance(f, dict):
            continue
        name = (f.get('name') or f.get('filename') or f.get('title')
                or f.get('url') or '')
        if name and '/' in str(name):
            name = str(name).rsplit('/', 1)[-1]
        category, ext = classify_file(name, f.get('type'))
        entry = {
            'id': f.get('id'),
            'name': name or None,
            'extension': ext or None,
            'category': category,
            'url': _abs_url(f.get('url') or f.get('link'), source_url),
            'size': f.get('size') or f.get('filesize') or None,
            'date_unix': f.get('unix_date') or f.get('date'),
            'date': _fmt_epoch(f.get('unix_date') or f.get('date')),
            'unsafe': is_unsafe(category),
            'previewable': previewable(category),
        }
        out['files'].append(entry)
        if entry['unsafe']:
            _bump(out['categories'], 'malware')
        if category == 'database':
            _bump(out['categories'], 'database')
        elif category == 'source_code':
            _bump(out['categories'], 'source_code')
        elif category == 'config':
            # Config/key material implies secrets are present; the COUNT is
            # reported, never the contents.
            _bump(out['categories'], 'private_keys')

    # ---- screenshots ----------------------------------------------------
    for s in (record.get('screenshots') or []):
        if isinstance(s, dict):
            url = _abs_url(s.get('url'), source_url)
            if url:
                out['screenshots'].append({'id': s.get('id'), 'url': url})
        elif isinstance(s, str):
            url = _abs_url(s, source_url)
            if url:
                out['screenshots'].append({'id': None, 'url': url})

    # ---- tags -----------------------------------------------------------
    raw_tags = record.get('tag_details')
    if not isinstance(raw_tags, list):
        raw_tags = record.get('tags') if isinstance(record.get('tags'), list) else []
    for t in raw_tags:
        if isinstance(t, dict):
            name = t.get('name')
            tag = {'id': t.get('id'), 'name': name,
                   'status': t.get('status'), 'category': categorise_tag(name)}
        elif isinstance(t, str):
            tag = {'id': None, 'name': t, 'status': None,
                   'category': categorise_tag(t)}
        else:
            continue
        out['tags'].append(tag)
        if tag['category']:
            _bump(out['categories'], tag['category'])

    # Preserve anything the leak site sends that we do not model yet.
    for k, v in record.items():
        if k not in _KNOWN_KEYS:
            out['extra'][k] = v

    out['indicators'] = build_indicators(out['categories'])
    return out


def _bump(counter, key, by=1):
    counter[key] = counter.get(key, 0) + by


def build_indicators(categories):
    """Turn category counts into display-ready, severity-ranked badges.

    Emits presence/counts ONLY - never a secret value. e.g.
        {'category':'credentials','label':'Credentials','count':24,
         'severity':'CRITICAL','text':'Credentials detected — 24 records'}
    """
    out = []
    for cat, count in (categories or {}).items():
        label = CATEGORY_LABELS.get(cat, cat.replace('_', ' ').title())
        severity = CATEGORY_SEVERITY.get(cat, 'MEDIUM')
        if count and count > 1:
            text = f'{label} detected — {count} records'
        else:
            text = f'{label} detected'
        out.append({'category': cat, 'label': label, 'count': count,
                    'severity': severity, 'text': text})
    order = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}
    out.sort(key=lambda i: (order.get(i['severity'], 9), -(i['count'] or 0)))
    return out


# ---------------------------------------------------------------------------
# Infostealer intelligence (ransomware.live victim record)
# ---------------------------------------------------------------------------

def parse_infostealer(block):
    """Structure the `infostealer` block. Real compromise counts per malware
    family - the highest-value field the old normaliser was discarding."""
    if not isinstance(block, dict):
        return None
    stats = block.get('infostealer_stats')
    families = []
    if isinstance(stats, dict):
        for name, count in stats.items():
            try:
                count = int(count)
            except (TypeError, ValueError):
                continue
            families.append({'family': name, 'count': count})
        families.sort(key=lambda f: -f['count'])
    return {
        'users': _int_or_none(block.get('users')),
        'users_url': _int_or_none(block.get('users_url')),
        'employees': _int_or_none(block.get('employees')),
        'employees_url': _int_or_none(block.get('employees_url')),
        'thirdparties': _int_or_none(block.get('thirdparties')),
        'last_user_compromised': block.get('last_user_compromised') or None,
        'last_employee_compromised': block.get('last_employee_compromised') or None,
        'updated': block.get('update') or None,
        'families': families,
        'total_infections': sum(f['count'] for f in families),
    }


def _int_or_none(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def safe_sample(text, limit=400):
    """Redacted, size-capped sample of text-file content.

    Reuses forum_documents.redact_secrets so a sample can never carry a
    password, token or key - the same guarantee the forum corpus has.
    """
    if not text:
        return None, {}
    try:
        from lib import forum_documents
        redacted, counts = forum_documents.redact_secrets(text[:limit * 4])
    except Exception:
        return None, {}
    sample = redacted[:limit]
    if len(redacted) > limit:
        sample += '…'
    return sample, counts
