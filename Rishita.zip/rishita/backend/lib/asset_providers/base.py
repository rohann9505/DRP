#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Asset Provider base interface
===================

Every discovery category (dns, whois, subdomains, liveness, technologies,
security_config, directory_enum, ports, vulnerabilities, web_scan) can have
multiple registered providers - a real implementation today, plus one or
more "not installed yet" stubs standing in for a future tool integration
(Subfinder, Naabu, Nuclei, ...). The orchestrator (see __init__.py's
run_category) only ever calls is_available() and collect() through this
one interface, so adding, replacing, or disabling a tool never touches
asset_jobs.py's orchestration logic.
"""

import os
import shutil
import subprocess

# Severity vocabulary shared by every provider that emits a finding, so the
# dashboard can rank, colour and filter findings from unrelated checks
# (TLS, email auth, headers, WAF, ...) on one scale. Ordered most-severe
# first - SEVERITY_ORDER.index() is the sort key the UI and reports use.
SEVERITY_ORDER = ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO')


def add_finding(context, category, title, severity='INFO', detail='', fqdn=None):
    """Appends one normalized finding to the scan-wide list.

    Providers own their own raw data shape, but findings are deliberately
    uniform: without a single list, a "severity-based findings" view would
    have to know the internals of every provider, which is exactly the
    coupling the provider interface exists to prevent.
    """
    context.setdefault('findings', []).append({
        'category': category,
        'title': title,
        'severity': severity if severity in SEVERITY_ORDER else 'INFO',
        'detail': detail,
        'fqdn': fqdn,
    })


# Scanner binaries are installed here rather than into /usr/local/bin,
# which is not writable in this deployment. Searched ahead of PATH so a
# tool we installed deliberately always wins over a same-named binary that
# happens to be on the system (see binary_identity below for why that
# matters).
TOOLS_BIN_DIR = os.path.join(
    os.environ.get('AIL_HOME') or os.path.dirname(os.environ.get('AIL_BIN', '/opt/ail-framework/backend').rstrip('/')),
    'tools', 'bin')


def resolve_binary(name):
    """Absolute path to `name` in the bundled tools dir, else on PATH, else None."""
    local = os.path.join(TOOLS_BIN_DIR, name)
    if os.path.isfile(local) and os.access(local, os.X_OK):
        return local
    return shutil.which(name)


class AssetProvider:
    id = 'base'
    name = 'Base Provider'
    category = None
    requires_binary = None

    # Name of the key this provider needs, looked up through get_api_key().
    # Enforced by is_available() below - a provider that needs a key it does
    # not have reports itself unavailable rather than failing at scan time.
    requires_api_key = None

    # Optional (args, marker): a name on PATH is not proof it is the tool we
    # mean. Confirmed case - `httpx` resolves to the Python HTTP client's CLI
    # (both in AILENV and via Debian's python3-httpx), not ProjectDiscovery's
    # Go binary, so a name-only check reported the HTTPx provider as active
    # when nothing could actually run. When set, the binary must identify
    # itself. Note the marker is matched against the tool's OWN version
    # output, which is not always the vendor name - nuclei prints "Nuclei
    # Engine Version", never "projectdiscovery".
    binary_identity = None

    def __init__(self):
        self._identity_cache = {}

    def get_api_key(self):
        """Key material for providers that need it. Stored in Kvrocks via
        asset_keys.py, mirroring ransomware_live.get_api_key()."""
        if not self.requires_api_key:
            return None
        from lib import asset_keys
        return asset_keys.get_api_key(self.requires_api_key)

    def binary_path(self):
        return resolve_binary(self.requires_binary) if self.requires_binary else None

    def is_available(self):
        """True if this provider can actually run right now: its binary is
        present AND is really that tool, and any required API key is
        configured. Overridden by providers whose dependency is a Python
        package instead."""
        if self.requires_api_key and not self.get_api_key():
            return False
        if not self.requires_binary:
            return True
        path = self.binary_path()
        if not path:
            return False
        if not self.binary_identity:
            return True
        # Cached per resolved path: this runs on every dashboard render, and
        # keying on the path means installing the real tool elsewhere still
        # gets re-checked rather than being masked by a stale answer.
        if path not in self._identity_cache:
            args, marker = self.binary_identity
            try:
                proc = subprocess.run([path, *args], capture_output=True, timeout=5, text=True)
                blob = f'{proc.stdout}{proc.stderr}'.lower()
                self._identity_cache[path] = marker.lower() in blob
            except (OSError, subprocess.SubprocessError):
                self._identity_cache[path] = False
        return self._identity_cache[path]

    def collect(self, target_domain, context):
        """Must never raise - any internal failure is caught and returned
        as {'ok': False, 'error': ...} so one misbehaving provider never
        takes down a whole scan job. `context` is a plain dict the
        orchestrator uses to share already-fetched data between providers
        in the same category group (e.g. the one HTTP response liveness/
        technologies/security_config all read from) - see __init__.py."""
        return self._unavailable_result()

    def _unavailable_result(self):
        # Distinguish the three ways a provider can be unusable - "not
        # installed" was previously reported even when the binary was on
        # PATH but was the wrong tool, which is actively misleading.
        if self.requires_api_key and not self.get_api_key():
            reason = f'not configured - no {self.requires_api_key} API key set'
        elif self.requires_binary and not self.binary_path():
            reason = f'not configured - {self.requires_binary} is not installed'
        elif self.requires_binary and not self.is_available():
            reason = (f'not configured - the {self.requires_binary} on PATH is not '
                      f'the expected tool')
        else:
            reason = 'not configured'
        return {'ok': False, 'provider': self.id, 'data': None, 'error': reason}

    def safe_collect(self, target_domain, context):
        if not self.is_available():
            return self._unavailable_result()
        try:
            result = self.collect(target_domain, context)
            result.setdefault('provider', self.id)
            return result
        except Exception as e:
            return {'ok': False, 'provider': self.id, 'data': None, 'error': str(e)}
