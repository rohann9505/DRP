#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Nuclei vulnerability scanning (ProjectDiscovery).

Runs the real binary and parses its JSONL output into the shared finding
shape, so results land in exactly the same severity-ranked list as the
keyless providers' findings and reach the alert pipeline through
asset_jobs.run_job()'s existing CRITICAL handling - no orchestration
changes.

Scope is deliberately conservative for an unattended scanner pointed at
third-party infrastructure:
  * only the hosts liveness already proved are up, capped at MAX_TARGETS
  * template severities limited to SCAN_SEVERITIES (no 'info' flood)
  * -dast, fuzzing and code-protocol templates excluded: those actively
    manipulate input and execute template code, which is well past the
    "safe, non-intrusive" line for an asset-monitoring product
  * rate-limited and bounded by an overall timeout
"""

import json
import os
import subprocess
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

# Nuclei's own severities map 1:1 onto ours apart from 'unknown'.
SEVERITY_MAP = {
    'critical': 'CRITICAL',
    'high': 'HIGH',
    'medium': 'MEDIUM',
    'low': 'LOW',
    'info': 'INFO',
    'unknown': 'INFO',
}

SCAN_SEVERITIES = 'critical,high,medium,low'
MAX_TARGETS = 10
RATE_LIMIT = 50            # requests/second, well under nuclei's 150 default
CONCURRENCY = 15
SCAN_TIMEOUT = 900         # hard ceiling for the whole run
EXCLUDE_TAGS = 'dast,fuzz,intrusive,brute-force'


class NucleiProvider(AssetProvider):
    id = 'nuclei'
    name = 'Nuclei'
    category = 'vulnerabilities'
    requires_binary = 'nuclei'
    # Nuclei prints "Nuclei Engine Version: vX.Y.Z" - it never prints the
    # vendor name, so matching on 'projectdiscovery' here would reject the
    # genuine binary.
    binary_identity = (['-version'], 'nuclei engine')

    def collect(self, target_domain, context):
        responses = context.get('http_response') or {}
        # Probe only what is actually up; scanning known-dead hosts is pure
        # timeout, and nuclei needs a scheme it can reach.
        targets = [str(r.url).rstrip('/') for fqdn, r in sorted(responses.items())][:MAX_TARGETS]
        if not targets:
            return {'ok': True, 'data': {'findings': [], 'skipped': 'no live hosts to scan'},
                    'error': None}

        cmd = [
            self.binary_path(),
            '-jsonl', '-silent', '-no-color', '-disable-update-check',
            '-severity', SCAN_SEVERITIES,
            '-exclude-tags', EXCLUDE_TAGS,
            '-exclude-type', 'code',
            '-rate-limit', str(RATE_LIMIT),
            '-concurrency', str(CONCURRENCY),
            '-timeout', '10',
            '-retries', '1',
        ]
        for t in targets:
            cmd += ['-target', t]

        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=SCAN_TIMEOUT)
        except subprocess.TimeoutExpired:
            return {'ok': False, 'data': None,
                    'error': f'nuclei exceeded the {SCAN_TIMEOUT}s scan timeout'}

        findings = []
        for line in (proc.stdout or '').splitlines():
            line = line.strip()
            if not line or not line.startswith('{'):
                continue
            try:
                hit = json.loads(line)
            except ValueError:
                continue
            info = hit.get('info') or {}
            severity = SEVERITY_MAP.get((info.get('severity') or '').lower(), 'INFO')
            fqdn = hit.get('host') or target_domain
            # 'host' arrives as a URL for http templates; findings are keyed
            # by fqdn everywhere else in the pipeline.
            if '://' in fqdn:
                fqdn = fqdn.split('://', 1)[1].split('/', 1)[0].split(':', 1)[0]
            title = info.get('name') or hit.get('template-id') or 'Nuclei finding'
            detail_bits = [b for b in (
                hit.get('matched-at') or hit.get('matched_at'),
                f"template: {hit.get('template-id')}" if hit.get('template-id') else None,
                ', '.join(info.get('classification', {}).get('cve-id') or []) or None,
            ) if b]
            finding = {
                'severity': severity,
                'title': title,
                'fqdn': fqdn,
                'template_id': hit.get('template-id'),
                'matched_at': hit.get('matched-at') or hit.get('matched_at'),
                'cve_ids': (info.get('classification') or {}).get('cve-id') or [],
                'tags': info.get('tags') or [],
                'detail': ' | '.join(detail_bits),
            }
            findings.append(finding)
            # Same shared list every other provider writes to, so nuclei hits
            # rank and filter alongside TLS/header/port findings in the UI.
            add_finding(context, 'vulnerabilities', title, severity, finding['detail'], fqdn)

        # Per-fqdn, for the asset record's `vulnerabilities` field.
        by_fqdn = {}
        for f in findings:
            by_fqdn.setdefault(f['fqdn'], []).append(f)
        context['vulnerabilities'] = by_fqdn

        if proc.returncode != 0 and not findings:
            return {'ok': False, 'data': None,
                    'error': f'nuclei exited {proc.returncode}: {(proc.stderr or "")[:300]}'}

        return {'ok': True,
                'data': {'findings': findings, 'targets_scanned': len(targets),
                         'exit_code': proc.returncode},
                'error': None}
