#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Web-Check (self-hosted) provider
===================

Integrates a locally-hosted Web-Check instance (github.com/Lissy93/web-check)
as an OSINT aggregator over the Asset Intelligence scan. Web-Check exposes one
JSON endpoint per check at `<base>/api/<check>?url=<target>`; this provider
queries a curated set of them for the ROOT target only (per the integration
decision - subdomains stay covered by the native providers), stores the whole
aggregated report target-wide (rendered as the dashboard's "Web-Check Report"
section), and raises Web-Check's genuinely-new signals - threat-intel hits,
DNS block-list listings, WAF presence - as normalized findings that feed the
risk score and the alert path, exactly like every other provider's findings.

Transport: Web-Check runs locally and does its OWN outbound checks, so the
call from here is a plain direct localhost request - NOT routed through Tor
(Tor is for the dark-web side; this is clearnet asset recon). The session is
built with trust_env=False so a system HTTP(S)_PROXY can never hijack a
localhost call.

Config: the base URL is read from asset_keys ('webcheck_base_url', settable
from the System page) and falls back to $WEBCHECK_URL, then http://localhost:3000
- so a default self-host works with zero configuration.
"""

import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

DEFAULT_BASE_URL = os.environ.get('WEBCHECK_URL') or 'http://localhost:3000'

# Curated set of checks fetched per scan. Everything here is stored in the
# report and rendered; a subset (threats/block-lists/firewall) also produces
# findings below. Deliberately excludes the checks that are broken or need a
# key on a stock self-host (tls-cipher-suites 404s; screenshot is heavy and
# duplicates the dark-web screenshot story; archives can hang).
CHECKS = [
    'get-ip', 'dns', 'dns-server', 'txt-records', 'whois', 'ssl', 'hsts',
    'http-security', 'headers', 'cookies', 'tech-stack', 'mail-config',
    'firewall', 'dnssec', 'security-txt', 'robots-txt', 'sitemap', 'redirects',
    'status', 'social-tags', 'quality', 'rank', 'threats', 'block-lists',
]
# Dropped from the fetched set on purpose - each makes its own slow outbound
# work inside Web-Check and either duplicates a native Anorphix provider or is
# low value: 'ports' (Anorphix has a dedicated ports category), 'carbon' and
# 'linked-pages' (slow page fetch/crawl, vanity). They were the checks that
# routinely hit the timeout and dominated this provider's wall-clock.

# Each call is bounded and the whole pass runs CONCURRENTLY, so the provider's
# total time is ~the slowest single check, not their sum. A tight per-check
# timeout plus enough workers to cover every check in one wave keeps a heavy,
# well-defended domain (amazon.com) from dragging the pass out - anything not
# back in time is recorded as a timeout rather than left to hang the job.
PER_CHECK_TIMEOUT = int(os.environ.get('WEBCHECK_TIMEOUT', 10))
MAX_WORKERS = int(os.environ.get('WEBCHECK_WORKERS', 12))


def _base_url():
    try:
        from lib import asset_keys
        configured = asset_keys.get_api_key('webcheck_base_url')
    except Exception:
        configured = ''
    return (configured or DEFAULT_BASE_URL).rstrip('/')


class WebCheckProvider(AssetProvider):
    id = 'webcheck'
    name = 'Web-Check (self-hosted OSINT)'
    category = 'webcheck'

    def is_available(self):
        # On by default - a base URL always resolves (config -> env -> the
        # standard localhost:3000 self-host). If the instance is actually down,
        # collect() degrades to an honest error rather than being hidden here,
        # which would make the section silently disappear.
        return bool(_base_url())

    def _fetch(self, session, base, check, target_url):
        url = f'{base}/api/{check}'
        try:
            resp = session.get(url, params={'url': target_url},
                               timeout=PER_CHECK_TIMEOUT)
            if resp.status_code != 200:
                return check, {'error': f'HTTP {resp.status_code}'}
            try:
                return check, resp.json()
            except ValueError:
                return check, {'error': 'non-JSON response'}
        except requests.Timeout:
            return check, {'error': f'timeout after {PER_CHECK_TIMEOUT}s'}
        except Exception as e:
            return check, {'error': f'{type(e).__name__}: {str(e)[:120]}'}

    def collect(self, target_domain, context):
        base = _base_url()
        target_url = f'https://{target_domain}'

        # trust_env=False: never let a system proxy env var reroute a localhost
        # request to the Web-Check service.
        session = requests.Session()
        session.trust_env = False
        # Size the connection pool to the worker count so concurrent checks
        # don't thrash the pool (the "Connection pool is full" churn).
        adapter = requests.adapters.HTTPAdapter(pool_connections=MAX_WORKERS,
                                                pool_maxsize=MAX_WORKERS)
        session.mount('http://', adapter)
        session.mount('https://', adapter)

        report = {}
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
            futures = {pool.submit(self._fetch, session, base, c, target_url): c
                       for c in CHECKS}
            for fut in as_completed(futures):
                check, data = fut.result()
                report[check] = data

        # If literally nothing came back OK, the instance is unreachable/misconfigured
        # - report that honestly instead of an empty, misleading section.
        ok_count = sum(1 for v in report.values()
                       if isinstance(v, dict) and not v.get('error'))
        if ok_count == 0:
            return {'ok': False, 'provider': self.id, 'data': None,
                    'error': f'Web-Check unreachable at {base} (no checks returned data)'}

        # Store the whole report target-wide (rendered as the Web-Check section).
        context['webcheck'] = {
            'base_url': base,
            'target_url': target_url,
            'checks_ok': ok_count,
            'checks_total': len(CHECKS),
            'report': report,
        }

        self._emit_findings(context, target_domain, report)

        return {'ok': True, 'provider': self.id,
                'data': {'checks_ok': ok_count, 'checks_total': len(CHECKS),
                         'result_count': ok_count}}

    # -- findings: only Web-Check's genuinely-new signals, so nothing here
    #    double-counts what the native TLS/headers/ports providers already report.
    def _emit_findings(self, context, fqdn, report):
        self._finding_threats(context, fqdn, report.get('threats'))
        self._finding_blocklists(context, fqdn, report.get('block-lists'))
        self._finding_firewall(context, fqdn, report.get('firewall'))

    def _finding_threats(self, context, fqdn, threats):
        if not isinstance(threats, dict) or threats.get('error'):
            return
        hits = []
        # PhishTank: a record counts as a real hit only when it is in the
        # database AND verified - an unverified submission is not evidence.
        pt = threats.get('phishTank')
        if isinstance(pt, dict):
            for rec in pt.values():
                if isinstance(rec, dict) and str(rec.get('in_database')).lower() == 'true' \
                        and str(rec.get('verified')).lower() == 'true':
                    hits.append('PhishTank (verified)')
                    break
        # URLhaus / Safe Browsing: a plain result with no error/skipped and a
        # non-empty match is a hit. These are commonly skipped (need a key) or
        # blocked on a stock self-host, in which case they simply don't fire.
        for src, label in (('urlHaus', 'URLhaus'), ('safeBrowsing', 'Google Safe Browsing')):
            val = threats.get(src)
            if isinstance(val, dict) and not val.get('error') and not val.get('skipped'):
                # URLhaus signals a listing via query_status == 'ok' with results.
                if src == 'urlHaus' and str(val.get('query_status')).lower() == 'ok':
                    hits.append(label)
                elif src == 'safeBrowsing' and val.get('matches'):
                    hits.append(label)
        if hits:
            add_finding(context, 'webcheck',
                        f'Threat-intelligence hit for {fqdn}', severity='HIGH',
                        detail='Flagged by: ' + ', '.join(hits) + ' (via Web-Check).',
                        fqdn=fqdn)

    def _finding_blocklists(self, context, fqdn, bl):
        if not isinstance(bl, dict) or bl.get('error'):
            return
        entries = bl.get('blocklists')
        if not isinstance(entries, list) or not entries:
            return
        blocked = [e.get('server') for e in entries
                   if isinstance(e, dict) and e.get('isBlocked')]
        if blocked:
            shown = ', '.join(str(s) for s in blocked[:8])
            add_finding(context, 'webcheck',
                        f'{fqdn} is listed on {len(blocked)} DNS block-list(s)',
                        severity='MEDIUM',
                        detail=f'Blocked by: {shown}'
                               + (' …' if len(blocked) > 8 else '')
                               + f' (of {len(entries)} checked, via Web-Check).',
                        fqdn=fqdn)

    def _finding_firewall(self, context, fqdn, fw):
        if not isinstance(fw, dict) or fw.get('error'):
            return
        if fw.get('hasWaf'):
            add_finding(context, 'webcheck', f'{fqdn} is protected by a WAF/CDN',
                        severity='INFO',
                        detail=f"Detected: {fw.get('waf') or 'unknown WAF'} (via Web-Check).",
                        fqdn=fqdn)
        else:
            add_finding(context, 'webcheck', f'No WAF/CDN detected in front of {fqdn}',
                        severity='LOW',
                        detail='Web-Check did not detect a web application firewall or CDN.',
                        fqdn=fqdn)
