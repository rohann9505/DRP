#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Passive web-surface providers, all reading the HTTP response
liveness_probe.py already fetched or making one cheap extra request against
a well-known path. Grouped in one module because each is only a few dozen
lines and they share the same parsing helpers - splitting them into six
files would be filing, not modularity. They remain separate AssetProvider
classes in separate categories, so any one can still be replaced or
disabled independently.

Covers Web-Check's security-txt, robots-txt, sitemap, social-tags,
redirects and archives checks. All keyless.
"""

import os
import re
import sys
from urllib.parse import urljoin, urlparse

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

REQUEST_TIMEOUT = 6
HEADERS = {'User-Agent': 'Anorphix-AssetIntel/1.0'}
MAX_BODY = 500000

_META_RE = re.compile(
    r'<meta\s+[^>]*?(?:name|property)\s*=\s*["\']([^"\']+)["\'][^>]*?content\s*=\s*["\']([^"\']*)["\']',
    re.I)
_TITLE_RE = re.compile(r'<title[^>]*>(.*?)</title>', re.I | re.S)
_SITEMAP_LOC_RE = re.compile(r'<loc>\s*([^<\s]+)\s*</loc>', re.I)


def _get(url, allow_redirects=True):
    try:
        r = requests.get(url, timeout=REQUEST_TIMEOUT, headers=HEADERS,
                         allow_redirects=allow_redirects, verify=False)
        return r
    except requests.RequestException:
        return None


def _base_url(context, target_domain):
    resp = (context.get('http_response') or {}).get(target_domain)
    if resp is not None:
        return str(resp.url).rstrip('/')
    return f'https://{target_domain}'


class SecurityTxtProvider(AssetProvider):
    """RFC 9116 - a published disclosure contact. Its absence is a real (if
    low-severity) finding for an org that wants vulnerabilities reported to
    it rather than sold."""
    id = 'security_txt'
    name = 'security.txt (RFC 9116)'
    category = 'security_txt'

    def collect(self, target_domain, context):
        base = _base_url(context, target_domain)
        for path in ('.well-known/security.txt', 'security.txt'):
            r = _get(f'{base}/{path}')
            if r is None or r.status_code != 200:
                continue
            body = r.text[:20000]
            # A styled catch-all HTML page is not a security.txt file.
            if '<html' in body[:500].lower() or 'contact:' not in body.lower():
                continue
            fields = {}
            for line in body.splitlines():
                if ':' in line and not line.strip().startswith('#'):
                    k, v = line.split(':', 1)
                    fields.setdefault(k.strip().lower(), []).append(v.strip())
            data = {'present': True, 'found_in': path, 'fields': fields,
                    'pgp_signed': 'BEGIN PGP SIGNED MESSAGE' in body}
            context['security_txt'] = data
            add_finding(context, 'security_txt', f'security.txt published by {target_domain}',
                        'INFO', f'Found at /{path}', target_domain)
            return {'ok': True, 'data': data, 'error': None}

        context['security_txt'] = {'present': False}
        add_finding(context, 'security_txt', f'No security.txt on {target_domain}', 'LOW',
                    'No RFC 9116 disclosure contact published - researchers have no documented '
                    'channel to report vulnerabilities.', target_domain)
        return {'ok': True, 'data': {'present': False}, 'error': None}


class CrawlRulesProvider(AssetProvider):
    """robots.txt + the sitemaps it points at. The sitemap is the cheapest
    honest map of a site's public surface, and robots.txt disallow entries
    routinely name paths the owner would rather nobody visited."""
    id = 'crawl_rules'
    name = 'robots.txt & Sitemap'
    category = 'crawl_rules'

    def collect(self, target_domain, context):
        base = _base_url(context, target_domain)
        data = {'robots_present': False, 'rules': [], 'sitemaps': [], 'sitemap_urls': [],
                'sitemap_url_count': 0}

        r = _get(f'{base}/robots.txt')
        if r is not None and r.status_code == 200 and 'html' not in (
                r.headers.get('Content-Type') or '').lower():
            data['robots_present'] = True
            for line in r.text[:100000].splitlines():
                line = line.strip()
                if not line or line.startswith('#') or ':' not in line:
                    continue
                key, value = (p.strip() for p in line.split(':', 1))
                lkey = key.lower()
                if lkey == 'sitemap':
                    data['sitemaps'].append(value)
                elif lkey in ('user-agent', 'allow', 'disallow', 'crawl-delay'):
                    data['rules'].append({'directive': key, 'value': value})

        sitemap_candidates = data['sitemaps'] or [f'{base}/sitemap.xml']
        urls = []
        for sitemap in sitemap_candidates[:3]:
            sr = _get(sitemap)
            if sr is None or sr.status_code != 200:
                continue
            body = sr.text[:MAX_BODY]
            if '<' not in body:
                continue
            urls.extend(_SITEMAP_LOC_RE.findall(body))
        # A sitemap index points at more sitemaps; one level of follow is
        # enough to get a useful page count without walking a whole tree.
        nested = [u for u in urls if u.endswith('.xml')][:3]
        if nested and len(urls) < 50:
            for sitemap in nested:
                sr = _get(sitemap)
                if sr is not None and sr.status_code == 200:
                    urls.extend(_SITEMAP_LOC_RE.findall(sr.text[:MAX_BODY]))

        seen = sorted(set(urls))
        data['sitemap_url_count'] = len(seen)
        data['sitemap_urls'] = seen[:200]
        context['crawl_rules'] = data
        return {'ok': True, 'data': data, 'error': None}


class SocialTagsProvider(AssetProvider):
    """Open Graph / Twitter / generic meta tags from the already-fetched
    homepage - the organisation's own description of itself, useful for
    confirming an asset really belongs to the target brand."""
    id = 'social_tags'
    name = 'Page Metadata & Social Tags'
    category = 'metadata'

    def collect(self, target_domain, context):
        resp = (context.get('http_response') or {}).get(target_domain)
        if resp is None:
            return {'ok': True, 'data': {'skipped': 'root domain did not respond'}, 'error': None}
        body = resp.text[:MAX_BODY] if resp.text else ''
        metas = {name.lower(): content for name, content in _META_RE.findall(body)}
        title = _TITLE_RE.search(body)
        data = {
            'title': (title.group(1).strip()[:300] if title else None),
            'description': metas.get('description'),
            'keywords': metas.get('keywords'),
            'generator': metas.get('generator'),
            'og_title': metas.get('og:title'),
            'og_description': metas.get('og:description'),
            'og_image': metas.get('og:image'),
            'og_site_name': metas.get('og:site_name'),
            'twitter_card': metas.get('twitter:card'),
            'twitter_site': metas.get('twitter:site'),
            'theme_color': metas.get('theme-color'),
        }
        context['metadata'] = {k: v for k, v in data.items() if v}
        return {'ok': True, 'data': context['metadata'], 'error': None}


class RedirectChainProvider(AssetProvider):
    """The hop-by-hop path from http:// to whatever finally answers. An
    http:// entry point that never upgrades to https is a genuine finding,
    and the chain itself often reveals a CDN or SSO boundary."""
    id = 'redirect_chain'
    name = 'Redirect Chain'
    category = 'redirects'

    def collect(self, target_domain, context):
        r = _get(f'http://{target_domain}/')
        if r is None:
            return {'ok': True, 'data': {'skipped': 'no HTTP response'}, 'error': None}
        chain = [{'url': h.url, 'status': h.status_code} for h in r.history]
        chain.append({'url': r.url, 'status': r.status_code})
        final_scheme = urlparse(r.url).scheme
        data = {'chain': chain, 'hops': len(chain) - 1, 'final_url': r.url,
                'upgrades_to_https': final_scheme == 'https'}

        if final_scheme != 'https':
            add_finding(context, 'redirects', f'{target_domain} does not redirect HTTP to HTTPS',
                        'MEDIUM',
                        f'Plain-HTTP requests end at {r.url} - traffic is not forced onto TLS.',
                        target_domain)
        context['redirects'] = data
        return {'ok': True, 'data': data, 'error': None}


class ArchiveHistoryProvider(AssetProvider):
    """Wayback Machine CDX API - keyless. First/last capture and total
    snapshot count establish how long an asset has existed publicly, which
    is exactly the context missing when a newly discovered subdomain turns
    up in a scan."""
    id = 'wayback_archives'
    name = 'Archive History (Wayback Machine)'
    category = 'archive'

    CDX_URL = 'https://web.archive.org/cdx/search/cdx'

    def collect(self, target_domain, context):
        try:
            # The CDX endpoint is routinely slow (30s+ for a busy domain);
            # a short timeout here reads as "never archived" when the real
            # answer is "we gave up asking".
            r = requests.get(self.CDX_URL, timeout=45, headers=HEADERS, params={
                'url': target_domain, 'output': 'json', 'fl': 'timestamp,statuscode',
                'collapse': 'timestamp:6', 'limit': 2000,
            })
        except requests.RequestException as e:
            return {'ok': False, 'data': None, 'error': f'Wayback CDX request failed: {e}'}

        # "We could not ask" is not "there is nothing there". Folding a
        # rate-limit or server error into archived=False would report a
        # 25-year-old domain as never archived, so it stays an error.
        if r.status_code != 200:
            return {'ok': False, 'data': None,
                    'error': f'Wayback CDX returned HTTP {r.status_code}'}
        try:
            rows = r.json()
        except ValueError:
            return {'ok': False, 'data': None, 'error': 'Wayback CDX returned unparseable JSON'}

        if len(rows) < 2:
            data = {'archived': False, 'scan_count': 0}
            context['archive'] = data
            return {'ok': True, 'data': data, 'error': None}

        stamps = sorted(row[0] for row in rows[1:] if row and row[0])

        def _iso(stamp):
            return (f'{stamp[0:4]}-{stamp[4:6]}-{stamp[6:8]}' if len(stamp) >= 8 else stamp)

        data = {
            'archived': True,
            'scan_count': len(stamps),
            'first_scan': _iso(stamps[0]),
            'last_scan': _iso(stamps[-1]),
            'scan_url': f'https://web.archive.org/web/*/{target_domain}',
        }
        context['archive'] = data
        return {'ok': True, 'data': data, 'error': None}
