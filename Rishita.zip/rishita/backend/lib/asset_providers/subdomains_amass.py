#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
OWASP Amass passive subdomain enumeration (v5).

Secondary, best-effort source in the `subdomains` category alongside the
fast keyless providers and subfinder. Amass v5 is a heavyweight engine (it
spins an internal service and a local SQLite asset store, and converges
slowly), so it is run strictly bounded: passive mode, a hard wall-clock cap,
and results parsed from an output file so a mid-run timeout still yields
whatever names were already flushed. subfinder remains the reliable primary;
amass adds breadth when it has time to converge and never blocks the scan
when it does not.

Strictness identical to subfinder's: every returned host is re-validated as
an in-scope, well-formed hostname before entering the shared set; liveness
downstream decides what is actually reachable, so a listed-but-dead name
shows as `disconnected`, not as a fabricated live asset.
"""

import os
import re
import signal
import subprocess
import sys
import tempfile

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

# Hard wall-clock ceiling. Amass v5 rarely "finishes" quickly; -timeout caps
# its own internal run (minutes) and this outer cap guarantees the scan job
# is never held hostage by it.
SCAN_TIMEOUT = 150
AMASS_INTERNAL_TIMEOUT_MIN = 2
_HOSTNAME_RE = re.compile(r'^(?=.{1,253}$)([a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?\.)+[a-z]{2,63}$')


class AmassProvider(AssetProvider):
    id = 'amass'
    name = 'Amass'
    category = 'subdomains'
    requires_binary = 'amass'
    # `amass -version` prints only the bare version string (e.g. "v5.1.1"),
    # with no vendor/tool name, so an identity marker would reject the genuine
    # binary. The bundled tools/bin/amass wins over PATH via resolve_binary,
    # and an "amass" name collision on this host is not a realistic risk.
    binary_identity = None

    def collect(self, target_domain, context):
        out_fd, out_path = tempfile.mkstemp(prefix='amass_', suffix='.txt')
        os.close(out_fd)
        cmd = [
            self.binary_path(), 'enum',
            '-d', target_domain,
            '-nocolor', '-silent',
            '-timeout', str(AMASS_INTERNAL_TIMEOUT_MIN),
            '-o', out_path,
        ]
        timed_out = False
        stdout = ''
        # amass v5 spawns a DETACHED "amass engine" daemon that outlives the
        # `amass enum` CLI - a plain subprocess timeout kills the CLI but leaks
        # that engine, one orphan per scan. Run the whole thing in its own
        # process group and, on every exit path, kill the group so the engine
        # dies with it.
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, start_new_session=True)
        try:
            stdout, _ = proc.communicate(timeout=SCAN_TIMEOUT)
            stdout = stdout or ''
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                stdout = proc.communicate(timeout=5)[0] or ''
            except Exception:
                stdout = ''
        finally:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except (ProcessLookupError, OSError):
                pass
            # The engine re-parents to init in its OWN session, so killpg
            # above can't reach it - reap it explicitly by cmdline. Safe: the
            # worker runs one scan at a time and this provider is the only
            # thing that ever launches amass.
            self._reap_engines(self.binary_path())
            file_blob = ''
            try:
                with open(out_path, 'r', errors='ignore') as f:
                    file_blob = f.read()
            except OSError:
                pass
            try:
                os.remove(out_path)
            except OSError:
                pass

        found = self._parse(f'{stdout}\n{file_blob}', target_domain)
        if found:
            context.setdefault('subdomains', set()).update(found)
            data = {'subdomains': sorted(found)}
            if timed_out:
                data['note'] = f'amass hit the {SCAN_TIMEOUT}s cap; partial results kept'
            return {'ok': True, 'data': data, 'error': None}

        if timed_out:
            # No names within budget: honest, not an error - amass v5 simply
            # did not converge in time and the other subdomain sources carry
            # the category.
            return {'ok': True,
                    'data': {'subdomains': [], 'note': f'amass produced no names within {SCAN_TIMEOUT}s'},
                    'error': None}
        return {'ok': True, 'data': {'subdomains': []}, 'error': None}

    @staticmethod
    def _reap_engines(binary_path):
        """SIGKILL any lingering `<amass> engine` daemon (it daemonizes past
        killpg). Matches on our exact binary path so it never touches an
        unrelated process."""
        import glob
        needle = (binary_path or 'amass').encode()
        for pdir in glob.glob('/proc/[0-9]*'):
            try:
                with open(os.path.join(pdir, 'cmdline'), 'rb') as f:
                    cl = f.read()
            except OSError:
                continue
            if needle in cl and b'engine' in cl:
                try:
                    os.kill(int(os.path.basename(pdir)), signal.SIGKILL)
                except (ProcessLookupError, ValueError, OSError):
                    pass

    @staticmethod
    def _parse(blob, target_domain):
        target = target_domain.lower().strip('.')
        found = set()
        # Amass output lines can carry extra tokens (v5 sometimes annotates
        # names); pull every hostname-looking token and scope-check it.
        for token in re.split(r'[\s,]+', blob.lower()):
            name = token.strip().rstrip('.')
            if not name:
                continue
            if name != target and not name.endswith('.' + target):
                continue
            if not _HOSTNAME_RE.match(name):
                continue
            found.add(name)
        return found
