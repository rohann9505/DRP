#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
ProjectDiscovery HTTPx - fast HTTP probing / tech fingerprinting.

Second provider in the `liveness` category, after the stdlib liveness_probe
(which owns context['http_response'], the shared requests.Response objects
nuclei/technologies/security_config/directory_enum all read). httpx does NOT
overwrite those - it runs its own engine over the discovered host set and
contributes two things the stdlib probe cannot:

  * a second, independent live/up confirmation - and deliberately ONLY an
    *upgrade* to live: httpx never downgrades a host the stdlib probe already
    saw as live to disconnected, so its own transient failure can't
    manufacture a false "went down". This keeps liveness strict.
  * technology signals (with versions where httpx extracts them), merged into
    context['technologies'] so they reach the UI and feed the OSV provider's
    component inventory.

Its full per-host record (status code, title, webserver, CDN, tech) is stored
in context['httpx'] for the report.
"""

import json
import os
import subprocess
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

SCAN_TIMEOUT = 150
MAX_TARGETS = 40


class HttpxProvider(AssetProvider):
    id = 'httpx'
    name = 'HTTPx (ProjectDiscovery)'
    category = 'liveness'
    requires_binary = 'httpx'
    # `httpx` is also the name of a popular Python HTTP client whose CLI is
    # installed in AILENV, so the name on PATH has to prove which one it is.
    binary_identity = (['-version'], 'projectdiscovery')

    def collect(self, target_domain, context):
        targets = sorted(set(context.get('subdomains') or set()) | {target_domain})[:MAX_TARGETS]
        if not targets:
            return {'ok': True, 'data': {'skipped': 'no hosts'}, 'error': None}

        cmd = [
            self.binary_path(),
            '-json', '-silent', '-no-color',
            '-status-code', '-title', '-tech-detect', '-web-server',
            '-timeout', '10', '-retries', '1', '-threads', '25',
            '-disable-update-check',
        ]
        try:
            proc = subprocess.run(cmd, input='\n'.join(targets),
                                  capture_output=True, text=True, timeout=SCAN_TIMEOUT)
        except subprocess.TimeoutExpired:
            return {'ok': False, 'data': None,
                    'error': f'httpx exceeded the {SCAN_TIMEOUT}s scan timeout'}

        status_by_fqdn = {}
        httpx_meta = {}
        techs = context.setdefault('technologies', {})
        confirmed = 0
        for line in (proc.stdout or '').splitlines():
            line = line.strip()
            if not line.startswith('{'):
                continue
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            fqdn = (rec.get('input') or rec.get('host') or '').strip().lower()
            # Strip any scheme/port httpx echoed back so the key matches the
            # fqdn used everywhere else in the pipeline.
            if '://' in fqdn:
                fqdn = fqdn.split('://', 1)[1]
            fqdn = fqdn.split('/', 1)[0].split(':', 1)[0]
            if not fqdn:
                continue
            live = bool(rec.get('status_code')) and not rec.get('failed')
            if live:
                status_by_fqdn[fqdn] = 'live'   # upgrade-only; see docstring
                confirmed += 1
            httpx_meta[fqdn] = {
                'status_code': rec.get('status_code'),
                'title': rec.get('title'),
                'webserver': rec.get('webserver'),
                'cdn': rec.get('cdn_name') or (rec.get('cdn') and 'yes'),
                'url': rec.get('url'),
                'tech': rec.get('tech') or [],
            }
            # Merge tech (union) - normalise httpx's "Name:version" to
            # "Name version" so the OSV provider's name/version parser and the
            # UI both read it the same way as the stdlib fingerprints.
            existing = set(techs.get(fqdn) or [])
            for t in (rec.get('tech') or []):
                existing.add(t.replace(':', ' ', 1) if ':' in t else t)
            if existing:
                techs[fqdn] = sorted(existing)

        context['httpx'] = httpx_meta
        return {'ok': True,
                'data': {'status_by_fqdn': status_by_fqdn, 'probed': len(targets),
                         'confirmed_live': confirmed, 'result_count': confirmed},
                'error': None}
