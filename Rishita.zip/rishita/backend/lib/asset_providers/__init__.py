#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Asset Provider registry + orchestration
===================

Central place asset_jobs.run_job() calls into - it never imports an
individual provider module itself, so adding/removing/replacing a tool
means editing PROVIDERS here (or eventually making this data-driven), not
touching the job-orchestration logic.

Providers within a category run in registration order and share one
`context` dict for the duration of a single target's scan - this is how
dns_provider's resolved_ips feeds liveness_probe, and liveness_probe's
fetched HTTP responses feed technologies_probe/security_config_probe/
directory_enum_probe, without each provider re-doing another's network
work.
"""

import os
import sys
import time

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.dns_provider import DnsProvider
from lib.asset_providers.whois_provider import WhoisProvider
from lib.asset_providers.subdomains_crtsh import SubdomainsCrtShProvider
from lib.asset_providers.subdomains_passive import (SubdomainsCertSpotterProvider,
                                                    SubdomainsHackerTargetProvider)
from lib.asset_providers.subdomains_subfinder import SubfinderProvider
from lib.asset_providers.subdomains_amass import AmassProvider
from lib.asset_providers.subdomain_dns_provider import SubdomainDnsProvider
from lib.asset_providers.liveness_probe import LivenessProbeProvider
from lib.asset_providers.probe_httpx import HttpxProvider
from lib.asset_providers.tls_provider import TlsProvider
from lib.asset_providers.dnssec_provider import DnssecProvider
from lib.asset_providers.mail_config_provider import MailConfigProvider
from lib.asset_providers.firewall_provider import FirewallProvider
from lib.asset_providers.ports_tcp import PortsTcpProvider
from lib.asset_providers.web_meta_provider import (SecurityTxtProvider, CrawlRulesProvider,
                                                   SocialTagsProvider, RedirectChainProvider,
                                                   ArchiveHistoryProvider)
from lib.asset_providers.technologies_probe import TechnologiesProbeProvider
from lib.asset_providers.security_config_probe import SecurityConfigProbeProvider
from lib.asset_providers.directory_enum_probe import DirectoryEnumProbeProvider
from lib.asset_providers.ports_naabu import NaabuProvider
from lib.asset_providers.ports_nmap import NmapProvider
from lib.asset_providers.vulnerabilities_nuclei import NucleiProvider
from lib.asset_providers.vulnerabilities_vulnx import VulnXProvider
from lib.asset_providers.vulnerabilities_osv import OsvScannerProvider
from lib.asset_providers.webscan_w3af import W3afProvider
from lib.asset_providers.webcheck_provider import WebCheckProvider

# Category run order matters: later categories' providers read context
# populated by earlier ones (see module docstring). Specifically:
# subdomains -> subdomain_dns (needs the discovered set) -> liveness (needs
# the capped set) -> everything that reads context['http_response'], and
# ports needs subdomain_dns's resolved addresses.
CATEGORY_ORDER = [
    'dns', 'whois', 'subdomains', 'subdomain_dns', 'liveness',
    'tls', 'ports', 'technologies', 'security_config', 'waf',
    'dns_security', 'email_security', 'crawl_rules', 'security_txt',
    'metadata', 'redirects', 'archive', 'directory_enum',
    'vulnerabilities', 'web_scan', 'webcheck',
]

# The heavy categories: they either fan out per-subdomain (subdomain
# enumeration then DNS/probe every discovered host) or run a slow external
# scanner (Nuclei, per-host port scan, directory brute). A full scan of a big
# domain (amazon.com -> hundreds of crt.sh subdomains) is legitimately minutes
# because of these. A QUICK scan drops them and probes the ROOT target only, so
# the fast OSINT/Web-Check/DNS/WHOIS/TLS results come back in seconds - the
# Web-Check-speed path. Everything not listed here is cheap and root-scoped.
HEAVY_CATEGORIES = {'subdomains', 'subdomain_dns', 'ports', 'vulnerabilities',
                    'directory_enum', 'web_scan'}
# Also excluded from a QUICK scan (not "heavy fan-out", just slow single calls
# that routinely hit their own timeout - 'archive' hits the Wayback Machine and
# was measured at ~45s to time out on amazon.com). Kept in the full scan.
QUICK_EXCLUDE = HEAVY_CATEGORIES | {'archive'}
QUICK_CATEGORIES = [c for c in CATEGORY_ORDER if c not in QUICK_EXCLUDE]

# Human-readable labels for the dashboard's section headings and the
# per-category provider-status list.
CATEGORY_LABELS = {
    'dns': 'DNS Records', 'whois': 'WHOIS / Registration',
    'subdomains': 'Subdomain Discovery', 'subdomain_dns': 'Subdomain Resolution',
    'liveness': 'Liveness', 'tls': 'TLS / SSL', 'ports': 'Ports & Services',
    'technologies': 'Technology Stack', 'security_config': 'Security Headers',
    'waf': 'WAF / CDN', 'dns_security': 'DNSSEC', 'email_security': 'Email Authentication',
    'crawl_rules': 'Crawl Rules & Sitemap', 'security_txt': 'security.txt',
    'metadata': 'Page Metadata', 'redirects': 'Redirect Chain',
    'archive': 'Archive History', 'directory_enum': 'Directory Enumeration',
    'vulnerabilities': 'Vulnerabilities & CVEs', 'web_scan': 'Web Application Scan',
    'webcheck': 'Web-Check (OSINT)',
}

# A passive source like crt.sh routinely returns 100+ entries for a
# well-known domain (confirmed: 118 for github.com) - every one of those
# gets a real network probe in the liveness/technologies/directory_enum
# categories, so an uncapped set turns one scan into hundreds of sequential
# HTTP requests. Bounding the set fed into per-asset probing keeps a v1
# scan's wall-clock time sane; raising this (or replacing it with
# concurrency-only scaling) is a reasonable later tuning knob, not an
# architectural change.
MAX_SUBDOMAINS_PER_SCAN = 20

PROVIDERS = {
    'dns': [DnsProvider()],
    'whois': [WhoisProvider()],
    'subdomains': [SubdomainsCrtShProvider(), SubdomainsCertSpotterProvider(),
                   SubdomainsHackerTargetProvider(), SubfinderProvider(), AmassProvider()],
    'subdomain_dns': [SubdomainDnsProvider()],
    'liveness': [LivenessProbeProvider(), HttpxProvider()],
    'tls': [TlsProvider()],
    'ports': [PortsTcpProvider(), NaabuProvider(), NmapProvider()],
    'technologies': [TechnologiesProbeProvider()],
    'security_config': [SecurityConfigProbeProvider()],
    'waf': [FirewallProvider()],
    'dns_security': [DnssecProvider()],
    'email_security': [MailConfigProvider()],
    'crawl_rules': [CrawlRulesProvider()],
    'security_txt': [SecurityTxtProvider()],
    'metadata': [SocialTagsProvider()],
    'redirects': [RedirectChainProvider()],
    'archive': [ArchiveHistoryProvider()],
    'directory_enum': [DirectoryEnumProbeProvider()],
    'vulnerabilities': [NucleiProvider(), OsvScannerProvider(), VulnXProvider()],
    'web_scan': [W3afProvider()],
    'webcheck': [WebCheckProvider()],
}

# Best-effort classification of a not-ok provider result into 'timeout' vs a
# hard 'error', from the wording every provider uses for its own subprocess
# timeouts ("exceeded the Ns ... timeout").
_TIMEOUT_MARKERS = ('exceeded', 'timed out', 'timeout')


def _infer_result_count(data):
    """Best-effort count of what a provider actually produced, when it does
    not report `result_count` itself - so telemetry has a number for every
    provider without each one having to opt in."""
    if not isinstance(data, dict):
        return 0
    if isinstance(data.get('result_count'), int):
        return data['result_count']
    for key in ('findings', 'subdomains', 'status_by_fqdn', 'records', 'directories'):
        val = data.get(key)
        if isinstance(val, (list, dict)):
            return len(val)
    for key in ('new_ports_found', 'hosts_scanned', 'targets_scanned', 'probed'):
        if isinstance(data.get(key), int):
            return data[key]
    return 0


def get_providers(category):
    return PROVIDERS.get(category, [])


def provider_status(category):
    """UI helper: which providers exist for this category and whether each
    is actually usable right now - lets the dashboard show 'not yet
    configured' next to a stubbed tool instead of a silently empty section."""
    return [{'id': p.id, 'name': p.name, 'available': p.is_available()} for p in get_providers(category)]


def run_category(category, target_domain, context):
    """Runs every registered provider for `category` against target_domain,
    sharing `context`. Returns the list of individual provider results
    (each {'ok', 'provider', 'data', 'error'}) - asset_jobs.run_job()
    decides how to merge them into asset_data records; this layer only
    reports what each provider found (or why it couldn't run)."""
    results = []
    telemetry = context.setdefault('provider_telemetry', {})
    for provider in get_providers(category):
        available = provider.is_available()
        started = time.time()
        rec = {
            'provider': provider.id, 'category': category,
            'available': available, 'status': 'started',
            'started_at': started, 'completed_at': None, 'duration_ms': None,
            'error': None, 'result_count': 0,
            'validated_count': None, 'deduplicated_count': None,
        }
        telemetry[provider.id] = rec

        result = provider.safe_collect(target_domain, context)
        rec['completed_at'] = time.time()
        rec['duration_ms'] = int((rec['completed_at'] - started) * 1000)
        data = result.get('data') or {}
        rec['result_count'] = _infer_result_count(data)
        if isinstance(data.get('validated_count'), int):
            rec['validated_count'] = data['validated_count']
        if isinstance(data.get('deduplicated_count'), int):
            rec['deduplicated_count'] = data['deduplicated_count']

        if not available:
            rec['status'] = 'skipped'
            rec['error'] = result.get('error')
        elif result.get('ok'):
            rec['status'] = 'completed'
        else:
            err = (result.get('error') or '').lower()
            rec['status'] = 'timeout' if any(m in err for m in _TIMEOUT_MARKERS) else 'error'
            rec['error'] = result.get('error')

        results.append(result)
    return results


def run_all_categories(target_domain, categories=None):
    """Convenience wrapper: runs every requested category (default: all, in
    CATEGORY_ORDER) against target_domain with one shared context, returning
    {category: [results]}."""
    categories = categories or CATEGORY_ORDER
    context = {}
    all_results = {}
    for category in CATEGORY_ORDER:
        if category not in categories:
            continue
        all_results[category] = run_category(category, target_domain, context)
        if category == 'subdomains' and context.get('subdomains'):
            capped = sorted(context['subdomains'])[:MAX_SUBDOMAINS_PER_SCAN]
            # The target itself is never optional. Capping a sorted set would
            # otherwise silently drop it whenever it sorts past the cut
            # (confirmed: github.com fell behind 20 alphabetically-earlier
            # api.*/awesome-*/central.* subdomains), leaving the scan's own
            # primary domain unprobed - and therefore recorded as
            # 'disconnected' by run_job's status default despite resolving fine.
            context['subdomains'] = set(capped) | {target_domain}
    return all_results, context
