#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
TCP connect port scan - stdlib sockets, no binary, no privileges.

Fills the 'ports' category that until now had only the Naabu/Nmap stubs in
it, so "Ports & Services" stops being an empty section. Naabu/Nmap remain
registered alongside this and take over automatically once installed - this
is the keyless floor, not a replacement for them (no SYN scan, no service
version detection, no UDP).

Scans are keyed on resolved IP, not hostname: a capped subdomain set
routinely collapses onto a handful of shared addresses (all of GitHub's
Pages subdomains land on the same anycast IPs), and scanning each hostname
separately would repeat identical work dozens of times against the same
host. Results are then mapped back onto every fqdn sharing that address.
"""

import os
import socket
import sys
from concurrent.futures import ThreadPoolExecutor

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

CONNECT_TIMEOUT = 1.5
SCAN_CONCURRENCY = 50
# Bounds the scan regardless of how many subdomains were discovered.
MAX_HOSTS_TO_SCAN = 12

COMMON_PORTS = (
    21, 22, 23, 25, 53, 80, 110, 143, 389, 443, 445, 465, 587, 993, 995,
    1433, 1521, 2049, 3000, 3306, 3389, 5432, 5900, 5984, 6379, 8000,
    8080, 8443, 8888, 9200, 11211, 27017,
)

PORT_SERVICES = {
    21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS', 80: 'HTTP',
    110: 'POP3', 143: 'IMAP', 389: 'LDAP', 443: 'HTTPS', 445: 'SMB',
    465: 'SMTPS', 587: 'SMTP submission', 993: 'IMAPS', 995: 'POP3S',
    1433: 'MSSQL', 1521: 'Oracle DB', 2049: 'NFS', 3000: 'HTTP alt',
    3306: 'MySQL', 3389: 'RDP', 5432: 'PostgreSQL', 5900: 'VNC',
    5984: 'CouchDB', 6379: 'Redis', 8000: 'HTTP alt', 8080: 'HTTP proxy',
    8443: 'HTTPS alt', 8888: 'HTTP alt', 9200: 'Elasticsearch',
    11211: 'Memcached', 27017: 'MongoDB',
}

# Ports that should essentially never be reachable from the public internet.
# These are the ones worth waking someone up for, as opposed to an open 443.
SENSITIVE_PORTS = {
    23: ('HIGH', 'Telnet transmits credentials in cleartext'),
    445: ('HIGH', 'SMB exposed to the internet'),
    1433: ('HIGH', 'Microsoft SQL Server directly reachable'),
    1521: ('HIGH', 'Oracle database directly reachable'),
    2049: ('HIGH', 'NFS export reachable'),
    3306: ('HIGH', 'MySQL directly reachable'),
    3389: ('HIGH', 'RDP exposed to the internet'),
    5432: ('HIGH', 'PostgreSQL directly reachable'),
    5900: ('HIGH', 'VNC exposed to the internet'),
    6379: ('CRITICAL', 'Redis is frequently unauthenticated by default'),
    9200: ('CRITICAL', 'Elasticsearch is frequently unauthenticated by default'),
    11211: ('CRITICAL', 'Memcached is unauthenticated by default and is a DDoS amplifier'),
    27017: ('CRITICAL', 'MongoDB is frequently unauthenticated by default'),
    21: ('MEDIUM', 'FTP transmits credentials in cleartext'),
}


def _check(args):
    ip, port = args
    try:
        with socket.create_connection((ip, port), timeout=CONNECT_TIMEOUT):
            return port
    except OSError:
        return None


def scan_host(ip, ports=COMMON_PORTS):
    """Returns the sorted list of ports accepting TCP connections on `ip`."""
    with ThreadPoolExecutor(max_workers=SCAN_CONCURRENCY) as pool:
        return sorted(p for p in pool.map(_check, ((ip, port) for port in ports)) if p)


class PortsTcpProvider(AssetProvider):
    id = 'ports_tcp'
    name = 'TCP Connect Port Scan (stdlib)'
    category = 'ports'

    def collect(self, target_domain, context):
        # Build fqdn -> ip from what DNS/liveness already established, so
        # this provider does no resolution of its own.
        ip_to_fqdns = {}
        root_ips = context.get('resolved_ips') or []
        for ip in root_ips[:1]:
            ip_to_fqdns.setdefault(ip, []).append(target_domain)

        for fqdn, records in (context.get('sub_dns') or {}).items():
            for ip in (records.get('A') or [])[:1]:
                ip_to_fqdns.setdefault(ip, []).append(fqdn)

        if not ip_to_fqdns:
            return {'ok': True, 'data': {'ports_by_fqdn': {}, 'skipped': 'no resolved IPs'},
                    'error': None}

        targets = sorted(ip_to_fqdns)[:MAX_HOSTS_TO_SCAN]
        ports_by_ip = {}
        for ip in targets:
            ports_by_ip[ip] = scan_host(ip)

        ports_by_fqdn = {}
        for ip, ports in ports_by_ip.items():
            entries = [{'port': p, 'service': PORT_SERVICES.get(p, 'unknown')} for p in ports]
            for fqdn in ip_to_fqdns[ip]:
                ports_by_fqdn[fqdn] = entries

            for port in ports:
                if port in SENSITIVE_PORTS:
                    severity, why = SENSITIVE_PORTS[port]
                    hosts = ', '.join(ip_to_fqdns[ip])
                    add_finding(context, 'ports',
                                f'{PORT_SERVICES.get(port, port)} (port {port}) open on {hosts}',
                                severity, f'{why} - reachable at {ip}:{port}', ip_to_fqdns[ip][0])

        context['ports'] = ports_by_fqdn
        return {'ok': True,
                'data': {'ports_by_fqdn': ports_by_fqdn, 'ports_by_ip': ports_by_ip,
                         'hosts_scanned': len(targets)},
                'error': None}
