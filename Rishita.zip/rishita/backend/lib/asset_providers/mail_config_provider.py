#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Email authentication provider - SPF / DMARC / DKIM / BIMI / MX.

Mirrors Web-Check's mail-config check (same DKIM selector-guessing approach,
since selectors cannot be enumerated from DNS), implemented on the dnspython
dependency we already have. Entirely keyless.

These are among the highest-value ASM findings for a brand-protection
platform: a missing or `p=none` DMARC policy is precisely what makes a
domain cheap to spoof, which is the same threat surface the Dark Web module
is already watching for leaked credentials.
"""

import os
import re
import sys

import dns.resolver

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

DNS_TIMEOUT = 4

# DKIM selectors are not discoverable from DNS - you can only guess the
# common ones (this is what every DKIM checker, Web-Check included, does).
DKIM_SELECTORS = ('default', 'google', 'selector1', 'selector2', 'k1', 'k2',
                  's1', 's2', 'dkim', 'mail', 'mandrill', 'zoho')

MX_PROVIDERS = (
    (re.compile(r'google(mail)?\.com$|googlemail\.com$', re.I), 'Google Workspace'),
    (re.compile(r'outlook\.com$|protection\.outlook\.com$', re.I), 'Microsoft 365'),
    (re.compile(r'protonmail\.ch$|proton\.me$', re.I), 'Proton Mail'),
    (re.compile(r'zoho\.(com|eu|in)$', re.I), 'Zoho Mail'),
    (re.compile(r'yahoodns\.net$', re.I), 'Yahoo Mail'),
    (re.compile(r'mimecast\.com$', re.I), 'Mimecast'),
    (re.compile(r'pphosted\.com$|ppe-hosted\.com$', re.I), 'Proofpoint'),
    (re.compile(r'messagelabs\.com$', re.I), 'Broadcom Email Security'),
    (re.compile(r'iphmx\.com$', re.I), 'Cisco Email Security'),
    (re.compile(r'mailgun\.org$', re.I), 'Mailgun'),
    (re.compile(r'sendgrid\.net$', re.I), 'SendGrid'),
    (re.compile(r'amazonaws\.com$', re.I), 'Amazon SES'),
)


def _resolver():
    r = dns.resolver.Resolver()
    r.timeout = DNS_TIMEOUT
    r.lifetime = DNS_TIMEOUT
    return r


def _txt(name):
    try:
        return [b''.join(rdata.strings).decode('utf-8', 'replace')
                for rdata in _resolver().resolve(name, 'TXT')]
    except Exception:
        return []


def _mx(name):
    try:
        return sorted(str(r.exchange).rstrip('.') for r in _resolver().resolve(name, 'MX'))
    except Exception:
        return []


def _parse_dmarc(record):
    tags = {}
    for part in record.split(';'):
        if '=' in part:
            k, v = part.split('=', 1)
            tags[k.strip().lower()] = v.strip()
    return tags


class MailConfigProvider(AssetProvider):
    id = 'mail_config'
    name = 'Email Authentication (SPF/DKIM/DMARC/BIMI)'
    category = 'email_security'

    def collect(self, target_domain, context):
        mx = _mx(target_domain)
        provider = next((label for pattern, label in MX_PROVIDERS
                         if any(pattern.search(host) for host in mx)), None)

        spf = next((t for t in _txt(target_domain) if t.lower().startswith('v=spf1')), None)
        dmarc_records = _txt(f'_dmarc.{target_domain}')
        dmarc = next((t for t in dmarc_records if t.lower().startswith('v=dmarc1')), None)
        bimi_records = _txt(f'default._bimi.{target_domain}')
        bimi = next((t for t in bimi_records if t.lower().startswith('v=bimi1')), None)

        dkim = []
        for selector in DKIM_SELECTORS:
            for record in _txt(f'{selector}._domainkey.{target_domain}'):
                # p= with an empty value is a revoked/placeholder key.
                if 'v=dkim1' in record.lower() and not re.search(r'p=\s*(;|$)', record):
                    dkim.append({'selector': selector, 'record': record[:400]})
                    break

        dmarc_tags = _parse_dmarc(dmarc) if dmarc else {}
        policy = dmarc_tags.get('p')

        data = {
            'mx_records': mx, 'mail_provider': provider,
            'spf_record': spf, 'spf_present': bool(spf),
            'dmarc_record': dmarc, 'dmarc_present': bool(dmarc),
            'dmarc_policy': policy, 'dmarc_pct': dmarc_tags.get('pct'),
            'dmarc_rua': dmarc_tags.get('rua'),
            'dkim_selectors': dkim, 'dkim_found': bool(dkim),
            'bimi_record': bimi, 'bimi_present': bool(bimi),
        }

        # Only meaningful for a domain that actually sends/receives mail, but
        # a domain with no MX is still spoofable, so these are reported either
        # way - at a lower severity when there is no mail infrastructure.
        has_mail = bool(mx)
        if not spf:
            add_finding(context, 'email_security', f'No SPF record on {target_domain}',
                        'MEDIUM' if has_mail else 'LOW',
                        'Without SPF, any host can send mail claiming to be this domain.', target_domain)
        if not dmarc:
            add_finding(context, 'email_security', f'No DMARC record on {target_domain}',
                        'HIGH' if has_mail else 'MEDIUM',
                        'Without DMARC, SPF/DKIM failures carry no enforcement policy and '
                        'spoofed mail is delivered normally.', target_domain)
        elif policy == 'none':
            add_finding(context, 'email_security', f'DMARC policy is p=none on {target_domain}', 'MEDIUM',
                        f'Monitoring only - spoofed mail is still delivered. Record: {dmarc}', target_domain)
        if has_mail and not dkim:
            add_finding(context, 'email_security', f'No DKIM key found for {target_domain}', 'LOW',
                        f'None of the {len(DKIM_SELECTORS)} common selectors published a key. '
                        'A custom selector may still exist - selectors are not enumerable via DNS.',
                        target_domain)

        context['mail_config'] = data
        return {'ok': True, 'data': data, 'error': None}
