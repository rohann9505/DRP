#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
TLS/SSL certificate + connection provider.

Web-Check splits this across three checks (ssl / tls-connection / tls-labs);
the first two are pure socket work and are reproduced here with Python's
stdlib `ssl` - no key, no binary, no external service. The third (Qualys SSL
Labs) is an external rate-limited API and is deliberately NOT reproduced -
see the inventory: a full Mozilla-guideline audit belongs to sslyze/testssl.sh
as a later provider, not to a third party's queue.

The certificate is fetched twice-over in one connection: once with
verification disabled (so an expired/self-signed cert still yields its
details rather than an exception - the same posture liveness_probe.py takes),
and the trust verdict is then established separately.
"""

import datetime
import os
import socket
import ssl
import sys
from concurrent.futures import ThreadPoolExecutor

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.x509.oid import ExtensionOID, NameOID

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

TLS_TIMEOUT = 5
TLS_CONCURRENCY = 10
EXPIRY_WARNING_DAYS = 30

# Protocols that should no longer be negotiable. TLSv1/1.1 are deprecated
# (RFC 8996); anything below that is long broken.
WEAK_PROTOCOLS = {'SSLv2', 'SSLv3', 'TLSv1', 'TLSv1.1'}


def _first(name, oid):
    """First value for an OID in an X.509 Name, or None."""
    try:
        attrs = name.get_attributes_for_oid(oid)
    except Exception:
        return None
    return attrs[0].value if attrs else None


def _parse_der(der):
    """Parses the certificate ourselves rather than using ssl's
    getpeercert().

    getpeercert() returns an EMPTY dict whenever the connection was made
    with verify_mode=CERT_NONE - and CERT_NONE is exactly the mode this
    provider must use, because an expired or self-signed certificate is
    precisely the case worth reporting and a verifying handshake would
    refuse to complete and hand back nothing at all. Parsing the DER gives
    the same fields for valid and invalid certificates alike.
    """
    cert = x509.load_der_x509_certificate(der)
    try:
        sans = sorted(cert.extensions.get_extension_for_oid(
            ExtensionOID.SUBJECT_ALTERNATIVE_NAME).value.get_values_for_type(x509.DNSName))
    except x509.ExtensionNotFound:
        sans = []
    not_after = cert.not_valid_after_utc
    not_before = cert.not_valid_before_utc
    return {
        'subject_cn': _first(cert.subject, NameOID.COMMON_NAME),
        'subject_org': _first(cert.subject, NameOID.ORGANIZATION_NAME),
        'issuer_cn': _first(cert.issuer, NameOID.COMMON_NAME),
        'issuer_org': _first(cert.issuer, NameOID.ORGANIZATION_NAME),
        'valid_from': not_before.isoformat(),
        'valid_to': not_after.isoformat(),
        'days_until_expiry': (not_after - datetime.datetime.now(datetime.timezone.utc)).days,
        'serial_number': format(cert.serial_number, 'x'),
        'signature_algorithm': cert.signature_algorithm_oid._name,
        'fingerprint_sha256': cert.fingerprint(hashes.SHA256()).hex(),
        'subject_alt_names': sans,
        'is_self_signed': cert.issuer == cert.subject,
    }


def inspect_tls(fqdn, port=443):
    """Returns a dict of certificate/connection facts, or {'error': ...}."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((fqdn, port), timeout=TLS_TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=fqdn) as tls:
                der = tls.getpeercert(binary_form=True)
                cipher = tls.cipher() or (None, None, None)
                info = {
                    'protocol': tls.version(),
                    'cipher_name': cipher[0],
                    'cipher_bits': cipher[2],
                    'alpn': tls.selected_alpn_protocol(),
                    'cert_size_bytes': len(der) if der else None,
                }
    except (OSError, ssl.SSLError, socket.timeout) as e:
        return {'error': str(e)}

    if not der:
        return {'error': 'no certificate presented'}
    try:
        info.update(_parse_der(der))
    except Exception as e:
        return {'error': f'certificate parse failed: {e}'}

    # Trust verdict, established in its own verified connection so that a
    # failure here is attributable to trust rather than to reachability.
    verify_ctx = ssl.create_default_context()
    try:
        with socket.create_connection((fqdn, port), timeout=TLS_TIMEOUT) as sock:
            with verify_ctx.wrap_socket(sock, server_hostname=fqdn):
                info['trusted'] = True
                info['trust_error'] = None
    except ssl.SSLCertVerificationError as e:
        info['trusted'] = False
        info['trust_error'] = e.verify_message or str(e)
    except (OSError, ssl.SSLError) as e:
        info['trusted'] = False
        info['trust_error'] = str(e)
    return info


class TlsProvider(AssetProvider):
    id = 'tls_probe'
    name = 'TLS/SSL Certificate & Connection (stdlib ssl)'
    category = 'tls'

    def collect(self, target_domain, context):
        fqdns = sorted(context.get('subdomains') or {target_domain})
        # Only hosts that answered a liveness probe - a TLS handshake to a
        # host already known to be unreachable is pure timeout.
        live = set((context.get('http_response') or {}).keys()) | {target_domain}
        fqdns = [f for f in fqdns if f in live]

        tls_by_fqdn = {}
        with ThreadPoolExecutor(max_workers=TLS_CONCURRENCY) as pool:
            for fqdn, info in zip(fqdns, pool.map(inspect_tls, fqdns)):
                if info.get('error'):
                    continue
                tls_by_fqdn[fqdn] = info

                days_left = info.get('days_until_expiry')
                if days_left is not None and days_left < 0:
                    add_finding(context, 'tls', f'TLS certificate expired on {fqdn}', 'CRITICAL',
                                f"Expired {abs(days_left)} day(s) ago ({info.get('valid_to')})", fqdn)
                elif days_left is not None and days_left <= EXPIRY_WARNING_DAYS:
                    add_finding(context, 'tls', f'TLS certificate expiring soon on {fqdn}',
                                'HIGH' if days_left <= 7 else 'MEDIUM',
                                f'Expires in {days_left} day(s) ({info.get("valid_to")})', fqdn)

                if info.get('trusted') is False:
                    reason = info.get('trust_error') or 'Certificate chain did not verify'
                    if info.get('is_self_signed'):
                        reason = f'Self-signed certificate. {reason}'
                    add_finding(context, 'tls', f'Untrusted TLS certificate on {fqdn}', 'HIGH',
                                reason, fqdn)

                if info.get('protocol') in WEAK_PROTOCOLS:
                    add_finding(context, 'tls', f'Deprecated TLS protocol on {fqdn}', 'HIGH',
                                f"Negotiated {info['protocol']}; TLS 1.2+ is required by RFC 8996", fqdn)

        context['tls'] = tls_by_fqdn
        return {'ok': True, 'data': {'tls_by_fqdn': tls_by_fqdn}, 'error': None}
