#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Nmap port + service/version detection.

The third provider in the `ports` category, running after ports_tcp and
naabu. Its distinct value is service/version detection (`-sV`) rather than
bare open/closed, so it MERGES into and ENRICHES what the earlier two
recorded in context['ports'] - a port they already found as
"MySQL"/"unknown" becomes "MySQL (MySQL 8.0.36)" when nmap fingerprints it,
and a genuinely new open port is unioned in. No privileges are available
here, so this is a connect scan (`-sT`); SYN/UDP are out of scope.

The binary is a locally-extracted official Ubuntu package launched through
tools/bin/nmap (a wrapper that sets the bundled library path and --datadir),
so no system install / root was needed. Strictness: only ports nmap reports
in state `open` are recorded; `filtered`/`closed` are ignored, and a
sensitive-port finding is only raised for a (host, port) the earlier passes
did not already flag, so findings are never double-counted.
"""

import os
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding
from lib.asset_providers.ports_tcp import PORT_SERVICES, SENSITIVE_PORTS

MAX_HOSTS_TO_SCAN = 8
TOP_PORTS = '100'
SCAN_TIMEOUT = 300        # hard ceiling for the whole nmap run


class NmapProvider(AssetProvider):
    id = 'nmap'
    name = 'Nmap'
    category = 'ports'
    requires_binary = 'nmap'
    # tools/bin/nmap is our wrapper; `--version` prints "Nmap version 7.98",
    # which contains the marker, so a same-named decoy still can't pose as it.
    binary_identity = (['--version'], 'nmap')

    def collect(self, target_domain, context):
        ip_to_fqdns = {}
        for ip in (context.get('resolved_ips') or [])[:1]:
            ip_to_fqdns.setdefault(ip, []).append(target_domain)
        for fqdn, records in (context.get('sub_dns') or {}).items():
            for ip in (records.get('A') or [])[:1]:
                ip_to_fqdns.setdefault(ip, []).append(fqdn)

        if not ip_to_fqdns:
            return {'ok': True, 'data': {'skipped': 'no resolved IPs'}, 'error': None}

        targets = sorted(ip_to_fqdns)[:MAX_HOSTS_TO_SCAN]
        cmd = [
            self.binary_path(),
            '-sT', '-sV', '-Pn',
            '--top-ports', TOP_PORTS,
            '--host-timeout', '40s',
            '-oX', '-',
        ] + targets
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=SCAN_TIMEOUT)
        except subprocess.TimeoutExpired:
            return {'ok': False, 'data': None,
                    'error': f'nmap exceeded the {SCAN_TIMEOUT}s scan timeout'}

        try:
            open_by_ip = self._parse_xml(proc.stdout or '')
        except ET.ParseError:
            return {'ok': False, 'data': None,
                    'error': f'nmap XML unparseable (exit {proc.returncode}): {(proc.stderr or "")[:200]}'}

        if proc.returncode != 0 and not open_by_ip:
            return {'ok': False, 'data': None,
                    'error': f'nmap exited {proc.returncode}: {(proc.stderr or "")[:300]}'}

        ports_by_fqdn = context.get('ports') or {}
        added = enriched = 0
        for ip, portmap in open_by_ip.items():
            for fqdn in ip_to_fqdns.get(ip, []):
                entries = ports_by_fqdn.setdefault(fqdn, list(ports_by_fqdn.get(fqdn, [])))
                by_port = {e['port']: e for e in entries}
                for port, svc in sorted(portmap.items()):
                    label = svc or PORT_SERVICES.get(port, 'unknown')
                    if port in by_port:
                        # Enrich: prefer nmap's fingerprinted service string.
                        if svc and by_port[port].get('service') != svc:
                            by_port[port]['service'] = svc
                            enriched += 1
                        continue
                    entries.append({'port': port, 'service': label})
                    added += 1
                    if port in SENSITIVE_PORTS:
                        severity, why = SENSITIVE_PORTS[port]
                        add_finding(context, 'ports',
                                    f'{PORT_SERVICES.get(port, port)} (port {port}) open on {fqdn}',
                                    severity, f'{why} - reachable at {ip}:{port} (nmap {label})', fqdn)
                entries.sort(key=lambda e: e['port'])

        context['ports'] = ports_by_fqdn
        return {'ok': True,
                'data': {'hosts_scanned': len(targets), 'new_ports_found': added,
                         'services_enriched': enriched,
                         'open_by_ip': {ip: sorted(p) for ip, p in open_by_ip.items()}},
                'error': None}

    @staticmethod
    def _parse_xml(xml_text):
        """{ip: {port: service_string}} for ports in state 'open' only."""
        out = {}
        if not xml_text.strip():
            return out
        root = ET.fromstring(xml_text)
        for host in root.findall('host'):
            addr = None
            for a in host.findall('address'):
                if a.get('addrtype') in ('ipv4', 'ipv6'):
                    addr = a.get('addr')
                    break
            if not addr:
                continue
            ports = out.setdefault(addr, {})
            for p in host.findall('./ports/port'):
                state = p.find('state')
                if state is None or state.get('state') != 'open':
                    continue
                try:
                    portid = int(p.get('portid'))
                except (TypeError, ValueError):
                    continue
                svc_el = p.find('service')
                label = ''
                if svc_el is not None:
                    name = svc_el.get('name') or ''
                    product = svc_el.get('product') or ''
                    version = svc_el.get('version') or ''
                    detail = ' '.join(x for x in (product, version) if x).strip()
                    base = PORT_SERVICES.get(portid) or (name.upper() if name else 'unknown')
                    label = f'{base} ({detail})' if detail else base
                ports[portid] = label
        return out
