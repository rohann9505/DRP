#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Per-subdomain DNS resolution.

This work used to live inline in asset_jobs.run_job() as its own thread
pool. It moved here because it is plainly provider work - it resolves names
over the network and produces per-asset data - and because two other
providers now need its output: ports_tcp.py scans resolved IPs, and the
job's per-asset records read the same records. Leaving it in the
orchestrator would have meant either running it twice or having providers
reach back into the job.

Basic record types only (A/AAAA/CNAME): a full 7-type lookup per subdomain
across a capped-but-dozens-large set is a lot of queries for records nobody
displays per-subdomain. The root domain still gets the full set from
dns_provider.py.
"""

import os
import sys
from concurrent.futures import ThreadPoolExecutor

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider
from lib.asset_providers import dns_provider

CONCURRENCY = 10


class SubdomainDnsProvider(AssetProvider):
    id = 'subdomain_dns'
    name = 'Per-Subdomain DNS Resolution (dnspython)'
    category = 'subdomain_dns'

    def collect(self, target_domain, context):
        fqdns = [f for f in sorted(context.get('subdomains') or ()) if f != target_domain]
        records_by_fqdn = {}
        if fqdns:
            def _resolve(fqdn):
                return dns_provider.resolve_all(fqdn, record_types=dns_provider.BASIC_RECORD_TYPES)

            with ThreadPoolExecutor(max_workers=CONCURRENCY) as pool:
                for fqdn, records in zip(fqdns, pool.map(_resolve, fqdns)):
                    records_by_fqdn[fqdn] = records

        context['sub_dns'] = records_by_fqdn
        return {'ok': True, 'data': {'resolved_count': len(records_by_fqdn)}, 'error': None}
