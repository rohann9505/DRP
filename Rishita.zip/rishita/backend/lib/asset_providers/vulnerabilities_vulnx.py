#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
VulnX (anouarbensaad/vulnx) - CMS detection adapter.

VulnX has two modes. Its headline mode is dork/exploit-DB guessing: it
queries search engines for a CMS's known-exploit dork patterns and lists
"possible" exploits. That output is unverified by construction (it never
confirms the exploit is actually present) and, from a server IP, the search
engines rate-limit/block it anyway - so wiring that mode would inject exactly
the kind of unconfirmed finding the pipeline's strict no-false-positive rule
forbids. It is therefore deliberately NOT invoked.

What IS wired is VulnX's factual `--cms` detection: the CMS and version it
reads directly from the target's own responses. That is verifiable, bounded,
and safe, so this adapter runs only `--cms` and contributes the detected
"<CMS> <version>" into context['technologies'] - real technology facts that
show in the UI and feed the OSV/nuclei providers. It emits no speculative
vulnerability findings of its own.

VulnX is a Python tool (not a native binary); it is launched through the
tools/bin/vulnx wrapper, which runs it from its own directory under AILENV.
"""

import os
import re
import subprocess
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

_ANSI_RE = re.compile(r'\x1B\[[0-9;]*[mK]')
_CMS_RE = re.compile(r'CMS\s*:\s*([A-Za-z][A-Za-z0-9 _-]+)', re.I)
_VER_RE = re.compile(r'version\D{0,12}(\d+(?:\.\d+){1,3})', re.I)
_UNKNOWN = {'unknown', 'uknown', 'none', ''}

PER_HOST_TIMEOUT = 45
MAX_HOSTS = 3


class VulnXProvider(AssetProvider):
    id = 'vulnx'
    name = 'VulnX (CMS detection)'
    category = 'vulnerabilities'
    requires_binary = 'vulnx'
    binary_identity = None   # python-tool wrapper; name collision not a risk

    def collect(self, target_domain, context):
        # Only hosts already proven up - never probe dead names, and stay
        # bounded so this cannot stall the scan.
        live = [f for f, r in (context.get('http_response') or {}).items()]
        targets = list(dict.fromkeys([target_domain] + sorted(live)))[:MAX_HOSTS]

        detected = {}
        techs = context.setdefault('technologies', {})
        for fqdn in targets:
            url = f'http://{fqdn}'
            try:
                proc = subprocess.run([self.binary_path(), '-u', url, '--cms'],
                                      capture_output=True, text=True, timeout=PER_HOST_TIMEOUT)
            except subprocess.TimeoutExpired:
                # One slow host must not sink the provider or the scan.
                continue
            except OSError as e:
                return {'ok': False, 'data': None, 'error': f'vulnx launch failed: {e}'}

            text = _ANSI_RE.sub('', f'{proc.stdout}\n{proc.stderr}')
            m = _CMS_RE.search(text)
            if not m:
                continue
            cms = m.group(1).strip()
            if cms.lower() in _UNKNOWN:
                continue
            vm = _VER_RE.search(text)
            label = f'{cms} {vm.group(1)}' if vm else cms
            detected[fqdn] = label
            existing = set(techs.get(fqdn) or [])
            existing.add(label)
            techs[fqdn] = sorted(existing)

        return {'ok': True,
                'data': {'cms_detected': detected, 'result_count': len(detected),
                         'hosts_checked': len(targets),
                         'note': 'strict --cms detection only; dork/exploit mode intentionally disabled'},
                'error': None}
