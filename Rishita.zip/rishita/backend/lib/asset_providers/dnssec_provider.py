#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
DNSSEC provider.

Web-Check answers this by asking Google's DNS-over-HTTPS endpoint
(dns.google/resolve) for DNSKEY/DS and reading the AD flag. We already
depend on dnspython and already query DNS directly (dns_provider.py), so
this asks the same questions over plain DNS instead of routing them through
a third party - same answers, one less external dependency, and no
disclosure of what we're scanning to an outside resolver.

The AD (Authenticated Data) flag is what actually proves a validating
resolver verified the chain, so it is requested explicitly rather than
inferred from the mere presence of a DNSKEY.
"""

import os
import sys

import dns.flags
import dns.message
import dns.query
import dns.rdatatype
import dns.resolver

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

DNS_TIMEOUT = 4
# A validating resolver is required for the AD flag to mean anything.
VALIDATING_RESOLVERS = ('1.1.1.1', '8.8.8.8')


def _query_type(fqdn, rdtype):
    resolver = dns.resolver.Resolver()
    resolver.timeout = DNS_TIMEOUT
    resolver.lifetime = DNS_TIMEOUT
    try:
        answer = resolver.resolve(fqdn, rdtype)
        return [str(r) for r in answer]
    except Exception:
        return []


def _authenticated_data(fqdn):
    """True if a validating resolver sets AD for this name - i.e. the DNSSEC
    chain actually validates, not merely that records exist."""
    query = dns.message.make_query(fqdn, dns.rdatatype.A, want_dnssec=True)
    for server in VALIDATING_RESOLVERS:
        try:
            response = dns.query.udp(query, server, timeout=DNS_TIMEOUT)
            return bool(response.flags & dns.flags.AD)
        except Exception:
            continue
    return None


class DnssecProvider(AssetProvider):
    id = 'dnssec_probe'
    name = 'DNSSEC Validation (dnspython)'
    category = 'dns_security'

    def collect(self, target_domain, context):
        dnskey = _query_type(target_domain, 'DNSKEY')
        ds = _query_type(target_domain, 'DS')
        ad = _authenticated_data(target_domain)

        data = {
            'dnskey_found': bool(dnskey),
            'dnskey_count': len(dnskey),
            'ds_found': bool(ds),
            'ds_records': ds,
            'authenticated_data': ad,
            'enabled': bool(dnskey) and bool(ds),
        }

        if not data['enabled']:
            add_finding(context, 'dns_security', f'DNSSEC not enabled for {target_domain}', 'LOW',
                        'No DNSKEY/DS chain published - DNS answers for this domain cannot be '
                        'cryptographically validated, leaving them open to spoofing.', target_domain)
        elif ad is False:
            # Records exist but do not validate: worse than not having it.
            add_finding(context, 'dns_security', f'DNSSEC published but failing validation on {target_domain}',
                        'HIGH', 'DNSKEY/DS records exist but a validating resolver did not set the '
                                'AD flag - a broken chain can make the domain unresolvable.', target_domain)

        context['dnssec'] = data
        return {'ok': True, 'data': data, 'error': None}
