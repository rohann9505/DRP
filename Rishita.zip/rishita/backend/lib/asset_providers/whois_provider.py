#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
WHOIS provider - registrar/creation/expiry/nameservers via the `python-whois`
package (pure-Python, talks directly to the relevant WHOIS server on TCP
port 43 - no external binary needed for the vast majority of TLDs). New
dependency added to requirements.txt; nothing in this codebase did WHOIS
lookups before this.
"""

import os
import sys
from datetime import datetime, date

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

WHOIS_TIMEOUT = 10


def _jsonable(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, list):
        return [_jsonable(v) for v in value]
    return value


class WhoisProvider(AssetProvider):
    id = 'python-whois'
    name = 'WHOIS (python-whois)'
    category = 'whois'

    def is_available(self):
        try:
            import whois  # noqa: F401
            return True
        except ImportError:
            return False

    def collect(self, target_domain, context):
        import whois
        w = whois.whois(target_domain)
        if not w or not (w.get('domain_name') if hasattr(w, 'get') else None):
            return {'ok': False, 'data': None, 'error': 'no WHOIS record found'}

        result = {
            'registrar': _jsonable(w.get('registrar')),
            'creation_date': _jsonable(w.get('creation_date')),
            'expiration_date': _jsonable(w.get('expiration_date')),
            'updated_date': _jsonable(w.get('updated_date')),
            'name_servers': _jsonable(w.get('name_servers')),
            'status': _jsonable(w.get('status')),
            'emails': _jsonable(w.get('emails')),
            'org': _jsonable(w.get('org')),
            'country': _jsonable(w.get('country')),
        }
        context['whois'] = result
        return {'ok': True, 'data': result, 'error': None}
