#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Naabu (ProjectDiscovery) port scanning.

The upgrade path for the `ports` category over ports_tcp.py's stdlib floor:
same connect-scan model (no root here, so SYN is unavailable - `-s connect`),
but naabu's own concurrency engine and a wider top-ports sweep than the fixed
32-port stdlib list. Registered AFTER PortsTcpProvider, so it MERGES its
findings into whatever ports_tcp already put in context['ports'] rather than
replacing it - the two are unioned per fqdn, and a sensitive-port finding is
only raised for a (host, port) the stdlib pass did not already flag, so no
finding is double-counted.

Strictness: only ports that actually complete a TCP connection are reported
(that is all a connect scan can assert); there is no inference, no
"filtered/maybe-open" state. Scans are keyed on resolved IP (reusing the
addresses DNS already established) and mapped back onto every fqdn sharing
that address, exactly like ports_tcp, so shared-anycast subdomains are not
re-scanned per hostname.
"""

import json
import os
import subprocess
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding
# Reuse the exact service names and sensitive-port severity table the stdlib
# scanner uses, so a port means the same thing regardless of which provider
# saw it.
from lib.asset_providers.ports_tcp import PORT_SERVICES, SENSITIVE_PORTS

MAX_HOSTS_TO_SCAN = 12
TOP_PORTS = '100'
CONCURRENCY = '25'
SCAN_TIMEOUT = 240        # hard ceiling for the whole naabu run


class NaabuProvider(AssetProvider):
    id = 'naabu'
    name = 'Naabu'
    category = 'ports'
    requires_binary = 'naabu'

    def collect(self, target_domain, context):
        # Same IP set ports_tcp derives - from what DNS already resolved, so
        # this provider does no resolution of its own.
        ip_to_fqdns = {}
        for ip in (context.get('resolved_ips') or [])[:1]:
            ip_to_fqdns.setdefault(ip, []).append(target_domain)
        for fqdn, records in (context.get('sub_dns') or {}).items():
            for ip in (records.get('A') or [])[:1]:
                ip_to_fqdns.setdefault(ip, []).append(fqdn)

        if not ip_to_fqdns:
            return {'ok': True, 'data': {'skipped': 'no resolved IPs'}, 'error': None}

        targets = sorted(ip_to_fqdns)[:MAX_HOSTS_TO_SCAN]
        cmd = [
            self.binary_path(),
            '-host', ','.join(targets),
            '-top-ports', TOP_PORTS,
            '-s', 'connect',
            '-c', CONCURRENCY,
            '-timeout', '2000',       # per-connection ms
            '-retries', '1',
            '-json', '-silent', '-disable-update-check',
        ]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=SCAN_TIMEOUT)
        except subprocess.TimeoutExpired:
            return {'ok': False, 'data': None,
                    'error': f'naabu exceeded the {SCAN_TIMEOUT}s scan timeout'}

        open_by_ip = {}
        for line in (proc.stdout or '').splitlines():
            line = line.strip()
            if not line.startswith('{'):
                continue
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            ip, port = rec.get('ip'), rec.get('port')
            if ip and isinstance(port, int):
                open_by_ip.setdefault(ip, set()).add(port)

        if proc.returncode != 0 and not open_by_ip:
            return {'ok': False, 'data': None,
                    'error': f'naabu exited {proc.returncode}: {(proc.stderr or "")[:300]}'}

        # Merge into (not replace) whatever ports_tcp already recorded.
        ports_by_fqdn = context.get('ports') or {}
        added = 0
        for ip, ports in open_by_ip.items():
            for fqdn in ip_to_fqdns.get(ip, []):
                existing = {e['port'] for e in ports_by_fqdn.get(fqdn, [])}
                merged = ports_by_fqdn.setdefault(fqdn, list(ports_by_fqdn.get(fqdn, [])))
                for port in sorted(ports):
                    if port in existing:
                        continue
                    merged.append({'port': port, 'service': PORT_SERVICES.get(port, 'unknown')})
                    added += 1
                    # Only flag a sensitive port the stdlib pass did not
                    # already flag for this host - avoids a duplicate finding.
                    if port in SENSITIVE_PORTS:
                        severity, why = SENSITIVE_PORTS[port]
                        add_finding(context, 'ports',
                                    f'{PORT_SERVICES.get(port, port)} (port {port}) open on {fqdn}',
                                    severity, f'{why} - reachable at {ip}:{port} (naabu)', fqdn)
                merged.sort(key=lambda e: e['port'])

        context['ports'] = ports_by_fqdn
        return {'ok': True,
                'data': {'hosts_scanned': len(targets), 'new_ports_found': added,
                         'open_by_ip': {ip: sorted(p) for ip, p in open_by_ip.items()}},
                'error': None}
