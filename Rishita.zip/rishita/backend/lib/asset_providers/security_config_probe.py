#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Security configuration provider - cheap, real findings derived from data
already collected by other v1 providers in the same job: missing security
headers (from the shared HTTP response) and WHOIS-expiry proximity. Each
finding is {'finding', 'severity', 'detail'}.
"""

import os
import sys
from datetime import datetime, timezone

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

_SECURITY_HEADERS = {
    'Strict-Transport-Security': ('MEDIUM', 'Missing HSTS header - connections can be silently downgraded to plain HTTP'),
    'Content-Security-Policy': ('LOW', 'Missing Content-Security-Policy header'),
    'X-Frame-Options': ('LOW', 'Missing X-Frame-Options header - page can be framed (clickjacking risk)'),
    'X-Content-Type-Options': ('LOW', 'Missing X-Content-Type-Options header - MIME-sniffing risk'),
    'Referrer-Policy': ('LOW', 'Missing Referrer-Policy header - full URLs may leak to third parties'),
    'Permissions-Policy': ('LOW', 'Missing Permissions-Policy header - browser features are not restricted'),
    'Cross-Origin-Opener-Policy': ('LOW', 'Missing Cross-Origin-Opener-Policy header'),
    'Cross-Origin-Resource-Policy': ('LOW', 'Missing Cross-Origin-Resource-Policy header'),
}

# Headers that hand out version/stack detail for free. Not a vulnerability
# on its own, but it is the reconnaissance step that precedes one.
_DISCLOSURE_HEADERS = ('Server', 'X-Powered-By', 'X-AspNet-Version', 'X-AspNetMvc-Version',
                       'X-Generator', 'X-Drupal-Cache')

WHOIS_EXPIRY_WARNING_DAYS = 30


def _parse_expiry(value):
    if isinstance(value, list):
        value = value[0] if value else None
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    except ValueError:
        return None


class SecurityConfigProbeProvider(AssetProvider):
    id = 'security_config_probe'
    name = 'Security Header/Config Checks'
    category = 'security_config'

    def collect(self, target_domain, context):
        findings = []
        responses = context.get('http_response') or {}
        headers_by_fqdn = {}
        for fqdn, resp in responses.items():
            present = {}
            for header, (severity, detail) in _SECURITY_HEADERS.items():
                if header in resp.headers:
                    present[header] = resp.headers[header]
                else:
                    findings.append({'finding': f'{header} missing on {fqdn}',
                                     'severity': severity, 'detail': detail})
                    add_finding(context, 'security_config', f'{header} missing on {fqdn}',
                                severity, detail, fqdn)
            headers_by_fqdn[fqdn] = present

            for header in _DISCLOSURE_HEADERS:
                value = resp.headers.get(header)
                # A bare product name ("nginx") leaks far less than a
                # version string ("nginx/1.18.0"), so only the latter is
                # worth reporting.
                if value and any(ch.isdigit() for ch in value):
                    detail = f'{header}: {value}'
                    findings.append({'finding': f'Version disclosure in {header} on {fqdn}',
                                     'severity': 'LOW', 'detail': detail})
                    add_finding(context, 'security_config',
                                f'Version disclosure in {header} on {fqdn}', 'LOW', detail, fqdn)

        context['security_headers'] = headers_by_fqdn
        whois_data = context.get('whois') or {}
        expiry = _parse_expiry(whois_data.get('expiration_date'))
        if expiry:
            days_left = (expiry - datetime.now(timezone.utc).replace(tzinfo=expiry.tzinfo) if expiry.tzinfo
                         else expiry - datetime.now()).days
            if days_left <= WHOIS_EXPIRY_WARNING_DAYS:
                severity = 'HIGH' if days_left <= 7 else 'MEDIUM'
                detail = f'WHOIS expiration_date: {whois_data.get("expiration_date")}'
                findings.append({
                    'finding': f'Domain registration expires in {days_left} day(s)',
                    'severity': severity, 'detail': detail,
                })
                add_finding(context, 'security_config',
                            f'Domain registration expires in {days_left} day(s)',
                            severity, detail, target_domain)

        context['security_findings'] = findings
        return {'ok': True, 'data': {'findings': findings}, 'error': None}
