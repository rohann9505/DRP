#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
WAF / CDN / edge-protection detection.

Header-and-cookie signature matching, ported in approach (not code) from
Web-Check's firewall check. It reads the HTTP response liveness_probe.py
already fetched, so it costs zero extra requests.

Worth having in an ASM context for the reason a defender cares about: a WAF
in front of a host changes how every other finding should be read - an open
port or a missing header behind Cloudflare is a different risk than the same
finding on a bare origin.
"""

import os
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

# (header, substring or None for "presence alone is the signal", label)
WAF_SIGNATURES = (
    ('server', 'cloudflare', 'Cloudflare'),
    ('cf-ray', None, 'Cloudflare'),
    ('cf-cache-status', None, 'Cloudflare'),
    ('server', 'sucuri', 'Sucuri CloudProxy'),
    ('x-sucuri-id', None, 'Sucuri CloudProxy'),
    ('server', 'imperva', 'Imperva SecureSphere'),
    ('x-iinfo', None, 'Imperva Incapsula'),
    ('x-cdn', 'incapsula', 'Imperva Incapsula'),
    ('server', 'akamaighost', 'Akamai'),
    ('x-akamai-transformed', None, 'Akamai'),
    ('server', 'awselb', 'AWS Elastic Load Balancer'),
    ('x-amz-cf-id', None, 'AWS CloudFront'),
    ('x-amzn-waf-action', None, 'AWS WAF'),
    ('server', 'big-ip', 'F5 BIG-IP'),
    ('server', 'barracudawaf', 'Barracuda WAF'),
    ('server', 'fortiweb', 'Fortinet FortiWeb'),
    ('via', 'ns-cache', 'Citrix NetScaler'),
    ('server', 'wallarm', 'Wallarm'),
    ('server', 'mod_security', 'ModSecurity'),
    ('server', 'ddos-guard', 'DDoS-Guard'),
    ('server', 'qrator', 'Qrator'),
    ('server', 'zscaler', 'Zscaler'),
    ('x-azure-ref', None, 'Azure Front Door'),
    ('x-fastly-request-id', None, 'Fastly'),
    ('x-served-by', 'cache-', 'Fastly'),
    ('server', 'gws', 'Google Web Server'),
    ('x-goog-', None, 'Google Cloud'),
    ('server', 'envoy', 'Envoy Proxy'),
    ('x-vercel-id', None, 'Vercel Edge'),
    ('x-nf-request-id', None, 'Netlify Edge'),
)

COOKIE_SIGNATURES = {
    '__cfduid': 'Cloudflare', '__cf_bm': 'Cloudflare',
    'incap_ses': 'Imperva Incapsula', 'visid_incap': 'Imperva Incapsula',
    'bigipserver': 'F5 BIG-IP', 'barra_counter_session': 'Barracuda WAF',
    'fortiwafsid': 'Fortinet FortiWeb', 'citrix_ns_id': 'Citrix NetScaler',
    'rbzid': 'Reblaze', '__ddg': 'DDoS-Guard',
}


def detect(headers, cookie_names=()):
    """Returns a sorted list of matched product labels."""
    lower = {k.lower(): (v or '') for k, v in headers.items()}
    found = set()
    for header, needle, label in WAF_SIGNATURES:
        if header.endswith('-'):
            # prefix-style signature (e.g. any 'x-goog-*' header)
            if any(k.startswith(header) for k in lower):
                found.add(label)
        elif header in lower and (needle is None or needle in lower[header].lower()):
            found.add(label)
    for cookie, label in COOKIE_SIGNATURES.items():
        if any(cookie in name.lower() for name in cookie_names):
            found.add(label)
    return sorted(found)


class FirewallProvider(AssetProvider):
    id = 'waf_detect'
    name = 'WAF/CDN Detection (header signatures)'
    category = 'waf'

    def collect(self, target_domain, context):
        responses = context.get('http_response') or {}
        waf_by_fqdn = {}
        for fqdn, resp in responses.items():
            matched = detect(resp.headers, list(resp.cookies.keys()))
            if matched:
                waf_by_fqdn[fqdn] = matched

        root = waf_by_fqdn.get(target_domain)
        if root:
            add_finding(context, 'waf', f'Edge protection detected on {target_domain}', 'INFO',
                        ', '.join(root), target_domain)
        elif target_domain in responses:
            add_finding(context, 'waf', f'No WAF/CDN signature on {target_domain}', 'LOW',
                        'The host responded directly with no recognised edge-protection headers - '
                        'requests may be reaching the origin server unfiltered.', target_domain)

        context['waf'] = waf_by_fqdn
        return {'ok': True, 'data': {'waf_by_fqdn': waf_by_fqdn}, 'error': None}
