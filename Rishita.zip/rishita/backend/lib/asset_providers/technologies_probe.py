#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Technology detection provider - derives tech signals from the HTTP
response(s) liveness_probe.py already fetched (context['http_response']):
Server/X-Powered-By headers, a set-cookie fingerprint, and a handful of
common HTML markers (meta generator tag, well-known JS/CSS library
signatures). Deliberately simple and dependency-light for v1 - a real
fingerprint database (Wappalyzer-style) is a natural later upgrade, not a
blocker for a working foundation.
"""

import os
import re
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

_HEADER_SIGNATURES = ('Server', 'X-Powered-By', 'X-AspNet-Version', 'X-Generator', 'Via')

_HTML_SIGNATURES = (
    (re.compile(r'<meta[^>]+generator["\']?\s+content=["\']([^"\']+)', re.I), 'generator'),
    (re.compile(r'wp-content|wp-includes', re.I), 'WordPress'),
    (re.compile(r'/sites/default/files|Drupal\.settings', re.I), 'Drupal'),
    (re.compile(r'react(?:-dom)?\.(?:production|development)', re.I), 'React'),
    (re.compile(r'ng-version=', re.I), 'Angular'),
    (re.compile(r'__NEXT_DATA__', re.I), 'Next.js'),
    (re.compile(r'cdn\.shopify\.com', re.I), 'Shopify'),
    (re.compile(r'jquery(?:-|\.)([0-9.]+)?\.js', re.I), 'jQuery'),
    (re.compile(r'Bootstrap v?([0-9.]+)?', re.I), 'Bootstrap'),
)

_COOKIE_SIGNATURES = {
    'PHPSESSID': 'PHP',
    'JSESSIONID': 'Java',
    'ASP.NET_SessionId': 'ASP.NET',
    'laravel_session': 'Laravel',
    'wordpress_logged_in': 'WordPress',
}


class TechnologiesProbeProvider(AssetProvider):
    id = 'technologies_probe'
    name = 'HTTP Header/Fingerprint Tech Detection'
    category = 'technologies'

    def collect(self, target_domain, context):
        responses = context.get('http_response') or {}
        # Merge into, not replace, whatever earlier providers (e.g. the httpx
        # liveness prober) already contributed for a host.
        techs_by_fqdn = {k: set(v) for k, v in (context.get('technologies') or {}).items()}
        for fqdn, resp in responses.items():
            found = techs_by_fqdn.get(fqdn, set())
            for header in _HEADER_SIGNATURES:
                value = resp.headers.get(header)
                if value:
                    found.add(f'{header}: {value}')
            for cookie_name, tech in _COOKIE_SIGNATURES.items():
                if cookie_name in resp.cookies:
                    found.add(tech)
            body = resp.text[:200000] if resp.text else ''
            for pattern, label in _HTML_SIGNATURES:
                m = pattern.search(body)
                if m:
                    found.add(label if not m.groups() or not m.group(1) else f'{label} {m.group(1)}')
            if found:
                techs_by_fqdn[fqdn] = sorted(found)

        # Normalise every entry to a sorted list (some may still be sets that
        # were seeded by httpx for hosts the stdlib probe got no response for).
        techs_by_fqdn = {k: (sorted(v) if isinstance(v, set) else v)
                         for k, v in techs_by_fqdn.items() if v}
        context['technologies'] = techs_by_fqdn
        return {'ok': True, 'data': {'technologies_by_fqdn': techs_by_fqdn}, 'error': None}
