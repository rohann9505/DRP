#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Directory/content enumeration provider - a small, fixed, conservative path
list checked against a per-host soft-404 baseline. Deliberately NOT a full
brute-force enumerator (no wordlist, no high request volume) - this is a
safe v1 foundation for the category, not a replacement for a dedicated tool
(gobuster/ffuf-class) later.

Why a baseline instead of "status < 400 means it exists"
-------------------------------------------------------
Plenty of real sites answer *every* URL with HTTP 200 and a styled
"not found"/landing page (a soft-404 or catch-all). Confirmed against
github.com, where a status-code-only check reported /wp-admin,
/phpmyadmin and /server-status as present. Status alone is therefore not
evidence that a path exists.

So before probing anything real, each host is calibrated: two guaranteed-
nonexistent random paths are fetched and become that host's "this is what
'absent' looks like here" reference. A candidate path is only reported when
it demonstrably differs from that reference - by status class, by
content-type, by redirect target, or by body content. That inverts the
default: a path is absent unless it proves otherwise, which is what makes a
catch-all site produce zero hits instead of one hit per probed path.

This needs the response body, so probes are capped GETs (MAX_BODY_BYTES,
streamed and closed early) rather than the HEAD requests an
existence-by-status-code check could get away with.
"""

import hashlib
import os
import re
import sys
import uuid
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

REQUEST_TIMEOUT = 3
# Every (fqdn, path) pair is one request - with a capped subdomain set this
# is still potentially hundreds of requests (see MAX_SUBDOMAINS_PER_SCAN's
# comment), so they all share ONE pool rather than nesting a per-fqdn pool
# around a serial per-path loop - a nested design's worst case is
# (fqdns / fqdn_concurrency) * paths * timeout; a flat shared pool's is
# (fqdns * paths / POOL_CONCURRENCY) * timeout, which scales with total
# work instead of the slowest dimension.
POOL_CONCURRENCY = 25
HEADERS = {'User-Agent': 'Anorphix-AssetIntel/1.0'}

# Bodies are only ever compared against each other, never stored, so they
# get read up to a cap and the connection dropped - a catch-all page's
# identity is established well within the first few KB, and this keeps a
# 200-request scan's bandwidth bounded no matter what the target serves.
MAX_BODY_BYTES = 32768

# Two baselines, deliberately different shapes: some catch-alls behave
# differently for a bare segment vs a nested path (and some route on file
# extensions). A candidate is discarded if it resembles EITHER one, which
# is the conservative direction.
BASELINE_PATH_SHAPES = ('{token}', '{token}/{token}.html')

# Jaccard overlap of the two bodies' unique-word sets, after normalization.
# Two renders of the same catch-all page land ~0.97-1.0; genuinely different
# pages on the same site (shared nav/footer/scripts) land well below 0.9.
SIMILARITY_THRESHOLD = 0.90

# "You may not see this" is still "this exists" - unlike a 404, a 401/403
# is a positive signal, but only when the host doesn't hand one out for
# random paths too (see _classify).
AUTH_STATUSES = (401, 403)

COMMON_PATHS = (
    'robots.txt', 'sitemap.xml', '.git/HEAD', '.env',
    '.well-known/security.txt', 'admin', 'login', '.aws/credentials',
)

_WORD_RE = re.compile(r'[a-z0-9_]+')
_DIGITS_RE = re.compile(r'\d+')
_WS_RE = re.compile(r'\s+')


def _normalize_body(text, strip_values=()):
    """Strips out the things that legitimately differ between two renders of
    the SAME page, so that what's left only differs when the pages really
    do. Chiefly: the probed path itself, which a catch-all typically echoes
    back ("No page at /wp-admin") and which would otherwise make every
    soft-404 look unique; and digit runs, which cover timestamps, request
    ids, nonces and cache-buster query strings."""
    if not text:
        return ''
    body = text.lower()
    for value in strip_values:
        if value:
            body = body.replace(value.lower(), ' ')
    body = _DIGITS_RE.sub('0', body)
    return _WS_RE.sub(' ', body).strip()


def _fingerprint(response, strip_values=()):
    """Reduces a response to the handful of comparable facts _classify()
    needs. Kept separate from the fetch so it can be unit-checked against
    canned responses."""
    body = _normalize_body(response['body'], strip_values)
    words = _WORD_RE.findall(body)
    location = response['location']
    if location:
        location = _normalize_body(location, strip_values)
    return {
        'status': response['status'],
        'content_type': (response['content_type'] or '').split(';')[0].strip().lower(),
        'location': location,
        'length': len(body),
        'word_count': len(words),
        'word_set': set(words),
        'digest': hashlib.sha1(body.encode('utf-8', 'replace')).hexdigest(),
    }


def _similarity(fp_a, fp_b):
    if fp_a['digest'] == fp_b['digest']:
        return 1.0
    set_a, set_b = fp_a['word_set'], fp_b['word_set']
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0
    return len(set_a & set_b) / len(set_a | set_b)


def _fetch(url, strip_values=()):
    """One capped GET. Returns a fingerprint, or None if the request failed
    (a failure is not evidence of absence OR presence - callers treat it as
    'no information')."""
    try:
        resp = requests.get(url, timeout=REQUEST_TIMEOUT, headers=HEADERS,
                            allow_redirects=False, verify=False, stream=True)
    except requests.RequestException:
        return None
    try:
        chunks = []
        size = 0
        for chunk in resp.iter_content(8192):
            chunks.append(chunk)
            size += len(chunk)
            if size >= MAX_BODY_BYTES:
                break
        raw = b''.join(chunks)[:MAX_BODY_BYTES]
        body = raw.decode(resp.encoding or 'utf-8', 'replace')
        return _fingerprint({
            'status': resp.status_code,
            'content_type': resp.headers.get('Content-Type'),
            'location': urljoin(url, resp.headers['Location']) if resp.headers.get('Location') else None,
            'body': body,
        }, strip_values)
    except Exception:
        return None
    finally:
        resp.close()


def calibrate(base_url):
    """Fetches this host's soft-404 reference: what it answers for paths that
    are guaranteed not to exist. Returns a list of fingerprints (possibly
    empty, if the host wouldn't answer)."""
    baselines = []
    for shape in BASELINE_PATH_SHAPES:
        token = f'anorphix-{uuid.uuid4().hex}'
        path = shape.format(token=token)
        fp = _fetch(f'{base_url}/{path}', strip_values=(path, token))
        if fp is not None:
            baselines.append(fp)
    return baselines


def _classify(candidate, baselines):
    """Decides whether `candidate` is real content or this host's way of
    saying "no such path". Returns a hit dict, or None to discard.

    The ordering matters: cheap, decisive signals (status class, redirect
    target, content-type) are checked before body comparison, so a
    well-behaved 404-serving host never needs the similarity math at all."""
    if candidate is None:
        return None
    status = candidate['status']

    if status >= 500:
        # A server error says nothing about whether the path exists.
        return None

    if status in AUTH_STATUSES:
        # Meaningful ONLY if random paths don't get the same treatment -
        # an entirely auth-walled host returns 401 for everything.
        if any(b['status'] == status for b in baselines):
            return None
        return {'reason': 'auth-required', 'evidence': f'HTTP {status} where random paths are not'}

    if 400 <= status < 500:
        # 404/410 and friends (405, 429, ...) - no evidence of existence.
        return None

    if 300 <= status < 400:
        baseline_locations = {b['location'] for b in baselines if 300 <= b['status'] < 400 and b['location']}
        if candidate['location'] and candidate['location'] in baseline_locations:
            # Catch-all that bounces every unknown path to the same place.
            return None
        return {'reason': 'redirect', 'evidence': f"HTTP {status} to a target random paths don't redirect to"}

    # --- 2xx from here on: the case status-code-only checking got wrong ---
    two_xx_baselines = [b for b in baselines if 200 <= b['status'] < 300]
    if not baselines:
        # Uncalibrated: without a reference there is no way to tell content
        # from a catch-all, and reporting on faith is exactly the bug this
        # provider is fixing. Say nothing.
        return None
    if not two_xx_baselines:
        # Host answers random paths with 404/redirect but answered this one
        # with 200 - that IS the distinguishing signal.
        return {'reason': 'status-differs',
                'evidence': f"HTTP {status} where random paths get {baselines[0]['status']}"}

    if candidate['content_type'] and all(
            candidate['content_type'] != b['content_type'] for b in two_xx_baselines):
        # e.g. robots.txt served as text/plain on a host whose catch-all is
        # text/html - a different content type is a different resource.
        return {'reason': 'content-type-differs', 'evidence': f"served as {candidate['content_type']}"}

    similarity = max(_similarity(candidate, b) for b in two_xx_baselines)
    if similarity >= SIMILARITY_THRESHOLD:
        return None
    return {'reason': 'content-differs',
            'evidence': f'body shares only {similarity:.0%} of the soft-404 page'}


class DirectoryEnumProbeProvider(AssetProvider):
    id = 'directory_enum_probe'
    name = 'Baseline-Calibrated Directory Enumeration'
    category = 'directory_enum'

    def collect(self, target_domain, context):
        responses = context.get('http_response') or {}
        live_fqdns = [fqdn for fqdn in sorted(context.get('subdomains') or {target_domain})
                      if responses.get(fqdn) is not None]
        base_urls = {fqdn: str(responses[fqdn].url).rstrip('/') for fqdn in live_fqdns}

        # Phase 1: calibrate every host. Has to complete before phase 2 for
        # a given host, but all hosts calibrate concurrently in the same
        # pool, so this costs one extra round-trip of wall-clock, not one
        # per host.
        with ThreadPoolExecutor(max_workers=POOL_CONCURRENCY) as pool:
            baselines_by_fqdn = dict(zip(live_fqdns, pool.map(
                lambda fqdn: calibrate(base_urls[fqdn]), live_fqdns)))

        # Phase 2: the real paths, each judged against its own host's baseline.
        def _check_pair(pair):
            fqdn, path = pair
            fp = _fetch(f'{base_urls[fqdn]}/{path}', strip_values=(path,))
            verdict = _classify(fp, baselines_by_fqdn.get(fqdn) or [])
            if not verdict:
                return fqdn, None
            return fqdn, {'path': path, 'status': fp['status'],
                          'reason': verdict['reason'], 'evidence': verdict['evidence']}

        pairs = [(fqdn, path) for fqdn in live_fqdns for path in COMMON_PATHS]
        found_by_fqdn = {}
        with ThreadPoolExecutor(max_workers=POOL_CONCURRENCY) as pool:
            for fqdn, hit in pool.map(_check_pair, pairs):
                if hit:
                    found_by_fqdn.setdefault(fqdn, []).append(hit)

        # Surfaced so a host that couldn't be calibrated is visibly
        # "unknown" rather than silently indistinguishable from a host with
        # genuinely nothing to find.
        uncalibrated = sorted(f for f in live_fqdns if not baselines_by_fqdn.get(f))

        context['directories'] = found_by_fqdn
        return {'ok': True,
                'data': {'directories_by_fqdn': found_by_fqdn, 'uncalibrated_fqdns': uncalibrated},
                'error': None}
