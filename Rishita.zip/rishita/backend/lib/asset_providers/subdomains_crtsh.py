#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Passive subdomain enumeration via crt.sh (Certificate Transparency log
search) - free, keyless, direct clearnet HTTP GET (using `requests`,
already a dependency). Real subdomain discovery for v1 without needing
Subfinder/Amass installed; see subdomains_subfinder.py / subdomains_amass.py
for the stubbed upgrade path once those binaries are available.
"""

import os
import re
import sys

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

CRTSH_URL = 'https://crt.sh/'
REQUEST_TIMEOUT = 20
_WILDCARD_RE = re.compile(r'^\*\.')


class SubdomainsCrtShProvider(AssetProvider):
    id = 'crtsh'
    name = 'Certificate Transparency (crt.sh)'
    category = 'subdomains'

    def collect(self, target_domain, context):
        resp = requests.get(CRTSH_URL, params={'q': f'%.{target_domain}', 'output': 'json'},
                             timeout=REQUEST_TIMEOUT, headers={'User-Agent': 'Anorphix-AssetIntel/1.0'})
        if resp.status_code != 200:
            return {'ok': False, 'data': None, 'error': f'crt.sh returned HTTP {resp.status_code}'}

        try:
            entries = resp.json()
        except ValueError:
            return {'ok': False, 'data': None, 'error': 'crt.sh returned unparseable JSON'}

        found = set()
        for entry in entries:
            name_value = entry.get('name_value') or ''
            for name in name_value.split('\n'):
                name = name.strip().lower()
                if not name or not name.endswith(target_domain):
                    continue
                name = _WILDCARD_RE.sub('', name)
                if name:
                    found.add(name)

        subdomains = sorted(found)
        context.setdefault('subdomains', set()).update(subdomains)
        return {'ok': True, 'data': {'subdomains': subdomains}, 'error': None}
