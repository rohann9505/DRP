#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Subfinder (ProjectDiscovery) passive subdomain enumeration.

Runs the real binary and folds its results into the same `subdomains`
category set every keyless source (crt.sh, CertSpotter, HackerTarget) feeds,
so the orchestrator's existing capping/resolution/liveness flow treats a
subfinder-discovered name exactly like any other - no orchestration change.

Strictness: subfinder is scoped with `-d <domain>`, but passive sources
occasionally return out-of-scope or malformed names, so every returned host
is re-validated (must be a well-formed hostname that is the target or a
subdomain of it) before it enters the set. Discovery is passive only - no
active DNS brute force here; whether a discovered name actually resolves and
responds is decided downstream by subdomain_dns / liveness, so a name that is
listed but dead surfaces as `disconnected`, never as a fabricated live asset.
"""

import os
import re
import subprocess
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

# Default (keyless) sources only - `-all` pulls in slow/rate-limited sources
# that pushed a single lookup past 45s in testing for no material recall gain.
SCAN_TIMEOUT = 120
_HOSTNAME_RE = re.compile(r'^(?=.{1,253}$)([a-z0-9_](?:[a-z0-9_-]{0,61}[a-z0-9_])?\.)+[a-z]{2,63}$')


class SubfinderProvider(AssetProvider):
    id = 'subfinder'
    name = 'Subfinder'
    category = 'subdomains'
    requires_binary = 'subfinder'

    def collect(self, target_domain, context):
        cmd = [
            self.binary_path(),
            '-d', target_domain,
            '-silent',
            '-no-color',
            '-timeout', '20',       # per-source HTTP timeout
        ]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=SCAN_TIMEOUT)
        except subprocess.TimeoutExpired as e:
            # A slow source should not sink the scan - keep whatever was
            # already emitted to stdout before the timeout.
            partial = self._parse(getattr(e, 'output', '') or '', target_domain)
            if partial:
                context.setdefault('subdomains', set()).update(partial)
                return {'ok': True,
                        'data': {'subdomains': sorted(partial),
                                 'note': f'subfinder timed out at {SCAN_TIMEOUT}s; partial results kept'},
                        'error': None}
            return {'ok': False, 'data': None,
                    'error': f'subfinder exceeded the {SCAN_TIMEOUT}s timeout with no output'}

        found = self._parse(proc.stdout or '', target_domain)
        if proc.returncode != 0 and not found:
            return {'ok': False, 'data': None,
                    'error': f'subfinder exited {proc.returncode}: {(proc.stderr or "")[:300]}'}

        context.setdefault('subdomains', set()).update(found)
        return {'ok': True, 'data': {'subdomains': sorted(found)}, 'error': None}

    @staticmethod
    def _parse(stdout, target_domain):
        target = target_domain.lower().strip('.')
        found = set()
        for line in stdout.splitlines():
            name = line.strip().lower().rstrip('.')
            if not name:
                continue
            # In-scope only, and a real hostname - never a wildcard, URL, or
            # log line that slipped through.
            if name != target and not name.endswith('.' + target):
                continue
            if not _HOSTNAME_RE.match(name):
                continue
            found.add(name)
        return found
