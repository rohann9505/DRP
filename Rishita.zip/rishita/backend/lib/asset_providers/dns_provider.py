#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
DNS resolution provider - A/AAAA/MX/NS/TXT/CNAME/SOA/CAA, direct clearnet
(no Tor - this is querying public DNS about a target's own infrastructure,
the same direct-request posture crawlers.py already uses for regular web
crawling). Modeled on the existing MX-lookup pattern in
bin/packages/lib_refine.py / bin/modules/Mail.py, generalized to every
common record type via dnspython (already an installed dependency).

On resolver choice and geographic answers
-----------------------------------------
This uses the host's configured recursive resolver (dnspython's default,
i.e. /etc/resolv.conf). That is deliberate, and the answers it returns are
correct *for this host's location*: large sites (github.com is the textbook
case) run GeoDNS/anycast and legitimately hand a different A record to a
resolver in Mumbai than to one in Virginia. A value that disagrees with an
external checker run from another country is therefore NOT evidence of
staleness - so the record's TTL, the resolver that answered, whether the
answer was authoritative, and the exact collection time are all captured
and surfaced, letting a viewer see *what* answered and *when* rather than
guessing whether a difference means "wrong".

Every record type that has an answer is stored in full (all values, sorted),
never just the first - see resolve_detailed().
"""

import os
import sys
import time

import dns.flags
import dns.resolver

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

RECORD_TYPES = ('A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'CAA')
BASIC_RECORD_TYPES = ('A', 'AAAA', 'CNAME')
DNS_TIMEOUT = 4


def _resolver():
    r = dns.resolver.Resolver()
    r.timeout = DNS_TIMEOUT
    r.lifetime = DNS_TIMEOUT
    return r


def _resolver_source(resolver):
    """A human label for which resolver answered - stored so the UI can show
    the provenance of the data instead of implying it is universal truth."""
    ns = list(resolver.nameservers or [])
    if not ns:
        return 'system resolver'
    # 127.0.0.53 is systemd-resolved's stub, the common Linux default.
    label = ', '.join(ns)
    if ns == ['127.0.0.53']:
        return f'system resolver ({label})'
    return f'resolver {label}'


def resolve_all(fqdn, record_types=RECORD_TYPES):
    """Back-compat helper: returns {record_type: [values]} only. Used by the
    per-subdomain path (subdomain_dns_provider) which only needs values."""
    records, _ttls, _meta = resolve_detailed(fqdn, record_types)
    return records


def resolve_detailed(fqdn, record_types=RECORD_TYPES):
    """Resolves every requested type and returns (records, ttls, meta).

      records : {rtype: [values, ...]}   every answer, sorted, never truncated
      ttls    : {rtype: ttl_seconds}     the record's own TTL as served
      meta    : {source, authoritative, collected_at}

    A type with no answer (NXDOMAIN/NoAnswer) is simply absent from records
    rather than raising. CNAME chains are followed by the resolver for A/AAAA
    lookups automatically; the CNAME record itself is also captured under the
    'CNAME' key when present.
    """
    resolver = _resolver()
    records = {}
    ttls = {}
    authoritative = False
    for rtype in record_types:
        try:
            answer = resolver.resolve(fqdn, rtype)
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.NoNameservers,
                dns.exception.Timeout):
            continue
        except Exception:
            continue
        try:
            records[rtype] = sorted(str(rdata).rstrip('.') for rdata in answer)
            if answer.rrset is not None:
                ttls[rtype] = int(answer.rrset.ttl)
            # AA flag is set only when the answering server is authoritative;
            # through a recursive resolver it is normally 0. Honest metadata.
            if getattr(answer, 'response', None) is not None:
                authoritative = authoritative or bool(answer.response.flags & dns.flags.AA)
        except Exception:
            continue

    meta = {
        'source': _resolver_source(resolver),
        'authoritative': authoritative,
        'collected_at': int(time.time()),
    }
    return records, ttls, meta


class DnsProvider(AssetProvider):
    id = 'dnspython'
    name = 'DNS Resolution (dnspython)'
    category = 'dns'

    def collect(self, target_domain, context):
        records, ttls, meta = resolve_detailed(target_domain)
        resolved_ips = sorted(set(records.get('A', []) + records.get('AAAA', [])))
        context['resolved_ips'] = resolved_ips
        context['dns_records'] = records
        context['dns_ttls'] = ttls
        context['dns_source'] = meta['source']
        context['dns_authoritative'] = meta['authoritative']
        context['dns_collected_at'] = meta['collected_at']
        return {'ok': True,
                'data': {'records': records, 'ttls': ttls, 'resolved_ips': resolved_ips,
                         'source': meta['source'], 'authoritative': meta['authoritative'],
                         'collected_at': meta['collected_at']},
                'error': None}
