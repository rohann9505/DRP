#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
OSV-Scanner (google/osv-scanner) dependency vulnerability provider.

Where nuclei probes the live host for exploitable conditions, OSV answers a
different question: of the *software components* this scan already
fingerprinted (technologies_probe / httpx / nmap -sV), which carry known
vulnerabilities per the OSV database (osv.dev, aggregating CVE/GHSA/PYSEC/
GO/etc.)?

It is genuinely wired into the domain workflow rather than pointed at source
we do not have: components detected on the target with a confident
version AND a confident package-ecosystem mapping are emitted as an SBOM
(CycloneDX), and the official osv-scanner binary is run against that SBOM.
Only components we can map without guessing an ecosystem are included - a
bare "Server: Apache/2.4.7" banner is NOT force-mapped to some OS ecosystem,
because that would fabricate the very identifier OSV keys on. This keeps the
provider strict: it reports a vulnerability only for a (real package, real
version) OSV itself matched, and severity comes only from OSV's own CVSS
score, never invented.

Findings are normalized into the shared vulnerability finding shape (the same
list nuclei writes to, so they rank/alert/deduplicate together) and merged
into context['vulnerabilities'][fqdn], deduplicated against any nuclei
finding that already carries the same CVE/GHSA/OSV id for that host.
"""

import json
import os
import re
import subprocess
import sys
import tempfile

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider, add_finding

SCAN_TIMEOUT = 240

# Curated, conservative label -> (ecosystem, package, purl-type). Only
# front-end libraries whose detected name maps unambiguously to a real OSV
# package are listed; anything not here is skipped rather than guessed. The
# key is matched case-insensitively against the leading name token of a
# detected "<Name> <version>" technology string.
_TECH_TO_PACKAGE = {
    'jquery': ('npm', 'jquery'),
    'jquery-ui': ('npm', 'jquery-ui'),
    'bootstrap': ('npm', 'bootstrap'),
    'angular': ('npm', '@angular/core'),
    'angularjs': ('npm', 'angular'),
    'react': ('npm', 'react'),
    'react-dom': ('npm', 'react-dom'),
    'vue': ('npm', 'vue'),
    'lodash': ('npm', 'lodash'),
    'moment': ('npm', 'moment'),
    'moment.js': ('npm', 'moment'),
    'axios': ('npm', 'axios'),
    'handlebars': ('npm', 'handlebars'),
    'underscore': ('npm', 'underscore'),
    'dompurify': ('npm', 'dompurify'),
    'next.js': ('npm', 'next'),
    'nextjs': ('npm', 'next'),
}

# "<Name> <version>" where version is 2-4 dotted numbers, optional leading v.
_NAME_VERSION_RE = re.compile(r'^([A-Za-z][A-Za-z0-9.#+_-]*?)[\s/]+v?(\d+(?:\.\d+){1,3})\b')


def _cvss_to_severity(score):
    try:
        s = float(score)
    except (TypeError, ValueError):
        return 'INFO'
    if s >= 9.0:
        return 'CRITICAL'
    if s >= 7.0:
        return 'HIGH'
    if s >= 4.0:
        return 'MEDIUM'
    if s > 0.0:
        return 'LOW'
    return 'INFO'


class OsvScannerProvider(AssetProvider):
    id = 'osv-scanner'
    name = 'OSV-Scanner (dependency CVEs)'
    category = 'vulnerabilities'
    requires_binary = 'osv-scanner'
    # `osv-scanner --version` prints "osv-scanner version: X.Y.Z".
    binary_identity = (['--version'], 'osv-scanner')

    # ---- component extraction -------------------------------------------

    def _components(self, context):
        """Return (components, purl_to_fqdns): the confidently-mapped
        (name, version, ecosystem, purl) tuples detected on the target, and
        which fqdn(s) each purl was seen on, for attribution."""
        comps = {}
        purl_to_fqdns = {}
        techs = context.get('technologies') or {}
        for fqdn, entries in techs.items():
            for raw in entries:
                m = _NAME_VERSION_RE.match(raw.strip())
                if not m:
                    continue
                name = m.group(1).lower().strip('.-_')
                version = m.group(2)
                mapping = _TECH_TO_PACKAGE.get(name)
                if not mapping:
                    continue
                ecosystem, pkg = mapping
                purl = f'pkg:{ecosystem}/{pkg}@{version}'
                comps[purl] = {'name': pkg, 'version': version, 'purl': purl}
                purl_to_fqdns.setdefault(purl, set()).add(fqdn)
        return list(comps.values()), purl_to_fqdns

    # ---- osv-scanner invocation -----------------------------------------

    def collect(self, target_domain, context):
        components, purl_to_fqdns = self._components(context)
        if not components:
            # Honest zero: nothing on this target mapped to a real OSV
            # package/version, so there is nothing for OSV to check.
            return {'ok': True,
                    'data': {'findings': [], 'result_count': 0, 'validated_count': 0,
                             'skipped': 'no version-pinned, ecosystem-mappable components detected'},
                    'error': None}

        workdir = tempfile.mkdtemp(prefix='osv_')
        sbom_path = os.path.join(workdir, 'bom.cdx.json')
        with open(sbom_path, 'w') as f:
            json.dump({
                'bomFormat': 'CycloneDX', 'specVersion': '1.5', 'version': 1,
                'components': [{'type': 'library', 'name': c['name'],
                                'version': c['version'], 'purl': c['purl']} for c in components],
            }, f)

        cmd = [self.binary_path(), 'scan', 'source',
               f'--sbom={sbom_path}', '--format=json']
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=SCAN_TIMEOUT)
        except subprocess.TimeoutExpired:
            return {'ok': False, 'data': None,
                    'error': f'osv-scanner exceeded the {SCAN_TIMEOUT}s scan timeout'}
        finally:
            try:
                os.remove(sbom_path)
                os.rmdir(workdir)
            except OSError:
                pass

        # osv-scanner exits 1 when it *finds* vulnerabilities - that is a
        # success, not an error. Only a missing/empty JSON body on a non
        # {0,1} exit is a real failure.
        raw = (proc.stdout or '').strip()
        if not raw:
            if proc.returncode in (0, 1):
                return {'ok': True, 'data': {'findings': [], 'result_count': 0,
                                             'validated_count': len(components)}, 'error': None}
            return {'ok': False, 'data': None,
                    'error': f'osv-scanner exited {proc.returncode}: {(proc.stderr or "")[:300]}'}
        try:
            report = json.loads(raw)
        except ValueError:
            return {'ok': False, 'data': None, 'error': 'osv-scanner returned unparseable JSON'}

        findings = self._normalize(report, purl_to_fqdns, target_domain)

        # Merge into the shared per-fqdn vulnerability map, deduplicating
        # against ids already recorded (e.g. by nuclei) for the same host.
        existing = context.get('vulnerabilities') or {}
        existing_ids = {fqdn: {i.upper() for v in vs for i in self._ids_of(v)}
                        for fqdn, vs in existing.items()}
        deduped = 0
        kept = []
        for f in findings:
            fqdn = f['fqdn']
            fids = {i.upper() for i in (f.get('cve_ids') or []) + list((f.get('ids') or {}).values())
                    if i}
            if existing_ids.get(fqdn, set()) & fids:
                deduped += 1
                continue
            existing.setdefault(fqdn, []).append(f)
            existing_ids.setdefault(fqdn, set()).update(fids)
            add_finding(context, 'vulnerabilities', f['title'], f['severity'], f['detail'], fqdn)
            kept.append(f)
        context['vulnerabilities'] = existing

        return {'ok': True,
                'data': {'findings': kept, 'result_count': len(kept),
                         'validated_count': len(components), 'deduplicated_count': deduped,
                         'components_scanned': len(components)},
                'error': None}

    # ---- normalization ---------------------------------------------------

    @staticmethod
    def _ids_of(vuln_finding):
        out = list(vuln_finding.get('cve_ids') or [])
        ids = vuln_finding.get('ids') or {}
        out += [v for v in ids.values() if v]
        return out

    def _normalize(self, report, purl_to_fqdns, target_domain):
        findings = []
        for result in report.get('results', []):
            for pkg in result.get('packages', []):
                pinfo = pkg.get('package') or {}
                name = pinfo.get('name')
                version = pinfo.get('version')
                ecosystem = pinfo.get('ecosystem')
                purl = pinfo.get('purl') or f'pkg:{(ecosystem or "").lower()}/{name}@{version}'
                fqdns = purl_to_fqdns.get(purl) or purl_to_fqdns.get(
                    f'pkg:npm/{name}@{version}') or {target_domain}

                vulns_by_id = {v.get('id'): v for v in pkg.get('vulnerabilities', [])}
                for group in pkg.get('groups', []):
                    group_ids = group.get('ids') or []
                    aliases = group.get('aliases') or []
                    all_ids = list(dict.fromkeys(group_ids + aliases))
                    cve_ids = [i for i in all_ids if i.upper().startswith('CVE-')]
                    ghsa = next((i for i in all_ids if i.upper().startswith('GHSA-')), None)
                    osv_id = next((i for i in all_ids if not i.upper().startswith(('CVE-', 'GHSA-'))), None)
                    severity = _cvss_to_severity(group.get('max_severity'))

                    # Pull remediation/detail from the primary vuln record.
                    primary = None
                    for gid in group_ids:
                        if gid in vulns_by_id:
                            primary = vulns_by_id[gid]
                            break
                    fixed = self._fixed_versions(primary) if primary else []
                    refs = [r.get('url') for r in (primary.get('references') or [])][:5] if primary else []
                    summary = (primary or {}).get('summary') or (primary or {}).get('details') or ''
                    summary = (summary or '').strip().split('\n')[0][:200]

                    ident = cve_ids[0] if cve_ids else (ghsa or osv_id or 'OSV')
                    title = f'{name} {version}: {ident}'
                    remediation = (f'Upgrade {name} to {", ".join(fixed)}' if fixed
                                   else f'No fixed version published for {name} {version}')
                    detail_bits = [
                        f'package: {name}@{version} ({ecosystem})',
                        f'ids: {", ".join(all_ids)}' if all_ids else None,
                        f'cvss: {group.get("max_severity")}' if group.get('max_severity') else None,
                        f'fixed: {", ".join(fixed)}' if fixed else 'fixed: none published',
                        summary or None,
                    ]
                    for fqdn in sorted(fqdns):
                        findings.append({
                            'severity': severity,
                            'title': title,
                            'fqdn': fqdn,
                            'source': 'osv-scanner',
                            'ids': {'cve': cve_ids[0] if cve_ids else None,
                                    'ghsa': ghsa, 'osv': osv_id},
                            'cve_ids': cve_ids,
                            'package': name,
                            'ecosystem': ecosystem,
                            'affected_version': version,
                            'fixed_versions': fixed,
                            'cvss': group.get('max_severity'),
                            'references': refs,
                            'remediation': remediation,
                            'detail': ' | '.join(b for b in detail_bits if b),
                        })
        return findings

    @staticmethod
    def _fixed_versions(vuln):
        fixed = []
        for aff in vuln.get('affected', []):
            for rng in aff.get('ranges', []):
                for ev in rng.get('events', []):
                    if ev.get('fixed'):
                        fixed.append(ev['fixed'])
        return sorted(set(fixed))
