#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Additional keyless passive subdomain sources, alongside crt.sh.

Web-Check queries three CT/OSINT sources and takes the first that answers.
We union them instead: each source has different blind spots (crt.sh only
sees certificates it has indexed; CertSpotter's free tier truncates;
HackerTarget's free tier is rate-limited but draws on passive DNS rather
than CT alone), and asset discovery is one of the few places where a
false negative costs more than a duplicate.

Both are best-effort: a rate-limited or unavailable source returns ok=False
with a reason and the scan continues on whatever the others found. That is
the whole point of registering several providers per category.
"""

import os
import re
import sys

import requests

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

REQUEST_TIMEOUT = 20
HEADERS = {'User-Agent': 'Anorphix-AssetIntel/1.0'}
_WILDCARD_RE = re.compile(r'^\*\.')


def _accept(names, target_domain, context):
    found = set()
    for name in names:
        name = _WILDCARD_RE.sub('', (name or '').strip().lower().rstrip('.'))
        if name and (name == target_domain or name.endswith(f'.{target_domain}')):
            found.add(name)
    subdomains = sorted(found)
    context.setdefault('subdomains', set()).update(subdomains)
    return subdomains


class SubdomainsCertSpotterProvider(AssetProvider):
    id = 'certspotter'
    name = 'Certificate Transparency (CertSpotter)'
    category = 'subdomains'

    URL = 'https://api.certspotter.com/v1/issuances'

    def collect(self, target_domain, context):
        resp = requests.get(self.URL, timeout=REQUEST_TIMEOUT, headers=HEADERS, params={
            'domain': target_domain, 'include_subdomains': 'true', 'expand': 'dns_names',
        })
        if resp.status_code == 429:
            return {'ok': False, 'data': None, 'error': 'CertSpotter rate limit reached (free tier)'}
        if resp.status_code != 200:
            return {'ok': False, 'data': None, 'error': f'CertSpotter returned HTTP {resp.status_code}'}
        try:
            entries = resp.json()
        except ValueError:
            return {'ok': False, 'data': None, 'error': 'CertSpotter returned unparseable JSON'}

        names = []
        for entry in entries:
            names.extend(entry.get('dns_names') or [])
        return {'ok': True, 'data': {'subdomains': _accept(names, target_domain, context)}, 'error': None}


class SubdomainsHackerTargetProvider(AssetProvider):
    id = 'hackertarget'
    name = 'Passive DNS (HackerTarget)'
    category = 'subdomains'

    URL = 'https://api.hackertarget.com/hostsearch/'

    def collect(self, target_domain, context):
        resp = requests.get(self.URL, timeout=REQUEST_TIMEOUT, headers=HEADERS,
                            params={'q': target_domain})
        if resp.status_code != 200:
            return {'ok': False, 'data': None, 'error': f'HackerTarget returned HTTP {resp.status_code}'}
        text = resp.text or ''
        # The free endpoint signals quota exhaustion with a plain-text
        # message and HTTP 200, so status alone is not enough.
        if 'error' in text.lower() or 'api count exceeded' in text.lower():
            return {'ok': False, 'data': None, 'error': f'HackerTarget: {text.strip()[:120]}'}

        names = [line.split(',', 1)[0] for line in text.splitlines() if ',' in line]
        return {'ok': True, 'data': {'subdomains': _accept(names, target_domain, context)}, 'error': None}
