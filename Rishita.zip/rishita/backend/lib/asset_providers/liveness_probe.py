#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Liveness provider - direct HTTP(S) probe (falling back to a raw TCP connect
on 443/80 if HTTP itself fails) to determine live vs disconnected per
discovered fqdn. The one response object it fetches is stashed in
`context['http_response'][fqdn]` so technologies_probe.py and
security_config_probe.py can read the same headers/body instead of each
re-requesting the target - a courtesy to whatever's actually being probed,
not just an efficiency trick.

See probe_httpx.py for the stubbed future upgrade path (ProjectDiscovery's
httpx binary) once it's installed.
"""

import os
import socket
import sys
from concurrent.futures import ThreadPoolExecutor

import requests
import urllib3

# verify=False below is intentional (a live-but-self-signed/expired cert on
# a scanned target is still "live" - liveness is not a cert-validity check)
# - silence the resulting per-request warning noise.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.asset_providers.base import AssetProvider

REQUEST_TIMEOUT = 6
PROBE_CONCURRENCY = 10
HEADERS = {'User-Agent': 'Anorphix-AssetIntel/1.0'}


def probe_fqdn(fqdn):
    """Returns (status: 'live'|'disconnected', response_or_none)."""
    for scheme in ('https', 'http'):
        try:
            resp = requests.get(f'{scheme}://{fqdn}/', timeout=REQUEST_TIMEOUT, headers=HEADERS,
                                 allow_redirects=True, verify=False)
            return 'live', resp
        except requests.RequestException:
            continue

    for port in (443, 80):
        try:
            with socket.create_connection((fqdn, port), timeout=REQUEST_TIMEOUT):
                return 'live', None
        except OSError:
            continue

    return 'disconnected', None


class LivenessProbeProvider(AssetProvider):
    id = 'liveness_probe'
    name = 'HTTP/TCP Liveness Probe'
    category = 'liveness'

    def collect(self, target_domain, context):
        fqdns = sorted(context.get('subdomains') or {target_domain})
        results = {}
        responses = context.setdefault('http_response', {})
        # Sequential probing of even a capped ~40-domain set (see
        # MAX_SUBDOMAINS_PER_SCAN) can take minutes at real network
        # timeouts - a small thread pool keeps this to roughly
        # REQUEST_TIMEOUT * 2 worst-case instead of that multiplied by
        # every fqdn.
        with ThreadPoolExecutor(max_workers=PROBE_CONCURRENCY) as pool:
            for fqdn, (status, resp) in zip(fqdns, pool.map(probe_fqdn, fqdns)):
                results[fqdn] = status
                if resp is not None:
                    responses[fqdn] = resp
        return {'ok': True, 'data': {'status_by_fqdn': results}, 'error': None}
