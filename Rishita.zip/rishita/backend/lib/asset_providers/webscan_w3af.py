#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""Stub - w3af web application scanning. Not installed; clean,
ready-to-activate integration point for a dedicated 'web_scan' category
(deeper application-layer scanning than security_config_probe.py's cheap
header checks)."""

import os
import sys

sys.path.append(os.environ['AIL_BIN'])
from lib.asset_providers.base import AssetProvider


class W3afProvider(AssetProvider):
    id = 'w3af'
    name = 'w3af'
    category = 'web_scan'
    requires_binary = 'w3af'
    # Prevent a same-named decoy from reporting this stub as active.
    binary_identity = (['--version'], 'w3af')
