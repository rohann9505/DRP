#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Browser fetch backend for challenge-protected forums.

Why this exists: plain `requests` cannot pass a JS anti-bot challenge, and the
audit confirmed live that both currently-registered HTML forums sit behind one
(breached.st -> Cloudflare "Just a moment", xforums.st -> DNSProxy antibot).
A verified Lacus/Playwright browser capture of the very same xforums.st URL
that `requests` was blocked on succeeded, which proves the block is on the
HTTP client's lack of a JS runtime, not on the source refusing us outright.

So the crawl engine uses a two-tier fetch strategy:
    1. plain HTTP through Tor  - cheap, used for everything that works
    2. real browser through Tor - only for forums that fail tier 1

Tier 2 is a genuine browser with a JS runtime, so a challenge that resolves on
its own (Cloudflare's non-interactive "managed" check, DDoS-Guard's JS check)
completes normally. It waits for that to settle and returns the resulting page.

This does NOT bypass authentication, solve CAPTCHAs, or defeat access controls
- an interactive challenge or a login wall still returns a block, which the
caller reports as an access failure. It only supplies the JS execution that a
normal visitor's browser would perform. Cookies persist for the life of the
session so the challenge clearance is reused across pages rather than being
re-triggered on every request, which is both faster and far less abusive to
the source than repeatedly re-solving.
"""

import os
import sys
import time

sys.path.append(os.environ['AIL_BIN'])

from lib.forum_providers import base as fp_base

TOR_SOCKS = os.environ.get('FORUM_CRAWL_TOR_PROXY_HOSTPORT', 'socks5://127.0.0.1:9050')
NAV_TIMEOUT_MS = int(os.environ.get('FORUM_BROWSER_TIMEOUT_MS', 90000))
# How long to keep waiting for a JS challenge to clear itself.
CHALLENGE_WAIT_SECONDS = int(os.environ.get('FORUM_BROWSER_CHALLENGE_WAIT', 35))

USER_AGENT = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

# Runs in the page: find the first visible text occurrence of `needle`, walk up
# to the enclosing forum post, highlight the matched run, and scroll it to the
# centre of the viewport. Returns true if it anchored on something. Purely
# cosmetic (highlight + scroll) - it reads the page, never submits or bypasses
# anything.
_FOCUS_HIGHLIGHT_JS = r"""
(needle) => {
  if (!needle) return false;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(n){
      if (!n.nodeValue || n.nodeValue.toLowerCase().indexOf(needle) === -1) return NodeFilter.FILTER_REJECT;
      const p = n.parentElement;
      if (!p) return NodeFilter.FILTER_REJECT;
      const t = p.tagName;
      if (t === 'SCRIPT' || t === 'STYLE' || t === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
      if (!p.offsetParent && p.offsetHeight === 0) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  const node = walker.nextNode();
  if (!node) return false;
  const idx = node.nodeValue.toLowerCase().indexOf(needle);
  try {
    const tail = node.splitText(idx);
    const mark = document.createElement('mark');
    mark.textContent = tail.nodeValue.substring(0, needle.length);
    mark.style.cssText = 'background:#fff2a8;color:#111;padding:1px 3px;border-radius:2px;outline:2px solid #e0a800;font-weight:600;';
    tail.nodeValue = tail.nodeValue.substring(needle.length);
    tail.parentNode.insertBefore(mark, tail);
    mark.scrollIntoView({block: 'center', inline: 'nearest'});
    return true;
  } catch (e) {
    try { node.parentElement.scrollIntoView({block: 'center'}); } catch(_){}
    return true;
  }
}
"""


class BrowserSession:
    """A persistent Chromium session routed through Tor.

    Held open across a forum's whole crawl so anti-bot clearance cookies are
    reused instead of re-earned per page.
    """

    def __init__(self, proxy=None, headless=True, cookies=None,
                 use_default_proxy=True, user_data_dir=None, engine='chromium'):
        """
        `proxy` is Playwright's ProxySettings shape - {'server', 'username',
        'password'} - or None. A plain string is accepted for backwards
        compatibility and treated as the server.

        `engine` selects the browser engine ('chromium' default, or 'firefox').
        Some hidden services close the connection on Chromium's request but
        serve Firefox normally (same engine family as Tor Browser). Firefox is
        used for the HEADED operator login on those, so the human can reach the
        page and solve any challenge THEMSELVES - it is a compatibility choice,
        never a way to defeat a check automatically.

        `use_default_proxy` distinguishes "caller said nothing, use Tor" from
        "caller resolved the route to DIRECT". Chromium cannot take credentials
        inline in a SOCKS URL the way requests can, which is why the caller
        hands us the split form rather than a URL.

        `user_data_dir` turns on a PERSISTENT profile: cookies AND localStorage
        AND the whole authenticated context survive across crawls and restarts,
        launched with `launch_persistent_context`. This is the legitimate reuse
        of a session a human established once (they log in - and solve any
        CAPTCHA - themselves in a headed profile); we never establish or solve
        it automatically. When None the session is ephemeral, exactly as before.
        """
        self._pw = None
        self._browser = None
        self._ctx = None
        self._page = None
        if isinstance(proxy, str):
            proxy = {'server': proxy}
        if proxy is None and use_default_proxy:
            proxy = {'server': TOR_SOCKS}
        self._proxy = proxy          # None => direct, no proxy at all
        self._headless = headless
        self._user_data_dir = user_data_dir
        self._engine = (engine or 'chromium').lower()
        # Operator-supplied authenticated session (see forum_crawl.load_cookiejar).
        self._cookies = cookies or []

    def start(self):
        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()
        engine = self._pw.firefox if self._engine == 'firefox' else self._pw.chromium
        # Chromium-only launch flags; Firefox rejects these, so it gets none.
        if self._engine == 'firefox':
            args = []
        else:
            args = ['--no-sandbox', '--disable-dev-shm-usage',
                    '--disable-blink-features=AutomationControlled']
            if not self._proxy:
                # Omit the proxy entirely when routing direct so Chromium's own
                # no-proxy behaviour is unambiguous.
                args.append('--no-proxy-server')
        # Options shared by both the ephemeral context and the persistent one.
        # ignore_https_errors: hidden services routinely serve self-signed
        # certs - the .onion address is ITSELF the crypto identity, so the CA
        # chain adds nothing. Clearnet hosts are unaffected because the crawler
        # only routes registered sources here.
        ctx_opts = dict(viewport={'width': 1400, 'height': 900},
                        locale='en-US', ignore_https_errors=True)
        # Let Firefox present its own native UA (the Tor Browser family the
        # human already used); only Chromium gets the pinned UA string.
        if self._engine != 'firefox':
            ctx_opts['user_agent'] = USER_AGENT

        # Firefox-only: treat http://*.onion as a secure context, exactly as
        # Tor Browser does. Without this, window.crypto.subtle (Web Crypto) is
        # undefined on a plain-http onion, so a site's OWN page scripts that
        # call it crash. This restores a standard browser API the page expects;
        # it does not solve or defeat any check - the human still does that.
        ff_prefs = {'dom.securecontext.allowlist_onions': True,
                    'dom.security.https_only_mode': False}

        if self._user_data_dir:
            # PERSISTENT profile: one call both launches the engine and opens the
            # on-disk context, so a session a human logged into once is reused
            # on every later crawl. There is no separate browser object here.
            launch_kwargs = dict(headless=self._headless, args=args, **ctx_opts)
            if self._proxy:
                launch_kwargs['proxy'] = self._proxy
            if self._engine == 'firefox':
                launch_kwargs['firefox_user_prefs'] = ff_prefs
            os.makedirs(self._user_data_dir, exist_ok=True)
            self._ctx = engine.launch_persistent_context(
                self._user_data_dir, **launch_kwargs)
            self._browser = None
        else:
            launch_kwargs = {'headless': self._headless, 'args': args}
            if self._proxy:
                launch_kwargs['proxy'] = self._proxy
            if self._engine == 'firefox':
                launch_kwargs['firefox_user_prefs'] = ff_prefs
            self._browser = engine.launch(**launch_kwargs)
            self._ctx = self._browser.new_context(**ctx_opts)
        # Trim the most obvious automation tell. This is fingerprint hygiene so
        # a normal page renders normally - not an attempt to defeat a CAPTCHA.
        self._ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
        if self._cookies:
            try:
                self._ctx.add_cookies([{
                    'name': c['name'], 'value': c['value'],
                    'domain': c.get('domain') or '',
                    'path': c.get('path') or '/',
                } for c in self._cookies if c.get('domain')])
            except Exception:
                pass  # a malformed stored cookie must not abort the crawl
        # A persistent context restored from disk may already hold a page.
        self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
        return self

    def context(self):
        """The live browser context (for cookie export / session validation)."""
        return self._ctx

    def storage_cookies(self):
        """Cookies currently held by the live context - the authenticated state
        as it stands after any challenge clearance / login. Returned in the
        plain dict shape the requests tier consumes, so BOTH transports can be
        driven from one persisted session. Never includes a value the source
        did not itself set."""
        if self._ctx is None:
            return []
        try:
            out = []
            for c in self._ctx.cookies():
                if c.get('name') and c.get('value') is not None:
                    out.append({'name': c['name'], 'value': c['value'],
                                'domain': c.get('domain') or '',
                                'path': c.get('path') or '/'})
            return out
        except Exception:
            return []

    def fetch(self, url):
        """Return (html, error). Waits out a self-clearing JS challenge."""
        if self._page is None:
            self.start()
        try:
            self._page.goto(url, timeout=NAV_TIMEOUT_MS, wait_until='domcontentloaded')
        except Exception as e:
            return None, f'{type(e).__name__}: {str(e)[:200]}'

        deadline = time.time() + CHALLENGE_WAIT_SECONDS
        html = ''
        while True:
            try:
                html = self._page.content()
            except Exception as e:
                return None, f'content error: {str(e)[:150]}'
            text = _text_of(html)
            info = fp_base.classify_block(text, html)
            if not info:
                return html, None
            # Only a self-clearing challenge is worth waiting on. An anti-spam
            # rejection, an auth wall or a banned account will NEVER clear by
            # waiting - re-polling one is pointless and, against a site that
            # already flagged us, abusive. Return immediately with the
            # server's own wording.
            if info['category'] not in (fp_base.BLOCK_CHALLENGE, fp_base.BLOCK_NETWORK):
                return html, info['reason'] if not info.get('message') else \
                    f"{info['reason']}: {info['message']}"
            if time.time() >= deadline:
                # Still challenged after the wait - a real block (interactive
                # challenge or login wall), reported honestly rather than
                # stored as a document.
                return html, 'challenge did not clear'
            time.sleep(2.5)

    def screenshot(self, url, focus_text=None, full_page=False):
        """Navigate to `url` (waiting out a self-clearing challenge exactly like
        fetch) and return (png_bytes, error). Rendered through THIS session's
        authenticated persistent profile, so a members-only thread is captured
        as the logged-in user - not the login wall a cold, unauthenticated
        capture would get. Never raises.

        `focus_text`: when given, the first occurrence of that text in the page
        is scrolled to CENTRE and highlighted before the shot, so the capture
        shows THIS finding's own matched content (not the identical forum
        header every thread shares). This is what makes each screenshot unique
        and evidently about the match. Falls back to the top of the page when
        the text isn't found.

        full_page defaults to False: a SHORT, uniform viewport shot rather than
        a giant full-length capture of an entire multi-page thread."""
        html, err = self.fetch(url)
        if err and not html:
            return None, err
        # A recognised block page still returned html (err set) - do not
        # screenshot an access/login/verification page as if it were the thread.
        if err:
            return None, err
        # Belt-and-suspenders: re-classify the rendered content directly. Never
        # capture an anti-bot splash ("checking your browser"), CAPTCHA, auth
        # wall or WAF page as thread evidence - that is the "verification page
        # in the name of evidence" noise.
        try:
            info = fp_base.classify_block(_text_of(html), html)
        except Exception:
            info = None
        if info:
            return None, f"{info.get('category')}: not a thread page"
        # Centre + highlight the matched content so the shot is unique to this
        # finding rather than the shared forum chrome at the top of every page.
        if focus_text:
            try:
                self._page.evaluate(_FOCUS_HIGHLIGHT_JS, str(focus_text).lower())
                self._page.wait_for_timeout(250)
            except Exception:
                pass
        try:
            png = self._page.screenshot(full_page=full_page)
            return png, None
        except Exception:
            try:
                return self._page.screenshot(full_page=False), None
            except Exception as e2:
                return None, f'{type(e2).__name__}: {str(e2)[:160]}'

    def close(self):
        for obj, name in ((self._ctx, 'ctx'), (self._browser, 'browser')):
            try:
                if obj:
                    obj.close()
            except Exception:
                pass
        try:
            if self._pw:
                self._pw.stop()
        except Exception:
            pass
        self._pw = self._browser = self._ctx = self._page = None

    def __enter__(self):
        return self.start()

    def __exit__(self, *exc):
        self.close()


import re as _re
_TAGS = _re.compile(r'<script.*?</script>|<style.*?</style>|<[^>]+>',
                    _re.IGNORECASE | _re.DOTALL)


def _text_of(html):
    if not html:
        return ''
    return _re.sub(r'\s+', ' ', _TAGS.sub(' ', html)).strip()


def is_available():
    try:
        from playwright.sync_api import sync_playwright  # noqa: F401
        return True
    except Exception:
        return False
