#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Authenticated per-thread evidence screenshots for stored forum documents.

Every finding surfaced from a forum document should carry a real screenshot of
the thread it came from - and for a members-only forum (CryptBB) that shot must
be taken THROUGH the persistent authenticated profile, or it is just the login
wall. This module captures those screenshots at COLLECTION time: after a search
stores new documents, one browser session (reused across the whole pass, so
Chromium is launched once, not per thread) renders each new thread and stores a
PNG, recording its id on the document. A screenshot is taken once per thread and
never re-taken (idempotent), so re-collection and backfill are cheap.

Nothing here logs in, solves a challenge, or bypasses anything - it reuses the
session a human established once (see forum_session / forum_browser), exactly as
the search path does.
"""

import os
import sys
import json

sys.path.append(os.environ['AIL_BIN'])

from lib import forum_ingest
from lib import forum_registry
from lib import forum_session
from lib.objects import Screenshots

# A hard ceiling per pass so a single collection run can never spend unbounded
# time (each authenticated Tor screenshot is several seconds) - the rest are
# picked up on the next pass / backfill.
DEFAULT_MAX_PER_PASS = int(os.environ.get('FORUM_SCREENSHOT_MAX_PER_PASS', 25))


def _doc_thread_url(doc):
    return doc.get('post_url') or doc.get('thread_url') or ''


def _needs_screenshot(doc):
    # Only search-collected documents that have a real thread URL and no shot
    # yet. A document whose capture already failed once carries 'none' so it is
    # not retried on every single pass (a members page that 404s stays 404).
    if doc.get('collection_mode') != 'search':
        return False
    if not _doc_thread_url(doc):
        return False
    return not doc.get('screenshot_id')


def _set_screenshot_id(forum_id, doc_id, value):
    r = forum_ingest._r()
    r.hset(f'forumdoc:full:{forum_id}:{doc_id}', 'screenshot_id', value)


# ---------------------------------------------------------------------------
# Term-specific (search-anchored) screenshots
#
# The base screenshot above is highlighted on the term the thread was
# COLLECTED under (matched_query). But a combo-dump thread surfaces again in
# many different domain/keyword searches (the cross-query fold), and the base
# shot then highlights the wrong term - e.g. a thread collected under "google"
# still highlights "google" when the user searched "netflix.com", contradicting
# the extract, which correctly highlights netflix.com. Fixing that means the
# screenshot's highlight must follow the SEARCHED term, so we keep a small
# per-document map {term -> screenshot sha256} and capture one shot per (doc,
# term) on demand, cached forever after. All capture stays in the worker (never
# a Flask request) via capture_for_findings below.
# ---------------------------------------------------------------------------
def _norm_term(term):
    return (term or '').strip().lower()


def _get_term_map(forum_id, doc_id):
    raw = forum_ingest._r().hget(f'forumdoc:full:{forum_id}:{doc_id}', 'screenshot_terms')
    if not raw:
        return {}
    try:
        m = json.loads(raw)
        return m if isinstance(m, dict) else {}
    except Exception:
        return {}


def _set_term_shot(forum_id, doc_id, term, sid):
    r = forum_ingest._r()
    m = _get_term_map(forum_id, doc_id)
    m[_norm_term(term)] = sid
    r.hset(f'forumdoc:full:{forum_id}:{doc_id}', 'screenshot_terms', json.dumps(m))


def resolve_cached_term_shot(forum_id, doc_id, term):
    """No-network lookup of a screenshot KNOWN to be highlighted on `term` -
    i.e. one recorded in this document's {term -> sha256} map, which is only
    ever written with the ACTUAL focus term a shot was captured with (see
    _set_term_shot). Returns that sha256 or None.

    Deliberately does NOT fall back to the document's base screenshot_id keyed
    on matched_query: a thread's matched_query can differ from the term its base
    shot was actually highlighted on (a doc re-folded/re-collected under another
    query), so trusting it showed the wrong highlight - the exact bug this
    fixes. Unknown -> None, so the caller captures a shot for `term` (and only
    falls back to the base shot as a last resort when capture is unavailable)."""
    t = _norm_term(term)
    if not t:
        return None
    sid = _get_term_map(forum_id, doc_id).get(t)
    return sid if sid and sid != 'none' else None


# A whole term-shot pass must never hang a search: if the Tor circuit drops
# mid-pass every navigation blocks for the full browser timeout, so bound the
# pass by wall-clock and abort a forum after a few consecutive failures (the
# circuit/profile is down - the remaining shots would only burn more timeouts).
TERM_SHOT_DEADLINE_SECONDS = int(os.environ.get('FORUM_TERM_SHOT_DEADLINE', 150))
TERM_SHOT_MAX_CONSEC_FAIL = int(os.environ.get('FORUM_TERM_SHOT_MAX_CONSEC_FAIL', 3))


def capture_for_findings(items, cap=DEFAULT_MAX_PER_PASS, logger=print):
    """Ensure a screenshot highlighted on each item's SEARCHED term exists.

    `items`: list of dicts {forum_id, doc_id, url, term}. Returns a dict keyed
    by (forum_id, doc_id, norm_term) -> screenshot sha256 for every item that
    now has a term-specific shot (cached hits included). Cheap cached hits are
    free; only genuinely-missing (doc, term) pairs cost a Tor capture, and the
    total number of NEW captures is bounded by `cap`. Best-effort, never raises
    - a caller falls back to the base screenshot for anything not returned."""
    resolved = {}
    to_capture = []  # (forum_id, doc_id, url, term)
    for it in items:
        fid, did = it.get('forum_id'), it.get('doc_id')
        url, term = it.get('url'), it.get('term')
        t = _norm_term(term)
        if not (fid and did and url and t):
            continue
        cached = _get_term_map(fid, did).get(t)
        if cached and cached != 'none':
            resolved[(fid, did, t)] = cached
        else:
            to_capture.append((fid, did, url, t))

    if not to_capture:
        return resolved

    from lib import forum_browser
    if not forum_browser.is_available():
        return resolved

    # `to_capture` is in finding order (callers pass findings most-relevant
    # first). Pick the top `cap` misses in THAT order so the budget is always
    # spent on the findings the user actually sees first - then group the chosen
    # few by forum so each forum is served by ONE session, opened and closed
    # before the next. (One session at a time is required: two live sync
    # Playwright sessions in the same worker raise "Sync API inside the asyncio
    # loop".) Selecting before grouping keeps the #1 finding from being starved
    # by a lower-ranked forum, without ever holding two browsers open.
    import time as _time
    deadline = _time.time() + TERM_SHOT_DEADLINE_SECONDS
    selected = to_capture[:cap]
    by_forum = {}
    for fid, did, url, t in selected:
        by_forum.setdefault(fid, []).append((did, url, t))

    for fid, work in by_forum.items():
        if _time.time() >= deadline:
            logger('[term-shot] pass deadline reached, remaining fall back to base')
            break
        if not forum_session.has_profile(fid):
            continue
        route = forum_registry.resolve_route(fid)
        proxy, use_default = forum_session._route_to_proxy(route)
        session = None
        consec_fail = 0
        try:
            session = forum_browser.BrowserSession(
                proxy=proxy, use_default_proxy=use_default, headless=True,
                user_data_dir=forum_session.profile_dir(fid)).start()
            for did, url, t in work:
                if _time.time() >= deadline:
                    logger(f'[{fid}] term-shot deadline reached, stopping')
                    break
                try:
                    png, err = session.screenshot(url, focus_text=t)
                except Exception as e:
                    png, err = None, f'{type(e).__name__}: {str(e)[:120]}'
                if err or not png:
                    consec_fail += 1
                    logger(f'[{fid}] term-shot miss {did[:12]} "{t}": {err}')
                    if consec_fail >= TERM_SHOT_MAX_CONSEC_FAIL:
                        # Circuit/profile is down - abort this forum rather than
                        # burning a full nav timeout on every remaining shot.
                        logger(f'[{fid}] term-shot aborting forum after '
                               f'{consec_fail} consecutive failures')
                        break
                    continue
                consec_fail = 0
                shot = Screenshots.create_screenshot(png, b64=False, force=True)
                if shot is None:
                    continue
                _set_term_shot(fid, did, t, shot.id)
                resolved[(fid, did, t)] = shot.id
                logger(f'[{fid}] term-shot ok {did[:12]} "{t}" -> {shot.id[:12]}')
        except Exception as e:
            logger(f'[{fid}] term-shot pass failed: {type(e).__name__}: {e}')
        finally:
            if session is not None:
                try:
                    session.close()
                except Exception:
                    pass
    return resolved


def capture_missing(forum_id, limit=DEFAULT_MAX_PER_PASS, only_doc_ids=None,
                    logger=print):
    """Capture authenticated screenshots for stored `forum_id` documents that
    don't have one yet (optionally restricted to `only_doc_ids`). Returns
    {'captured': n, 'failed': n, 'scanned': n}. Best-effort: never raises."""
    stats = {'captured': 0, 'failed': 0, 'scanned': 0}
    if not forum_session.has_profile(forum_id):
        # No authenticated profile -> a capture would just be the guest view /
        # login wall, so it is honestly skipped rather than storing a misleading
        # shot. (ransomware.live and any profile-less source fall here.)
        return stats

    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        return stats
    route = forum_registry.resolve_route(forum_id)

    # Pick the work set first (cheap Kvrocks reads) so the browser is only
    # launched when there is actually something to shoot.
    targets = []
    only = set(only_doc_ids) if only_doc_ids else None
    for doc in forum_ingest.list_documents(forum_id, limit=10000):
        if only is not None and doc.get('doc_id') not in only:
            continue
        if not _needs_screenshot(doc):
            continue
        targets.append(doc)
        if len(targets) >= limit:
            break
    stats['scanned'] = len(targets)
    if not targets:
        return stats

    from lib import forum_browser
    if not forum_browser.is_available():
        return stats
    proxy, use_default = forum_session._route_to_proxy(route)

    session = None
    try:
        session = forum_browser.BrowserSession(
            proxy=proxy, use_default_proxy=use_default, headless=True,
            user_data_dir=forum_session.profile_dir(forum_id)).start()
        for doc in targets:
            doc_id = doc.get('doc_id')
            url = _doc_thread_url(doc)
            # Anchor the shot on the term this thread was collected for, so the
            # capture centres on THIS thread's own matched content instead of
            # the identical forum header every page shares.
            focus = (doc.get('matched_query') or '').strip() or None
            try:
                png, err = session.screenshot(url, focus_text=focus)
            except Exception as e:
                png, err = None, f'{type(e).__name__}: {str(e)[:120]}'
            if err or not png:
                # Mark as attempted-and-failed so it is not retried forever.
                _set_screenshot_id(forum_id, doc_id, 'none')
                stats['failed'] += 1
                logger(f'[{forum_id}] screenshot miss {doc_id}: {err}')
                continue
            shot = Screenshots.create_screenshot(png, b64=False, force=True)
            if shot is None:
                _set_screenshot_id(forum_id, doc_id, 'none')
                stats['failed'] += 1
                continue
            _set_screenshot_id(forum_id, doc_id, shot.id)
            # Also register the base shot under the term it was highlighted on,
            # so a search for that same term reuses it with no re-capture.
            if focus:
                _set_term_shot(forum_id, doc_id, focus, shot.id)
            stats['captured'] += 1
            logger(f'[{forum_id}] screenshot ok {doc_id} -> {shot.id[:12]}')
    except Exception as e:
        logger(f'[{forum_id}] screenshot pass failed: {type(e).__name__}: {e}')
    finally:
        if session is not None:
            session.close()
    return stats
