#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Asset Intelligence Scan Jobs
===================

Job lifecycle for an Asset Intelligence scan, mirroring intel_jobs.py's
shape (Kvrocks-hash job record + Kvrocks-list queue + blpop worker +
atomic JSON report file) - see bin/intel/AssetIntelWorker.py for the
consumer process.

run_job() is the orchestrator: runs every requested provider category
(bin/lib/asset_providers) against the target with one shared context, then
merges the results into per-asset records (asset_data.py), updates the
target registry (asset_registry.py), detects live/disconnected/back-online
transitions, raises alerts on a back-online transition or a CRITICAL
vulnerability finding (asset_data.record_alert - reuses the exact same
alert_dispatch.py delivery pipeline watchlist alerts use), and writes the
scan's full JSON report.
"""

import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import asset_registry
from lib import asset_data
from lib import asset_providers
from lib.asset_providers.base import SEVERITY_ORDER
from lib.ConfigLoader import ConfigLoader
from lib import crawlers

config_loader = ConfigLoader()
AIL_HOME = os.environ.get('AIL_HOME') or os.path.dirname(os.environ['AIL_BIN'].rstrip('/'))
REPORTS_FOLDER = os.path.join(AIL_HOME, config_loader.get_config_str('Directories', 'asset_reports'))
config_loader = None

os.makedirs(REPORTS_FOLDER, exist_ok=True)

r_crawler = crawlers.r_crawler

QUEUE_KEY = 'asset:jobs:queue'
STATUSES = {'QUEUED', 'RUNNING', 'COMPLETED', 'FAILED'}


def _job_key(job_id):
    return f'assetjob:meta:{job_id}'


def create_job(target_id, categories=None):
    categories = [c for c in (categories or asset_providers.CATEGORY_ORDER) if c in asset_providers.CATEGORY_ORDER]
    if not categories:
        categories = list(asset_providers.CATEGORY_ORDER)

    job_id = str(uuid.uuid4())
    now = int(time.time())
    r_crawler.hset(_job_key(job_id), mapping={
        'id': job_id,
        'target_id': target_id,
        'categories': json.dumps(categories),
        'status': 'QUEUED',
        'created_at': now,
        'started_at': '',
        'completed_at': '',
        'asset_count': 0,
        'live_count': 0,
        'disconnected_count': 0,
        'report_path': '',
        'error': '',
    })
    r_crawler.rpush(QUEUE_KEY, job_id)
    asset_registry.record_scan_triggered(target_id)
    return get_job(job_id)


def pop_queued_job(timeout=5):
    popped = r_crawler.blpop([QUEUE_KEY], timeout=timeout)
    if not popped:
        return None
    return popped[1]


def recover_orphaned_jobs():
    """Same rationale as intel_jobs.recover_orphaned_jobs(): a job stuck in
    RUNNING only ever means the worker died mid-run - safe to re-queue since
    run_job() always rebuilds/overwrites its report."""
    requeued = []
    for job in list_jobs(limit=100000):
        if job.get('status') == 'RUNNING':
            r_crawler.rpush(QUEUE_KEY, job['id'])
            requeued.append(job['id'])
    return requeued


def get_job(job_id):
    data = r_crawler.hgetall(_job_key(job_id))
    if not data:
        return {'status': 'error', 'reason': 'Unknown job'}, 404
    return _job_to_dict(data), 200


def list_jobs(limit=100):
    jobs = []
    for key in r_crawler.scan_iter(match='assetjob:meta:*', count=200):
        data = r_crawler.hgetall(key)
        if data:
            jobs.append(_job_to_dict(data))
    jobs.sort(key=lambda j: j.get('created_at') or 0, reverse=True)
    return jobs[:limit]


def _job_to_dict(data):
    d = dict(data)
    d['categories'] = json.loads(d.get('categories') or '[]')
    for int_field in ('created_at', 'started_at', 'completed_at', 'asset_count', 'live_count', 'disconnected_count'):
        d[int_field] = int(d[int_field]) if d.get(int_field) not in (None, '') else None
    return d


def _set_job_fields(job_id, **fields):
    r_crawler.hset(_job_key(job_id), mapping=fields)


def delete_job(job_id):
    job, code = get_job(job_id)
    if code != 200:
        return job, code
    report_path = job.get('report_path')
    if report_path and os.path.isfile(report_path):
        os.remove(report_path)
    r_crawler.delete(_job_key(job_id))
    return {'status': 'ok', 'deleted': job_id}, 200


def get_report(job_id):
    job, code = get_job(job_id)
    if code != 200:
        return job, code
    if job['status'] != 'COMPLETED' or not job.get('report_path'):
        return {'status': 'error', 'reason': f"Job is {job['status']}, no report available"}, 409
    with open(job['report_path']) as f:
        return json.load(f), 200


CRITICAL_VULN_SEVERITY = 'CRITICAL'


def run_job(job_id):
    job, code = get_job(job_id)
    if code != 200:
        return
    target_id = job['target_id']
    categories = job['categories']

    _set_job_fields(job_id, status='RUNNING', started_at=int(time.time()))

    if asset_registry.is_circuit_open(target_id):
        _set_job_fields(job_id, status='FAILED', completed_at=int(time.time()),
                         error='Target circuit open after repeated recent failures - skipped')
        return

    try:
        all_results, context = asset_providers.run_all_categories(target_id, categories)

        subdomains = context.get('subdomains') or set()
        all_fqdns = sorted(set(subdomains) | {target_id})

        status_by_fqdn = {}
        for r in (all_results.get('liveness') or []):
            if r.get('ok') and r.get('data'):
                status_by_fqdn.update(r['data'].get('status_by_fqdn') or {})

        technologies = context.get('technologies') or {}
        directories = context.get('directories') or {}
        # security_config_probe's findings are target-wide (missing headers
        # are reported per-fqdn within the finding text, WHOIS expiry is
        # inherently domain-level) - attached to the root domain's asset
        # record rather than duplicated across every subdomain.
        security_findings = context.get('security_findings') or []
        whois_data = context.get('whois') or {}
        dns_records_root = context.get('dns_records') or {}
        resolved_ips_root = context.get('resolved_ips') or []
        dns_ttls_root = context.get('dns_ttls') or {}
        dns_source_root = context.get('dns_source') or ''
        dns_authoritative_root = context.get('dns_authoritative') or False
        dns_collected_at_root = context.get('dns_collected_at') or 0

        # Resolved by the subdomain_dns provider (it used to be an inline
        # thread pool here, but ports_tcp needs the same addresses and
        # duplicating the lookups was the alternative).
        sub_dns_by_fqdn = context.get('sub_dns') or {}

        # Per-fqdn data from the Web-Check-style providers.
        tls_by_fqdn = context.get('tls') or {}
        ports_by_fqdn = context.get('ports') or {}
        vulns_by_fqdn = context.get('vulnerabilities') or {}
        waf_by_fqdn = context.get('waf') or {}
        security_headers = context.get('security_headers') or {}
        findings = sorted(context.get('findings') or [],
                          key=lambda f: SEVERITY_ORDER.index(f.get('severity', 'INFO'))
                          if f.get('severity') in SEVERITY_ORDER else len(SEVERITY_ORDER))

        back_online_fqdns = []
        for fqdn in all_fqdns:
            status = status_by_fqdn.get(fqdn, 'disconnected')
            if asset_data.record_status_transition(target_id, fqdn, status):
                back_online_fqdns.append(fqdn)

            fields = {
                'current_status': status,
                'technologies': technologies.get(fqdn, []),
                'directories': directories.get(fqdn, []),
                'tls': tls_by_fqdn.get(fqdn, {}),
                'ports': ports_by_fqdn.get(fqdn, []),
                'waf': waf_by_fqdn.get(fqdn, []),
                'security_headers': security_headers.get(fqdn, {}),
                'vulnerabilities': vulns_by_fqdn.get(fqdn, []),
            }
            if fqdn == target_id:
                fields['whois'] = whois_data
                fields['dns_records'] = dns_records_root
                fields['dns_ttls'] = dns_ttls_root
                fields['dns_source'] = dns_source_root
                # Store as a display string, not a bool: a stored Python bool
                # comes back as the string "False", which is truthy in Jinja.
                fields['dns_authoritative'] = 'authoritative' if dns_authoritative_root else 'recursive'
                fields['dns_collected_at'] = dns_collected_at_root
                fields['resolved_ips'] = resolved_ips_root
                fields['security_findings'] = security_findings
            elif fqdn in sub_dns_by_fqdn:
                sub_dns = sub_dns_by_fqdn[fqdn]
                fields['dns_records'] = sub_dns
                fields['resolved_ips'] = sorted(set(sub_dns.get('A', []) + sub_dns.get('AAAA', [])))

            asset_data.upsert_asset(target_id, fqdn, **fields)

            # Finally populates lib/objects/Domains.py's long-dangling ports
            # field, so a domain discovered here carries its open ports into
            # the shared Domain object the Dark Web side also reads.
            for entry in ports_by_fqdn.get(fqdn, []):
                asset_data.add_domain_port(fqdn, entry['port'])

        # A CRITICAL finding from any provider (a nuclei CVE hit, an exposed
        # Redis/MongoDB port, an expired certificate) is worth the same alert
        # path as any other - the severity scale exists so this does not need
        # a per-provider special case. Nuclei findings are already in this
        # shared `findings` list (the provider calls add_finding), so they
        # are covered here and must NOT be alerted again from a
        # vulnerabilities-specific loop or they would fire twice.
        for finding in findings:
            if finding.get('severity') == CRITICAL_VULN_SEVERITY:
                asset_data.record_alert(
                    target_id, finding.get('fqdn') or target_id,
                    f"critical_{finding.get('category', 'finding')}",
                    f"{finding.get('title')} - {finding.get('detail')}", severity='CRITICAL')

        for fqdn in back_online_fqdns:
            asset_data.record_alert(
                target_id, fqdn, 'back_online',
                f'{fqdn} is live again after previously being disconnected.', severity='HIGH')

        # Target-wide check results, stored once rather than copied onto
        # every asset row.
        target_intel = {key: context.get(key) or {} for key in
                        ('dnssec', 'mail_config', 'crawl_rules', 'security_txt',
                         'metadata', 'redirects', 'archive', 'webcheck')}
        target_intel['findings'] = findings
        asset_data.set_target_intel(target_id, **target_intel)

        severity_counts = {sev: sum(1 for f in findings if f.get('severity') == sev)
                           for sev in SEVERITY_ORDER}

        summary = asset_data.target_summary_counts(target_id)
        asset_registry.record_scan_result(target_id, success=True, **summary)

        report = {
            'query': {
                'target_id': target_id,
                'categories': categories,
                'generated_at': datetime.now(timezone.utc).isoformat(),
            },
            'summary': {**summary, 'back_online_count': len(back_online_fqdns),
                        'finding_count': len(findings), 'severity_counts': severity_counts},
            'findings': findings,
            'target_intel': target_intel,
            'provider_status': {cat: asset_providers.provider_status(cat) for cat in categories},
            # Per-provider run telemetry: started/completed/timeout/error,
            # duration, and result/validated/deduplicated counts - captured by
            # the orchestrator (asset_providers.run_category) during the scan.
            'provider_telemetry': context.get('provider_telemetry') or {},
            'assets': asset_data.list_assets(target_id),
        }
        report_path = os.path.join(REPORTS_FOLDER, f'{job_id}.json')
        tmp_path = f'{report_path}.tmp-{os.getpid()}'
        with open(tmp_path, 'w') as f:
            json.dump(report, f, indent=2, sort_keys=True, default=str)
        os.replace(tmp_path, report_path)

        _set_job_fields(
            job_id, status='COMPLETED', completed_at=int(time.time()),
            asset_count=summary['asset_count'], live_count=summary['live_count'],
            disconnected_count=summary['disconnected_count'], report_path=report_path,
        )
    except Exception as e:
        _set_job_fields(job_id, status='FAILED', completed_at=int(time.time()), error=str(e))
        asset_registry.record_scan_result(target_id, success=False, error=str(e))
        return
