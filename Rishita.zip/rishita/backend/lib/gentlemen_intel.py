#!/usr/bin/env python3
# -*-coding:UTF-8 -*
"""
Leak-site victim-name intelligence (The Gentlemen and similar blogs).

Some ransomware leak blogs are NOT forums and expose no browsable index, but
do publish an open list of victim organisation NAMES. The Gentlemen's
`/api/reports` returns ~823 victim names (a name -> "report available" flag)
and is readable through the persistent operator session WITHOUT any captcha.

This module turns that open list into a name-level intelligence signal: when a
searched domain or keyword matches a victim name, it is surfaced as a finding
for an analyst to confirm. It is deliberately name-level only:

  * The per-victim DETAIL (descriptions, domains) sits behind the site's own
    `/api/companies` endpoint, which requires an `X-Browser-Token` issued only
    after a human solves a math/click CAPTCHA. We never solve that
    automatically, so this module never touches it - it reads the open
    `/api/reports` list and nothing else.

Transport: the leak site drops non-browser clients (a plain requests call, even
carrying the session cookies, gets HTTP 403), so the open list is fetched
through the SAME persistent browser session the operator established, exactly
like the crawler's other browser fetches. Results are cached so a real browser
is not launched on every search.
"""

import json
import os
import re
import sys
import time

sys.path.append(os.environ['AIL_BIN'])
from lib import crawlers
from lib import forum_registry
from lib import forum_session

r_cache = crawlers.r_cache

# Status vocabulary, mirroring russian_market so the report panel can be honest
# about "checked, nothing found" vs "couldn't check".
GM_OK = 'retrieved'
GM_EMPTY = 'no_matches'            # list read, no victim name matched the query
GM_NO_SESSION = 'session_required'  # forum enabled but no operator session yet
GM_UNAVAILABLE = 'unavailable'      # site/list unreachable through the session
GM_NOT_CONFIGURED = 'not_configured'  # no enabled leak forum of this kind

SOURCE_KIND = 'ransomware leak site (victim list)'

# Known leak sites whose open victim-name list this module can read, keyed by
# host. Adding another is one line once its open list endpoint is confirmed.
LEAK_SITES = {
    'tezwsse5czllksjb7cwp65rvnk4oobmzti2znn42i43bjdfd2prqqkad.onion': {
        'name': 'The Gentlemen',
        'reports_path': '/api/reports',
    },
}

CACHE_TTL = 6 * 60 * 60   # re-fetch the victim list at most every 6 hours
_CACHE_KEY = 'gentlemen:victim_names'   # per-forum suffix appended below
MIN_MATCH_LEN = 4         # shortest query token allowed to match, avoids noise


def _norm(text):
    """Lowercased alphanumerics only - so 'Guardrisk', 'guard-risk' and
    'GUARDRISK ' all compare equal."""
    return re.sub(r'[^a-z0-9]+', '', (text or '').lower())


def _brand_of(query, query_type):
    """The token to match on: a domain's registrable label (guardrisk.co.za ->
    guardrisk), or the keyword itself."""
    q = (query or '').strip()
    if query_type == 'domain':
        host = q.split('/')[0]
        parts = [p for p in host.split('.') if p]
        # drop a leading www and take the label left of the public suffix;
        # good enough for name matching (guardrisk.co.za -> guardrisk).
        if parts and parts[0] == 'www':
            parts = parts[1:]
        if len(parts) >= 3 and parts[-2] in ('co', 'com', 'org', 'net', 'gov', 'edu', 'ac'):
            return parts[-3]
        if len(parts) >= 2:
            return parts[-2]
        return parts[0] if parts else q
    return q


def _iter_leak_forums():
    """Enabled registered forums whose host is a known leak site."""
    for f in forum_registry.list_forums():
        host = re.sub(r'^https?://', '', (f.get('url') or '')).split('/')[0].lower()
        site = LEAK_SITES.get(host)
        if site and f.get('enabled'):
            yield f, host, site


def _extract_json(body):
    """The site returns JSON; a browser navigation wraps it in a <pre>. Pull the
    JSON object out either way."""
    if not body:
        return None
    m = re.search(r'<pre[^>]*>(.*)</pre>', body, re.S)
    raw = m.group(1) if m else body
    raw = raw.replace('&quot;', '"').replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
    try:
        return json.loads(raw)
    except Exception:
        start = raw.find('{')
        if start >= 0:
            try:
                return json.loads(raw[start:])
            except Exception:
                return None
    return None


def _fetch_victim_names(forum_id, host, site, logger=None):
    """Fetch the open victim-name list through the persistent browser session.
    Returns (names_list_or_None, error). Cached in Redis for CACHE_TTL."""
    ck = f'{_CACHE_KEY}:{forum_id}'
    cached = r_cache.get(ck)
    if cached:
        try:
            return json.loads(cached), None
        except Exception:
            pass

    if not forum_session.has_profile(forum_id):
        return None, 'no session profile'

    # Negative cache: the Gentlecloud clearance is short-lived and only a human
    # in a HEADED browser re-clears it (a headless worker cannot). Once a fetch
    # finds the session challenged, don't relaunch a browser on every search for
    # a few minutes - fail fast so a dashboard search isn't slowed each time.
    nck = f'{ck}:stale'
    if r_cache.get(nck):
        return None, 'session expired - re-run the headed login to refresh'

    from lib import forum_browser
    if not forum_browser.is_available():
        return None, 'browser tier unavailable'

    route = forum_registry.resolve_route(forum_id)
    proxy, use_default = forum_session._route_to_proxy(route)
    engine = forum_session._engine_for(forum_id)
    url = f'http://{host}{site["reports_path"]}'
    session = None
    try:
        session = forum_browser.BrowserSession(
            proxy=proxy, use_default_proxy=use_default, headless=True,
            user_data_dir=forum_session.profile_dir(forum_id), engine=engine).start()
        html, err = session.fetch(url)
        if err and not html:
            return None, err
        data = _extract_json(html)
        reports = data.get('reports') if isinstance(data, dict) else None
        if not isinstance(reports, dict):
            # Challenged/expired session. Mark stale for a few minutes so the
            # next searches fail fast instead of relaunching a browser each time.
            try:
                r_cache.setex(nck, 300, '1')
            except Exception:
                pass
            return None, 'session expired - re-run the headed login to refresh'
        names = sorted(reports.keys())
        try:
            r_cache.setex(ck, CACHE_TTL, json.dumps(names))
            r_cache.delete(nck)   # session is live again
        except Exception:
            pass
        return names, None
    except Exception as e:
        return None, f'{type(e).__name__}: {str(e)[:150]}'
    finally:
        if session is not None:
            session.close()


def _match(brand, names):
    """Victim names whose normalised form matches the normalised brand token.
    Conservative: exact normalised equality, or the brand as a substring of the
    name (both >= MIN_MATCH_LEN). Returns [(name, reason), ...]."""
    nb = _norm(brand)
    if len(nb) < MIN_MATCH_LEN:
        return []
    out = []
    for name in names:
        nn = _norm(name)
        if not nn:
            continue
        if nn == nb:
            out.append((name, 'exact name match'))
        elif nb in nn or nn in nb:
            out.append((name, 'partial name match'))
    return out


def search(query, query_type='domain', logger=None):
    """Check the searched asset against enabled leak sites' open victim-name
    lists. Returns (records, status, detail) like russian_market.search.

    A record is a name-level hit an analyst confirms - never presented as a
    proven breach, and carrying no domain/detail (that is captcha-gated)."""
    forums = list(_iter_leak_forums())
    if not forums:
        return [], GM_NOT_CONFIGURED, 'no enabled leak site of this kind'
    if not query or not query.strip():
        return [], GM_EMPTY, 'no query supplied'

    brand = _brand_of(query, query_type)
    records = []
    last_status, last_detail = GM_EMPTY, None
    for f, host, site in forums:
        fid = f['id']
        names, err = _fetch_victim_names(fid, host, site, logger=logger)
        if names is None:
            if err and 'session' in err.lower():
                last_status, last_detail = GM_NO_SESSION, err
            else:
                last_status, last_detail = GM_UNAVAILABLE, err
            if logger:
                logger(f'[{site["name"]}] victim-list unavailable: {err}')
            continue
        for name, reason in _match(brand, names):
            records.append({
                'victim_name': name,
                'source_name': site['name'],
                'source_url': f.get('url'),
                'matched_query': query,
                'match_reason': f'{reason} ("{brand}" vs "{name}") - confirm manually',
                'collected_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'victim_count_on_site': len(names),
            })
    if records:
        return records, GM_OK, None
    return records, last_status, last_detail


# ---------------------------------------------------------------------------
# UI leak-data import
#
# The open victim LIST read in search() is name-only. The DETAILED records
# (company + domain + leak description) come from the site's own /api/companies
# response, which the SPA fetches once the operator clears the PoW+CAPTCHA. The
# operator-triggered import (bin/intel/leak_import.py) opens a headed browser,
# the human clears the challenge, we INTERCEPT that response (no token forging,
# no captcha solving) and store each victim as a forum document here.
# ---------------------------------------------------------------------------
CAPTURE_ENDPOINT = '/api/companies'

_DOMAIN_RE = re.compile(r'\b([a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)+)\b')


def leak_site_for(forum_id):
    """The LEAK_SITES entry for a forum (matched on its host), with 'host'
    added, or None if this forum is not a configured leak site."""
    forum, code = forum_registry.get_forum(forum_id)
    if code != 200:
        return None
    host = re.sub(r'^https?://', '', (forum.get('url') or '')).split('/')[0].lower()
    site = LEAK_SITES.get(host)
    return {**site, 'host': host} if site else None


def is_leak_site(forum_id):
    return leak_site_for(forum_id) is not None


def _primary_domain(text):
    """The victim's real domain: the first domain-looking token (the site puts
    it first), validated against the public suffix list so sentence fragments
    like 'deadlines.to' or 'midwest.founded' are not mistaken for domains."""
    try:
        from publicsuffixlist import PublicSuffixList
        psl = PublicSuffixList()
    except Exception:
        psl = None
    for cand in _DOMAIN_RE.findall((text or '').lower()):
        if 'zoominfo' in cand:
            continue
        if psl is None:
            return cand
        suf = psl.publicsuffix(cand)
        if suf and '.' in cand and cand.rsplit('.', 1)[-1] == suf.rsplit('.', 1)[-1] \
                and len(cand.split('.')[0]) > 1:
            return cand
    return None


def store_companies(forum_id, body):
    """Parse a captured /api/companies JSON body and store each victim as a
    forum document (title=company, text=description, domains=[primary domain]),
    deduplicated. Returns (stored, duplicate, total_docs)."""
    from lib import forum_ingest
    forum, code = forum_registry.get_forum(forum_id)
    forum_name = forum.get('name') if code == 200 else 'leak site'
    host = (leak_site_for(forum_id) or {}).get('host', '')
    try:
        recs = json.loads(body)
    except Exception:
        return 0, 0, forum_ingest.count_documents(forum_id)
    if isinstance(recs, dict):
        recs = recs.get('companies') or recs.get('reports') or []
    if not isinstance(recs, list):
        recs = []
    stored = dup = 0
    for rec in recs:
        if not isinstance(rec, dict):
            continue
        title = (rec.get('title') or rec.get('id') or '').strip()
        desc = (rec.get('description') or '').strip()
        if not title and not desc:
            continue
        rid = rec.get('id') or re.sub(r'[^a-z0-9]+', '-', title.lower())
        dom = _primary_domain(f'{title} {desc}')
        url = f'http://{host}/#{rid}' if host else ''
        doc = {
            'title': title, 'text': f'{title}\n{desc}'.strip(), 'author': forum_name,
            'thread_url': url, 'post_url': url, 'thread_id': rid,
            'domains': [dom] if dom else [], 'keywords': [title] if title else [],
            'collection_mode': 'leak_list', 'published_at': '',
        }
        out = forum_ingest.store_external_document(forum_id, forum_name, doc)
        if out == 'stored':
            stored += 1
        elif out == 'duplicate':
            dup += 1
    forum_registry.set_document_count(forum_id, forum_ingest.count_documents(forum_id))
    return stored, dup, forum_ingest.count_documents(forum_id)
