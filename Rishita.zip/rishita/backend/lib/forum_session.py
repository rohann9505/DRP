#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Persistent per-forum session / browser-profile manager
=======================================================

The gap this closes (audited against darkweb-forums-tracker's shared-Chromium
user_data_dir idea): our cookiejar persisted NAME/VALUE cookies, but the
Playwright context itself was ephemeral - launched and closed every crawl, so
challenge-clearance and localStorage were re-earned each run. This module gives
every forum a PERSISTENT on-disk browser profile that both transports reuse:

  * the browser tier launches straight from the profile
    (`BrowserSession(user_data_dir=...)`), so a session a human logged into once
    is already valid on the next scheduled crawl and after a restart;
  * the requests tier is seeded with the SAME cookies exported live from that
    profile, so the cheap HTTP path and the browser path never diverge.

What this is NOT: it does not create, guess, solve or bypass anything. A human
establishes the session once in a headed profile (open_login) - solving any
CAPTCHA themselves, exactly as they would in their own browser - and we reuse
what they established. When it lapses we DETECT and CLASSIFY that (validate_
session), record per-forum health, and let the caller pause only that forum
while every other forum keeps collecting. A challenge/expired/login page is
classified and never stored as a document.

Session states (never guessed - always derived from what the source returned):
    none            no persistent profile has been created for this forum yet
    valid           an authenticated marker was present -> session is live
    expired         was authenticated, now shows a logged-out / session-expired
                    signal -> needs the human to log in again
    login_required  an anonymous/login wall (never authenticated, or unknown)
    challenge       a JS/interactive anti-bot wall stood in front of the check
    unreachable     the probe could not be fetched at all (Tor/host down)
    unknown         fetched, but nothing let us decide (kept distinct from a
                    confirmed logged-out state so it is never mistaken for one)
"""

import json
import os
import re
import sys
import time

sys.path.append(os.environ['AIL_BIN'])

from lib import crawlers
from lib.forum_providers import base as fp_base

# --- session state vocabulary ------------------------------------------------
SESSION_NONE = 'none'
SESSION_VALID = 'valid'
SESSION_EXPIRED = 'expired'
SESSION_LOGIN_REQUIRED = 'login_required'
SESSION_CHALLENGE = 'challenge'
SESSION_UNREACHABLE = 'unreachable'
SESSION_UNKNOWN = 'unknown'

# States in which the crawl can proceed authenticated. Everything else means
# "this forum needs attention" - the caller pauses it and continues the rest.
HEALTHY_STATES = {SESSION_VALID}
# States that a scheduled crawl must NOT keep hammering - a human has to act.
NEEDS_OPERATOR = {SESSION_EXPIRED, SESSION_LOGIN_REQUIRED}

_HEALTH_KEY = 'forumsession:health:{}'

# Root for on-disk profiles. Isolated per forum, never world-readable content
# beyond what the operator's own browser already stored locally.
_PROFILES_ROOT = os.environ.get(
    'FORUM_BROWSER_PROFILES',
    os.path.join(os.environ.get('AIL_HOME')
                 or os.path.dirname(os.environ['AIL_BIN'].rstrip('/')),
                 'FORUM_PROFILES'))

# Generic logged-out / session-expired wording, used only as a fallback when a
# provider offers no markers of its own. Deliberately conservative.
_GENERIC_EXPIRED = re.compile(
    r'your session (?:has )?expired|you have been logged out|session timed out|'
    r'please log ?in again|re-?authenticate', re.IGNORECASE)
_GENERIC_LOGIN = re.compile(
    r'you (?:must|need to) (?:be )?(?:logged|registered|sign(?:ed)? in)|'
    r'please log ?in|member(?:s)? only|name="password"|type="password"|'
    r'action="[^"]*login', re.IGNORECASE)


def _r():
    return crawlers.r_crawler


# --- profile locations -------------------------------------------------------
def _safe_id(forum_id):
    """Filesystem-safe, collision-free directory name for a forum id."""
    return re.sub(r'[^A-Za-z0-9._-]', '_', forum_id or '')[:120] or 'unnamed'


def profiles_root():
    return _PROFILES_ROOT


def profile_dir(forum_id):
    return os.path.join(_PROFILES_ROOT, _safe_id(forum_id))


def has_profile(forum_id):
    """True when a persistent profile has actually been created on disk. An
    empty/absent directory is not a profile - Chromium writes marker files
    (Default/, etc.) only once a context has been opened there."""
    d = profile_dir(forum_id)
    try:
        return os.path.isdir(d) and any(os.scandir(d))
    except OSError:
        return False


# --- health storage ----------------------------------------------------------
def get_health(forum_id):
    """Per-forum session health. Always returns a dict; state defaults to
    `none` (no profile) or `unknown` (profile exists, never validated)."""
    raw = _r().hgetall(_HEALTH_KEY.format(forum_id)) or {}
    present = has_profile(forum_id)
    state = raw.get('state') or (SESSION_UNKNOWN if present else SESSION_NONE)
    out = {
        'forum_id': forum_id,
        'state': state,
        'detail': raw.get('detail') or None,
        'profile_present': present,
        'last_validated': _as_int(raw.get('last_validated')),
        'last_ok': _as_int(raw.get('last_ok')),
        'consecutive_invalid': _as_int(raw.get('consecutive_invalid')) or 0,
    }
    out['healthy'] = state in HEALTHY_STATES
    out['needs_operator'] = state in NEEDS_OPERATOR
    return out


def _as_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def record_health(forum_id, state, detail=None):
    """Persist a validation outcome. `detail` is a short, non-sensitive reason
    (never a response body). Returns the stored health dict."""
    now = int(time.time())
    key = _HEALTH_KEY.format(forum_id)
    mapping = {'state': state, 'last_validated': now}
    if detail:
        mapping['detail'] = str(detail)[:200]
    else:
        _r().hdel(key, 'detail')
    if state == SESSION_VALID:
        mapping['last_ok'] = now
        mapping['consecutive_invalid'] = 0
    else:
        prev = _as_int((_r().hget(key, 'consecutive_invalid'))) or 0
        mapping['consecutive_invalid'] = prev + 1
    _r().hset(key, mapping=mapping)
    return get_health(forum_id)


def clear_health(forum_id):
    _r().delete(_HEALTH_KEY.format(forum_id))


# --- session classification --------------------------------------------------
def classify_session(html, provider=None):
    """Decide the session state from a probe response. Never stores anything.

    Provider may expose (all optional, all lists of substrings/regex-ready
    strings): `logged_in_markers`, `session_expired_markers`,
    `login_required_markers`. When absent, conservative generic wording is used.
    """
    if not html:
        return SESSION_UNREACHABLE, 'no response from probe'

    text = _text_of(html)

    # A wall in front of the check (JS/interactive anti-bot). We report it as a
    # challenge rather than a logged-out state - the two are different problems.
    block = fp_base.classify_block(text, html)
    if block and block.get('category') in (fp_base.BLOCK_CHALLENGE,
                                           fp_base.BLOCK_NETWORK):
        return SESSION_CHALLENGE, block.get('reason') or 'anti-bot challenge'

    logged_in = _markers(provider, 'logged_in_markers')
    if logged_in and _any(logged_in, text, html):
        return SESSION_VALID, None

    expired = _markers(provider, 'session_expired_markers')
    if expired and _any(expired, text, html):
        return SESSION_EXPIRED, 'source reports the session is no longer valid'
    if not expired and _GENERIC_EXPIRED.search(text):
        return SESSION_EXPIRED, 'logged-out / session-expired wording present'

    login = _markers(provider, 'login_required_markers')
    if login and _any(login, text, html):
        return SESSION_LOGIN_REQUIRED, 'anonymous / login wall'
    if not login and _GENERIC_LOGIN.search(html or ''):
        return SESSION_LOGIN_REQUIRED, 'login form / members-only wording present'

    # If the provider gave us a positive marker to look for and we did not see
    # it, we are logged out but cannot say which kind - do not claim valid.
    if logged_in:
        return SESSION_LOGIN_REQUIRED, 'authenticated marker absent'

    # No markers to judge by and no negative signal: a page came back, but we
    # will not assert "valid" without evidence.
    return SESSION_UNKNOWN, 'no session markers to classify by'


def _markers(provider, attr):
    return [m for m in (getattr(provider, attr, None) or []) if m]


def _any(markers, text, html):
    hay = f'{text}\n{html}'.lower()
    return any(m.lower() in hay for m in markers)


# --- live validation ---------------------------------------------------------
def _engine_for(forum_id):
    """The browser engine this forum's persistent profile was created with.
    Must match the login engine - a Chromium can't read a Firefox profile, and
    some onions only serve Firefox. Defaults to chromium."""
    try:
        from lib import forum_registry
        forum, code = forum_registry.get_forum(forum_id)
        if code == 200:
            return forum.get('browser_engine') or 'chromium'
    except Exception:
        pass
    return 'chromium'


def validate_session(forum_id, probe_url, provider=None, route=None,
                     logger=print):
    """Fetch an authenticated-only probe URL through this forum's PERSISTENT
    profile, classify the session, record health, and return (state, detail).

    The probe page is only classified - never parsed into a document, never
    stored. Requires a profile to exist; otherwise records `none`.
    """
    from lib import forum_browser
    if not has_profile(forum_id):
        record_health(forum_id, SESSION_NONE, 'no persistent profile yet')
        return SESSION_NONE, 'no persistent profile yet'
    if not forum_browser.is_available():
        return SESSION_UNKNOWN, 'browser tier unavailable'

    proxy, use_default = _route_to_proxy(route)
    session = None
    try:
        session = forum_browser.BrowserSession(
            proxy=proxy, use_default_proxy=use_default, headless=True,
            user_data_dir=profile_dir(forum_id),
            engine=_engine_for(forum_id)).start()
        html, err = session.fetch(probe_url)
        if err and not html:
            state, detail = SESSION_UNREACHABLE, err[:180]
        else:
            state, detail = classify_session(html, provider)
        record_health(forum_id, state, detail)
        logger(f'[{forum_id}] session validate: {state}'
               + (f' ({detail})' if detail else ''))
        return state, detail
    except Exception as e:
        detail = f'{type(e).__name__}: {str(e)[:150]}'
        record_health(forum_id, SESSION_UNKNOWN, detail)
        return SESSION_UNKNOWN, detail
    finally:
        if session is not None:
            session.close()


def export_cookies(forum_id, route=None):
    """Open the persistent profile briefly and return its live cookies in the
    requests-tier dict shape, so the HTTP transport shares the browser's
    authenticated state. Returns [] when there is no profile."""
    from lib import forum_browser
    if not has_profile(forum_id) or not forum_browser.is_available():
        return []
    proxy, use_default = _route_to_proxy(route)
    session = None
    try:
        session = forum_browser.BrowserSession(
            proxy=proxy, use_default_proxy=use_default, headless=True,
            user_data_dir=profile_dir(forum_id),
            engine=_engine_for(forum_id)).start()
        return session.storage_cookies()
    except Exception:
        return []
    finally:
        if session is not None:
            session.close()


def open_login(forum_id, url, route=None, logger=print, engine='chromium'):
    """HEADED bootstrap: open the forum in a visible browser on this forum's
    persistent profile so a human can log in once (and solve any CAPTCHA
    THEMSELVES). Whatever they establish is written to the profile and reused by
    every later crawl. This is an operator action, never run by the worker.

    `engine` is the real browser the operator drives ('chromium' default, or
    'firefox' for sites that drop Chromium). Requires a display. Returns True
    once the window closes.
    """
    from lib import forum_browser
    proxy, use_default = _route_to_proxy(route)
    session = forum_browser.BrowserSession(
        proxy=proxy, use_default_proxy=use_default, headless=False,
        user_data_dir=profile_dir(forum_id), engine=engine)
    session.start()
    try:
        # A first navigation over Tor can fail transiently (dead circuit,
        # RemoteDisconnected, ERR_EMPTY_RESPONSE) before the operator has done
        # anything. That must NOT tear the window down - the whole point is to
        # leave it open so the human can retry and solve any challenge THEMSELVES.
        try:
            session._page.goto(url, timeout=forum_browser.NAV_TIMEOUT_MS,
                               wait_until='domcontentloaded')
        except Exception as e:
            logger(f'[{forum_id}] initial load failed ({type(e).__name__}: {e}). '
                   f'Window stays open - reload the tab (Ctrl+R) and solve the '
                   f'check yourself.')
        logger(f'[{forum_id}] headed login window open - log in / solve the '
               f'challenge, then close the window.')
        # Block until the human closes the browser window, regardless of how
        # the first navigation went.
        session._page.wait_for_event('close', timeout=0)
    except Exception as e:
        logger(f'[{forum_id}] login window ended: {type(e).__name__}: {e}')
    finally:
        session.close()
    return has_profile(forum_id)


# --- UI-triggered operator login ---------------------------------------------
# These let the Flask UI START the same headed login (open_login) and the same
# headless health check (validate_session) that bin/intel/forum_session_login.py
# runs, so an operator never has to drop to a shell to add/re-authenticate a
# forum. NOTHING here automates, guesses or bypasses a login or a CAPTCHA: the
# headed launch still opens a VISIBLE browser on the server's display for a
# human to sign in themselves. It only removes the manual CLI step.
_LOGIN_PID_KEY = 'forumlogin:pid:{}'
_VALIDATE_PID_KEY = 'forumvalidate:pid:{}'
_LEAKIMPORT_PID_KEY = 'forumleakimport:pid:{}'
_LEAKIMPORT_RESULT_KEY = 'forumleakimport:result:{}'


def set_leak_import_result(forum_id, message):
    """Record the outcome of the last leak import (success, site-down, closed…)
    so the forum page can show what happened instead of silently going idle."""
    try:
        _r().set(_LEAKIMPORT_RESULT_KEY.format(forum_id),
                 json.dumps({'message': message, 'at': int(time.time())}),
                 ex=7 * 86400)
    except Exception:
        pass


def get_leak_import_result(forum_id):
    """Last leak-import outcome as {'message', 'at'} or None."""
    try:
        raw = _r().get(_LEAKIMPORT_RESULT_KEY.format(forum_id))
        return json.loads(raw) if raw else None
    except Exception:
        return None


def _ail_home():
    return (os.environ.get('AIL_HOME')
            or os.path.dirname(os.environ['AIL_BIN'].rstrip('/')))


def _pid_is_ours(pid, forum_id):
    """True only if `pid` is a live process that is one of OUR spawned session
    scripts (login / leak import) for THIS forum. Reading the real command line
    guards against PID reuse: once a finished login's PID number is recycled by
    an unrelated process, os.kill(pid, 0) still succeeds, which would otherwise
    make the UI falsely report a login window as still open ('already_running').
    /proc/<pid>/cmdline exists only while the process lives, so this also tests
    liveness."""
    try:
        with open(f'/proc/{pid}/cmdline', 'rb') as fh:
            cmd = fh.read().replace(b'\x00', b' ').decode('utf-8', 'replace')
    except (OSError, ValueError):
        return False
    if forum_id not in cmd:
        return False
    return 'forum_session_login.py' in cmd or 'leak_import.py' in cmd


def _pid_alive(key, forum_id):
    """True only while the session script whose PID is stored under `key` for
    this forum is genuinely still running - verified against its command line,
    not just PID liveness - so a stale or reused PID never shows a false
    'already_running'. Any such PID is cleared on the way out."""
    try:
        pid = _r().get(key.format(forum_id))
    except Exception:
        return False
    if not pid:
        return False
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        pid = None
    if pid is not None and _pid_is_ours(pid, forum_id):
        return True
    try:
        _r().delete(key.format(forum_id))
    except Exception:
        pass
    return False


def login_running(forum_id):
    """True while a headed login window launched from the UI is still open."""
    return _pid_alive(_LOGIN_PID_KEY, forum_id)


def validate_running(forum_id):
    """True while a UI-launched headless validation is still in flight."""
    return _pid_alive(_VALIDATE_PID_KEY, forum_id)


def _spawn_session_script(forum_id, extra_args, pid_key=None, need_display=False,
                          script='intel/forum_session_login.py', log_prefix='forum_login'):
    """Run a bin/intel/*.py operator script as a detached background process.
    Returns (status, detail): 'launched' / 'error'. Output goes to a per-forum
    log under logs/ so a launch failure (e.g. no display) is inspectable."""
    import subprocess
    script_path = os.path.join(os.environ['AIL_BIN'], script)
    if not os.path.isfile(script_path):
        return 'error', f'{os.path.basename(script)} not found'
    cmd = [sys.executable, script_path, forum_id] + list(extra_args)
    env = dict(os.environ)
    if need_display:
        # supervisord does not export DISPLAY, and a headed browser needs one.
        # Default to the local display (WSLg / a local X server) so the window
        # appears on the operator's own screen. With no real display the script
        # fails fast and logs it - it never silently falls back to headless.
        env.setdefault('DISPLAY', ':0')
    log_dir = os.path.join(_ail_home(), 'logs')
    try:
        os.makedirs(log_dir, exist_ok=True)
        log = open(os.path.join(log_dir, f'{log_prefix}_{_safe_id(forum_id)}.log'), 'ab')
    except OSError:
        log = subprocess.DEVNULL
    try:
        proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT,
                                env=env, cwd=_ail_home(), start_new_session=True)
    except Exception as e:
        return 'error', f'{type(e).__name__}: {str(e)[:150]}'
    if pid_key:
        try:
            _r().set(pid_key.format(forum_id), proc.pid, ex=3600)
        except Exception:
            pass
    return 'launched', proc.pid


def launch_login(forum_id, url=None, engine=None):
    """Open the headed operator-login window for this forum FROM THE UI (same as
    running forum_session_login.py by hand). A visible browser opens on the
    server's display; the human logs in / solves any CAPTCHA themselves and the
    established session is persisted to the forum's profile. Returns
    (status, detail): 'launched' | 'already_running' | 'error'."""
    if login_running(forum_id):
        try:
            return 'already_running', int(_r().get(_LOGIN_PID_KEY.format(forum_id)))
        except Exception:
            return 'already_running', None
    extra = []
    if url:
        extra += ['--url', url]
    if engine:
        extra += ['--engine', engine]
    return _spawn_session_script(forum_id, extra, pid_key=_LOGIN_PID_KEY,
                                 need_display=True)


def launch_validate(forum_id):
    """Start a headless session health check FROM THE UI (same as
    forum_session_login.py --validate). It writes the result to this forum's
    session health, which the page then reads back. Returns (status, detail)."""
    if validate_running(forum_id):
        return 'already_running', None
    return _spawn_session_script(forum_id, ['--validate'],
                                 pid_key=_VALIDATE_PID_KEY, need_display=False)


def leak_import_running(forum_id):
    """True while a UI-launched leak-site import window is still open."""
    return _pid_alive(_LEAKIMPORT_PID_KEY, forum_id)


def launch_leak_import(forum_id):
    """Open the headed leak-site import window FROM THE UI (bin/intel/leak_import.py):
    the operator clears the anti-bot, and the site's own victim list is captured
    and stored as documents. Returns (status, detail): 'launched' |
    'already_running' | 'error'. Nothing here solves or bypasses the challenge."""
    if leak_import_running(forum_id):
        return 'already_running', None
    return _spawn_session_script(forum_id, [], pid_key=_LEAKIMPORT_PID_KEY,
                                 need_display=True, script='intel/leak_import.py',
                                 log_prefix='leak_import')


def _route_to_proxy(route):
    """Map a forum_registry route dict onto BrowserSession's (proxy,
    use_default_proxy) pair. No route -> Tor default."""
    if not route:
        return None, True
    browser_proxy = route.get('browser')
    # An explicit direct route resolves 'browser' to None: honour it rather
    # than falling back to Tor.
    return browser_proxy, False


# --- local html-to-text (kept independent of the browser module) -------------
_TAGS = re.compile(r'<script.*?</script>|<style.*?</style>|<[^>]+>',
                   re.IGNORECASE | re.DOTALL)


def _text_of(html):
    if not html:
        return ''
    return re.sub(r'\s+', ' ', _TAGS.sub(' ', html)).strip()
