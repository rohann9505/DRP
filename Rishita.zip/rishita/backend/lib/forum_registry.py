#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Forum Registry
===================

Permanent registry of admin-approved dark-web/clearnet forums.

This is the single source of truth for "which forums does this platform
monitor". Nothing outside this module may register a forum, and nothing
in the controlled-collection layer (forum_collector.py) is allowed to
crawl a domain that isn't registered here and enabled.

Built on top of the existing lib.objects.Forums.Forum object (Kvrocks
"Objects" DB), which already persists across restarts and already has
name/url/enabled/first_seen/last_seen storage - reused rather than
re-implemented.
"""

import json
import os
import sys
import time
from urllib.parse import urlparse, urlunparse, quote

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib.objects.Forums import Forum, Forums
from lib.objects import Domains
from lib import crawlers

VALID_SOURCE_TYPES = {'onion', 'i2p', 'web'}
# Sub-hourly options exist so an operator can run a genuinely continuous
# incremental crawl. 'every_1min' does NOT mean "re-download the forum every
# minute" - it means "check for newly posted threads every minute", which the
# incremental cursor makes cheap (see forum_metrics.get_cursor).
VALID_FREQUENCIES = {'manual', 'disabled', 'every_1min', 'every_5min',
                     'every_15min', 'every_30min', 'hourly', 'daily',
                     'weekly', 'monthly'}
VALID_CRAWL_STATUSES = {'never', 'queued', 'running', 'success', 'error'}

# Human labels for the UI, in display order.
FREQUENCY_LABELS = [
    ('manual', 'Manual'),
    ('every_1min', 'Every 1 minute'),
    ('every_5min', 'Every 5 minutes'),
    ('every_15min', 'Every 15 minutes'),
    ('every_30min', 'Every 30 minutes'),
    ('hourly', 'Every hour'),
    ('daily', 'Daily'),
    ('disabled', 'Disabled'),
]

# Per-forum safety limits. Deliberately high enough for a meaningful crawl -
# these are backstops against a runaway bug, not collection targets.
DEFAULT_MAX_PAGES = 200
DEFAULT_MAX_DOCUMENTS = 5000


# ---------------------------------------------------------------------------
# Per-forum network routing
#
# Collection used to be hardcoded to Tor for every forum (one module-level
# TOR_PROXY in forum_crawl, another in forum_browser). That is the right
# default - and the only safe option for a hidden service - but it is also why
# clearnet forums whose anti-bot blocks Tor exit ranges were unreachable:
# there was no way to send one forum down a different path.
#
#   auto    - current behaviour, unchanged: Tor. The default for every forum,
#             including ones registered before routing existed (an absent
#             field reads as 'auto').
#   tor     - explicitly Tor. Same transport as auto; distinct so an operator
#             can record the intent rather than relying on the default.
#   direct  - no proxy at all. Clearnet only.
#   proxy   - a configured HTTP/HTTPS/SOCKS proxy.
#
# HARD RULE: .onion and .i2p sources are ALWAYS routed through Tor regardless
# of what is configured. Enforced in resolve_route() below - the resolver, not
# the UI - so no form post, API call or direct _set_field can deanonymise a
# hidden-service crawl by sending it out over clearnet.
# ---------------------------------------------------------------------------
VALID_ROUTES = {'auto', 'tor', 'direct', 'proxy'}

ROUTE_LABELS = [
    ('auto', 'Auto'),
    ('tor', 'Tor'),
    ('direct', 'Direct'),
    ('proxy', 'Custom Proxy'),
]

# Tor transport strings. The scheme difference is deliberate and load-bearing:
# socks5h makes the SOCKS proxy resolve DNS (required for .onion, and it keeps
# clearnet lookups off the local resolver), while Chromium does its own name
# resolution through the proxy and is configured with a plain socks5 server.
TOR_HTTP_PROXY = os.environ.get('FORUM_CRAWL_TOR_PROXY', 'socks5h://127.0.0.1:9050')
TOR_BROWSER_PROXY = os.environ.get('FORUM_CRAWL_TOR_PROXY_HOSTPORT', 'socks5://127.0.0.1:9050')

# Proxy credentials live in their own Kvrocks hash, NOT in the forum's
# metadata hash - same separation asset_keys.py uses for provider API keys.
# meta:forum:<id> is read by _forum_to_dict() and rendered into the UI and API
# responses; keeping the secret out of it means a password cannot leak through
# a template, a JSON response, or a crawl-history record by accident.
PROXY_SECRETS_HASH = 'forum:proxy:secrets'


def _proxy_secret_key(forum_id, part):
    return f'{forum_id}:{part}'


def _get_proxy_secret(forum_id, part):
    return crawlers.r_crawler.hget(PROXY_SECRETS_HASH, _proxy_secret_key(forum_id, part)) or ''


def _set_proxy_secret(forum_id, part, value):
    key = _proxy_secret_key(forum_id, part)
    if value:
        crawlers.r_crawler.hset(PROXY_SECRETS_HASH, key, value)
    else:
        crawlers.r_crawler.hdel(PROXY_SECRETS_HASH, key)


def _clear_proxy_secrets(forum_id):
    for part in ('username', 'password'):
        crawlers.r_crawler.hdel(PROXY_SECRETS_HASH, _proxy_secret_key(forum_id, part))


def mask_proxy_url(url, username=None):
    """Render a proxy URL safe for display, logs, API responses and errors.

    Always returns scheme://[user:****@]host:port - the password is never
    included in any form, not even truncated.
    """
    if not url:
        return ''
    try:
        p = urlparse(url)
    except Exception:
        return '(invalid proxy)'
    if not p.hostname:
        return '(invalid proxy)'
    host = p.hostname
    if p.port:
        host = f'{host}:{p.port}'
    user = username or p.username
    if user:
        return f'{p.scheme}://{user}:****@{host}'
    return f'{p.scheme}://{host}'


def get_proxy_config(forum_id):
    """Configured (not resolved) proxy settings for this forum.

    Returns the credential-free parts plus a masked display string. The raw
    password is only ever handed out by resolve_route(), which is called by
    the crawl engine - never by anything that renders.
    """
    forum = Forum(forum_id)
    if not forum.exists():
        return {}
    base = forum._get_field('proxy_url') or ''
    username = _get_proxy_secret(forum_id, 'username')
    return {
        'proxy_url': base,
        'proxy_label': forum._get_field('proxy_label') or '',
        'proxy_masked': mask_proxy_url(base, username) if base else '',
        'proxy_has_credentials': bool(username),
    }


def set_route(forum_id, route, proxy_url=None, proxy_label=None):
    """Configure this forum's network route.

    `proxy_url` may embed credentials (scheme://user:pass@host:port). They are
    split out and stored in the secrets hash; only the credential-free URL is
    written to the forum's metadata.
    """
    route = (route or 'auto').strip()
    if route not in VALID_ROUTES:
        return {'status': 'error',
                'reason': f'Invalid route, must be one of {sorted(VALID_ROUTES)}'}, 400

    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404

    if route == 'proxy':
        proxy_url = (proxy_url or '').strip()
        if not proxy_url:
            # Keep the existing proxy if the operator only changed the label.
            proxy_url = forum._get_field('proxy_url') or ''
            if not proxy_url:
                return {'status': 'error',
                        'reason': 'A proxy URL is required for the Custom Proxy route'}, 400
            stored_user = _get_proxy_secret(forum_id, 'username')
            stored_pass = _get_proxy_secret(forum_id, 'password')
        else:
            # Reuse AIL's own validator so the accepted syntax matches the rest
            # of the platform (scheme in http/https/socks5, host, port, and
            # username+password together or not at all).
            verified, code = crawlers.api_verify_proxy(proxy_url)
            if code != 200:
                return {'status': 'error',
                        'reason': verified.get('error', 'Invalid proxy')}, 400
            parsed = urlparse(proxy_url)
            stored_user = parsed.username or ''
            stored_pass = parsed.password or ''
            # Strip credentials before persisting to forum metadata.
            netloc = parsed.hostname or ''
            if parsed.port:
                netloc = f'{netloc}:{parsed.port}'
            proxy_url = urlunparse((parsed.scheme, netloc, parsed.path or '',
                                    '', '', ''))
        forum._set_field('proxy_url', proxy_url)
        _set_proxy_secret(forum_id, 'username', stored_user)
        _set_proxy_secret(forum_id, 'password', stored_pass)
    else:
        # Leaving proxy mode: drop the stored credentials rather than keeping
        # a dormant secret around.
        if route in ('auto', 'tor', 'direct'):
            _clear_proxy_secrets(forum_id)
            forum._delete_field('proxy_url')

    if proxy_label is not None:
        forum._set_field('proxy_label', (proxy_label or '').strip())
    forum._set_field('route', route)
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def resolve_route(forum_id, source_type=None, route=None):
    """Resolve the EFFECTIVE transport for this forum.

    This is the single authority on how a forum is reached. Returns:
        {
          'mode':    'tor' | 'direct' | 'proxy',
          'reason':  human-readable explanation of why,
          'forced':  True when the configured route was overridden,
          'http':    proxy URL for requests (None = direct),
          'browser': {'server','username','password'} for Playwright (None = direct),
          'display': credential-free string safe to log or render,
        }

    The .onion/.i2p override lives here so it applies to every caller.
    """
    forum = Forum(forum_id)
    exists = forum.exists()
    if source_type is None and exists:
        source_type = forum.get_forum_type()
    if route is None:
        route = (forum._get_field('route') if exists else None) or 'auto'
    if route not in VALID_ROUTES:
        route = 'auto'

    # HARD OVERRIDE - a hidden service is never reachable, and never safe to
    # reach, over clearnet. This cannot be turned off from the UI or the API.
    if source_type in ('onion', 'i2p'):
        forced = route not in ('auto', 'tor')
        return {
            'mode': 'tor', 'forced': forced,
            'reason': f'Tor — forced because this is a .{source_type} source',
            'http': TOR_HTTP_PROXY, 'browser': {'server': TOR_BROWSER_PROXY},
            'display': TOR_HTTP_PROXY,
        }

    if route == 'auto':
        return {'mode': 'tor', 'forced': False, 'reason': 'Tor — automatic default',
                'http': TOR_HTTP_PROXY, 'browser': {'server': TOR_BROWSER_PROXY},
                'display': TOR_HTTP_PROXY}

    if route == 'tor':
        return {'mode': 'tor', 'forced': False, 'reason': 'Tor — explicitly configured',
                'http': TOR_HTTP_PROXY, 'browser': {'server': TOR_BROWSER_PROXY},
                'display': TOR_HTTP_PROXY}

    if route == 'direct':
        return {'mode': 'direct', 'forced': False,
                'reason': 'Direct — explicitly configured',
                'http': None, 'browser': None, 'display': 'direct (no proxy)'}

    # route == 'proxy'
    base = forum._get_field('proxy_url') if exists else None
    if not base:
        # Misconfiguration must be explicit, never a silent fallback to Tor:
        # an operator who set 'proxy' and lost the URL needs to be told.
        return {'mode': 'invalid', 'forced': False,
                'reason': 'Proxy route configured but no proxy URL is set',
                'http': None, 'browser': None, 'display': '(unconfigured proxy)',
                'error': 'Proxy route configured but no proxy URL is set'}

    username = _get_proxy_secret(forum_id, 'username')
    password = _get_proxy_secret(forum_id, 'password')
    parsed = urlparse(base)

    # requests/PySocks accept inline credentials in the URL...
    http_url = base
    if username:
        netloc = f'{quote(username, safe="")}:{quote(password, safe="")}@{parsed.hostname}'
        if parsed.port:
            netloc = f'{netloc}:{parsed.port}'
        http_url = urlunparse((parsed.scheme, netloc, parsed.path or '', '', '', ''))

    # ...but Chromium does NOT: Playwright needs them as separate fields.
    browser = {'server': base}
    if username:
        browser['username'] = username
        browser['password'] = password

    return {'mode': 'proxy', 'forced': False,
            'reason': 'Proxy — explicitly configured',
            'http': http_url, 'browser': browser,
            'display': mask_proxy_url(base, username)}


def _normalize_domain(url_or_domain):
    """Resolve any submitted URL/domain string down to a bare, lowercased domain."""
    value = (url_or_domain or '').strip()
    if not value:
        return None
    if '://' not in value:
        value = f'http://{value}'
    return crawlers.get_url_domain(value)


def _detect_source_type(domain):
    return Domains.Domain(domain).get_domain_type()


def _today_str():
    """AbstractDaterangeObject first_seen/last_seen are YYYYMMDD strings, not epoch."""
    return time.strftime('%Y%m%d', time.gmtime())


def register_forum(name, url, source_type=None, crawl_frequency='manual', enabled=True):
    """
    Register a new forum, or update an existing one (idempotent on domain).
    Returns (forum_dict, http_status).
    """
    name = (name or '').strip()
    url = (url or '').strip()
    if not name:
        return {'status': 'error', 'reason': 'Missing forum name'}, 400
    if not url:
        return {'status': 'error', 'reason': 'Missing forum URL'}, 400

    domain = _normalize_domain(url)
    if not domain:
        return {'status': 'error', 'reason': 'Could not parse a domain from the supplied URL'}, 400

    if source_type and source_type not in VALID_SOURCE_TYPES:
        return {'status': 'error', 'reason': f'Invalid source_type, must be one of {sorted(VALID_SOURCE_TYPES)}'}, 400
    if not source_type:
        source_type = _detect_source_type(domain)

    if crawl_frequency not in VALID_FREQUENCIES:
        return {'status': 'error', 'reason': f'Invalid crawl_frequency, must be one of {sorted(VALID_FREQUENCIES)}'}, 400

    forum = Forum(domain)
    is_new = not forum.exists()

    forum.create(source_type, name=name, url=url)
    forum.set_crawl_config({'enabled': 1 if enabled else 0, 'javascript': 0})

    today = _today_str()
    if is_new:
        forum.set_first_seen(today)
        forum._set_field('document_count', 0)
        forum._set_field('last_crawl_status', 'never')
    forum.set_last_seen(today)
    forum._set_field('crawl_frequency', crawl_frequency)

    return get_forum(domain)


def get_forum(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    return _forum_to_dict(forum), 200


# ---------------------------------------------------------------------------
# Onion monitoring pool
#
# The Forums view and the monitored collection pool are DARK-WEB scoped: only
# hidden services belong in them. Membership is DERIVED from the stored URL
# rather than kept as a flag, which is what makes the exclusion permanent - a
# clearnet source cannot drift back in through a re-registration, a refresh,
# or a flag someone forgot to set, because its URL can never satisfy the test.
#
# Clearnet sources are NOT deleted. Their records, documents, metrics and
# providers are untouched and still reachable through the registry's
# unfiltered API; they are simply not part of this pool.
# ---------------------------------------------------------------------------
ONION_SUFFIXES = ('.onion', '.i2p')


def is_onion_source(forum):
    """True when a forum dict/record's PRIMARY monitored URL is a hidden
    service. Judged on the stored url and source_type - never on the name,
    which says nothing about how the source is actually reached."""
    if not forum:
        return False
    if isinstance(forum, str):
        url = forum
        source_type = None
    else:
        url = forum.get('url') or ''
        source_type = forum.get('source_type')
    host = (urlparse(url).hostname or '').lower()
    return host.endswith(ONION_SUFFIXES) or source_type in ('onion', 'i2p')


def list_forums(onion_only=False):
    """All registered forums.

    `onion_only=True` returns the dark-web monitoring pool. The default is
    unfiltered so existing non-pool callers keep their current behaviour.
    """
    forums = []
    for forum_id in Forums().get_ids():
        forum = Forum(forum_id)
        d = _forum_to_dict(forum)
        if onion_only and not is_onion_source(d):
            continue
        forums.append(d)
    forums.sort(key=lambda f: f.get('name') or f.get('id') or '')
    return forums


def _session_health(forum_id):
    """Persistent-session health for a forum, resilient to forum_session being
    unavailable (keeps the registry usable even if the browser stack isn't)."""
    try:
        from lib import forum_session
        return forum_session.get_health(forum_id)
    except Exception:
        return {'state': 'none', 'profile_present': False, 'healthy': False,
                'needs_operator': False}


def _forum_to_dict(forum):
    config = forum.get_crawl_config()
    return {
        'id': forum.id,
        'name': forum.get_name(),
        'url': forum.get_url(),
        'source_type': forum.get_forum_type(),
        'enabled': config.get('enabled'),
        'crawl_frequency': forum._get_field('crawl_frequency') or 'manual',
        'document_count': int(forum._get_field('document_count') or 0),
        'last_crawl_status': forum._get_field('last_crawl_status') or 'never',
        'last_crawl_error': forum._get_field('last_crawl_error'),
        'last_collection_triggered': forum._get_field('last_collection_triggered'),
        'last_successful_crawl': forum._get_field('last_successful_crawl'),
        'first_added': forum.get_first_seen(),
        'last_updated': forum.get_last_seen(),
        'rss_url': forum._get_field('rss_url') or None,
        'last_rss_poll': forum._get_field('last_rss_poll'),
        'rss_new_items_total': int(forum._get_field('rss_new_items_total') or 0),
        'search_url': forum._get_field('search_url') or None,
        'search_queries': get_search_queries(forum.id) if hasattr(forum, 'id') else [],
        'search_enabled': (forum._get_field('search_enabled') or '1') == '1',
        'circuit_state': forum._get_field('circuit_state') or 'closed',
        'consecutive_failures': int(forum._get_field('consecutive_failures') or 0),
        'circuit_opened_at': forum._get_field('circuit_opened_at'),
        # Persistent authenticated-session health (state, profile_present,
        # last_validated, needs_operator...). Cheap: one hash read + a dir stat.
        'session_health': _session_health(forum.id),
        'provider': forum._get_field('provider') or None,
        # Browser engine for the HEADED operator login ('chromium' default, or
        # 'firefox' for hidden services that drop Chromium's connection). Only
        # affects which real browser the human uses to solve a challenge.
        'browser_engine': forum._get_field('browser_engine') or 'chromium',
        'live_crawl': forum._get_field('live_crawl') == '1',
        'max_pages': int(forum._get_field('max_pages') or DEFAULT_MAX_PAGES),
        'max_documents': int(forum._get_field('max_documents') or DEFAULT_MAX_DOCUMENTS),
        # Network routing. `proxy_url` here is credential-free by construction
        # (set_route strips them into the secrets hash), and `proxy_masked` is
        # the only value intended for display. The raw password is never a
        # member of this dict, so it cannot reach a template or API response.
        'route': forum._get_field('route') or 'auto',
        'proxy_url': forum._get_field('proxy_url') or '',
        'proxy_label': forum._get_field('proxy_label') or '',
        'proxy_masked': mask_proxy_url(forum._get_field('proxy_url') or '',
                                       _get_proxy_secret(forum.id, 'username')),
    }


def set_provider(forum_id, provider_id):
    """Override platform auto-detection for this forum."""
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('provider', (provider_id or '').strip())
    return get_forum(forum_id)


def set_browser_engine(forum_id, engine):
    """Set the browser engine used for the HEADED operator login on this forum.
    'chromium' (default) or 'firefox'. Firefox is for hidden services that drop
    Chromium's connection - it only changes which real browser the human opens
    to solve a challenge themselves, never automates solving one."""
    engine = (engine or 'chromium').strip().lower()
    if engine not in ('chromium', 'firefox'):
        return {'status': 'error', 'reason': "engine must be 'chromium' or 'firefox'"}, 400
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('browser_engine', engine)
    return get_forum(forum_id)


def get_crawl_limits(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return {'max_pages': DEFAULT_MAX_PAGES, 'max_documents': DEFAULT_MAX_DOCUMENTS}
    return {
        'max_pages': int(forum._get_field('max_pages') or DEFAULT_MAX_PAGES),
        'max_documents': int(forum._get_field('max_documents') or DEFAULT_MAX_DOCUMENTS),
    }


def set_crawl_limits(forum_id, max_pages=None, max_documents=None):
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    if max_pages is not None:
        forum._set_field('max_pages', int(max_pages))
    if max_documents is not None:
        forum._set_field('max_documents', int(max_documents))
    return get_forum(forum_id)


def set_live_crawl(forum_id, enabled):
    """LIVE CRAWLING toggle - continuous incremental ingestion."""
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('live_crawl', '1' if enabled else '0')
    return get_forum(forum_id)


def set_document_count(forum_id, count):
    """Set the count to the number of documents ACTUALLY stored.

    Replaces the previous increment-on-capture behaviour, which counted pages
    the crawler saw rather than documents that were retrievable - the reason
    the dashboard showed 280 documents against 25 files on disk.
    """
    forum = Forum(forum_id)
    if not forum.exists():
        return
    forum._set_field('document_count', int(count))


def set_enabled(forum_id, enabled):
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum.set_crawl_config({'enabled': 1 if enabled else 0, 'javascript': 0})
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def set_cookiejar(forum_id, cookiejar_uuid):
    """Associate a stored cookiejar (authenticated session) with a forum, so
    all collection - bulk and on-demand evidence captures alike - can reuse
    it automatically instead of every caller needing to know the UUID."""
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('cookiejar_uuid', cookiejar_uuid or '')
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def get_cookiejar(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return None
    return forum._get_field('cookiejar_uuid') or None


def set_crawl_frequency(forum_id, crawl_frequency):
    if crawl_frequency not in VALID_FREQUENCIES:
        return {'status': 'error', 'reason': f'Invalid crawl_frequency, must be one of {sorted(VALID_FREQUENCIES)}'}, 400
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('crawl_frequency', crawl_frequency)
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def delete_forum(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum.delete()
    return {'status': 'ok', 'deleted': forum_id}, 200


def is_registered_and_enabled(domain):
    """The allowlist gate: True only if `domain` is a registered, enabled forum."""
    forum = Forum(domain)
    if not forum.exists():
        return False
    return bool(forum.get_crawl_config().get('enabled'))


def record_collection_triggered(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return
    forum._set_field('last_collection_triggered', int(time.time()))
    forum._set_field('last_crawl_status', 'queued')


def record_crawl_result(forum_id, success, error=None):
    forum = Forum(forum_id)
    if not forum.exists():
        return
    now = int(time.time())
    if success:
        forum._set_field('last_crawl_status', 'success')
        forum._set_field('last_successful_crawl', now)
        forum._delete_field('last_crawl_error')
    else:
        forum._set_field('last_crawl_status', 'error')
        if error:
            forum._set_field('last_crawl_error', error)
    forum.set_last_seen(_today_str())
    _update_circuit_state(forum, success)


# ---------------------------------------------------------------------------
# Circuit breaker
#
# A forum being unreachable is routine (Tor + hidden services + Cloudflare
# means it happens constantly - darkforums.ru sat unreachable for most of
# this project). Without this, every collection cycle (RSS poll, live
# search, scheduled collection) keeps re-trying a dead forum at full speed
# forever, burning a capture slot and adding real wall-clock delay to every
# job that touches it. Three states, same shape as any standard circuit
# breaker: CLOSED (normal - try it), OPEN (recently failed enough times -
# skip it without even trying), HALF_OPEN (cooldown elapsed - let exactly
# one probe through to see if it's back, rather than resuming full traffic
# blind). This is what makes "if one forum goes down, get results from the
# others instead" an actual property of the system rather than something
# that just happens to work because a slow timeout eventually gives up.
# ---------------------------------------------------------------------------

CIRCUIT_FAILURE_THRESHOLD = 3      # consecutive failures before a forum is skipped outright
CIRCUIT_COOLDOWN_SECONDS = 900     # 15 min - how long OPEN lasts before a single probe is allowed through


def _update_circuit_state(forum, success):
    if success:
        forum._set_field('consecutive_failures', 0)
        forum._set_field('circuit_state', 'closed')
        forum._delete_field('circuit_opened_at')
        return

    failures = int(forum._get_field('consecutive_failures') or 0) + 1
    forum._set_field('consecutive_failures', failures)
    # A HALF_OPEN probe that fails goes straight back to OPEN with a fresh
    # cooldown window, regardless of the raw failure count - one bad probe
    # after a cooldown means it's still down, not "one more strike".
    was_half_open = forum._get_field('circuit_state') == 'half_open'
    if was_half_open or failures >= CIRCUIT_FAILURE_THRESHOLD:
        forum._set_field('circuit_state', 'open')
        forum._set_field('circuit_opened_at', int(time.time()))


def is_circuit_open(forum_id):
    """
    True if `forum_id` should be skipped right now (OPEN, cooldown not yet
    elapsed). Transitions OPEN -> HALF_OPEN itself once the cooldown has
    elapsed and returns False for that call, so the caller's very next
    attempt against this forum *is* the probe - no separate "try a probe"
    codepath needed. A forum with no circuit state yet (never failed) is
    always CLOSED.
    """
    forum = Forum(forum_id)
    if not forum.exists():
        return False
    state = forum._get_field('circuit_state') or 'closed'
    if state != 'open':
        return False
    opened_at = int(forum._get_field('circuit_opened_at') or 0)
    if int(time.time()) - opened_at >= CIRCUIT_COOLDOWN_SECONDS:
        forum._set_field('circuit_state', 'half_open')
        return False
    return True


def increment_document_count(forum_id, by=1):
    forum = Forum(forum_id)
    if not forum.exists():
        return
    current = int(forum._get_field('document_count') or 0)
    forum._set_field('document_count', current + by)


def set_rss_url(forum_id, rss_url):
    """
    Native syndication feed for continuous monitoring (see forum_monitor.py) -
    e.g. MyBB's 'misc.php?action=syndication' or XenForo's
    '/forums/-/index.rss?order=post_date'. Empty/None disables RSS polling
    for this forum without touching its enabled/collection state.
    """
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('rss_url', (rss_url or '').strip())
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def get_rss_url(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return None
    return forum._get_field('rss_url') or None


def set_search_url(forum_id, search_url):
    """
    Forum's own search feature, for live cross-forum search (see
    live_search.py). Two supported shapes, distinguished by whether the
    value contains the literal '{query}' placeholder:
      - contains '{query}': a direct GET template (e.g. MyBB's
        'https://forum.example/search.php?action=results&keywords={query}')
        - captured with a plain URL fetch, no browser scripting needed.
      - no placeholder: a search landing page (e.g. XenForo's
        'https://forum.example/search/') whose own search form has to be
        filled in and submitted via in-browser JS, because Lacus/Playwright
        only ever navigates to a URL - see
        Crawler.py:build_search_submit_init_script and
        forum_collector.search_forum.
    """
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('search_url', (search_url or '').strip())
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def set_search_queries(forum_id, queries):
    """Intelligence queries run against this forum's OWN search function.

    Stored per forum because relevance is per source: a card-fraud forum and a
    ransomware leak site do not answer to the same terms. Re-run on every
    search collection so newly published matching content is picked up over
    time rather than only at registration.
    """
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    if isinstance(queries, str):
        queries = [q.strip() for q in queries.replace('\n', ',').split(',')]
    cleaned = []
    for q in (queries or []):
        q = (q or '').strip()
        if q and q not in cleaned:
            cleaned.append(q[:120])
    forum._set_field('search_queries', json.dumps(cleaned))
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def get_search_queries(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return []
    raw = forum._get_field('search_queries')
    if not raw:
        return []
    try:
        out = json.loads(raw)
        return out if isinstance(out, list) else []
    except Exception:
        return []


def set_search_enabled(forum_id, enabled):
    """Turn query-driven collection on/off for a forum without losing the
    configured terms - an operator pausing a noisy source should not have to
    retype its query list to resume."""
    forum = Forum(forum_id)
    if not forum.exists():
        return {'status': 'error', 'reason': 'Unknown forum'}, 404
    forum._set_field('search_enabled', '1' if enabled else '0')
    forum.set_last_seen(_today_str())
    return get_forum(forum_id)


def get_search_enabled(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return False
    raw = forum._get_field('search_enabled')
    # Default ON when queries exist: configuring terms is the opt-in.
    if raw is None or raw == '':
        return True
    return raw == '1'


def get_search_url(forum_id):
    forum = Forum(forum_id)
    if not forum.exists():
        return None
    return forum._get_field('search_url') or None


def record_rss_poll(forum_id, new_items_found=0):
    forum = Forum(forum_id)
    if not forum.exists():
        return
    forum._set_field('last_rss_poll', int(time.time()))
    if new_items_found:
        current = int(forum._get_field('rss_new_items_total') or 0)
        forum._set_field('rss_new_items_total', current + new_items_found)
