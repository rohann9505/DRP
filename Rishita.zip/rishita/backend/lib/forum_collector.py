#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
Controlled Forum Collection
===================

The ONLY path that is allowed to (a) enqueue a crawl against a forum and
(b) register a freshly-crawled page as a permanent, indexed document in
the intelligence corpus.

Every domain touched here MUST already be a registered, enabled forum
(see forum_registry.py). This module never discovers or crawls anything
outside the Forum Registry.

Collection itself reuses the existing, already-verified-working Lacus/Tor
crawl pipeline (lib.crawlers.create_task -> Crawler.py -> Lacus) rather
than reimplementing browser automation.
"""

import os
import re
import sys
import time
import xml.etree.ElementTree as ET
from hashlib import sha256
from html import unescape

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers
from lib import forum_registry
from lib import intel_extraction
from lib import search_engine
from lib import watchlist

D_HAR = True
D_SCREENSHOT = False  # bulk/board collection is text-only by default - see capture_evidence_screenshot()
# depth=1 (homepage + everything one hop away) never actually reaches real
# leak-dump thread pages on a large forum - confirmed on xforums.st
# (657k+ threads, only 214 documents collected after repeated depth=1
# collects): its threads sit two hops out (homepage -> board/category page
# -> thread page), so a depth=1 crawl only ever captured nav-bar/footer/
# language-variant noise plus whatever the top-level category pages
# themselves are, never the threads inside them. 2 reaches the actual
# thread links a board's listing page shows. MAX_NEW_DOCS_PER_FORUM below
# is the real backstop against this getting too large, not a shallow depth.
D_DEPTH = 2

# Cap how many *new* distinct documents a forum's corpus can accumulate.
# Originally sized for a single depth=1 collect_forum() run, where without a
# cap it follows every same-domain link it finds (nav bars, language
# variants, footers, ...) and floods the corpus with near-duplicate pages
# instead of a handful of genuinely relevant ones.
#
# That reasoning breaks down for continuous monitoring and live search
# (forum_monitor.py / live search jobs): both are *deliberate*, targeted
# captures of genuinely new content discovered via RSS or a search result -
# never blind link-following - and they're supposed to keep the corpus
# growing indefinitely as a forum keeps posting. A cap sized for "one bulk
# run's worth of nav-bar noise" silently stops accepting ALL new content the
# moment a forum's legitimate document count crosses it - confirmed live
# (2026-08-28): xforums.st hit exactly 80 real documents from RSS-discovered
# threads, and every capture after that point - RSS-discovered or live
# search - kept succeeding at the network/browser level while silently
# never being recorded, because this cap was rejecting them before they
# ever reached the watchlist check or the search index. That's not a corner
# case, it's the expected steady state after roughly one day of normal
# monitoring on an active forum - so a low cap here quietly disables both
# features shortly after they're turned on.
#
# Kept as a large-but-finite ceiling (not removed outright) purely as a
# backstop against a genuine runaway bug elsewhere, not as a size target -
# 10k documents at typical forum-post text sizes is a non-issue for
# Kvrocks/Meilisearch at this platform's scale.
MAX_NEW_DOCS_PER_FORUM = 10000


def _circuit_guard(forum_id):
    """
    Shared skip-if-unhealthy check for every enqueue path (bulk collection,
    single-page capture, RSS polling, live search). Returns an
    (error_dict, 503) tuple to return early with, or None if it's fine to
    proceed. Centralizing this in one place (rather than each caller
    re-deriving "is this forum okay to hit right now") is what makes
    failover automatic: a caller that just tries every forum in its list
    and skips the ones this returns non-None for gets "if one forum is
    down, use the others" for free, without needing its own health logic.
    """
    if forum_registry.is_circuit_open(forum_id):
        return {'status': 'error', 'reason': 'Forum circuit breaker is open (repeated recent failures) - skipping'}, 503
    return None


def collect_forum(forum_id, priority=90):
    """
    Queue a controlled collection run for one registered, enabled forum.
    Returns (result_dict, http_status). Never touches unregistered domains.
    """
    forum, status = forum_registry.get_forum(forum_id)
    if status != 200:
        return forum, status
    if not forum.get('enabled'):
        return {'status': 'error', 'reason': 'Forum is disabled'}, 409
    guard = _circuit_guard(forum_id)
    if guard:
        return guard

    # Always route forum collection through Tor, regardless of whether the
    # forum's registered URL happens to be an .onion address or a clearnet
    # mirror. A monitored forum is a monitored forum either way - the whole
    # point is to never expose this server's real IP to it. Previously this
    # only forced Tor for source_type == 'onion', which meant clearnet-mirror
    # forums (source_type 'web') were captured directly, unprotected - a real
    # bug, not just a theoretical one.
    proxy = 'force_tor'
    cookiejar_uuid = forum_registry.get_cookiejar(forum_id)
    task_uuid = crawlers.create_task(
        forum['url'],
        depth=D_DEPTH,
        har=D_HAR,
        screenshot=D_SCREENSHOT,
        cookiejar=cookiejar_uuid,
        proxy=proxy,
        parent='forum_registry',
        priority=priority,
        new_task=False,
    )
    forum_registry.record_collection_triggered(forum_id)
    return {'status': 'ok', 'forum_id': forum_id, 'task_uuid': task_uuid}, 200


def capture_page(forum_id, url, priority=90):
    """
    Capture one specific page belonging to a registered, enabled forum
    (e.g. a specific thread, not just the forum's main registered URL) -
    text-only, no screenshot, same as bulk collection. Used to broaden a
    forum's corpus beyond its single registered seed URL.
    """
    forum, status = forum_registry.get_forum(forum_id)
    if status != 200:
        return forum, status
    if not forum.get('enabled'):
        return {'status': 'error', 'reason': 'Forum is disabled'}, 409
    guard = _circuit_guard(forum_id)
    if guard:
        return guard

    cookiejar_uuid = forum_registry.get_cookiejar(forum_id)
    task_uuid = crawlers.create_task(
        url, depth=0, har=D_HAR, screenshot=False, cookiejar=cookiejar_uuid,
        proxy='force_tor', parent='forum_registry', priority=priority, new_task=False,
    )
    return {'status': 'ok', 'forum_id': forum_id, 'task_uuid': task_uuid}, 200


def capture_evidence_screenshot(forum_id, url, priority=95):
    """
    On-demand, screenshot-enabled capture of one specific page - used only
    when a finding turns out to matter (e.g. CRITICAL risk), not for every
    page in bulk collection. Keeps screenshot storage proportional to what's
    actually significant instead of every page ever touched.

    Tagged 'evidence_crop' so Crawler.py knows to isolate just the matched
    forum post (hiding nav/header/other-replies/footer chrome) before the
    screenshot is taken, instead of a full-page shot of the whole forum
    theme - see CROP_TO_POST_INIT_SCRIPT in Crawler.py.
    """
    forum, status = forum_registry.get_forum(forum_id)
    if status != 200:
        return forum, status
    guard = _circuit_guard(forum_id)
    if guard:
        return guard
    cookiejar_uuid = forum_registry.get_cookiejar(forum_id)
    task_uuid = crawlers.create_task(
        url, depth=0, har=True, screenshot=True, cookiejar=cookiejar_uuid,
        proxy='force_tor', parent='forum_registry', priority=priority, new_task=False,
        tags=['evidence_crop'],
    )
    return {'status': 'ok', 'forum_id': forum_id, 'task_uuid': task_uuid}, 200


def search_forum(forum_id, search_url, query, priority=95):
    """
    Drive the forum's own search feature for `query`, rather than crawling
    board-by-board and hoping to stumble on a mention. Lacus/Playwright only
    ever navigates to a URL - there is no POST/form-data option - so a
    platform whose search requires a real form submission (most XenForo
    forums; confirmed a bare `?q=<term>` GET against xforums.st is silently
    ignored) can't be searched with a plain link the way MyBB's
    `?action=results&keywords=<term>` can. Tagging the task
    'search_query:<term>' instead has Crawler.py inject a script that fills
    in and submits the real search form already on the page, so whatever
    CSRF token/action the forum itself renders is used automatically - see
    build_search_submit_init_script in Crawler.py. `search_url` should be
    the forum's plain search landing page (e.g. https://xforums.st/search/),
    not a query string - the query is injected by the in-browser script, not
    the URL.
    """
    forum, status = forum_registry.get_forum(forum_id)
    if status != 200:
        return forum, status
    if not forum.get('enabled'):
        return {'status': 'error', 'reason': 'Forum is disabled'}, 409
    guard = _circuit_guard(forum_id)
    if guard:
        return guard
    cookiejar_uuid = forum_registry.get_cookiejar(forum_id)
    task_uuid = crawlers.create_task(
        search_url, depth=0, har=True, screenshot=False, cookiejar=cookiejar_uuid,
        proxy='force_tor', parent='forum_registry', priority=priority, new_task=False,
        tags=[f'search_query:{query}'],
    )
    return {'status': 'ok', 'forum_id': forum_id, 'task_uuid': task_uuid}, 200


def record_forum_document(forum_id, item_id, url, html_content, timestamp):
    """
    Called from Crawler.py right after a page belonging to a registered,
    enabled forum has been fetched. Deduplicates by content hash, tracks
    first_seen/last_seen, and indexes the page for domain-intelligence
    search. Never creates a document for a domain that isn't a registered,
    enabled forum - callers MUST check forum_registry.is_registered_and_enabled()
    first (Crawler.py does this before calling in).

    Safe to call even if this specific page was already seen before -
    it just bumps last_seen instead of creating a duplicate.
    """
    if not html_content:
        return

    r_crawler = crawlers.r_crawler

    text_content = None
    try:
        from lib.objects.Items import Item
        text_content = Item(item_id).get_html2text_content(content=html_content)
    except Exception:
        return
    if not text_content or not text_content.strip():
        return

    content_hash = sha256(text_content.encode()).hexdigest()
    hash_key = f'forumdoc:hash:{forum_id}'
    meta_key = f'forumdoc:meta:{forum_id}:{content_hash}'

    is_new = not r_crawler.sismember(hash_key, content_hash)
    if is_new and r_crawler.scard(hash_key) >= MAX_NEW_DOCS_PER_FORUM:
        return
    if is_new:
        r_crawler.sadd(hash_key, content_hash)
        r_crawler.hset(meta_key, mapping={
            'item_id': item_id,
            'url': url,
            'first_seen': timestamp,
            'last_seen': timestamp,
        })
        forum_registry.increment_document_count(forum_id)
    else:
        r_crawler.hset(meta_key, 'last_seen', timestamp)
        r_crawler.hset(meta_key, 'item_id', item_id)
        r_crawler.hset(meta_key, 'url', url)

    if search_engine.Engine is not None:
        try:
            search_engine.Engine.index_intel_doc(forum_id, content_hash, text_content, url, int(timestamp), is_new)
        except Exception:
            pass

    # Only ever check genuinely new content - a re-crawl that just bumps
    # last_seen on a page already in the corpus was already checked the
    # first time it was seen, and re-alerting on every subsequent re-crawl
    # would turn one real match into a stream of duplicate alerts.
    if is_new:
        try:
            _check_watchlist(forum_id, item_id, url, text_content, content_hash)
        except Exception as e:
            print(f'Watchlist check failed for {item_id}: {e}')

    forum_registry.record_crawl_result(forum_id, success=True)


_MATCH_CONFIDENCE_RANK = {'high': 2, 'medium': 1, 'low': 0}


def _check_watchlist(forum_id, item_id, url, text_content, content_hash):
    """
    Run every active watch against one freshly-collected document. Mirrors
    intel_jobs.run_job()'s matching pipeline (same classifiers, same
    analysis-window scoping) so a watch alert and a manual search finding
    for the same term are never inconsistent with each other - just
    triggered at a different time (as soon as collected, vs on demand).
    """
    active_watches = [w for w in watchlist.get_active_watches()
                       if not w['forum_ids'] or forum_id in w['forum_ids']]
    if not active_watches:
        return

    forum_meta, _ = forum_registry.get_forum(forum_id)
    forum_name = forum_meta.get('name') if forum_meta else forum_id

    for watch in active_watches:
        if watch['query_type'] == 'keyword':
            matches = intel_extraction.classify_keyword_matches(text_content, watch['query'])
        else:
            matches = intel_extraction.classify_matches(text_content, watch['query'])
        if not matches:
            continue

        best_match = max(matches, key=lambda m: _MATCH_CONFIDENCE_RANK.get(m['confidence'], 0))
        analysis_text = intel_extraction.extract_analysis_window(text_content, best_match['matched_value'])
        entities = intel_extraction.extract_entities(analysis_text)
        sensitive_signals = intel_extraction.detect_sensitive_signals(analysis_text)
        risk_score, risk_level = intel_extraction.score_document_risk(matches, entities, sensitive_signals)
        match_snippet, specific_url = intel_extraction.extract_match_snippet(
            text_content, best_match['matched_value'], base_url=url)

        # Deliberately no evidence-screenshot capture triggered from here:
        # this function runs inline in Crawler.py's single-threaded capture
        # loop (via record_forum_document), and a screenshot re-capture can
        # take up to ~120s per finding (see intel_jobs.EVIDENCE_CAPTURE_TIMEOUT)
        # - blocking every other queued capture behind one alert is the exact
        # synchronous-evidence bug already fixed once for search jobs (see
        # intel_jobs.py's deferred-evidence-capture comment). An alert just
        # records the match; a screenshot can be pulled on demand later by
        # running a domain/keyword search job for it.
        watchlist.record_alert(
            watch['id'], forum_id, forum_name, specific_url or url, item_id,
            best_match['match_type'], best_match['matched_value'],
            risk_level, risk_score, match_snippet,
        )


def get_forum_document_meta(forum_id, content_hash):
    r_crawler = crawlers.r_crawler
    meta = r_crawler.hgetall(f'forumdoc:meta:{forum_id}:{content_hash}')
    return meta or None


def get_forum_document_hashes(forum_id):
    r_crawler = crawlers.r_crawler
    return r_crawler.smembers(f'forumdoc:hash:{forum_id}')


# ---------------------------------------------------------------------------
# Continuous monitoring: RSS/syndication polling
#
# "As soon as it's posted" means collection can't wait for someone to
# manually click Collect - a forum's own native RSS/syndication feed (MyBB:
# misc.php?action=syndication, XenForo: /forums/-/index.rss) already lists
# its newest threads, so polling that feed on a short interval and capturing
# only the genuinely new links is far cheaper than re-crawling whole boards
# looking for what changed. forum_monitor.py (the worker loop) calls
# poll_forum_rss() on a timer for every registered forum that has an rss_url
# configured; Crawler.py routes the fetched feed content to process_rss_feed()
# instead of treating it as a normal forum page (see RSS_POLL_TAG_PREFIX).
# ---------------------------------------------------------------------------

RSS_POLL_TAG_PREFIX = 'rss_poll:'
MAX_NEW_ITEMS_PER_RSS_POLL = 25  # a typical MyBB/XenForo feed only lists ~15-25 items anyway


def poll_forum_rss(forum_id, priority=80):
    """Queue a capture of the forum's configured RSS feed URL. Returns
    (result_dict, http_status). No-op error if no rss_url is configured."""
    forum, status = forum_registry.get_forum(forum_id)
    if status != 200:
        return forum, status
    if not forum.get('enabled'):
        return {'status': 'error', 'reason': 'Forum is disabled'}, 409
    guard = _circuit_guard(forum_id)
    if guard:
        return guard
    rss_url = forum.get('rss_url')
    if not rss_url:
        return {'status': 'error', 'reason': 'No RSS feed configured for this forum'}, 400

    cookiejar_uuid = forum_registry.get_cookiejar(forum_id)
    task_uuid = crawlers.create_task(
        rss_url, depth=0, har=False, screenshot=False, cookiejar=cookiejar_uuid,
        proxy='force_tor', parent='forum_registry', priority=priority, new_task=False,
        tags=[f'{RSS_POLL_TAG_PREFIX}{forum_id}'],
    )
    return {'status': 'ok', 'forum_id': forum_id, 'task_uuid': task_uuid}, 200


def _extract_rss_items(raw_content):
    """
    Best-effort RSS <item> extraction, tolerant of a browser rendering the
    XML response rather than handing back the raw bytes (Lacus/Playwright
    navigates like a real browser - it doesn't expose a raw HTTP body the
    way `requests` would). Tries, in order: (1) Chromium's built-in XML
    viewer wraps the original document verbatim inside a hidden
    `#webkit-xml-viewer-source-xml` node - if present, parse that as real
    XML; (2) parse the raw content directly as XML, in case it came back
    unwrapped; (3) a tolerant regex scan for <item>...<link>/<guid>...
    blocks, which survives HTML-entity-escaped or otherwise mangled markup
    that neither ET.fromstring above would accept.
    """
    if not raw_content:
        return []

    candidates = []
    m = re.search(r'id=["\']webkit-xml-viewer-source-xml["\'][^>]*>(.*?)</div>', raw_content, re.DOTALL)
    if m:
        candidates.append(unescape(m.group(1)))
    candidates.append(raw_content)

    for candidate in candidates:
        try:
            root = ET.fromstring(candidate.strip())
        except ET.ParseError:
            continue
        items = []
        for item_el in root.iter():
            if item_el.tag.split('}')[-1] != 'item':
                continue
            link, guid = None, None
            for child in item_el:
                child_tag = child.tag.split('}')[-1]
                if child_tag == 'link':
                    link = (child.text or '').strip()
                elif child_tag == 'guid':
                    guid = (child.text or '').strip()
            if link:
                items.append({'link': link, 'guid': guid or link})
        if items:
            return items

    # Fallback: regex scan, tolerant of a syntax-highlighted/escaped view.
    text = unescape(raw_content)
    items = []
    for item_match in re.finditer(r'<item\b.*?</item>', text, re.DOTALL | re.IGNORECASE):
        block = item_match.group(0)
        link_m = re.search(r'<link[^>]*>(.*?)</link>', block, re.DOTALL | re.IGNORECASE)
        guid_m = re.search(r'<guid[^>]*>(.*?)</guid>', block, re.DOTALL | re.IGNORECASE)
        link = link_m.group(1).strip() if link_m else None
        guid = (guid_m.group(1).strip() if guid_m else link)
        if link:
            items.append({'link': link, 'guid': guid or link})
    return items


def process_rss_feed(forum_id, entries):
    """
    Called from Crawler.py once a task tagged 'rss_poll:<forum_id>' comes
    back. Diffs the feed's items against this forum's previously-seen GUIDs
    and queues capture_page() only for genuinely new ones - this is the step
    that turns "a new thread exists" into "it's now in our corpus and
    checked against the watchlist" (record_forum_document -> _check_watchlist
    happens automatically once that capture completes). Returns the count of
    new items queued.

    `entries` is the full Lacus capture result, not just entries['html']:
    confirmed live (2026-08-28 poll of xforums.st) that a real-XML response
    is inconsistently rendered by the browser - sometimes as an inline
    pretty-printed <pre> view inside entries['html'] (handled by
    _extract_rss_items' regex fallback), and sometimes Chromium instead
    treats the XML mimetype as a file download, in which case entries['html']
    comes back essentially empty and the actual bytes are only in
    entries['downloaded_file'] instead. Preferring downloaded_file when
    present sidesteps guessing which rendering path a given poll will take.
    """
    raw_content = None
    downloaded = entries.get('downloaded_file')
    if downloaded:
        try:
            raw_content = downloaded.decode('utf-8', errors='replace') if isinstance(downloaded, bytes) else str(downloaded)
        except Exception:
            raw_content = None
    if not raw_content:
        raw_content = entries.get('html') or ''

    items = _extract_rss_items(raw_content)
    if not items:
        forum_registry.record_rss_poll(forum_id, new_items_found=0)
        return 0

    r_crawler = crawlers.r_crawler
    seen_key = f'forumrss:seen:{forum_id}'
    queued = 0
    for entry in items:
        if queued >= MAX_NEW_ITEMS_PER_RSS_POLL:
            break
        guid = entry.get('guid') or entry.get('link')
        if not guid or r_crawler.sismember(seen_key, guid):
            continue
        capture_page(forum_id, entry['link'], priority=88)
        r_crawler.sadd(seen_key, guid)
        queued += 1

    forum_registry.record_rss_poll(forum_id, new_items_found=queued)
    return queued
