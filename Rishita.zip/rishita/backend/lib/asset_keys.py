#!/usr/bin/env python3
# -*-coding:UTF-8 -*

"""
API key storage for Asset Intelligence providers.

Same shape and same storage as ransomware_live.get_api_key()/set_api_key():
one Kvrocks hash on the shared crawler connection, keyed by provider name.
Keys live in Kvrocks rather than in configs/core.cfg so they are never
committed to the repository and can be rotated from the System page without
a restart.
"""

import os
import sys

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import crawlers

r_crawler = crawlers.r_crawler

KEYS_HASH = 'asset:api_keys'


def get_api_key(provider):
    return r_crawler.hget(KEYS_HASH, provider) or ''


def set_api_key(provider, api_key):
    api_key = (api_key or '').strip()
    if api_key:
        r_crawler.hset(KEYS_HASH, provider, api_key)
    else:
        r_crawler.hdel(KEYS_HASH, provider)
    return True


def has_api_key(provider):
    return bool(get_api_key(provider))
