#!/usr/bin/env bash
# One-shot bootstrap step run by supervisord before the app-level programs
# start: waits for Redis (6379/6380/6381) and Kvrocks (6383) to actually be
# accepting connections, then runs AIL_Init.py once (clears queue stats -
# see LAUNCH.sh's launching_scripts, which this replicates for the minimal
# process set this platform actually uses: no need to wait on ARDB/6382,
# nothing here uses it).
set -euo pipefail

AIL_HOME="${AIL_HOME:-$(cd "$(dirname "$0")/.." && pwd)}"
PY="${AIL_HOME}/AILENV/bin/python"

wait_for_port() {
    local port="$1"
    for _ in $(seq 1 60); do
        if (exec 3<>"/dev/tcp/127.0.0.1/${port}") 2>/dev/null; then
            exec 3>&- 3<&-
            return 0
        fi
        sleep 1
    done
    echo "Timed out waiting for port ${port}" >&2
    return 1
}

for port in 6379 6380 6381 6383; do
    wait_for_port "$port"
done

# Meilisearch (7700) must be up for AIL_Init to apply the index
# searchable/filterable/sortable settings (e.g. the intel_docs forum_id filter
# the domain-intel search needs). On a fresh/slow machine it can start later
# than Redis/Kvrocks, so wait for it too - but NEVER let a slow Meilisearch
# abort init (|| true keeps set -e happy); AIL_Init still retries, and the
# collector self-heals the index on first use.
wait_for_port 7700 || echo "Meilisearch (7700) not up yet; continuing - init retries" >&2

cd "${AIL_HOME}/backend"
exec "${PY}" ./AIL_Init.py
