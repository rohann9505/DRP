#!/usr/bin/env python3
# -*-coding:UTF-8 -*
"""
AIL Init
============================

Init DB + Clear Stats

"""

import os
import sys
import time
import logging.config

sys.path.append(os.environ['AIL_BIN'])
##################################
# Import Project packages
##################################
from lib import ail_core
from lib import ail_queues
from lib import ail_logger
from lib import search_engine

logging.config.dictConfig(ail_logger.get_config(name='modules'))
logger = logging.getLogger()


def setup_meilisearch_indexes():
    """Ensure the Meilisearch indexes carry their searchable/filterable/sortable
    settings. Meilisearch auto-creates an index on first document add WITHOUT
    these settings, so on a fresh install the intel_docs index rejects the
    domain-intel `forum_id` filter until configured. This is idempotent and
    re-applied on every boot, so it also repairs an already-misconfigured index.
    The boot wrapper only waits for Redis/Kvrocks, so wait briefly for the
    Meilisearch service here; never fatal - a missing index settings pass just
    means full-text search is degraded until the next boot."""
    if not search_engine.is_meilisearch_enabled():
        return
    engine = search_engine.Engine
    for _ in range(90):
        if engine.is_up():
            break
        time.sleep(1)
    if not engine.is_up():
        logger.warning("Meilisearch enabled but not reachable at init; index settings not applied")
        return
    try:
        engine.setup_indexes_searchable_filterable_sortable()
        logger.warning("Meilisearch indexes configured (searchable/filterable/sortable)")
    except Exception as e:
        logger.warning(f"Meilisearch index setup failed: {e}")


if __name__ == "__main__":
    ail_queues.save_queue_digraph()
    ail_queues.clear_modules_queues_stats()
    setup_meilisearch_indexes()

    # Send module state to logs
    ail_uuid = ail_core.get_ail_uuid()
    logger.warning(f"AIL {ail_uuid} started")
