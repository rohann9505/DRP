{
  "product": {
    "name": "Brand Monitoring / Digital Risk Protection Console",
    "design_personality": [
      "light enterprise SaaS (not dark)",
      "SOC-grade data density without glare",
      "trustworthy + precise",
      "filter-first + investigation-forward",
      "tenant-isolated + admin-governed"
    ],
    "north_star": "Analysts can filter fast, scan dense tables safely for hours, and drill into evidence without losing context. Admins can configure tenants via a guided wizard with strong guardrails."
  },

  "layout_blueprint": {
    "app_shell": {
      "pattern": "Persistent left sidebar + top command bar + content area + optional right detail drawer",
      "regions": {
        "left_sidebar": {
          "width": "w-[264px] (desktop), collapsible to icon rail w-[72px]",
          "content": [
            "Product logo + environment badge (Prod/Staging)",
            "Role badge (Super Admin / Tenant Admin / Analyst / Viewer)",
            "Primary nav groups: Admin Portal / Tenant View",
            "Secondary: Saved Filters, Recent Cases, Help"
          ],
          "interaction": "Sidebar items show active state with left accent bar + subtle background tint; supports keyboard navigation."
        },
        "top_bar": {
          "height": "h-14",
          "content": [
            "Tenant switcher (admin sees All Tenants + search)",
            "Global filter context chip row (applied filters summarized)",
            "Global search (findings/cases/assets)",
            "Notifications bell + user menu"
          ],
          "sticky": true
        },
        "content": {
          "max_width": "fluid; use container only for marketing-like pages (auth)",
          "padding": "px-4 sm:px-6 lg:px-8 py-5",
          "grid": "12-col on lg, 6-col on md, 1-col on mobile"
        },
        "right_detail_drawer": {
          "width": "w-[520px] lg:w-[640px]",
          "use_cases": [
            "Finding detail (evidence, entities, timeline)",
            "Collector error drill-in",
            "Case detail quick view"
          ],
          "behavior": "Opens from right; keeps table state; supports Esc to close; has tabbed sections."
        }
      }
    },

    "filter_first_standard": {
      "rule": "Every listing/searchable screen starts with the same reusable Filter Bar component.",
      "structure": [
        "Row 1: Tenant (if applicable), Date Range, Severity, Status, Source, Platform, Risk Score slider, Search",
        "Row 2: Module-specific filters + Saved Filters + Presets + Apply/Reset + Export"
      ],
      "density": "Compact height; chips summarize applied filters; advanced filters in popover/drawer.",
      "saved_filters": {
        "types": [
          "User Saved Filters",
          "Admin-managed Global Presets (read-only for analysts)"
        ],
        "ui": "Saved Filters dropdown with search + pin favorites; preset chips appear as quick toggles."
      }
    },

    "data_table_standard": {
      "pattern": "Dense table + sticky header + row selection + row actions + right drawer",
      "must_have": [
        "Sorting (multi-column optional)",
        "Pagination",
        "Column visibility",
        "CSV export",
        "Row detail drawer",
        "Bulk actions (assign, change status, add to case, export)"
      ],
      "row_height": "h-11 (dense) with optional h-14 (comfortable) toggle",
      "empty_states": "Explain why empty (filters too strict) + quick reset button"
    },

    "wizard_standard": {
      "pattern": "12-step tenant configuration wizard",
      "layout": "Two-column on desktop: left stepper + right form; single-column on mobile",
      "guardrails": [
        "Autosave per step",
        "Validate before next",
        "Review step with diff summary",
        "Danger zone actions require confirmation dialog"
      ]
    }
  },

  "typography": {
    "font_pairing": {
      "primary_ui": {
        "name": "Manrope",
        "why": "High legibility at small sizes; modern enterprise feel; less generic than Inter.",
        "google_fonts_import": "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap"
      },
      "mono": {
        "name": "IBM Plex Mono",
        "why": "For domains, hashes, IDs, code-like evidence.",
        "google_fonts_import": "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&display=swap"
      }
    },
    "tailwind_usage": {
      "headings": {
        "h1": "text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight",
        "h2": "text-base md:text-lg font-medium text-muted-foreground",
        "section_title": "text-lg font-semibold tracking-tight",
        "table_header": "text-xs font-semibold uppercase tracking-wide"
      },
      "body": {
        "default": "text-sm leading-6",
        "dense": "text-[13px] leading-5",
        "muted": "text-sm text-muted-foreground"
      },
      "mono": "font-mono text-[12.5px]"
    },
    "numbers": "Use tabular numbers for KPIs: add `tabular-nums` on KPI values and table numeric columns."
  },

  "color_system": {
    "notes": "Light theme with reduced glare: use warm-neutral background, crisp white cards, and ocean-teal accent (no purple).",
    "tokens_css": {
      "file": "/app/frontend/src/index.css",
      "instructions": "Replace :root tokens with the following HSL values (keep .dark tokens present but not used by default).",
      "css_variables": {
        "--background": "36 33% 97%",
        "--foreground": "222 47% 11%",
        "--card": "0 0% 100%",
        "--card-foreground": "222 47% 11%",
        "--popover": "0 0% 100%",
        "--popover-foreground": "222 47% 11%",

        "--primary": "196 84% 33%",
        "--primary-foreground": "0 0% 100%",

        "--secondary": "210 40% 96%",
        "--secondary-foreground": "222 47% 11%",

        "--muted": "210 40% 96%",
        "--muted-foreground": "215 16% 40%",

        "--accent": "174 45% 92%",
        "--accent-foreground": "196 84% 20%",

        "--destructive": "0 72% 51%",
        "--destructive-foreground": "0 0% 100%",

        "--border": "214 24% 88%",
        "--input": "214 24% 88%",
        "--ring": "196 84% 33%",

        "--chart-1": "196 84% 33%",
        "--chart-2": "173 58% 39%",
        "--chart-3": "27 87% 55%",
        "--chart-4": "43 74% 56%",
        "--chart-5": "222 47% 35%",

        "--radius": "0.75rem"
      },
      "extended_semantic_tokens_to_add": {
        "--surface": "0 0% 100%",
        "--surface-2": "210 40% 98%",
        "--surface-3": "210 40% 96%",
        "--shadow-color": "222 47% 11%",

        "--info": "199 89% 48%",
        "--info-foreground": "0 0% 100%",
        "--success": "158 64% 36%",
        "--success-foreground": "0 0% 100%",
        "--warning": "38 92% 50%",
        "--warning-foreground": "222 47% 11%",

        "--severity-critical": "0 72% 51%",
        "--severity-high": "18 88% 52%",
        "--severity-medium": "38 92% 50%",
        "--severity-low": "158 64% 36%",

        "--status-open": "199 89% 48%",
        "--status-triage": "38 92% 50%",
        "--status-resolved": "158 64% 36%",
        "--status-ignored": "215 16% 46%",

        "--health-healthy": "158 64% 36%",
        "--health-degraded": "38 92% 50%",
        "--health-failed": "0 72% 51%"
      }
    },

    "usage_rules": {
      "backgrounds": {
        "app_background": "bg-background",
        "cards": "bg-card",
        "subtle_sections": "bg-[hsl(var(--surface-2))]"
      },
      "borders": "Use 1px borders for tables and filter bars: `border border-border`.",
      "focus": "Use ring color `ring-[hsl(var(--ring))]` with `focus-visible:ring-2 focus-visible:ring-offset-2`."
    },

    "gradients_and_texture": {
      "allowed": {
        "where": [
          "Auth page header band",
          "Very small decorative top strip in dashboards",
          "Large hero-like empty states (rare)"
        ],
        "max_viewport_coverage": "<= 20%",
        "examples": [
          "bg-gradient-to-r from-[hsl(174_45%_92%)] via-[hsl(210_40%_96%)] to-[hsl(36_33%_97%)]",
          "bg-gradient-to-b from-[hsl(210_40%_98%)] to-[hsl(36_33%_97%)]"
        ]
      },
      "noise_overlay": {
        "pattern": "Add subtle noise via CSS mask on large backgrounds only.",
        "css_snippet": ".noise { background-image: url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"120\" height=\"120\"><filter id=\"n\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.8\" numOctaves=\"3\" stitchTiles=\"stitch\"/></filter><rect width=\"120\" height=\"120\" filter=\"url(%23n)\" opacity=\"0.08\"/></svg>'); background-repeat: repeat; mix-blend-mode: multiply; pointer-events:none; }"
      }
    }
  },

  "spacing_and_density": {
    "principle": "2–3x more whitespace around sections; inside tables keep density high but consistent.",
    "tokens": {
      "page_padding": "px-4 sm:px-6 lg:px-8 py-5",
      "card_padding": "p-4 sm:p-5",
      "filter_bar_padding": "p-3",
      "table_cell_padding": "py-2.5 px-3",
      "section_gap": "space-y-4"
    }
  },

  "shadows_radius_borders": {
    "radius": {
      "default": "rounded-[var(--radius)]",
      "chips_pills": "rounded-full",
      "drawer": "rounded-l-[var(--radius)]"
    },
    "shadows": {
      "card": "shadow-[0_1px_0_rgba(15,23,42,0.04),0_8px_24px_rgba(15,23,42,0.06)]",
      "popover": "shadow-[0_10px_30px_rgba(15,23,42,0.10)]",
      "focus": "No glow; rely on ring + subtle outline"
    },
    "borders": {
      "default": "border border-border",
      "active": "border-[hsl(var(--ring))]"
    }
  },

  "components": {
    "component_path": {
      "shadcn_primary": "/app/frontend/src/components/ui/",
      "use_these": {
        "app_shell": [
          "navigation-menu.jsx",
          "breadcrumb.jsx",
          "separator.jsx",
          "scroll-area.jsx",
          "resizable.jsx",
          "sheet.jsx (mobile sidebar)",
          "dropdown-menu.jsx (user menu)",
          "command.jsx (global search / command palette)"
        ],
        "filter_bar": [
          "select.jsx",
          "calendar.jsx (date range)",
          "popover.jsx (advanced filters)",
          "slider.jsx (risk score)",
          "input.jsx (search)",
          "button.jsx",
          "badge.jsx (applied filter chips)",
          "tabs.jsx (preset groups)",
          "tooltip.jsx"
        ],
        "tables": [
          "table.jsx",
          "pagination.jsx",
          "checkbox.jsx (row selection)",
          "dropdown-menu.jsx (row actions)",
          "hover-card.jsx (quick preview)",
          "skeleton.jsx (loading)",
          "drawer.jsx (right detail drawer)"
        ],
        "wizard": [
          "tabs.jsx (step content sections)",
          "progress.jsx (completion)",
          "collapsible.jsx (advanced sections)",
          "form.jsx + input.jsx + select.jsx + switch.jsx",
          "alert-dialog.jsx (danger confirmations)"
        ],
        "status_and_feedback": [
          "badge.jsx (severity/status pills)",
          "alert.jsx (inline warnings)",
          "sonner.jsx (toasts)",
          "dialog.jsx (create/edit)",
          "tooltip.jsx"
        ]
      }
    },

    "global_filter_bar_spec": {
      "visual": {
        "container": "bg-card border border-border rounded-[var(--radius)] shadow-[0_1px_0_rgba(15,23,42,0.04)]",
        "layout": "grid grid-cols-1 gap-2 md:grid-cols-12 md:gap-2",
        "field_size": "h-9 text-[13px]",
        "chip_row": "flex flex-wrap gap-1.5 pt-2"
      },
      "fields": {
        "required": [
          "tenant",
          "dateRange",
          "severity",
          "status",
          "source",
          "platform",
          "riskScoreSlider",
          "search",
          "apply",
          "reset"
        ],
        "module_specific": "Append after platform; keep consistent ordering across modules.",
        "saved_filters": "Dropdown with: My Saved, Team, Global Presets; include pin + rename (if allowed)."
      },
      "data_testids": {
        "container": "global-filter-bar",
        "tenant": "global-filter-tenant-select",
        "date": "global-filter-date-range",
        "severity": "global-filter-severity-select",
        "status": "global-filter-status-select",
        "source": "global-filter-source-select",
        "platform": "global-filter-platform-select",
        "risk": "global-filter-risk-score-slider",
        "search": "global-filter-search-input",
        "apply": "global-filter-apply-button",
        "reset": "global-filter-reset-button",
        "saved": "global-filter-saved-filters-menu",
        "presets": "global-filter-presets-tabs",
        "export": "global-filter-export-csv-button"
      }
    },

    "severity_status_pills": {
      "component": "badge.jsx",
      "style": {
        "base": "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[12px] font-medium",
        "critical": "bg-[hsl(var(--severity-critical)/0.12)] text-[hsl(var(--severity-critical))] border border-[hsl(var(--severity-critical)/0.25)]",
        "high": "bg-[hsl(var(--severity-high)/0.12)] text-[hsl(var(--severity-high))] border border-[hsl(var(--severity-high)/0.25)]",
        "medium": "bg-[hsl(var(--severity-medium)/0.14)] text-[hsl(var(--foreground))] border border-[hsl(var(--severity-medium)/0.30)]",
        "low": "bg-[hsl(var(--severity-low)/0.12)] text-[hsl(var(--severity-low))] border border-[hsl(var(--severity-low)/0.25)]"
      },
      "iconography": "Use lucide-react icons (AlertTriangle, Flame, ShieldAlert, ShieldCheck) at 14px inside pill when space allows."
    },

    "monitoring_health_board": {
      "pattern": "Table-first status board with sticky header + status pills + drill-in drawer",
      "row": [
        "Tenant",
        "Collector",
        "Last heartbeat",
        "Lag",
        "Status (healthy/degraded/failed)",
        "Errors (count)",
        "Actions"
      ],
      "status_pills": {
        "healthy": "bg-[hsl(var(--health-healthy)/0.12)] text-[hsl(var(--health-healthy))]",
        "degraded": "bg-[hsl(var(--health-degraded)/0.16)] text-[hsl(var(--foreground))]",
        "failed": "bg-[hsl(var(--health-failed)/0.12)] text-[hsl(var(--health-failed))]"
      },
      "drill_in_drawer_tabs": [
        "Overview",
        "Recent Errors",
        "Logs",
        "Config",
        "Retry/Actions"
      ],
      "data_testids": {
        "table": "monitoring-health-table",
        "row": "monitoring-health-row",
        "status": "monitoring-health-status-pill",
        "open": "monitoring-health-open-drawer-button"
      }
    },

    "finding_detail_drawer": {
      "component": "drawer.jsx",
      "layout": {
        "header": "Title + severity pill + risk score + status dropdown + primary actions (Create Case, Export Evidence)",
        "tabs": [
          "Evidence",
          "Entities",
          "Timeline",
          "Notes",
          "Actions"
        ],
        "evidence_blocks": "Use Card sections with mono fields; highlight matched strings with subtle background."
      },
      "data_testids": {
        "drawer": "finding-detail-drawer",
        "close": "finding-detail-close-button",
        "create_case": "finding-detail-create-case-button",
        "status": "finding-detail-status-select",
        "tabs": "finding-detail-tabs"
      }
    },

    "kpi_cards_and_charts": {
      "kpi_card": {
        "component": "card.jsx",
        "style": "bg-card border border-border rounded-[var(--radius)] p-4 shadow-[0_1px_0_rgba(15,23,42,0.04)]",
        "value": "text-2xl font-semibold tabular-nums",
        "label": "text-xs uppercase tracking-wide text-muted-foreground",
        "sparkline": "Optional tiny chart area; keep subtle."
      },
      "charts": {
        "library": "recharts",
        "why": "Fast to implement for KPI trends, severity distribution, risk score histograms.",
        "install": "npm i recharts",
        "style_rules": [
          "Use muted gridlines: stroke='hsl(var(--border))'",
          "Use primary for main series; use chart-2..5 for secondary",
          "Tooltips in Popover-like card with border"
        ],
        "empty_state": "Show skeleton + 'No data for current filters' with Reset Filters button."
      }
    },

    "cases": {
      "pattern": "Case list table + case detail drawer; allow linking findings",
      "case_status": [
        "Open",
        "In Progress",
        "Waiting",
        "Closed"
      ],
      "micro_interaction": "Drag findings into a case (optional later); for now provide bulk 'Add to Case' action."
    },

    "auth": {
      "look": "Clean, minimal, slightly warm background with small gradient band (<=20% viewport) + card form.",
      "components": [
        "card.jsx",
        "input.jsx",
        "button.jsx",
        "label.jsx"
      ],
      "data_testids": {
        "email": "login-email-input",
        "password": "login-password-input",
        "submit": "login-submit-button"
      }
    }
  },

  "motion_microinteractions": {
    "principles": [
      "Motion should clarify state changes (apply filters, open drawer, row hover), not decorate.",
      "Respect prefers-reduced-motion.",
      "No universal transition: only transition color/border/shadow/opacity."
    ],
    "recommended_library": {
      "name": "framer-motion",
      "install": "npm i framer-motion",
      "use_cases": [
        "Drawer entrance/exit",
        "Filter chip add/remove",
        "Table row hover highlight",
        "Wizard step transitions"
      ]
    },
    "tailwind_patterns": {
      "buttons": "transition-colors duration-150",
      "inputs": "transition-colors duration-150",
      "cards": "hover:shadow-[0_1px_0_rgba(15,23,42,0.04),0_12px_30px_rgba(15,23,42,0.08)] transition-shadow duration-200",
      "table_rows": "hover:bg-[hsl(var(--accent)/0.35)] transition-colors duration-150"
    }
  },

  "accessibility": {
    "contrast": "Ensure pills and text meet WCAG AA; avoid ultra-white backgrounds by using warm background token.",
    "keyboard": [
      "Filter bar: Tab order left-to-right; Apply/Reset reachable",
      "Tables: row selection via checkbox; Enter opens drawer",
      "Drawer: focus trap; Esc closes; return focus to triggering row"
    ],
    "aria": [
      "Use aria-labels for icon-only buttons",
      "Use role='status' for live collector status updates"
    ]
  },

  "images": {
    "image_urls": [
      {
        "category": "auth_background",
        "description": "Subtle abstract texture (very light) used behind login card; keep low contrast.",
        "urls": [
          "https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&w=1600&q=60",
          "https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=1600&q=60"
        ]
      },
      {
        "category": "empty_states",
        "description": "Neutral abstract shapes for empty states (optional).",
        "urls": [
          "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1600&q=60"
        ]
      }
    ]
  },

  "page_level_notes": {
    "admin_portal": {
      "dashboard": "Show platform health + tenant onboarding progress + recent audit events. Use 2-column grid with Monitoring Health preview table.",
      "tenants": "Tenants list table with status + last scan + collectors health summary; Create Tenant opens wizard.",
      "monitoring_configuration": "Use tabs per module; each module has toggles + schedule + thresholds; show 'effective policy' summary card.",
      "intelligence_sources": "Table of providers with credentials status + rate limits; drill-in drawer for config.",
      "detection_configuration": "Rules table with severity mapping + similarity thresholds; include allow/ignore lists with bulk import.",
      "scheduler": "Calendar-like schedule list (not full calendar UI unless needed); show next run times.",
      "credentials_secrets": "Masked secrets; reveal requires confirmation; audit every reveal.",
      "users_rbac": "Role matrix table; use badges for roles; include tenant scoping.",
      "audit_logs": "Immutable table; advanced filters; export.",
      "monitoring_health": "Primary SOC-style status board; drill-in errors in drawer."
    },
    "tenant_view": {
      "dashboard": "KPI cards + severity trend chart + top sources chart; all respect global filters.",
      "all_findings": "Central investigation table; row opens drawer; bulk actions; saved filters heavily used.",
      "module_pages": "Reuse same table + module-specific columns and filters; keep consistent.",
      "cases": "Case queue + case detail; link findings; export report.",
      "reports": "Report builder with presets; export PDF/CSV; show filter snapshot used."
    }
  },

  "data_testid_convention": {
    "rule": "All interactive and key informational elements must include data-testid in kebab-case describing role.",
    "examples": [
      "tenant-switcher-button",
      "sidebar-nav-tenants-link",
      "findings-table",
      "findings-row-open-drawer-button",
      "csv-export-button",
      "wizard-next-step-button",
      "wizard-step-3-keywords-input",
      "monitoring-health-status-pill"
    ]
  },

  "instructions_to_main_agent": [
    "Update /app/frontend/src/App.css to remove the default CRA dark centered header styles; do not center the app container.",
    "Update /app/frontend/src/index.css :root tokens to the provided light enterprise palette; add extended semantic tokens.",
    "Implement an AppShell layout with persistent sidebar + sticky top bar + content + right Drawer.",
    "Create a reusable GlobalFilterBar component used on every listing page; include Saved Filters + Presets.",
    "Standardize tables: sticky header, dense rows, selection, pagination, CSV export, and right-side detail drawer.",
    "Use Badge-based severity/status pills with the provided semantic colors.",
    "Use recharts for dashboards; ensure charts respect filters and have empty states.",
    "Use framer-motion for subtle transitions (drawer, chips, wizard steps) and respect prefers-reduced-motion.",
    "Ensure every interactive element and key info element has a stable data-testid attribute."
  ],

  "General UI UX Design Guidelines": [
    "- You must **not** apply universal transition. Eg: `transition: all`. This results in breaking transforms. Always add transitions for specific interactive elements like button, input excluding transforms",
    "- You must **not** center align the app container, ie do not add `.App { text-align: center; }` in the css file. This disrupts the human natural reading flow of text",
    "- NEVER: use AI assistant Emoji characters like`🤖🧠💭💡🔮🎯📚🎭🎬🎪🎉🎊🎁🎀🎂🍰🎈🎨🎰💰💵💳🏦💎🪙💸🤑📊📈📉💹🔢🏆🥇 etc for icons. Always use **FontAwesome cdn** or **lucid-react** library already installed in the package.json",
    "",
    " **GRADIENT RESTRICTION RULE**",
    "NEVER use dark/saturated gradient combos (e.g., purple/pink) on any UI element.  Prohibited gradients: blue-500 to purple 600, purple 500 to pink-500, green-500 to blue-500, red to pink etc",
    "NEVER use dark gradients for logo, testimonial, footer etc",
    "NEVER let gradients cover more than 20% of the viewport.",
    "NEVER apply gradients to text-heavy content or reading areas.",
    "NEVER use gradients on small UI elements (<100px width).",
    "NEVER stack multiple gradient layers in the same viewport.",
    "",
    "**ENFORCEMENT RULE:**",
    "    • Id gradient area exceeds 20% of viewport OR affects readability, **THEN** use solid colors",
    "",
    "**How and where to use:**",
    "   • Section backgrounds (not content backgrounds)",
    "   • Hero section header content. Eg: dark to light to dark color",
    "   • Decorative overlays and accent elements only",
    "   • Hero section with 2-3 mild color",
    "   • Gradients creation can be done for any angle say horizontal, vertical or diagonal",
    "",
    "- For AI chat, voice application, **do not use purple color. Use color like light green, ocean blue, peach orange etc",
    "",
    "</Font Guidelines>",
    "",
    "- Every interaction needs micro-animations - hover states, transitions, parallax effects, and entrance animations. Static = dead.",
    "",
    "- Use 2-3x more spacing than feels comfortable. Cramped designs look cheap.",
    "",
    "- Subtle grain textures, noise overlays, custom cursors, selection states, and loading animations: separates good from extraordinary.",
    "",
    "- Before generating UI, infer the visual style from the problem statement (palette, contrast, mood, motion) and immediately instantiate it by setting global design tokens (primary, secondary/accent, background, foreground, ring, state colors), rather than relying on any library defaults. Don't make the background dark as a default step, always understand problem first and define colors accordingly",
    "    Eg: - if it implies playful/energetic, choose a colorful scheme",
    "           - if it implies monochrome/minimal, choose a black–white/neutral scheme",
    "",
    "**Component Reuse:**",
    "\t- Prioritize using pre-existing components from src/components/ui when applicable",
    "\t- Create new components that match the style and conventions of existing components when needed",
    "\t- Examine existing components to understand the project's component patterns before creating new ones",
    "",
    "**IMPORTANT**: Do not use HTML based component like dropdown, calendar, toast etc. You **MUST** always use `/app/frontend/src/components/ui/ ` only as a primary components as these are modern and stylish component",
    "",
    "**Best Practices:**",
    "\t- Use Shadcn/UI as the primary component library for consistency and accessibility",
    "\t- Import path: ./components/[component-name]",
    "",
    "**Export Conventions:**",
    "\t- Components MUST use named exports (export const ComponentName = ...)",
    "\t- Pages MUST use default exports (export default function PageName() {...})",
    "",
    "**Toasts:**",
    "  - Use `sonner` for toasts\"",
    "  - Sonner component are located in `/app/src/components/ui/sonner.tsx`",
    "",
    "Use 2–4 color gradients, subtle textures/noise overlays, or CSS-based noise to avoid flat visuals."
  ]
}
