# plan.md (Updated)

## 1. Objectives
- Maintain a production-style, **Admin-configured**, **tenant-isolated**, **filter-first** Brand Monitoring / Digital Risk Protection Platform.
- Continue using **real, free data sources** in v1/v2 where possible (no mocked monitoring results).
- Preserve the core end-to-end workflow:
  **Admin config → scheduler/run now → collectors → normalization/correlation → scoring → findings/cases → dashboards + monitoring health → exports/reports**.
- Stage 2 (this update): add **identity-driven intelligence** and **confidence-based verification** to reduce noise and make results more actionable:
  1) **Advanced Typosquat Engine** with a multi-stage validation pipeline.
  2) **Brand Identity Intelligence Profile** as the trusted baseline for all detectors.
  3) **Social verification** via an **Impersonation Confidence Score + classification** (kept alongside severity).

## 2. Implementation Steps

### Phase 1 — Core Workflow POC (Completed)
**Goal:** generate and store real findings from free sources.
- Implemented `test_core.py` and validated collectors:
  - crt.sh (CT)
  - RDAP
  - DNS snapshots
  - Typosquat generation + resolution
  - Search/dorking
- Added retry/backoff and strict post-filtering for relevance.

**Phase 1 success criteria (met):** Collectors return non-empty real results, degrade gracefully on partial failures.

---

### Phase 2 — V1 App Development (Completed)
#### 2.1 Backend foundation (FastAPI + Mongo)
- `/api/*` routes, Mongo persistence.
- Core objects implemented:
  - Users + RBAC + tenant scoping
  - Tenants (domains, brand aliases, products, monitoring config, risk policy)
  - Findings (normalized schema, evidence, entities, risk_score, severity, status)
  - Cases
  - Saved Filters + Presets
  - Collector health + audit logs

#### 2.2 Monitoring runtime (Completed)
- Scheduler + “Run now” endpoint.
- Real collectors implemented in `collectors.py`:
  - Certificate Transparency (crt.sh)
  - RDAP + DNS enrichment
  - Typosquat generator (bounded, strict relevance)
  - Search/dorking-based social discovery
  - Google Play scraper app discovery
  - Change Watch (content/DNS/cert drift)
  - Playwright screenshot capture

#### 2.3 Frontend V1 (Completed)
- Admin portal:
  - Tenants + Tenant Wizard
  - Monitoring config, intelligence sources, detection config
  - Scheduler, users/RBAC, notifications, audit logs, settings
  - Monitoring health
- Tenant workspace:
  - Dashboard + modules (All Findings, Social, Fake Websites, Domain Intel, Mobile Apps, Executive, Telegram, Meta Ads)
  - Cases
  - Reports (CSV export + PDF report endpoint)
- Global filter system: consistent filtering, saved filters, presets.

#### 2.4 Authentication & RBAC (Completed)
- Email/password login, JWT.
- Roles: Super Admin, Tenant Admin, Analyst, Viewer.
- Strict server-side tenant isolation.

**Phase 2 success criteria (met):** Admin can create/configure tenants, run monitoring, triage findings, create cases, monitor health; filtering works across modules.

---

### Phase 3 — Testing, hardening, and UX completion (Ongoing / Iterative)
- End-to-end testing already performed across multiple iterations.
- Continue to:
  - Validate tenant isolation matrix and role permissions.
  - Validate filter-first behavior across all modules.
  - Track remaining minor UX/test automation selector issues.

---

## Phase 4 — Stage 2 Intelligence Enhancements (Status: COMPLETED — backend 13/13, frontend 23/25 verified; only 2 non-functional Playwright pointer-interception issues)
**Release approach:** Build all three enhancements together as one cohesive release.

**Decisions locked:**
- Scoring/confidence is **heuristic-only** (no LLM).
- **Skip logo similarity** for now.
- Social signals not reliably available from free sources (followers/account age/follower patterns) will be shown as **“Unknown / not available”**.
- Impersonation confidence **classification is shown alongside existing severity**, not replacing it.

### 4.1 Brand Identity Intelligence Profile (Trusted baseline for all detectors)
**Goal:** move from “brand → aliases → search → finding” to “brand → identity graph → discovery → correlation → confidence”.

1) Data model changes (Tenant)
- Extend tenant schema with `identity` object:
  - Brand
    - `legal_name`
    - `trading_names[]`
    - `aliases[]` (kept compatible with existing `brand_names`)
    - `product_names[]` (compatible with existing `products`)
    - `keywords[]`
    - `logo_variants[]` (reserved; not used in scoring yet)
  - Domains
    - `official_domains[]` (compatible with existing `all_domains`)
    - `redirect_domains[]`
    - `marketing_domains[]`
    - `regional_domains[]`
  - Social identities
    - `social_handles{ platform: { handle, display_name, profile_url } }`
  - Executives
    - `executives[]`
  - Mobile apps
    - `official_apps{ google_play_package_ids[], apple_app_ids[] }`
  - Email
    - `email_domains[]`
  - Known infrastructure
    - `known_nameservers[]`, `known_ips[]` (baseline; optional)

2) Backend API updates
- Update tenant create/update flows to accept/store `identity`.
- Add migrations/backfill behavior:
  - If `identity` missing, synthesize from existing `brand_names`, `products`, and `all_domains`.

3) Enrichment: extend domain analysis
- Enhance `collectors.analyze_domain()` to optionally extract:
  - emails/email domains from homepage text + mailto links
  - obvious social links from homepage anchor tags (e.g., linkedin.com/company/…, instagram.com/…, x.com/…)
- Output: `brand_names`, `products`, plus `suggested_social_handles`, `suggested_email_domains`.

4) Admin UX updates (Tenant Wizard)
- Update Wizard steps (Brand/Domains/Social/Executives/Apps/Email) to edit identity profile fields.
- Auto-detect button fills identity suggestions (brand/products already exist; add handles/emails suggestions).

**Acceptance criteria**
- Tenant has a clear, viewable identity baseline used by detectors.
- Existing tenants continue to work with backward compatibility.

---

### 4.2 Advanced Typosquat Engine (Generator + Validation Pipeline)
**Goal:** expand typosquat coverage while substantially reducing noise via a validation pipeline.

1) Expanded generation (Typo Intelligence)
Implement stages/types:
- Addition
- Deletion
- Substitution
- Transposition
- Repetition
- Hyphenation
- Prefix/suffix
- TLD variation
- Number substitution
- Keyboard adjacency
- Unicode homoglyph (heuristic mapping)
- IDN / punycode handling
- Brand + function combinations (e.g., `brand-support`, `brand-login`, `secure-brand`)

2) Validation pipeline (only persist high-signal outputs)
Pipeline:
Generated
  ↓
DNS exists?
  ↓
HTTP exists?
  ↓
Brand similarity?
  ↓
Content similarity?
  ↓
Infrastructure suspicious?
  ↓
Risk score + severity

Implementation detail:
- DNS: A/AAAA/NS/MX presence.
- HTTP exists: HEAD/GET with short timeout; store status code, redirect chain (if any).
- Brand similarity: label similarity vs official label(s) and baseline brand aliases.
- Content similarity: compare page title + lightweight text fingerprint to official baseline (no LLM).
- Infrastructure suspicion:
  - MX present (email phishing potential)
  - very young domain age (RDAP)
  - unknown nameservers compared to tenant known infra
  - TLS certificate fingerprint novelty (optional signal)

3) Findings evidence format
- Store per-stage signals in `evidence.typo_pipeline`:
  - `generated_kind`, `dns_ok`, `http_ok`, `brand_similarity`, `content_similarity`, `infra_flags[]`
- Keep `entities` enriched fields consistent for filtering (registrar, age, nameservers, ips, etc.).

4) Noise control
- Do not flag all generated domains:
  - Persist only those that pass minimum gates (e.g., DNS ok + HTTP ok OR DNS ok + MX ok), and exceed a similarity threshold.
  - Cap enrichment concurrency and total per run.

**Acceptance criteria**
- Typosquat findings decrease in irrelevant noise while capturing more realistic impersonation patterns.
- Evidence clearly shows which pipeline stages triggered the score.

---

### 4.3 Social Media: Discovery → Verification (Impersonation Confidence)
**Goal:** make social results actionable by assigning confidence + classification.

1) Confidence scoring (0–100), heuristic-only
Inputs limited to what we can reliably measure:
- Username similarity vs official handle (if present in identity profile)
- Display name similarity vs brand/aliases
- Official wording presence (e.g., “official”, “verified”) as a *discount* signal
- Suspicious wording presence (support/login/verify/giveaway/wallet/etc.) as a *risk* signal
- External domain present and whether it matches any official domains
- Official link mismatch signal (when a social URL contains an external domain or mentions a non-official domain)

Unavailable signals shown as:
- `account_age`: Unknown / not available
- `followers`: Unknown / not available
- `follower_pattern`: Unknown / not available

2) Classification
Based on confidence score thresholds:
- LEGITIMATE
- LIKELY LEGITIMATE
- SUSPICIOUS
- LIKELY IMPERSONATION
- HIGH-CONFIDENCE IMPERSONATION

3) Data model
- Add to finding entities/evidence:
  - `entities.impersonation_confidence` (0–100)
  - `entities.impersonation_classification`
  - `evidence.verification_signals{...}` breakdown

4) UI updates
- Social Media table:
  - Add a **Confidence** column (score + classification pill)
  - Keep existing severity/risk score columns
- Finding drawer:
  - Add a “Verification” section/tab for social findings showing signal breakdown + unknown fields.

**Acceptance criteria**
- Social findings show both severity and impersonation confidence classification.
- Analysts can quickly prioritize investigations based on confidence.

---

### 4.4 Testing, verification, and rollout
- Add/update backend tests for:
  - identity profile persistence + backward compatibility
  - typosquat pipeline gates
  - social confidence computation and classification
- Run testing agent E2E scenarios:
  - Create/edit tenant identity profile
  - Run monitoring
  - Verify social confidence fields appear and filter/search unaffected
  - Verify typosquat pipeline reduces noise and stores pipeline evidence
- After agent verification, request **user confirmation** on:
  - Noise reduction quality
  - Analyst usefulness of confidence classifications
  - Wizard usability for identity profile

## 3. Next Actions (Updated)
1) Implement tenant `identity` schema changes + backfill behavior.
2) Extend `/tools/analyze-domain` output to include suggested social handles + email domains.
3) Upgrade typosquat generator + implement validation pipeline stages.
4) Add social impersonation confidence scoring + classification.
5) Update frontend: Tenant Wizard identity fields, Social page confidence column, Finding drawer verification view.
6) Run testing agent and address any regressions.

## 4. Success Criteria (Updated)
- Platform remains tenant-isolated and filter-first across all modules.
- **Identity profile** becomes the baseline for correlation/scoring (no breaking changes to existing tenants).
- **Typosquat engine** generates broader candidates but persists only high-signal results via the pipeline, reducing noise.
- **Social module** displays a deterministic **Impersonation Confidence Score + classification**, with unavailable metrics explicitly shown as unknown.
- End-to-end tests pass and users confirm usability improvements.